# Appli Frelons (Android)

Application téléphone du système de pistage du frelon asiatique : React Native + Expo SDK 58, TypeScript.
Toutes les fonctions du cahier des charges sont présentes ; ce qui dépend du matériel est écrit d'après les firmwares et testé en simulation.

## Écrans

| Onglets | |
|---|---|
| **Direct** | boussole, direction du tag, niveaux des 5 voies en %, nid estimé ; accès Mode conduite et Direction à l'œil |
| **Carte** | se déplace au doigt, zoom à deux doigts, appui long pour ajouter un nid, un rucher ou un piège ; densité des nids toutes saisons, pièges ; fond IGN (plan ou photo, hors ligne), trajet, relèvements retenus / écartés, directions à l'œil, appâts et anneaux, nid et précision, nids du carnet, ruchers ; envoyer au portatif, ajouter au carnet |
| **Portatif** | niveau en % et distance approximative du tag (≈ 120 m, avec fourchette), tendance, courbe 2 min, bips qui suivent le signal, tours de goniométrie, nid, direction vers le nid, réglages ; portatif simulé |
| **Chrono** | appât, départs / retours automatiques (toit) ou à la main, caps, distance et direction du nid, appât suivant |
| **Réglages** | outils, appareils, sortie simulée, réglages du toit, gains, maintenance |

| Outils (depuis Réglages) | |
|---|---|
| Étalonner la distance | tag posé à une distance connue : signal mesuré 10 s (médiane) → signal à 1 m ; seconde mesure facultative → affaiblissement du milieu |
| Paramètres | profil (nom, opérateur et n° Certibiocide, structure), seuils d'alerte, recharge des tags, rayons autour des ruchers, densité, pièges (délai, appâts), météo, sortie (annonce vocale, reprise, GPS écran verrouillé), partage, dépôt GitHub des mises à jour, noms Bluetooth ; valeur par défaut rappelée, retour au défaut par rubrique |
| Calendrier de saison | étapes de l'année (pièges, nids primaires, tags, destruction, vérification, bilan GDSA, entretien) ; frise, cases « fait », dates modifiables par étape, décalage selon le secteur ; rappel à l'ouverture quand une étape commence |
| Avant de partir | vérifications automatiques + liste à cocher modifiable |
| Carnet des nids / fiche | états, description, photos, intervention, partage, fiche PDF, export GPX / KML |
| Mes tags / Poser un tag | état de chaque tag, pile, signal, allers-retours, tags à recharger (pile faible, a servi, recharge de plus de 7 jours ; rappel au démarrage et dans « Avant de partir ») ; pose en 4 étapes (le chrono démarre) |
| Direction à l'œil | boussole du téléphone, la direction rejoint le calcul du nid |
| Mode conduite | très grand affichage, annonce vocale toutes les 10 s, bips |
| Sons et alertes | nouveau tag, tag perdu, pile faible, retour à l'appât, nid localisé, approche d'un nid (écran rouge), batteries |
| Cartes hors ligne | téléchargement de zones IGN (plan, photo) |
| Ruchers / Station fixe | nids à moins de 1 km de chaque rucher ; toit sur trépied : rose des directions de départ |
| Météo d'activité | meilleur créneau, heure par heure, jours suivants (Open-Meteo) |
| Bilan de saison | choix de l'année, chiffres, nids par semaine, statistiques par rucher (1 km / 3 km, détruits, pièges), comparaison des saisons, efficacité, tags ; export pour le GDSA (rapport PDF d'une page + classeur Excel : résumé, nids, ruchers, pièges, relevés) ; liste des nids en CSV |
| Pièges de printemps | pièges à fondatrices : relevés, captures par semaine, pièges à relever ; partagés avec l'équipe |
| Mises à jour | appli (dernière version publiée sur GitHub, téléchargement) ; appareils : import des paquets `…_mise_a_jour_bluetooth.zip`, envoi par Bluetooth (portatif, toit, 4 voies, nacelle, station sol) |
| Étalonnage du toit | 4 étapes, résultat commenté, aide |
| Sauvegarde du carnet | un fichier .zip (nids et photos, tags, ruchers, appâts, réglages) ; restauration |
| Connexion | écran au premier lancement (facultatif) : compte e-mail + mot de passe (Supabase), création de compte, mot de passe oublié, « Continuer sans compte » |
| Partage entre téléphones | compte, équipe (créer, rejoindre avec le code d'invitation, membres, responsables, changer le code, quitter), synchronisation des nids, ruchers et pièges (la modification la plus récente gagne) ; script SQL dans l'écran |
| Banc d'essai | première mise sous tension de chaque carte (chargeur, tags, portatif, écran et dos, toit, nacelle) : étapes à cocher, mesures avec plage attendue, vérifications automatiques par l'appli, notes, export |
| Journal de mise au point | lignes Bluetooth reçues / envoyées, connexions, erreurs, lignes non comprises, étapes des mises à jour ; envoi d'une commande à la main ; export texte |

## Vérifié

- Partage : essayé contre un vrai PostgREST + PostgreSQL (le moteur de Supabase) avec deux téléphones simulés : envoi, réception, conflit, suppression, cloisonnement des équipes ; comptes et droits (intrus refusé, code faux refusé, seul le responsable change le code ou retire un membre).
- `npm run test:calculs` (lancé aussi par la compilation GitHub) :
  - nid du tag 7 retrouvé à 4 m du vrai sur la sortie simulée ;
  - chrono identique au rejeu de l'écran voiture (6 allers-retours, 364 m ± 76, cap 115°) ;
  - encodage CBOR et protocole de mise à jour SMP contre un appareil simulé (image de 50 ko reçue intacte, paquets ≤ MTU, image « à essayer » puis redémarrage) ;
  - lecture des paquets, météo, géométrie des tuiles IGN.
- Les calculs de nid sont identiques au C de l'écran voiture (40 cas, écart < 1 cm).
- `npx tsc --noEmit` et `npx expo lint` sans erreur ; bundle Android et `expo prebuild` OK ; chaque écran ouvert sans erreur pendant la sortie simulée.

## Versions des firmwares

À chaque connexion, le toit (`V,…`) et le portatif (`{"type":"ver",…}`) annoncent leur firmware et leur protocole. L'appli compare avec `src/calc/versions.ts` (protocoles compris, firmwares livrés avec cette version) : version affichée sous chaque appareil (Réglages → Appareils) et dans Mises à jour, bandeau si le firmware ou l'appli doit être mis à jour, ligne dans le journal. Un firmware muet après 8 s date d'avant la 1.1.0.

## Raccourcis Android

Appui long sur l'icône de l'appli : **Poser un tag**, **Nid trouvé ici** (attend une bonne position puis crée la fiche), **Pièges**, **Mode conduite**. Déclarés par `plugins/raccourcis.js` (liens `frelons://…`).

## Fonctionnement pendant une sortie

- **Écran verrouillé** : tant que le toit ou le portatif est connecté (ou une station fixe en cours), un service Android garde l'appli active (notification « Frelons : sortie en cours »). Il demande la position « Toujours autoriser ». Réglages → Appareils → « Continuer écran verrouillé ».
- **Reprise après coupure** : relevés, directions, trajet et station sont enregistrés toutes les 10 s ; si l'appli est fermée ou plante, ils sont repris au redémarrage (moins de 12 h) et l'appli se reconnecte aux appareils. Réglages → Appareils → « Terminer » pour repartir de zéro.
- **Erreurs** : toute erreur de l'appli va dans le journal de mise au point ; celles d'avant un plantage y sont reprises au redémarrage.

## Pas encore essayé sur le vrai matériel

Bluetooth avec le toit et le portatif, mise à jour par Bluetooth (en cas de souci : Réglages → Journal de mise au point → Exporter), boussole et GPS du téléphone, sons, photos, PDF.
Les alertes sonnent tant que l'appli est ouverte ; téléphone verrouillé, Android peut les retarder.

## Installer (APK)

À chaque envoi sur GitHub, la compilation se lance seule (onglet **Actions**) et publie l'APK dans **Releases** (`apk-<numéro>`). L'appli la détecte (Réglages → Mises à jour) ; elle reste aussi dans « Artifacts » en bas de la page de la compilation.

## Essayer sans matériel

**Réglages → Lancer la sortie simulée** (×30), puis Direct, Carte, Chrono. **Portatif → Essayer avec le portatif simulé**.
Réglages et étalonnage répondent comme un vrai toit pendant la simulation.

## Développer

1. `npm install --legacy-peer-deps`, puis `npm run preparer` (Python 3 et `pip install pillow`) : sortie simulée, icônes et sons, qui ne sont pas stockés dans le dépôt.
2. `npm run typecheck`, `npm run lint`, `npm run test:calculs`.
3. `npx expo start --web` : aperçu dans le navigateur (sans Bluetooth).

## Organisation du code

```
src/app/            écrans (expo-router) ; (onglets)/ = Direct, carte, portatif, chrono, reglages
src/calc/           calculs : géographie, relèvements, fusion, aller-retour (appat), tuiles
src/proto/          lignes du toit (CSV) et du portatif (JSON), commandes
src/store/          état partagé
src/sources/        Bluetooth (UART Nordic, reconnexion automatique), simulation, toit simulé
src/services/       carnet, position, sons, alertes, cartes IGN, météo, exports, mises à jour
src/dfu/            CBOR, SMP (mcumgr), paquets de mise à jour
src/db.ts           base SQLite (nids, tags, ruchers, réglages)
scripts/            préparation, tests
```

## Simplicité

Onglets : **Suivi** (direction du tag ; sans appareil connecté, trois gros boutons : connecter le toit, chercher à pied, poser un tag), **Carte**, **Portatif**, **Chrono**, **Menu**.
Le Menu regroupe tout par usage : Appareils, Sur le terrain, Carnet, Compte et réglages, Essayer sans matériel.
**Mode expert** (interrupteur en bas du Menu, coupé par défaut) : réglages de mesure du toit, gains, maintenance, étalonnage de distance, banc d'essai, journal, paramètres avancés (alertes, distance, Bluetooth…), niveaux par voie, ampli et antenne GPS du portatif.

## Interventions et registre des traitements biocides

Sur la fiche d'un nid, rubrique **Interventions** : Destruction (puis Retraitement si besoin), Contrôle, Autre (déplacement sans intervention, autre espèce).
Chaque intervention suit le compte rendu des FREDON : type, date, méthode, hauteur (classe < 10 m, 10-25 m, > 25 m), diamètre, produit (substance, n° AMM, lot), quantité en grammes,
nid décroché ou non, client ou riverain (adresse trouvée d'après la position du nid, présent ou absent, signature au doigt), photos avant et après, météo, opérateur et n° Certibiocide.
L'état du nid en découle : traité, vérifié mort, ou à retraiter si le contrôle trouve encore de l'activité. Les interventions sont partagées avec l'équipe (les photos restent sur le téléphone).
- **Compte rendu PDF** à remettre au client, avec les consignes « Suites de l'intervention » et la date du contrôle prévu.
- **Contrôle** rappelé quelques jours après un traitement (Paramètres → Entreprise et interventions), au démarrage, dans le Menu et sur le widget.
- **Registre des traitements** (Menu → Carnet) : par année et par opérateur, totaux par produit, export PDF (paysage) et Excel (toutes les colonnes).
- **Produits biocides** (Menu → Carnet) : nom commercial, substance active, n° d'autorisation.

## Widget d'écran d'accueil (Android)

Appui long sur l'écran d'accueil → Widgets → Frelons. Il affiche les tags posés, les nids à traiter, les nids à contrôler, les pièges à relever et l'étape du calendrier,
avec deux raccourcis (Nid ici, Poser un tag). Chaque case ouvre l'écran correspondant. Mis à jour à chaque changement du carnet et toutes les 30 min.
Bibliothèque : react-native-android-widget ; point d'entrée de l'appli : `index.ts` (appli + tâche du widget).

## Pression des frelons devant les ruches

Menu → Ruchers : sur chaque rucher, un appui note le nombre de frelons qui chassent devant les ruches (aucun, 1 à 5, 5 à 20, plus de 20 ; un relevé par jour, corrigé d'un nouvel appui).
Barres des 8 dernières semaines, niveau moyen des 7 derniers jours et tendance (en hausse, en baisse). Les relevés sont partagés avec l'équipe comme le rucher.

## Fiche d'intervention allégée

Par défaut, une intervention ne garde que l'essentiel : type, date, méthode, hauteur, produit et quantité, photos, commentaires.
Paramètres → Interventions sur les nids → « Fiche complète » ajoute le client ou riverain, sa signature, la météo, l'opérateur et le compte rendu PDF.

## Sauvegarde automatique

Menu → Sauvegarde : chaque jour ou chaque semaine (par défaut), une copie du carnet (sans les photos) part sur votre compte Supabase ; les 8 dernières sont gardées et se restaurent d'un appui.
Il faut être connecté et avoir relancé le script SQL (table `sauvegarde`, visible par son seul propriétaire). La sauvegarde .zip garde les photos.

## Tag perdu

Le dernier contact de chaque tag (vrai toit ou vrai portatif) est gardé : heure, position (estimation du nid si elle existe, sinon le récepteur), précision.
Menu → Mes tags : « Dernier contact il y a … » et bouton « Y aller » (navigation) ; filtre « Sans nouvelles » pour les tags posés plus entendus depuis 2 jours (réglable : Paramètres → Tags).

## Lien pression / nids

Pour chaque nid traité à moins du rayon d'un rucher (1 km par défaut), l'appli compare la pression devant les ruches la semaine avant le traitement et la semaine après.
Affiché sous le rucher (Menu → Ruchers) et sur la fiche du nid (« Effet sur les ruchers ») ; une baisse de 30 % ou plus est signalée : ce nid gênait ce rucher.

## Résultats de saison

Bilan de saison → « Vos résultats » : tags posés (journal des poses), nids trouvés grâce à un tag et taux de réussite, délai entre la pose et le nid,
distance des nids au rucher le plus proche, méthode qui a trouvé chaque nid (voiture, portatif, chrono, à l'œil, drone, à la main), morts au premier traitement.
