# Appli Frelons (Android)

Application téléphone du système de pistage du frelon asiatique : React Native + Expo SDK 58, TypeScript.
Toutes les fonctions du cahier des charges sont présentes ; ce qui dépend du matériel est écrit d'après les firmwares et testé en simulation.

## Écrans

| Onglets | |
|---|---|
| **Direct** | boussole, direction du tag, niveaux des 5 voies en %, nid estimé ; accès Mode conduite et Direction à l'œil |
| **Carte** | se déplace au doigt, zoom à deux doigts ; fond IGN (plan ou photo, hors ligne), trajet, relèvements retenus / écartés, directions à l'œil, appâts et anneaux, nid et précision, nids du carnet, ruchers ; envoyer au portatif, ajouter au carnet |
| **Portatif** | niveau en %, tendance, courbe 2 min, bips qui suivent le signal, tours de goniométrie, nid, direction vers le nid, réglages ; portatif simulé |
| **Chrono** | appât, départs / retours automatiques (toit) ou à la main, caps, distance et direction du nid, appât suivant |
| **Réglages** | outils, appareils, sortie simulée, réglages du toit, gains, maintenance |

| Outils (depuis Réglages) | |
|---|---|
| Avant de partir | vérifications automatiques + liste à cocher modifiable |
| Carnet des nids / fiche | états, description, photos, intervention, partage, fiche PDF, export GPX / KML |
| Mes tags / Poser un tag | état de chaque tag, pile, signal, allers-retours ; pose en 4 étapes (le chrono démarre) |
| Direction à l'œil | boussole du téléphone, la direction rejoint le calcul du nid |
| Mode conduite | très grand affichage, annonce vocale toutes les 10 s, bips |
| Sons et alertes | nouveau tag, tag perdu, pile faible, retour à l'appât, nid localisé, approche d'un nid (écran rouge), batteries |
| Cartes hors ligne | téléchargement de zones IGN (plan, photo) |
| Ruchers / Station fixe | nids à moins de 1 km de chaque rucher ; toit sur trépied : rose des directions de départ |
| Météo d'activité | meilleur créneau, heure par heure, jours suivants (Open-Meteo) |
| Bilan de saison | chiffres, nids par semaine, efficacité, tags ; export tableur |
| Mises à jour | import des paquets `…_mise_a_jour_bluetooth.zip`, envoi par Bluetooth (portatif, toit, 4 voies, nacelle, station sol) |
| Étalonnage du toit | 4 étapes, résultat commenté, aide |
| Banc d'essai | première mise sous tension de chaque carte (chargeur, tags, portatif, écran et dos, toit, nacelle) : étapes à cocher, mesures avec plage attendue, vérifications automatiques par l'appli, notes, export |
| Journal de mise au point | lignes Bluetooth reçues / envoyées, connexions, erreurs, lignes non comprises, étapes des mises à jour ; envoi d'une commande à la main ; export texte |

## Vérifié

- `npm run test:calculs` (lancé aussi par la compilation GitHub) :
  - nid du tag 7 retrouvé à 4 m du vrai sur la sortie simulée ;
  - chrono identique au rejeu de l'écran voiture (6 allers-retours, 364 m ± 76, cap 115°) ;
  - encodage CBOR et protocole de mise à jour SMP contre un appareil simulé (image de 50 ko reçue intacte, paquets ≤ MTU, image « à essayer » puis redémarrage) ;
  - lecture des paquets, météo, géométrie des tuiles IGN.
- Les calculs de nid sont identiques au C de l'écran voiture (40 cas, écart < 1 cm).
- `npx tsc --noEmit` et `npx expo lint` sans erreur ; bundle Android et `expo prebuild` OK ; chaque écran ouvert sans erreur pendant la sortie simulée.

## Pas encore essayé sur le vrai matériel

Bluetooth avec le toit et le portatif, mise à jour par Bluetooth (en cas de souci : Réglages → Journal de mise au point → Exporter), boussole et GPS du téléphone, sons, photos, PDF.
Les alertes sonnent tant que l'appli est ouverte ; téléphone verrouillé, Android peut les retarder.

## Installer (APK)

À chaque envoi sur GitHub, la compilation se lance seule (onglet **Actions**) ; l'APK se télécharge en bas de la page de la compilation, rubrique « Artifacts ».

## Essayer sans matériel

**Réglages → Lancer la sortie simulée** (×30), puis Direct, Carte, Chrono. **Portatif → Essayer avec le portatif simulé**.
Réglages et étalonnage répondent comme un vrai toit pendant la simulation.

## Développer

1. `npm install --legacy-peer-deps`, puis `npm run preparer` (Python 3 et `pip install pillow`) : sortie simulée, icônes et sons, qui ne sont pas stockés dans le dépôt.
2. `npm run typecheck`, `npm run lint`, `npm run test:calculs`.
3. `npx expo start --web` : aperçu dans le navigateur (sans Bluetooth).

## Organisation du code

```
src/app/            écrans (expo-router) ; (onglets)/ = Direct, carte, portatif, chrono, reglages
src/calc/           calculs : géographie, relèvements, fusion, aller-retour (appat), tuiles
src/proto/          lignes du toit (CSV) et du portatif (JSON), commandes
src/store/          état partagé
src/sources/        Bluetooth (UART Nordic, reconnexion automatique), simulation, toit simulé
src/services/       carnet, position, sons, alertes, cartes IGN, météo, exports, mises à jour
src/dfu/            CBOR, SMP (mcumgr), paquets de mise à jour
src/db.ts           base SQLite (nids, tags, ruchers, réglages)
scripts/            préparation, tests
```
