# Appli Frelons (Android)

Application téléphone du système de pistage du frelon asiatique. Elle est écrite en React Native avec Expo SDK 58 et TypeScript.

## Contenu de cette première version

| Partie | État |
|---|---|
| Socle : onglets Direct, Carte, Portatif, Chrono, Réglages | fait |
| **Sortie simulée** : rejoue une vraie sortie enregistrée (×1, ×10, ×30) | fait |
| **Direct** : boussole, nord en haut, direction du tag, cône ±12°, niveaux des 5 voies en %, pile, nid estimé | fait |
| **Carte** : trajet, relèvements retenus et écartés, directions à l'œil, nid avec sa précision, échelle, zoom, envoi au portatif, carnet | fait |
| Liaison Bluetooth avec le toit (« TOIT-Frelons ») | écrite, à essayer sur le vrai toit |
| **Portatif** : niveau du tag en %, tendance, courbe sur 2 min, tours de goniométrie, points et nid calculé, direction vers le nid, ampli, GPS, son ; portatif simulé | fait |
| Liaison Bluetooth avec le portatif (« RX-Frelons ») | écrite, à essayer sur le vrai portatif (firmware du portatif mis à jour) |
| **Chrono à l'appât** : « Lâcher ici », détection automatique des départs et retours par le toit (portage de aller.c), Parti / Revenu à la main avec cap pointé au portatif, allers-retours, distance et direction du nid, appât suivant, anneaux sur la carte, appâts sauvegardés | fait |
| **Réglages** : appareils, sortie simulée, orientation, lobe, vitesse mini, arrêt auto, gains des 4 voies, maintenance (mise à jour, redémarrage, arrêt du toit), aide | fait |
| **Étalonnage du toit** en 4 étapes (calpos, cal, tours, calfin), résultat commenté, aide ; toit simulé pour s'entraîner | fait |
| Les autres écrans du cahier des charges | à venir |

Les calculs sont un portage direct du code de l'écran de la voiture :

- `src/calc/estim.ts` reprend `estim.c` ;
- `src/calc/releves.ts` reprend `data.c` ;
- `src/calc/fusion.ts` reprend `fusion.c`.

Ils ont été vérifiés sur 40 cas tirés au hasard. Le C et le TypeScript donnent le même nid, avec moins de 1 cm d'écart.

Sur la sortie simulée, le nid du tag 7 est retrouvé à 4 m du vrai. Pour vérifier de nouveau, lancez `npm run test:calculs`.

## Installer l'appli sur le téléphone (APK)

**Le plus simple** : à chaque envoi sur GitHub, la compilation se lance seule (onglet **Actions** du dépôt). L'APK se télécharge en bas de la page de la compilation, rubrique « Artifacts ».

**Sinon, avec EAS** :

1. Installez Node.js 20 ou une version plus récente, puis créez un compte gratuit sur expo.dev.
2. Dans ce dossier, lancez :
   ```
   npm install --legacy-peer-deps
   npx eas-cli@latest login
   npx eas-cli@latest build -p android --profile preview
   ```
3. Une fois la compilation terminée, EAS affiche un lien et un QR code. Ouvrez-le sur le téléphone et installez l'APK. Il faut autoriser l'installation depuis cette source.

L'appli utilise le Bluetooth natif. Elle ne fonctionne donc **pas dans Expo Go** : il faut passer par l'APK.

## Essayer sans matériel

Dans l'onglet **Réglages**, touchez **Lancer la sortie simulée**, à la vitesse ×30. Allez ensuite sur **Direct** puis sur **Carte**.

Dans l'onglet **Portatif**, touchez **Essayer avec le portatif simulé** : vous êtes à 170 m du nid du tag 007. Faites un tour, ajoutez le point, attendez que la personne simulée ait marché, puis recommencez.

## Développer

Avant tout, lancez `npm run preparer` (Python 3 et `pip install pillow`) : il fabrique la sortie simulée et les icônes, qui ne sont pas stockées dans le dépôt.

- `npm run typecheck` : vérifie les types.
- `npm run test:calculs` : rejoue la sortie simulée, compare aux vrais nids et au rejeu du chrono de l'écran voiture.
- `npx expo start --web` : aperçu rapide dans le navigateur, sans Bluetooth (il faut installer `react-native-web` et `react-dom`, déjà présents).

## Organisation du code

```
src/app/            écrans (expo-router) : (onglets)/index = Direct, carte, portatif, chrono, reglages
src/calc/           calculs : géographie, relèvements, fusion, aller-retour
src/proto/          décodage des lignes du toit (CSV) et du portatif (JSON), commandes
src/store/          état partagé de l'appli
src/sources/        simulation (rejeu) et Bluetooth (UART Nordic)
src/sim/            sortie enregistrée embarquée (R0001.CSV)
src/db.ts           journal SQLite (sorties, relèvements, nids)
scripts/            test des calculs
```
