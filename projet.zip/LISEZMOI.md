# Appli Frelons (Android)

Application téléphone du système de pistage du frelon asiatique : React Native + Expo SDK 58, TypeScript.
Toutes les fonctions du cahier des charges sont présentes ; ce qui dépend du matériel est écrit d'après les firmwares et testé en simulation.

## Écrans

| Onglets | |
|---|---|
| **Direct** | boussole, direction du tag, niveaux des 5 voies en %, nid estimé ; accès Mode conduite et Direction à l'œil |
| **Carte** | se déplace au doigt, zoom à deux doigts, appui long pour ajouter un nid, un rucher ou un piège ; densité des nids toutes saisons, pièges ; fond IGN (plan ou photo, hors ligne), trajet, relèvements retenus / écartés, directions à l'œil, appâts et anneaux, nid et précision, nids du carnet, ruchers ; envoyer au portatif, ajouter au carnet |
| **Portatif** | niveau en % et distance approximative du tag (≈ 120 m, avec fourchette), tendance, courbe 2 min, bips qui suivent le signal, tours de goniométrie, nid, direction vers le nid, réglages ; portatif simulé |
| **Chrono** | appât, départs / retours automatiques (toit) ou à la main, caps, distance et direction du nid, appât suivant |
| **Réglages** | outils, appareils, sortie simulée, réglages du toit, gains, maintenance |

| Outils (depuis Réglages) | |
|---|---|
| Étalonner la distance | tag posé à une distance connue : signal mesuré 10 s (médiane) → signal à 1 m ; seconde mesure facultative → affaiblissement du milieu |
| Paramètres | profil (nom, opérateur et n° Certibiocide, structure), seuils d'alerte, recharge des tags, rayons autour des ruchers, densité, pièges (délai, appâts), météo, sortie (annonce vocale, reprise, GPS écran verrouillé), partage, dépôt GitHub des mises à jour, noms Bluetooth ; valeur par défaut rappelée, retour au défaut par rubrique |
| Calendrier de saison | étapes de l'année (pièges, nids primaires, tags, destruction, vérification, bilan GDSA, entretien) ; frise, cases « fait », dates modifiables par étape, décalage selon le secteur ; rappel à l'ouverture quand une étape commence |
| Avant de partir | vérifications automatiques + liste à cocher modifiable |
| Carnet des nids / fiche | états, description, photos, intervention, partage, fiche PDF, export GPX / KML |
| Mes tags / Poser un tag | état de chaque tag, pile, signal, allers-retours, tags à recharger (pile faible, a servi, recharge de plus de 7 jours ; rappel au démarrage et dans « Avant de partir ») ; pose en 4 étapes (le chrono démarre) |
| Direction à l'œil | boussole du téléphone, la direction rejoint le calcul du nid |
| Mode conduite | très grand affichage, annonce vocale toutes les 10 s, bips |
| Sons et alertes | nouveau tag, tag perdu, pile faible, retour à l'appât, nid localisé, approche d'un nid (écran rouge), batteries |
| Cartes hors ligne | téléchargement de zones IGN (plan, photo) |
| Ruchers / Station fixe | nids à moins de 1 km de chaque rucher ; toit sur trépied : rose des directions de départ |
| Météo d'activité | meilleur créneau, heure par heure, jours suivants (Open-Meteo) |
| Bilan de saison | choix de l'année, chiffres, nids par semaine, statistiques par rucher (1 km / 3 km, détruits, pièges), comparaison des saisons, efficacité, tags ; export pour le GDSA (rapport PDF d'une page + classeur Excel : résumé, nids, ruchers, pièges, relevés) ; liste des nids en CSV |
| Pièges de printemps | pièges à fondatrices : relevés, captures par semaine, pièges à relever ; partagés avec l'équipe |
| Mises à jour | appli (dernière version publiée sur GitHub, téléchargement) ; appareils : import des paquets `…_mise_a_jour_bluetooth.zip`, envoi par Bluetooth (portatif, toit, 4 voies, nacelle, station sol) |
| Étalonnage du toit | 4 étapes, résultat commenté, aide |
| Sauvegarde du carnet | un fichier .zip (nids et photos, tags, ruchers, appâts, réglages) ; restauration |
| Connexion | écran au premier lancement (facultatif) : compte e-mail + mot de passe (Supabase), création de compte, mot de passe oublié, « Continuer sans compte » |
| Partage entre téléphones | compte, équipe (créer, rejoindre avec le code d'invitation, membres, responsables, changer le code, quitter), synchronisation des nids, ruchers et pièges (la modification la plus récente gagne) ; script SQL dans l'écran |
| Banc d'essai | première mise sous tension de chaque carte (chargeur, tags, portatif, écran et dos, toit, nacelle) : étapes à cocher, mesures avec plage attendue, vérifications automatiques par l'appli, notes, export |
| Journal de mise au point | lignes Bluetooth reçues / envoyées, connexions, erreurs, lignes non comprises, étapes des mises à jour ; envoi d'une commande à la main ; export texte |

## Vérifié

- Partage : essayé contre un vrai PostgREST + PostgreSQL (le moteur de Supabase) avec deux téléphones simulés : envoi, réception, conflit, suppression, cloisonnement des équipes ; comptes et droits (intrus refusé, code faux refusé, seul le responsable change le code ou retire un membre).
- `npm run test:calculs` (lancé aussi par la compilation GitHub) :
  - nid du tag 7 retrouvé à 4 m du vrai sur la sortie simulée ;
  - chrono identique au rejeu de l'écran voiture (6 allers-retours, 364 m ± 76, cap 115°) ;
  - encodage CBOR et protocole de mise à jour SMP contre un appareil simulé (image de 50 ko reçue intacte, paquets ≤ MTU, image « à essayer » puis redémarrage) ;
  - lecture des paquets, météo, géométrie des tuiles IGN.
- Les calculs de nid sont identiques au C de l'écran voiture (40 cas, écart < 1 cm).
- `npx tsc --noEmit` et `npx expo lint` sans erreur ; bundle Android et `expo prebuild` OK ; chaque écran ouvert sans erreur pendant la sortie simulée.

## Versions des firmwares

À chaque connexion, le toit (`V,…`) et le portatif (`{"type":"ver",…}`) annoncent leur firmware et leur protocole. L'appli compare avec `src/calc/versions.ts` (protocoles compris, firmwares livrés avec cette version) : version affichée sous chaque appareil (Réglages → Appareils) et dans Mises à jour, bandeau si le firmware ou l'appli doit être mis à jour, ligne dans le journal. Un firmware muet après 8 s date d'avant la 1.1.0.

## Raccourcis Android

Appui long sur l'icône de l'appli : **Poser un tag**, **Nid trouvé ici** (attend une bonne position puis crée la fiche), **Pièges**, **Mode conduite**. Déclarés par `plugins/raccourcis.js` (liens `frelons://…`).

## Fonctionnement pendant une sortie

- **Écran verrouillé** : tant que le toit ou le portatif est connecté (ou une station fixe en cours), un service Android garde l'appli active (notification « Frelons : sortie en cours »). Il demande la position « Toujours autoriser ». Réglages → Appareils → « Continuer écran verrouillé ».
- **Reprise après coupure** : relevés, directions, trajet et station sont enregistrés toutes les 10 s ; si l'appli est fermée ou plante, ils sont repris au redémarrage (moins de 12 h) et l'appli se reconnecte aux appareils. Réglages → Appareils → « Terminer » pour repartir de zéro.
- **Erreurs** : toute erreur de l'appli va dans le journal de mise au point ; celles d'avant un plantage y sont reprises au redémarrage.

## Pas encore essayé sur le vrai matériel

Bluetooth avec le toit et le portatif, mise à jour par Bluetooth (en cas de souci : Réglages → Journal de mise au point → Exporter), boussole et GPS du téléphone, sons, photos, PDF.
Les alertes sonnent tant que l'appli est ouverte ; téléphone verrouillé, Android peut les retarder.

## Installer (APK)

À chaque envoi sur GitHub, la compilation se lance seule (onglet **Actions**) et publie l'APK dans **Releases** (`apk-<numéro>`). L'appli la détecte (Réglages → Mises à jour) ; elle reste aussi dans « Artifacts » en bas de la page de la compilation.

## Essayer sans matériel

**Réglages → Lancer la sortie simulée** (×30), puis Direct, Carte, Chrono. **Portatif → Essayer avec le portatif simulé**.
Réglages et étalonnage répondent comme un vrai toit pendant la simulation.

## Développer

1. `npm install --legacy-peer-deps`, puis `npm run preparer` (Python 3 et `pip install pillow`) : sortie simulée, icônes et sons, qui ne sont pas stockés dans le dépôt.
2. `npm run typecheck`, `npm run lint`, `npm run test:calculs`.
3. `npx expo start --web` : aperçu dans le navigateur (sans Bluetooth).

## Organisation du code

```
src/app/            écrans (expo-router) ; (onglets)/ = Direct, carte, portatif, chrono, reglages
src/calc/           calculs : géographie, relèvements, fusion, aller-retour (appat), tuiles
src/proto/          lignes du toit (CSV) et du portatif (JSON), commandes
src/store/          état partagé
src/sources/        Bluetooth (UART Nordic, reconnexion automatique), simulation, toit simulé
src/services/       carnet, position, sons, alertes, cartes IGN, météo, exports, mises à jour
src/dfu/            CBOR, SMP (mcumgr), paquets de mise à jour
src/db.ts           base SQLite (nids, tags, ruchers, réglages)
scripts/            préparation, tests
```

## Simplicité

Onglets : **Suivi** (direction du tag ; sans appareil connecté, trois gros boutons : connecter le toit, chercher à pied, poser un tag), **Carte**, **Portatif**, **Chrono**, **Menu**.
Le Menu regroupe tout par usage : Appareils, Sur le terrain, Carnet, Compte et réglages, Essayer sans matériel.
**Mode expert** (interrupteur en bas du Menu, coupé par défaut) : réglages de mesure du toit, gains, maintenance, étalonnage de distance, banc d'essai, journal, paramètres avancés (alertes, distance, Bluetooth…), niveaux par voie, ampli et antenne GPS du portatif.

## Interventions et registre des traitements biocides

Sur la fiche d'un nid, rubrique **Interventions** : Destruction (puis Retraitement si besoin), Contrôle, Autre (déplacement sans intervention, autre espèce).
Chaque intervention suit le compte rendu des FREDON : type, date, méthode, hauteur (classe < 10 m, 10-25 m, > 25 m), diamètre, produit (substance, n° AMM, lot), quantité en grammes,
nid décroché ou non, client ou riverain (adresse trouvée d'après la position du nid, présent ou absent, signature au doigt), photos avant et après, météo, opérateur et n° Certibiocide.
L'état du nid en découle : traité, vérifié mort, ou à retraiter si le contrôle trouve encore de l'activité. Les interventions sont partagées avec l'équipe (les photos restent sur le téléphone).
- **Compte rendu PDF** à remettre au client, avec les consignes « Suites de l'intervention » et la date du contrôle prévu.
- **Contrôle** rappelé quelques jours après un traitement (Paramètres → Entreprise et interventions), au démarrage, dans le Menu et sur le widget.
- **Registre des traitements** (Menu → Carnet) : par année et par opérateur, totaux par produit, export PDF (paysage) et Excel (toutes les colonnes).
- **Produits biocides** (Menu → Carnet) : nom commercial, substance active, n° d'autorisation.

## Widget d'écran d'accueil (Android)

Appui long sur l'écran d'accueil → Widgets → Frelons. Il affiche les tags posés, les nids à traiter, les nids à contrôler, les pièges à relever et l'étape du calendrier,
avec deux raccourcis (Nid ici, Poser un tag). Chaque case ouvre l'écran correspondant. Mis à jour à chaque changement du carnet et toutes les 30 min.
Bibliothèque : react-native-android-widget ; point d'entrée de l'appli : `index.ts` (appli + tâche du widget).

## Pression des frelons devant les ruches

Menu → Ruchers : sur chaque rucher, un appui note le nombre de frelons qui chassent devant les ruches (aucun, 1 à 5, 5 à 20, plus de 20 ; un relevé par jour, corrigé d'un nouvel appui).
Barres des 8 dernières semaines, niveau moyen des 7 derniers jours et tendance (en hausse, en baisse). Les relevés sont partagés avec l'équipe comme le rucher.

## Fiche d'intervention allégée

Par défaut, une intervention ne garde que l'essentiel : type, date, méthode, hauteur, produit et quantité, photos, commentaires.
Paramètres → Interventions sur les nids → « Fiche complète » ajoute le client ou riverain, sa signature, la météo, l'opérateur et le compte rendu PDF.

## Sauvegarde automatique

Menu → Sauvegarde : chaque jour ou chaque semaine (par défaut), une copie du carnet (sans les photos) part sur votre compte Supabase ; les 8 dernières sont gardées et se restaurent d'un appui.
Il faut être connecté et avoir relancé le script SQL (table `sauvegarde`, visible par son seul propriétaire). La sauvegarde .zip garde les photos.

## Tag perdu

Le dernier contact de chaque tag (vrai toit ou vrai portatif) est gardé : heure, position (estimation du nid si elle existe, sinon le récepteur), précision.
Menu → Mes tags : « Dernier contact il y a … » et bouton « Y aller » (navigation) ; filtre « Sans nouvelles » pour les tags posés plus entendus depuis 2 jours (réglable : Paramètres → Tags).

## Lien pression / nids

Pour chaque nid traité à moins du rayon d'un rucher (1 km par défaut), l'appli compare la pression devant les ruches la semaine avant le traitement et la semaine après.
Affiché sous le rucher (Menu → Ruchers) et sur la fiche du nid (« Effet sur les ruchers ») ; une baisse de 30 % ou plus est signalée : ce nid gênait ce rucher.

## Résultats de saison

Bilan de saison → « Vos résultats » : tags posés (journal des poses), nids trouvés grâce à un tag et taux de réussite, délai entre la pose et le nid,
distance des nids au rucher le plus proche, méthode qui a trouvé chaque nid (voiture, portatif, chrono, à l'œil, drone, à la main), morts au premier traitement.

## Firmwares 1.2.0 (au nid / en chasse, flèche, erreurs)
- **Au nid / en chasse** : le tag (firmware 4, carte V4.1 avec capteur de lumière) ajoute un octet d'état à chaque trame (bit 7 = dans le noir, bits 0-6 = température + 40). Le toit le passe en 18ᵉ champ des lignes `R`, le portatif en champ `etat` (JSON `st` et `tag`). L'appli (`calc/activite.ts`) en déduit « Au nid / En chasse depuis… », les sorties du jour et leur durée moyenne (Suivi, Mes tags, Portatif). Un silence de plus de 20 min : la sortie n'est pas comptée.
- **Fin de vie du tag** : sous 2,35 V il n'émet plus qu'une trame sur trois (une sur dix sous 2,1 V) pour tenir plus longtemps.
- **Flèche vers un point** : commande portatif `cible <lat> <lon> <nom>` / `cible off`. Boutons « Portatif » sur la fiche d'un nid et le dernier contact d'un tag, « Flèche sur l'écran du portatif » vers le nid estimé ; le portatif passe en mode NAV avec la distance et la direction.
- **Remontée des erreurs** : chien de garde de 30 s sur le chef, les voies, le portatif, la nacelle et le dos de l'écran. Ligne `V` du toit : `…,rst,uptime_s,rst_voie0..3` ; `ver` du portatif : `"rst"`, `"up"`. Une voie qui redémarre seule → ligne `E,voie,n,rst,texte`. L'appli note la cause dans le Journal et affiche un bandeau si c'est un blocage ou une tension trop basse.
- **Écran de la voiture** : 2 bips longs aigus = tag entendu pour la 1ʳᵉ fois, 3 bips courts = tag qui revient ; LiPo de la nacelle ≤ 15 % = 2 bips graves et message, ≤ 5 % = 5 bips toutes les 30 s et « POSER LE DRONE ». La nacelle clignote à chaque trame quand sa LiPo est faible.
- **Chargeur** : pile qui se charge en moins de 10 min en partant de moins de 2,5 V, ou pas pleine après 4 h → « U » à l'écran, LED rapide, « PILE n USEE ? ». Seuils provisoires, à régler après les premiers essais.
- **Pause la nuit (tag, firmware 5)** : après 1 h sans interruption dans le noir, une trame toutes les 15 s ; rythme normal dès le retour de la lumière.
- **Tag immobile** (`immobileDepuis`) : toujours entendu mais plus aucun passage nid ↔ dehors pendant 3 h de jour (8 h - 20 h) → « Immobile depuis… : tombé, ou frelon mort ? » dans Mes tags et alerte (réglage « Tag perdu »).
- **Carte du signal à pied** (`calc/traceAPied.ts`) : chaque ligne `st` du portatif avec GPS donne un point (un tous les 3 m, le plus fort sur place), coloré du bleu (faible) au rouge (fort), cercle sur le point le plus fort. Calque « Signal à pied » de la Carte, bouton « Carte du signal » dans l'onglet Portatif.
- **Mode poche (portatif)** : commande `poche 1|0` ou menu du portatif ; écran éteint, vibreur de 1 battement / 3 s (−100 dBm) à 4 / s (−50 dBm). N'importe quelle touche rallume l'écran. Le portatif renvoie `"poche":1` dans `st`.
- **Drone (écran voiture)** : au sol « PRET AU DECOLLAGE » (GPS ≥ 6 sat., LiPo, LoRa, tag choisi) avec 2 bips, sinon « PAS PRET : … » ; point chaud = 2 bips aigus à chaque nouveau maximum (+3 dB) ; liaison perdue en vol (plus rien depuis 5 s alors que le drone était à plus de 5 m) = 4 bips graves toutes les 15 s et dernier point connu (distance, cap, hauteur).
- **Chargeur** : place toujours en charge après 8 h → « ! », LED en double éclat, « RETIRER PILE n ». Pas de coupure (la carte n'a pas d'interrupteur par place, le courant est limité à ~1 mA par la résistance).
- **Carte à pied sans téléphone (portatif)** : sans téléphone connecté, le portatif garde lui-même ses points (2 000 au plus, un tous les 3 m) et les envoie à la reconnexion en lignes `{"type":"pas",…}` (10 par seconde) ; l'appli les ajoute à la carte du signal à pied.
- **Rattrapage après coupure (drone)** : la nacelle garde ses 128 dernières trames et écoute 120 ms après chaque envoi ; le dos de l'écran redemande les trames manquantes (paquet `N`), renvoyées avec le drapeau « rattrapée » et relayées en lignes `d,…`. L'écran les ajoute à la carte du vol sans toucher à l'état courant (« n rattrap. »).
- **Vols du drone** (`calc/vol.ts`, `services/vols.ts`, Menu → Vols du drone) : le téléphone se connecte au dos de l'écran (« SOL-Frelons ») en même temps que l'écran ; chaque vol (trace, hauteur, niveaux des tags, trames rattrapées) est enregistré (20 derniers), affiché sur la Carte (calque « Vol drone ») et sur la fiche du nid du tag, exportable en GPX ou CSV.
- **Contrôle du traitement par le tag** (`controleTraitement`) : après une destruction, plus aucune sortie du frelon tagué et un tag qui refroidit dans le nid (≤ 18 °C, ou 6 °C de moins qu'avant) pendant au moins 6 h → « nid probablement mort » ; une sortie → « encore actif ». Carte sur la fiche du nid, alerte, bouton « Noter le contrôle ». L'activité des tags est gardée d'une session à l'autre.
- **Nid estimé en marchant (portatif, `pf.c`)** : filtre à particules (600) sur la position du nid du tag suivi ; chaque trame apporte position GPS, cap de la boussole et niveau (modèle : P1m − 25·log10(d) − 12 dB·(1 − cos θ)/2, bruit 7 dB). Utilisable après 30 mesures, 30 m de marche et moins de ± 60 m. Affiché sur la page Recherche, en mode NAV (« NID (MARCHE) » s'il est plus précis que celui du toit), envoyé à l'appli (`{"type":"est",…}` toutes les 5 s) : carte Portatif, cercle sur la Carte, boutons Plan de vol et Flèche. Essai sur PC (marche simulée, nid à 190 m, bruit 6 dB) : 20 à 30 m d'erreur en moyenne ; avec 9 dB de bruit, environ 50 m.
- **Étalonnage de chaque tag** : Mes tags → « Étalonner » (portatif connecté) ; le tag posé à 1 m devant l'antenne, le portatif relève 20 trames (commande `etal <id>`), garde la médiane (`rx/p1m`) et la renvoie (`{"type":"etal",…}`). L'appli la garde et la renvoie au portatif à chaque connexion (`p1m <id> <dBm>`). Utilisée pour la distance affichée (portatif et appli) et le nid estimé en marchant.
- **Plan de vol automatique** (`calc/planVol.ts`, écran Plan de vol depuis la fiche d'un nid à traiter ou le nid estimé en marchant) : spirale de l'extérieur vers le nid ou quadrillage, rayon conseillé 3 × l'incertitude (80 à 400 m), hauteur ≤ 120 m, 99 points au plus ; export mission Litchi (CSV, hauteur au-dessus du décollage) et trace KML.
- **Puissance du tag** : le tag émet à +8 dBm (pile ≥ 50 %), +4 dBm (≥ 16 %), 0 dBm en dessous. Le chef, le portatif et la nacelle déduisent la puissance du pourcentage de pile et ramènent le niveau à +8 dBm : les distances et les estimations ne dérivent plus quand la pile baisse.
- **Trame longue portée (tag firmware 6)** : une trame sur 10 en PHY codée S8 (environ 4 fois la portée), octet batt | 0x80. Voies, nacelle : écoute 1M + codée quand aucun tag n'est entendu en 1M depuis 5 s. Chef : trame longue portée = détection seule (pas de relèvement, entendue par une partie des voies) ; 19ᵉ champ des lignes `R` = 1.
- **Portatif** : écoute permanente (fenêtre = intervalle, 60 ms) au lieu de 50 % ; tag suivi muet en 1M depuis 5 s → une fenêtre sur deux en PHY codée.
- **Boussole du portatif** : intensité du champ surveillée (écart > 15 % de sa moyenne lente = métal ou aimant proche) → « BOUSSOLE PERTURBÉE », mesures écartées du tour sur place et du nid estimé en marchant ; message « refaites le 8 » après 30 s ; calibration refusée si un axe a trop peu varié.
- **LoRa adaptatif (drone)** : le dos de l'écran renvoie le SNR dans la fenêtre d'écoute de la nacelle (paquet `Q`) ; la nacelle passe en SF9 (portée × 2, une trame / 2 s) sous −3 dB, revient en SF7 au-dessus de +5 dB, et passe en SF9 sans nouvelles du sol depuis 6 s ; le dos de l'écran, sans trame depuis 3 s, écoute SF7 et SF9 à tour de rôle.
- **Position au bon instant (chef)** : chaque trame est datée (impulsion SYNC + temps mesuré par la voie) et la position de la voiture est interpolée entre deux points GPS (2 Hz, retard NMEA 150 ms) ou prolongée avec la vitesse et la route.
- **Diagramme réel des antennes du toit** : pendant l'étalonnage habituel (`calpos`, `cal <id>`, tours autour du tag, `calfin`), le chef mesure aussi le niveau de chaque voie par secteur de 10° ; gardé seulement s'il fait mieux que le modèle sur des trames qu'il n'a pas servi à construire. Ligne `K` : 10ᵉ champ = erreur avec le diagramme (−1 = modèle gardé). `pat 0` revient au modèle. Essai sur PC : 8,5° → 3,7° avec 1 dB de bruit, 10° → 7,6° avec 2 dB ; aucun gain au-delà de 3 dB.
- **Nid estimé en roulant (écran voiture, `pfroute.c`)** : filtre à particules par tag (4 à la fois, en PSRAM) nourri par chaque ligne R (relèvement absolu et niveau), entre dans la fusion quand il est sûr (15 trames, 100 m, ± 80 m). Essai sur PC (un seul passage en ligne droite, nid à 390 m) : 76 m d'erreur en moyenne.
- **Nid en 3D par le drone** (`nid3D`) : ajustement du modèle de signal (avec la hauteur) sur tout le vol : position et hauteur du nid au-dessus du décollage avec son intervalle ; liste des vols, fiche du nid, Carte. Essai : position à 5-12 m, hauteur indicative (± 10 m) ; varier la hauteur de vol l'améliore.
- **Estimation unique du nid** : la fusion de l'appli (`calc/fusion.ts`) prend maintenant aussi le nid estimé en marchant (portatif) et le nid en 3D du dernier vol de drone (`store.estimationExterne`), en plus des relèvements du toit, des tours sur place, des caps à l'œil et du chrono. Sources affichées : « portatif (en marchant) », « drone ».
- **Terrain appris sur les nids trouvés** (`calc/terrain.ts`, `services/terrain.ts`) : quand un nid relié à un tag est noté trouvé, les points de la carte du signal à pied donnent l'exposant du terrain (2 dégagé … 4 forêt) ; médiane des 5 derniers nids nets → distances du portatif (appli) et commande `nexp` au portatif (distance affichée, nid estimé en marchant). Essai sur PC : apprendre l'exposant PENDANT la marche dégradait la position (17 → 52 m), d'où ce choix.
- **Recalage du toit sur les nids trouvés** : écart médian entre les relèvements pris en roulant (40 m à 1 km, qualité ≥ 50) et la vraie direction du nid ; dès 2 nids ou 30 relèvements et un écart > 3°, l'écran Étalonnage du toit propose « Corriger de x° » → commande `rot` (chef : orientation du modèle et du diagramme mesuré, réponse `K,ROT,deg,fwd`).
- **Portatif, trames** : une trame part sur 3 canaux ; le portatif garde la meilleure réception de chaque trame (regroupement 120 ms) et écrête à ± 15 dB du niveau filtré les valeurs aberrantes pour le filtre de Kalman.
- **Chef, reflets** : écart habituel entre la meilleure voie directive et l'antenne omni appris en continu ; s'il s'effondre de plus de 6 dB (signal qui arrive de partout), la qualité du relèvement est divisée par 2.
- **Enregistrer un essai** (Menu → Enregistrer un essai, `services/essais.ts`) : toutes les lignes brutes du toit (T), du portatif (P, dont `{"type":"f",…}` = chaque trame reçue : niveau, cap, PHY, voie RF, boussole, GPS), du drone (D), le GPS du téléphone toutes les 5 s (G), des repères de terrain (R : « Nid ici », « Tag posé ici », note libre, avec la position du téléphone) et des infos (I) dans `essais/essai_AAAAMMJJ_HHMM.txt` (« heure_ms;source;ligne », en-tête avec versions et réglages). Pendant l'essai, le chef (`brut 1` : niveaux non lissés) et le portatif (`brut 1` : lignes `f`, 20 par seconde au plus) passent en mode brut ; à chaque reconnexion aussi. Bouton « Envoyer » pour partager le fichier.
- **Recette des cartes** (Menu → Recette des cartes, `calc/recette.ts`) : tags (radio, pile, température, capteur de lumière caché puis découvert, antenne : niveau à 1 m comparé à la médiane des tags étalonnés), toit (4 voies présentes, GPS, test des 4 directions : la voie attendue doit être la plus forte de 3 dB, sinon câble ou panneau inversé), portatif (GPS, boussole `"cmp"` dans `st`, batterie, réception), chargeur (liste à cocher) ; rapport texte à partager.

## Firmwares 1.3.0 (ordres à distance aux tags)
- **Tag (firmware 7)** : une trame sur 5 est connectable. Le portatif ou le toit s'y connectent un instant ; les paramètres de la connexion portent l'ordre (intervalle 30 ms, supervision 400 + ordre × 10 ms), le tag coupe aussitôt. Ordres : `ping` (« Répond ? »), `rech` (une trame / 0,5 s pendant 10 min, longue portée 1 sur 5), `fin`, `off` (éteint, réveil seulement par le chargeur).
- **Commandes** : `ordre <tag> ping|rech|fin|off` au portatif et au toit (module commun `tagcmd.c`, connexion en parallèle du scan). Réponses : portatif `{"type":"ordre","tag":…,"ordre":…,"res":"go|ok|echec|occupe","ms":…}`, toit `K,TAG,<tag>,<ordre>,GO|OK,<ms>|ECHEC|OCCUPE`. Un ordre est tenté 60 s.
- **Appli** (`services/ordres.ts`) : Mes tags → « Répond ? », « Recherche 10 min » / « Arrêter la recherche », « Désactiver » (avec confirmation), via le portatif s'il est connecté, sinon le toit. Onglet Portatif → « Tag : mode recherche ». Portatif seul : menu « Tag suivi : mode recherche » et « Tag suivi : repond-il ? ». Écran voiture : écran Nid → « Tag : recherche ».

## Étalonnage automatique (1.3.0)
- **Un seul écran** : Menu → Matériel → Étalonnage (`app/etalonnages.tsx`), cinq étapes dans l'ordre avec leur état (`calc/etalAuto.ts : etapes`) ; bandeau sur l'accueil tant qu'il en reste. Procédure complète : `app/procedure-etalonnage.tsx`.
- **Portatif** : boussole (`cmpcal`) et entrée radio (`rfcal`) lancées depuis l'appli ; résultats `{"type":"cal","quoi":"cmp|rf","ok":…}` ; `ver` donne `rfc`, `att`, `lna`, `cmpc`.
- **Réglages calculés** (`services/etalonnages.ts`) : pendant les tours d'étalonnage du toit, les niveaux du tag (position prise à `calpos`) donnent le signal du toit à 1 m et l'incertitude (`ajusterDistance`) ; le signal du portatif à 1 m suit la médiane des tags étalonnés ; l'exposant appris sur les nids sert au toit comme au portatif ; la correction d'orientation du toit est envoyée seule.
- Réglages manuels (toit, distance) : en mode expert seulement, pour un dépannage.

## Automatismes (Paramètres → Automatismes, chacun se coupe)
- **Connexion automatique** (`services/connexionAuto.ts`) : scan de 6 s toutes les 30 s tant que le toit ou le portatif n'est pas connecté (premier plan, ou sortie en cours) ; rien après un « Déconnecter », en simulation, ou sans autorisations Bluetooth déjà accordées.
- **Enregistrement de chaque sortie** (`services/essais.ts`) : fichier `sortie_…` dès qu'un appareil est connecté, sans mode brut, arrêté 10 min après la dernière déconnexion ; 10 gardés. Un essai à la main (brut, repères) le remplace.
- **Voiture → pied** (`services/automatismes.ts`) : voiture arrêtée 15 s à moins de 200 m du nid estimé du tag suivi → bandeau et annonce, le portatif suit ce tag et reçoit la flèche (dès sa connexion s'il est éteint), onglet Portatif ouvert.
- **Mode recherche du tag** : demandé à l'arrêt près du nid, ou quand le portatif suit un tag reçu au-dessus de −80 dBm ou à moins de 150 m du nid estimé ; renouvelé tant qu'on cherche ; « fin » envoyé quand le nid est noté ; abandonné après 2 échecs (tag ancien).
- **« Nid trouvé ici ? »** : portatif qui reçoit le tag à moins de ~5 m (P1m − 18 dB) pendant 15-20 s et position stable à 8 m près → question, nid créé pour ce tag (ce qui nourrit l'apprentissage du terrain).
- **Chrono au portatif** (`calc/appat.ts : presencePortatif, tramePortatif`) : un appât lâché à la main est chronométré seul tant que le portatif reste à moins de 30 m ; emporté plus loin, rien n'est conclu.
- **Fin de vie du tag** : contrôle par le tag « mort » → « Noter seulement » ou « Noter + désactiver » (intervention de contrôle pré-remplie « mort », désactivation envoyée dès qu'un relais entend le tag).
- **Recharge notée par le chargeur** : le portatif signale chaque tag posé sur le chargeur (`{"type":"chg",…}`, gardé hors connexion) ; le tag est noté rechargé et disponible, avec sa pile.
- **Réglages appris sur les sorties** (`calc/terrain.ts : vitesseApprise, facteurIncertitude`) : à chaque nid trouvé pour un tag, l'appli garde l'écart réel de l'estimation et les allers-retours à l'appât. Vitesse de vol (médiane, 2 trajets au moins) appliquée seule au chrono ; facteur d'incertitude (3 nids au moins) appliqué au rayon des plans de vol et à l'alerte « nid localisé ».
- **Météo du matin** (`services/meteoMatin.ts`, expo-notifications) : prévision relue à chaque ouverture (3 h au plus), notification à 7 h (réglable) pour chaque jour avec au moins 2 h de bon créneau.
- **Rappels par notification** (`calc/rappels.ts`, `services/rappels.ts`, `services/notifs.ts`) : contrôle d'un nid traité (jour dû, 9 h), piège à relever (9 h), tags à recharger (18 h), tag posé sans nouvelles (9 h) ; un rappel en retard revient chaque jour ; un appui ouvre l'écran concerné. Reprogrammés 20 s après chaque changement du carnet.
- **Avant de partir** (`services/avantDepart.ts`) : en plus des batteries et du GPS, l'appli vérifie les voies du toit, la boussole, les versions, l'étalonnage, la météo du jour ; bandeau 15 s après la connexion (une fois par jour et par appareil) ; les cases cochées à la main restent cochées pour la journée.
- **Mise à jour proposée à la connexion** (`services/paquets.ts`) : les paquets importés sont gardés dans le téléphone ; un toit ou un portatif en retard → « Mettre à jour ? » puis lancement direct ; sans paquet gardé, recherche de `chef…`/`portatif…_mise_a_jour_bluetooth.zip` dans la dernière Release du dépôt.
- **Plan de vol prêt** (`services/plansPrets.ts`) : nid estimé à ± 30 m (incertitude corrigée de l'écart appris) → spirale Litchi calculée, refaite si l'estimation bouge de 15 m ou s'affine ; Menu → Vols du drone → Plans prêts.
- **Tags sans nouvelles → itinéraire** (`calc/itineraire.ts`) : Mes tags → Sans nouvelles → lien Google Maps par les derniers contacts, du plus proche au plus loin (10 au plus).
- **Compte rendu de sortie** (`calc/compteRendu.ts`, `services/sorties.ts`, `app/sorties.tsx`) : sortie = du premier appareil connecté à 30 min après la dernière déconnexion (ou « Terminer la sortie ») ; durée, km en voiture et à pied, tags, nids estimés, trouvés, traités, allers-retours ; notification, partage en texte.

## Transitions et optimisation
- **Transitions** (`ui/anim.ts`, API Animated sur le fil natif) : écrans qui glissent depuis la droite (260 ms), onglets en glissé-fondu (« shift »), cartes qui apparaissent en fondu, boutons qui s'enfoncent (ressort), bandeau d'alerte qui descend puis s'efface, sections et filtres qui se replacent en douceur (LayoutAnimation). Tout est coupé si Android demande de supprimer les animations.
- **Écrans gelés** (`freezeOnBlur`) : un onglet ou un écran caché ne se redessine plus à chaque mesure du toit.
- **Rafraîchissement** : 10 fois par seconde au plus (au lieu de 20) ; sélections étroites de l'état (étalonnage, avant de partir, bandeaux) ; numéros des nids calculés une fois par version du carnet ; carnet des nids en liste virtualisée ; boussole mémorisée.
