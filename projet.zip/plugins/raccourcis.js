/**
 * Raccourcis Android : appui long sur l'icône de l'appli → Poser un tag, Nid trouvé ici, Pièges, Mode conduite.
 * Chaque raccourci ouvre un lien frelons://… que expo-router dirige vers le bon écran.
 */
const { withAndroidManifest, withDangerousMod, withStringsXml, AndroidConfig } = require('expo/config-plugins');
const fs = require('fs');
const path = require('path');

const RACCOURCIS = [
  { id: 'poser_tag', court: 'Poser tag', long: 'Poser un tag', lien: 'frelons://pose-tag',
    icone: 'M20 8h-2.81c-.45-.78-1.07-1.45-1.82-1.96L17 4.41 15.59 3l-2.17 2.17C12.96 5.06 12.49 5 12 5c-.49 0-.96.06-1.41.17L8.41 3 7 4.41l1.62 1.63C7.88 6.55 7.26 7.22 6.81 8H4v2h2.09c-.05.33-.09.66-.09 1v1H4v2h2v1c0 .34.04.67.09 1H4v2h2.81c1.04 1.79 2.97 3 5.19 3s4.15-1.21 5.19-3H20v-2h-2.09c.05-.33.09-.66.09-1v-1h2v-2h-2v-1c0-.34-.04-.67-.09-1H20V8zm-6 8h-4v-2h4v2zm0-4h-4v-2h4v2z' },
  { id: 'nid_ici', court: 'Nid ici', long: 'Nid trouvé ici', lien: 'frelons://nid-ici',
    icone: 'M12 2C8.14 2 5 5.14 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.86-3.14-7-7-7zm4 8h-3v3h-2v-3H8V8h3V5h2v3h3v2z' },
  { id: 'pieges', court: 'Pièges', long: 'Relever un piège', lien: 'frelons://pieges',
    icone: 'M4.25 5.61C6.27 8.2 10 13 10 13v6c0 .55.45 1 1 1h2c.55 0 1-.45 1-1v-6s3.72-4.8 5.74-7.39c.51-.66.04-1.61-.79-1.61H5.04c-.83 0-1.3.95-.79 1.61z' },
  { id: 'conduite', court: 'Conduite', long: 'Mode conduite', lien: 'frelons://conduite',
    icone: 'M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z' },
];

const echapper = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;').replace(/'/g, "\\'");

function fichiers(paquet) {
  const icone = (d) => `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="48dp" android:height="48dp" android:viewportWidth="48" android:viewportHeight="48">
  <path android:fillColor="#14202E" android:pathData="M24,0A24,24 0,1 1,23.99,0Z"/>
  <group android:translateX="12" android:translateY="12"><path android:fillColor="#E8A33A" android:pathData="${d}"/></group>
</vector>
`;
  const xml = `<?xml version="1.0" encoding="utf-8"?>
<shortcuts xmlns:android="http://schemas.android.com/apk/res/android">
${RACCOURCIS.map((r) => `  <shortcut android:shortcutId="${r.id}" android:enabled="true" android:icon="@drawable/raccourci_${r.id}"
    android:shortcutShortLabel="@string/raccourci_${r.id}_court" android:shortcutLongLabel="@string/raccourci_${r.id}_long">
    <intent android:action="android.intent.action.VIEW" android:targetPackage="${paquet}" android:targetClass="${paquet}.MainActivity" android:data="${r.lien}" />
  </shortcut>`).join('\n')}
</shortcuts>
`;
  return { xml, icones: RACCOURCIS.map((r) => [`raccourci_${r.id}.xml`, icone(r.icone)]) };
}

module.exports = function raccourcis(config) {
  const paquet = config.android && config.android.package;
  if (!paquet) throw new Error('raccourcis : android.package manquant dans app.json');

  config = withDangerousMod(config, ['android', async (c) => {
    const res = path.join(c.modRequest.platformProjectRoot, 'app/src/main/res');
    const f = fichiers(paquet);
    fs.mkdirSync(path.join(res, 'xml'), { recursive: true });
    fs.mkdirSync(path.join(res, 'drawable'), { recursive: true });
    fs.writeFileSync(path.join(res, 'xml/raccourcis.xml'), f.xml);
    for (const [nom, contenu] of f.icones) fs.writeFileSync(path.join(res, 'drawable', nom), contenu);
    return c;
  }]);

  config = withStringsXml(config, (c) => {
    for (const r of RACCOURCIS) {
      for (const [suffixe, texte] of [['court', r.court], ['long', r.long]]) {
        c.modResults = AndroidConfig.Strings.setStringItem([{ $: { name: `raccourci_${r.id}_${suffixe}` }, _: echapper(texte) }], c.modResults);
      }
    }
    return c;
  });

  config = withAndroidManifest(config, (c) => {
    const activite = AndroidConfig.Manifest.getMainActivityOrThrow(c.modResults);
    activite['meta-data'] = (activite['meta-data'] || []).filter((m) => m.$['android:name'] !== 'android.app.shortcuts');
    activite['meta-data'].push({ $: { 'android:name': 'android.app.shortcuts', 'android:resource': '@xml/raccourcis' } });
    return c;
  });
  return config;
};
