/** Rejoue la sortie simulée dans les calculs de l'appli et compare au vrai nid. Lancer : npm run test:calculs */
import { SORTIE_SIMULEE } from '../src/sim/sortieSimulee';
import { parseToit } from '../src/proto/toit';
import { ajouterReleve, type Ligne } from '../src/calc/releves';
import { fusionner, type DirectionOeil } from '../src/calc/fusion';
import { distM, niveauPct } from '../src/calc/geo';
import { estRoundtrip } from '../src/calc/estim';
import { chronoVide, lacher, resume, tic, trameToit } from '../src/calc/appat';

const VRAIS: Record<number, [number, number]> = { 7: [45.0483716, 3.8839642], 12: [45.0547042, 3.8780927] };
const lignes: Record<number, Ligne[]> = {};
const oeil: Record<number, DirectionOeil[]> = {};
let nR = 0, nS = 0;
for (const brut of SORTIE_SIMULEE.split('\n')) {
  const m = /^@(\d+),(.*)$/.exec(brut);
  if (!m) continue;
  const t = Number(m[1]), corps = m[2];
  if (corps.startsWith('E,VIS,')) {
    const f = corps.split(',');
    (oeil[+f[2]] ??= []).push({ lat: +f[3], lon: +f[4], deg: +f[5] });
    continue;
  }
  const l = parseToit(corps);
  if (l?.kind === 'R') { nR++; lignes[l.tag] = ajouterReleve(lignes[l.tag] ?? [], l.lat, l.lon, l.abs, l.q, t); }
  if (l?.kind === 'S') nS++;
}
console.log(`lignes R ${nR}, S ${nS}`);
let ok = true;
for (const tag of [7, 12]) {
  const L = lignes[tag] ?? [];
  const f = fusionner({ lignes: L, oeil: oeil[tag] ?? [], portatif: [] });
  const [la, lo] = VRAIS[tag];
  const e = f.ok ? distM(f.lat, f.lon, la, lo) : NaN;
  console.log(`tag ${tag}: ${L.length} relevés (${L.filter((x) => x.ecartee).length} écartés), ${f.nOeil} à l'œil → ` +
    (f.ok ? `nid ${f.lat.toFixed(6)},${f.lon.toFixed(6)} ±${f.errM.toFixed(0)} m, écart au vrai ${e.toFixed(0)} m` : 'pas de nid'));
  if (!f.ok || e > Math.max(60, f.errM)) ok = false;
}
// contrôles simples
const chk = (c: boolean, msg: string) => { if (!c) { ok = false; console.log('ÉCHEC', msg); } };
chk(niveauPct(-100) === 0 && niveauPct(-40) === 100 && niveauPct(-70) === 50 && niveauPct(-128) === null, 'niveauPct');
const rt = estRoundtrip([300, 320, 900]);
chk(rt.ok && Math.abs(rt.r - (3.4 * 245) / 2) < 1, 'estRoundtrip');
// chrono à l'appât : mêmes allers-retours que le rejeu de l'écran voiture (outils/rejeu/exemple/rejeu_rapport.txt)
{
  const c = chronoVide(); let toit: { lat: number; lon: number } | null = null, dt = 0;
  for (const brut of SORTIE_SIMULEE.split('\n')) {
    const m = /^@(\d+),(.*)$/.exec(brut); if (!m) continue;
    const t = Number(m[1]), f = m[2].split(',');
    while (dt + 1000 <= t) { dt += 1000; tic(c, dt); }
    if (f[0] === 'E' && f[1] === 'LACHER') lacher(c, +f[2], +f[3], +f[4], 'voiture', t);
    const l = parseToit(m[2]);
    if (l?.kind === 'S' && l.lat) toit = { lat: l.lat, lon: l.lon };
    if (l?.kind === 'R') trameToit(c, l.tag, Math.max(...l.r), l.abs, l.q, toit, t);
  }
  const a = c.appats[0], r = a && resume(c, a);
  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  const ar = a ? a.trajets.map((x) => fmt(x.dureeS)).join(' ') : '';
  console.log(`appât : [${ar}] -> ${r ? Math.round(r.rt.r) : '?'} m ± ${r ? Math.round(r.rt.sig) : '?'}, cap ${r?.cap?.toFixed(0)}`);
  chk(ar === '4:29 4:34 8:25 4:48 4:35 4:41' && !!r && Math.round(r.rt.r) === 364 && Math.round(r.cap ?? 0) === 115, 'chrono appât');
}
console.log(ok ? 'OK' : 'ÉCHEC');
if (!ok) process.exit(1);
// la compilation GitHub ne lance que ce script : il enchaîne sur les tests des services
import('./test_services');
