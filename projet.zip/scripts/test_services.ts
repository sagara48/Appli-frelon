/** Tests des services sans matériel : CBOR, protocole SMP de mise à jour (appareil simulé), paquets, météo, tuiles. Lancer : npx tsx scripts/test_services.ts */
import { zipSync, strToU8 } from 'fflate';
import { decoder, encoder } from '../src/dfu/cbor';
import { Smp } from '../src/dfu/smp';
import { lirePaquet } from '../src/dfu/paquet';
import { activite, meilleurCreneau } from '../src/services/meteo';
import { latVersY, lonVersX, tuilesDe, xVersLon, yVersLat, zoomPour, compterTuiles } from '../src/calc/tuilesGeo';

let ok = true;
const chk = (c: boolean, m: string) => { console.log(`${c ? 'ok  ' : 'ÉCHEC'} ${m}`); if (!c) ok = false; };
const egal = (a: unknown, b: unknown) => JSON.stringify(a, (_, v) => (v instanceof Uint8Array ? Array.from(v) : v)) === JSON.stringify(b, (_, v) => (v instanceof Uint8Array ? Array.from(v) : v));

// --- CBOR
const obj = { off: 70000, data: new Uint8Array([1, 2, 255]), len: 300, txt: 'éàü€', neg: -500, b: true, n: null, l: [1, 'a', { x: 0 }] };
chk(egal(decoder(encoder(obj)), obj), 'CBOR : aller-retour (entiers 32 bits, octets, texte UTF-8, négatifs, booléens, null, tableaux, tables)');
chk(Array.from(encoder({ off: 0 })).join(',') === [0xa1, 0x63, 0x6f, 0x66, 0x66, 0x00].join(','), 'CBOR : {off:0} encodé comme mcumgr l\'attend');

// --- SMP : appareil simulé (mcumgr) qui reçoit l'image par morceaux, répond en 2 notifications, puis liste les images
const b64 = (u: Uint8Array) => { let x = ''; for (let i = 0; i < u.length; i++) x += String.fromCharCode(u[i]); return btoa(x); };
function fauxAppareil(mtu: number) {
  let cb: ((e: unknown, c: { value: string } | null) => void) | null = null;
  const recu: number[] = []; let etat: Record<string, unknown> | null = null; let reset = false;
  const repondre = (hdr: Uint8Array, corps: Record<string, unknown>) => {
    const d = encoder(corps as never), p = new Uint8Array(8 + d.length);
    p.set([hdr[0] + 1, 0, d.length >> 8, d.length & 0xff, hdr[4], hdr[5], hdr[6], hdr[7]]); p.set(d, 8);
    const coupe = Math.ceil(p.length / 2); // réponse en deux morceaux, comme quand elle dépasse le MTU
    setTimeout(() => { cb?.(null, { value: b64(p.slice(0, coupe)) }); cb?.(null, { value: b64(p.slice(coupe)) }); }, 1);
  };
  const dev = {
    id: 'faux', mtu,
    discoverAllServicesAndCharacteristics: async () => dev,
    monitorCharacteristicForService: (_s: string, _c: string, f: typeof cb) => { cb = f; return { remove: () => { cb = null; } }; },
    writeCharacteristicWithoutResponseForService: async (_s: string, _c: string, v: string) => {
      const p = Uint8Array.from(atob(v), (ch) => ch.charCodeAt(0));
      if (p.length > mtu - 3) throw new Error(`paquet trop long (${p.length} > ${mtu - 3})`);
      const len = (p[2] << 8) | p[3], grp = (p[4] << 8) | p[5], id = p[7];
      const c = decoder(p.slice(8, 8 + len)) as Record<string, unknown>;
      if (grp === 1 && id === 1) { // upload
        if ((c.off as number) !== recu.length) { repondre(p, { rc: 0, off: recu.length }); return; }
        recu.push(...(c.data as Uint8Array)); repondre(p, { rc: 0, off: recu.length });
      } else if (grp === 1 && id === 0 && p[0] === 0) repondre(p, { images: [{ slot: 0, version: '0.0.0', hash: new Uint8Array([1]), active: true, confirmed: true }, { slot: 1, version: '0.1.0', hash: new Uint8Array([9, 9]) }] });
      else if (grp === 1 && id === 0) { etat = c; repondre(p, { images: [] }); }
      else if (grp === 0 && id === 5) { reset = true; repondre(p, {}); }
    },
  };
  return { dev, recu, etat: () => etat, reset: () => reset };
}
(async () => {
  const img = Uint8Array.from({ length: 50000 }, (_, i) => (i * 7) & 0xff);
  const f = fauxAppareil(185);
  const smp = new Smp(f.dev as never, 185);
  await smp.ouvrir();
  const imgs = await smp.images();
  chk(imgs.length === 2 && imgs[0].active && imgs[1].version === '0.1.0', 'SMP : liste des images (réponse en 2 notifications)');
  let derniers = 0;
  await smp.envoyer(img, (fait) => { derniers = fait; }, () => false);
  chk(f.recu.length === img.length && f.recu.every((x, i) => x === img[i]), `SMP : image de 50 ko reçue intacte en paquets ≤ MTU (avancement ${derniers})`);
  await smp.installer();
  const e = f.etat();
  chk(!!e && e.confirm === false && egal(e.hash, new Uint8Array([9, 9])) && f.reset(), 'SMP : image marquée « à essayer » puis redémarrage');
  smp.fermer();

  // --- paquet de mise à jour
  const manifest = { name: 'rx_v2', time: 1794378107, files: [{ file: 'rx_v2.signed.bin', size: 4, version_MCUBOOT: '1.2.0+0' }] };
  const zip = zipSync({ 'manifest.json': strToU8(JSON.stringify(manifest)), 'rx_v2.signed.bin': new Uint8Array([1, 2, 3, 4]) });
  const p = lirePaquet(zip, 'x.zip');
  chk(p.appareil === 'portatif' && p.version === '1.2.0' && p.image.length === 4, 'Paquet : portatif reconnu, version et image lues');
  let refuse = false; try { lirePaquet(zipSync({ 'a.txt': strToU8('x') }), 'a.zip'); } catch { refuse = true; }
  chk(refuse, 'Paquet : un zip sans manifest est refusé');

  // --- météo
  chk(activite(18, 5, 0) === 3 && activite(13, 5, 0) === 2 && activite(18, 30, 0) === 1 && activite(18, 5, 2) === 0 && activite(5, 0, 0) === 0, 'Météo : niveaux d\'activité');
  const h = [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19].map((x) => ({ h: x, temp: x >= 12 && x < 16 ? 17 : 9, vent: 5, dirVent: 0, pluie: 0, activite: activite(x >= 12 && x < 16 ? 17 : 9, 5, 0) }));
  const cr = meilleurCreneau(h);
  chk(!!cr && cr.debut === 12 && cr.fin === 16, 'Météo : meilleur créneau 12 h – 16 h');

  // --- tuiles IGN
  const z = 15, lat = 45.05, lon = 3.88;
  chk(Math.abs(xVersLon(lonVersX(lon, z), z) - lon) < 1e-9 && Math.abs(yVersLat(latVersY(lat, z), z) - lat) < 1e-9, 'Tuiles : conversions lat/lon ↔ tuile réversibles');
  chk(zoomPour(45, 2.4) === 16 || zoomPour(45, 2.4) === 17, 'Tuiles : niveau adapté à ~2 m/pixel');
  const n = compterTuiles({ lat, lon, largeurKm: 8, hauteurKm: 6, couches: ['plan'] });
  chk(n > 200 && n < 600, `Tuiles : zone 8 × 6 km = ${n} tuiles (niveaux 12 à 16)`);
  chk(tuilesDe(45.06, 3.87, 45.04, 3.89, 16).length > 0, 'Tuiles : rectangle → tuiles');

  console.log(ok ? 'OK' : 'ÉCHEC');
  process.exit(ok ? 0 : 1);
})();
