/** Tests des services sans matériel : CBOR, protocole SMP de mise à jour (appareil simulé), paquets, météo, tuiles. Lancer : npx tsx scripts/test_services.ts */
import { zipSync, strToU8 } from 'fflate';
import { decoder, encoder } from '../src/dfu/cbor';
import { Smp } from '../src/dfu/smp';
import { lirePaquet } from '../src/dfu/paquet';
import { activite, meilleurCreneau } from '../src/services/meteo';
import { latVersY, lonVersX, tuilesDe, xVersLon, yVersLat, zoomPour, compterTuiles } from '../src/calc/tuilesGeo';

let ok = true;
const chk = (c: boolean, m: string) => { console.log(`${c ? 'ok  ' : 'ÉCHEC'} ${m}`); if (!c) ok = false; };
const egal = (a: unknown, b: unknown) => JSON.stringify(a, (_, v) => (v instanceof Uint8Array ? Array.from(v) : v)) === JSON.stringify(b, (_, v) => (v instanceof Uint8Array ? Array.from(v) : v));

// --- CBOR
const obj = { off: 70000, data: new Uint8Array([1, 2, 255]), len: 300, txt: 'éàü€', neg: -500, b: true, n: null, l: [1, 'a', { x: 0 }] };
chk(egal(decoder(encoder(obj)), obj), 'CBOR : aller-retour (entiers 32 bits, octets, texte UTF-8, négatifs, booléens, null, tableaux, tables)');
chk(Array.from(encoder({ off: 0 })).join(',') === [0xa1, 0x63, 0x6f, 0x66, 0x66, 0x00].join(','), 'CBOR : {off:0} encodé comme mcumgr l\'attend');

// --- SMP : appareil simulé (mcumgr) qui reçoit l'image par morceaux, répond en 2 notifications, puis liste les images
const b64 = (u: Uint8Array) => { let x = ''; for (let i = 0; i < u.length; i++) x += String.fromCharCode(u[i]); return btoa(x); };
function fauxAppareil(mtu: number) {
  let cb: ((e: unknown, c: { value: string } | null) => void) | null = null;
  const recu: number[] = []; let etat: Record<string, unknown> | null = null; let reset = false;
  const repondre = (hdr: Uint8Array, corps: Record<string, unknown>) => {
    const d = encoder(corps as never), p = new Uint8Array(8 + d.length);
    p.set([hdr[0] + 1, 0, d.length >> 8, d.length & 0xff, hdr[4], hdr[5], hdr[6], hdr[7]]); p.set(d, 8);
    const coupe = Math.ceil(p.length / 2); // réponse en deux morceaux, comme quand elle dépasse le MTU
    setTimeout(() => { cb?.(null, { value: b64(p.slice(0, coupe)) }); cb?.(null, { value: b64(p.slice(coupe)) }); }, 1);
  };
  const dev = {
    id: 'faux', mtu,
    discoverAllServicesAndCharacteristics: async () => dev,
    monitorCharacteristicForService: (_s: string, _c: string, f: typeof cb) => { cb = f; return { remove: () => { cb = null; } }; },
    writeCharacteristicWithoutResponseForService: async (_s: string, _c: string, v: string) => {
      const p = Uint8Array.from(atob(v), (ch) => ch.charCodeAt(0));
      if (p.length > mtu - 3) throw new Error(`paquet trop long (${p.length} > ${mtu - 3})`);
      const len = (p[2] << 8) | p[3], grp = (p[4] << 8) | p[5], id = p[7];
      const c = decoder(p.slice(8, 8 + len)) as Record<string, unknown>;
      if (grp === 1 && id === 1) { // upload
        if ((c.off as number) !== recu.length) { repondre(p, { rc: 0, off: recu.length }); return; }
        recu.push(...(c.data as Uint8Array)); repondre(p, { rc: 0, off: recu.length });
      } else if (grp === 1 && id === 0 && p[0] === 0) repondre(p, { images: [{ slot: 0, version: '0.0.0', hash: new Uint8Array([1]), active: true, confirmed: true }, { slot: 1, version: '0.1.0', hash: new Uint8Array([9, 9]) }] });
      else if (grp === 1 && id === 0) { etat = c; repondre(p, { images: [] }); }
      else if (grp === 0 && id === 5) { reset = true; repondre(p, {}); }
    },
  };
  return { dev, recu, etat: () => etat, reset: () => reset };
}
(async () => {
  const img = Uint8Array.from({ length: 50000 }, (_, i) => (i * 7) & 0xff);
  const f = fauxAppareil(185);
  const smp = new Smp(f.dev as never, 185);
  await smp.ouvrir();
  const imgs = await smp.images();
  chk(imgs.length === 2 && imgs[0].active && imgs[1].version === '0.1.0', 'SMP : liste des images (réponse en 2 notifications)');
  let derniers = 0;
  await smp.envoyer(img, (fait) => { derniers = fait; }, () => false);
  chk(f.recu.length === img.length && f.recu.every((x, i) => x === img[i]), `SMP : image de 50 ko reçue intacte en paquets ≤ MTU (avancement ${derniers})`);
  await smp.installer();
  const e = f.etat();
  chk(!!e && e.confirm === false && egal(e.hash, new Uint8Array([9, 9])) && f.reset(), 'SMP : image marquée « à essayer » puis redémarrage');
  smp.fermer();

  // --- paquet de mise à jour
  const manifest = { name: 'rx_v2', time: 1794378107, files: [{ file: 'rx_v2.signed.bin', size: 4, version_MCUBOOT: '1.2.0+0' }] };
  const zip = zipSync({ 'manifest.json': strToU8(JSON.stringify(manifest)), 'rx_v2.signed.bin': new Uint8Array([1, 2, 3, 4]) });
  const p = lirePaquet(zip, 'x.zip');
  chk(p.appareil === 'portatif' && p.version === '1.2.0' && p.image.length === 4, 'Paquet : portatif reconnu, version et image lues');
  let refuse = false; try { lirePaquet(zipSync({ 'a.txt': strToU8('x') }), 'a.zip'); } catch { refuse = true; }
  chk(refuse, 'Paquet : un zip sans manifest est refusé');

  // --- météo
  chk(activite(18, 5, 0) === 3 && activite(13, 5, 0) === 2 && activite(18, 30, 0) === 1 && activite(18, 5, 2) === 0 && activite(5, 0, 0) === 0, 'Météo : niveaux d\'activité');
  const h = [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19].map((x) => ({ h: x, temp: x >= 12 && x < 16 ? 17 : 9, vent: 5, dirVent: 0, pluie: 0, activite: activite(x >= 12 && x < 16 ? 17 : 9, 5, 0) }));
  const cr = meilleurCreneau(h);
  chk(!!cr && cr.debut === 12 && cr.fin === 16, 'Météo : meilleur créneau 12 h – 16 h');

  // --- tuiles IGN
  const z = 15, lat = 45.05, lon = 3.88;
  chk(Math.abs(xVersLon(lonVersX(lon, z), z) - lon) < 1e-9 && Math.abs(yVersLat(latVersY(lat, z), z) - lat) < 1e-9, 'Tuiles : conversions lat/lon ↔ tuile réversibles');
  chk(zoomPour(45, 2.4) === 16 || zoomPour(45, 2.4) === 17, 'Tuiles : niveau adapté à ~2 m/pixel');
  const n = compterTuiles({ lat, lon, largeurKm: 8, hauteurKm: 6, couches: ['plan'] });
  chk(n > 200 && n < 600, `Tuiles : zone 8 × 6 km = ${n} tuiles (niveaux 12 à 16)`);
  chk(tuilesDe(45.06, 3.87, 45.04, 3.89, 16).length > 0, 'Tuiles : rectangle → tuiles');


// --- journal de mise au point
{
  const J = await import('../src/services/journal');
  J.viderJournal();
  J.journaliser('toit', 'recu', 'S,1,2,3', false); J.journaliser('toit', 'recu', 'n\'importe quoi', true);
  J.journaliser('portatif', 'envoye', 'clr'); J.journaliser('maj', 'erreur', 'Nacelle non trouvée');
  for (let i = 0; i < 5100; i++) J.journaliser('toit', 'recu', 'x');
  const l = J.lireJournal();
  const txt = J.texteJournal(l.slice(0, 0).concat([{ n: 1, t: 0, app: 'toit', sens: 'recu', txt: 'abc', incomprise: true }]), ['T']);
  chk(l.length === 5000 && l[l.length - 1].txt === 'x' && txt.includes('1 lignes reçues (1 non comprises)') && txt.includes('< abc   [non comprise]'), 'Journal : limite 5 000 lignes, résumé et format d\'export');
  J.activerJournal(false); J.journaliser('toit', 'recu', 'y'); chk(J.lireJournal().length === 5000, 'Journal : rien n\'est gardé quand l\'enregistrement est coupé');
  J.activerJournal(true); J.viderJournal();
}


// --- banc d'essai
{
  const B = await import('../src/calc/banc');
  const ids = B.CARTES.flatMap((c) => c.etapes.map((x) => x.id));
  chk(new Set(ids).size === ids.length, `Banc : ${ids.length} étapes, identifiants uniques`);
  const v = { unite: 'V', min: 3.2, max: 3.4 };
  chk(B.mesureOk(v, '3,30') === true && B.mesureOk(v, '3.1') === false && B.mesureOk(v, 'abc') === false && B.mesureOk(v, '') === null && B.mesureOk({ unite: 'g' }, '120') === null, 'Banc : jugement des mesures (virgule, hors plage, sans plage)');
  const txt = B.texteBanc({ 'ch-3v3': { ok: true, t: 0, val: '3,1' } }, { chargeur: 'LED 4 faible' });
  chk(txt.includes('3,1 V (HORS PLAGE)') && txt.includes('Notes : LED 4 faible') && txt.includes('(1/'), 'Banc : export de la fiche');
}


// --- sauvegarde du carnet
{
  const Z = await import('../src/calc/sauvegardeZip');
  const s0 = { version: 1 as const, date: 1, nids: [{ id: 1, uid: 'a', photos: JSON.stringify(['file:///x/photos/nid1_1.jpg', 'file:///x/photos/perdue.jpg']), supprime: 0 }], tags: [{ id: 7 }], ruchers: [], reglages: [{ cle: 'alertes', valeur: '{}' }] };
  const r = Z.construireZip(s0, (u) => (u.includes('perdue') ? null : new Uint8Array([1, 2, 3])));
  const l = Z.lireZip(r.zip);
  chk(r.photos === 1 && r.manquantes === 1 && l.photos['nid1_1.jpg']?.length === 3 && JSON.parse(String(l.s.nids[0].photos))[0] === 'nid1_1.jpg' && l.s.tags.length === 1,
    'Sauvegarde : zip avec photos, photo manquante signalée, relecture');
  let refuse = '';
  try { Z.lireZip(new Uint8Array([1, 2, 3])); } catch (e) { refuse = (e as Error).message; }
  chk(/pas un zip/.test(refuse), 'Sauvegarde : fichier quelconque refusé avec un message clair');
}


// --- saison : pièges, ruchers, comparaison, densité, recharge
{
  const Sa = await import('../src/calc/saison');
  const J = 86400000, t0 = new Date(2026, 6, 15).getTime();
  const nid = (id: number, lat: number, lon: number, t: number, etat = 'trouve', traite_ms: number | null = null) => ({
    id, tag: -1, t, lat, lon, err: 20, etat, note: '', sources: '', support: '', hauteur: '', diametre: '', activite: '', photos: [], inter_ms: null,
    methode: '', produit: '', quantite: '', operateur: '', traite_ms, verifie_ms: null, uid: String(id), maj_ms: t, auteur: '' }) as any;
  const r = { id: 1, nom: 'Bas', ruches: 10, lat: 45.0, lon: 3.88, note: '', uid: 'r', maj_ms: 0, auteur: '' };
  const nids = [nid(1, 45.005, 3.88, t0, 'traite', t0 + 2 * J), nid(2, 45.02, 3.88, t0 + 3 * J), nid(3, 45.0, 3.88, new Date(2025, 7, 1).getTime(), 'mort', new Date(2025, 7, 5).getTime())];
  const pg = { id: 1, nom: 'P', lat: 45.001, lon: 3.881, appat: '', pose_ms: new Date(2026, 2, 1).getTime(), retire_ms: null, note: '', uid: 'p', maj_ms: 0, auteur: '',
    releves: [{ t: new Date(2026, 2, 10).getTime(), frelons: 3, autres: 1, note: '' }, { t: new Date(2026, 2, 20).getTime(), frelons: 5, autres: 0, note: '' }, { t: new Date(2025, 3, 1).getTime(), frelons: 9, autres: 0, note: '' }] };
  const st = Sa.statsRucher(r, nids, [pg], 2026);
  chk(st.n1km === 1 && st.n3km === 2 && st.detruits === 1 && st.aTraiter === 1 && Math.abs(st.plusProche!.d - 556) < 5 && st.pieges === 1 && st.captures === 8,
    'Saison : statistiques d\'un rucher (1 km / 3 km, détruits, plus proche, pièges)');
  const c = Sa.comparerSaisons(nids, [r], [pg]);
  chk(c.length === 2 && c[0].annee === 2026 && c[0].nids === 2 && c[0].detruits === 1 && Math.abs(c[0].delaiTraitementJ! - 2) < 1e-6 && c[0].captures === 8 && c[1].captures === 9 && c[0].parMois[6] === 2,
    'Saison : comparaison des années (nids, délai de traitement, captures, par mois)');
  chk(Sa.aRelever(pg, new Date(2026, 2, 21).getTime()) === false && Sa.aRelever(pg, new Date(2026, 3, 1).getTime()) === true && Sa.capturesParSemaine([pg], 2026).length === 2,
    'Saison : piège à relever après 7 jours, captures par semaine');
  const pos = (p: { lat: number; lon: number }) => ({ x: (p.lon - 3.88) * 78000 / 10 + 150, y: 150 - (p.lat - 45.0) * 111000 / 10 });
  const g = Sa.grilleDensite([{ lat: 45.0, lon: 3.88 }, { lat: 45.0005, lon: 3.8805 }], pos, 300, 300, 10);
  const pic = g.reduce((a, b) => (b.v > a.v ? b : a), g[0]);
  chk(g.length > 10 && pic.v === 1 && Math.hypot(pic.x - 150, pic.y - 150) < 30 && Sa.grilleDensite([], pos, 300, 300, 10).length === 0, 'Saison : densité centrée sur les nids');
  const f = (o: object) => ({ id: 1, etat: 'dispo', pose_ms: null, appat: null, lat: null, lon: null, note: '', maj_ms: 0, pile: null, pile_ms: null, recharge_ms: null, ...o }) as any;
  const N = new Date(2026, 6, 20).getTime();
  chk(Sa.raisonRecharge(f({ recharge_ms: N - J }), N) === null && Sa.raisonRecharge(f({ recharge_ms: N - 9 * J }), N) === 'ancien'
    && Sa.raisonRecharge(f({ recharge_ms: N - J, pose_ms: N - 3600e3, etat: 'recupere' }), N) === 'pose'
    && Sa.raisonRecharge(f({ recharge_ms: N - 2 * J, pile: 30, pile_ms: N - J }), N) === 'pile' && Sa.raisonRecharge(f({ recharge_ms: N - J, pile: 30, pile_ms: N - 2 * J }), N) === null
    && Sa.raisonRecharge(f({}), N) === 'jamais' && Sa.raisonRecharge(f({ etat: 'perdu' }), N) === null,
    'Saison : raisons de recharge (pile, a servi, ancienne, jamais notée)');
}


// --- export GDSA (classeur Excel)
{
  const X = await import('../src/calc/xlsx'), G = await import('../src/calc/exportGdsa');
  const { unzipSync: dez, strFromU8: txt } = await import('fflate');
  const t = new Date(2026, 6, 1).getTime();
  const nid = { id: 1, tag: -1, t, lat: 45.01, lon: 3.88, err: 25, etat: 'traite', note: 'A & B <test>', sources: '', support: 'chêne', hauteur: '12 m', diametre: '', activite: '', photos: [],
    inter_ms: null, methode: 'perche', produit: '', quantite: '', operateur: 'N. 12345', traite_ms: t + 86400000, verifie_ms: null, uid: 'n', maj_ms: t, auteur: 'Nicolas' } as any;
  const d = { nids: [nid], ruchers: [{ id: 1, nom: 'Bas', ruches: 8, lat: 45.0, lon: 3.88, note: '', uid: 'r', maj_ms: 0, auteur: '' }], pieges: [], annee: 2026, auteur: 'Nicolas', maintenant: t };
  const z = dez(X.classeurXlsx(G.feuillesGdsa(d)));
  const wb = txt(z['xl/workbook.xml']), s2 = txt(z['xl/worksheets/sheet2.xml']);
  chk(Object.keys(z).filter((k) => k.startsWith('xl/worksheets/')).length === 5 && wb.includes('name="Relevés des pièges"') && s2.includes('A &amp; B &lt;test&gt;') && s2.includes('<v>45.01</v>'),
    'Export GDSA : classeur de 5 feuilles, texte échappé, nombres');
  const r = G.resumeGdsa(d);
  chk(r.nids === 1 && r.detruits === 1 && r.parRucher[0].n3km === 1 && G.rapportHtml(r).includes('saison 2026'), 'Export GDSA : résumé et rapport');
}


// --- calendrier de saison
{
  const K = await import('../src/calc/calendrier');
  const j10 = new Date(2027, 0, 10).getTime(), n11 = new Date(2026, 10, 11).getTime(), m3 = new Date(2026, 2, 3).getTime();
  const hiver = K.etapesDatees(j10).find((e) => e.id === 'hiver')!;
  chk(hiver.etat === 'en-cours' && hiver.saison === 2026 && new Date(hiver.finMs).getMonth() === 1, 'Calendrier : étape d\'hiver à cheval sur deux années');
  const e11 = K.etapesDatees(n11);
  chk(e11.find((e) => e.id === 'bilan')!.etat === 'en-cours' && e11.find((e) => e.id === 'hiver')!.etat === 'a-venir' && e11.find((e) => e.id === 'pieges')!.etat === 'passee', 'Calendrier : états au 11 novembre');
  const r = K.aRappeler(m3, {}, {});
  chk(r.some((e) => e.id === 'pieges') && K.aRappeler(m3, {}, { 'pieges-2026': true }).every((e) => e.id !== 'pieges') && K.aRappeler(m3, { 'pieges-2026': true }, {}).every((e) => e.id !== 'pieges'),
    'Calendrier : rappel une seule fois, pas si fait');
  chk(K.etapesDatees(new Date(2026, 1, 25).getTime(), -7).find((e) => e.id === 'pieges')!.etat === 'en-cours' && K.etapesDatees(new Date(2026, 1, 25).getTime(), 0).find((e) => e.id === 'pieges')!.etat === 'a-venir',
    'Calendrier : décalage du secteur');
}


// --- paramètres
{
  const Pm = await import('../src/calc/parametres');
  const K = await import('../src/calc/calendrier');
  const p = Pm.normaliser({ tagPerduS: '90', pileFaiblePct: 500, zoneNidM: 'abc', nomToit: '  ', nom: ' Nicolas ', rayonMenaceM: 1234.6, tempMin: '11,5', inconnu: 3 });
  chk(p.tagPerduS === 90 && p.pileFaiblePct === 90 && p.zoneNidM === 10 && p.nomToit === 'TOIT-Frelons' && p.nom === 'Nicolas' && p.rayonMenaceM === 1235 && p.tempMin === 11.5 && !('inconnu' in p),
    'Paramètres : défauts, bornes, entiers, virgule, textes vides');
  const cles = Pm.DEFINITIONS.flatMap((x) => x.params.map((d) => d.cle));
  chk(cles.length === Object.keys(Pm.DEFAUTS).length && new Set(cles).size === cles.length && Pm.listeAppats(p).length === 4 && Pm.depotValide('a-b/c.d') && !Pm.depotValide('pas un dépôt'),
    'Paramètres : chaque valeur a sa ligne dans l\'écran, appâts, dépôt');
  chk(String(K.lireJourMois('15/03')) === '15,3' && K.lireJourMois('31/04') === null && String(K.lireJourMois('29/2')) === '29,2' && K.jourMois([5, 9]) === '05/09',
    'Calendrier : saisie des dates jj/mm');
  const pg = K.etapesDatees(new Date(2026, 1, 20).getTime(), 0, { pieges: { debut: [15, 2], fin: [30, 4] } }).find((e) => e.id === 'pieges')!;
  chk(pg.etat === 'en-cours' && new Date(pg.finMs).getMonth() === 3, 'Calendrier : dates choisies par l\'utilisateur');
}


// --- versions des firmwares
{
  const Vs = await import('../src/calc/versions');
  const { parseToit: pt } = await import('../src/proto/toit');
  const { parsePortatif: pp } = await import('../src/proto/portatif');
  const v = pt('V,1.1.0,1,1,1,0,1') as any, vp = pp('{"type":"ver","fw":"1.0.3","proto":1}') as any;
  chk(v?.kind === 'V' && v.fw === '1.1.0' && v.proto === 1 && v.voies.join() === '1,1,0,1' && vp?.type === 'ver' && vp.fw === '1.0.3' && pt('V') === null,
    'Versions : lignes V du toit et « ver » du portatif');
  const r = (o: object) => ({ fw: '1.1.0', proto: 1, recuMs: 0, ...o });
  chk(Vs.verdict('toit', null) === null && Vs.verdict('toit', r({ voies: [1, 1, 1, 1] }))!.etat === 'ok' && Vs.verdict('portatif', r({ fw: '1.0.3' }))!.etat === 'maj'
    && Vs.verdict('toit', r({ proto: 0 }))!.etat === 'firmware' && Vs.verdict('portatif', r({ proto: 2 }))!.etat === 'appli' && Vs.verdict('toit', r({ absente: true }))!.etat === 'inconnu'
    && Vs.comparerVersions('1.10.0', '1.9.9') === 1 && Vs.comparerVersions('1.1.0+3', '1.1.0') === 0,
    'Versions : verdicts (à jour, mise à jour proposée, firmware ou appli trop ancien, inconnu)');
}


// --- distance d'après le signal
{
  const D = await import('../src/calc/distance');
  const mod = { ref1m: -25, n: 2.5, margeDb: 6 };
  const d = D.distanceRssi(-75, mod)!;
  chk(Math.abs(d.m - 100) < 0.5 && d.min < d.m && d.max > d.m && D.distanceRssi(-128, mod) === null && Math.abs(D.refDepuisMesure(-57.5, 20, 2.5) - (-25)) < 0.05,
    'Distance : 100 m pour −75 dBm, fourchette, voie muette, étalonnage');
  chk(D.arrondiDistance(23) === '25 m' && D.arrondiDistance(123) === '120 m' && D.arrondiDistance(333) === '350 m' && D.arrondiDistance(1530) === '1,5 km' && D.texteDistance(d).court === '≈ 100 m',
    'Distance : arrondis lisibles');
}

  console.log(ok ? 'OK' : 'ÉCHEC');
  process.exit(ok ? 0 : 1);
})();
