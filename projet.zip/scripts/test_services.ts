/** Tests des services sans matériel : CBOR, protocole SMP de mise à jour (appareil simulé), paquets, météo, tuiles. Lancer : npx tsx scripts/test_services.ts */
import { zipSync, strToU8 } from 'fflate';
import { decoder, encoder } from '../src/dfu/cbor';
import { Smp } from '../src/dfu/smp';
import { lirePaquet } from '../src/dfu/paquet';
import { activite, meilleurCreneau } from '../src/services/meteo';
import { latVersY, lonVersX, tuilesDe, xVersLon, yVersLat, zoomPour, compterTuiles } from '../src/calc/tuilesGeo';

let ok = true;
const chk = (c: boolean, m: string) => { console.log(`${c ? 'ok  ' : 'ÉCHEC'} ${m}`); if (!c) ok = false; };
const egal = (a: unknown, b: unknown) => JSON.stringify(a, (_, v) => (v instanceof Uint8Array ? Array.from(v) : v)) === JSON.stringify(b, (_, v) => (v instanceof Uint8Array ? Array.from(v) : v));

// --- CBOR
const obj = { off: 70000, data: new Uint8Array([1, 2, 255]), len: 300, txt: 'éàü€', neg: -500, b: true, n: null, l: [1, 'a', { x: 0 }] };
chk(egal(decoder(encoder(obj)), obj), 'CBOR : aller-retour (entiers 32 bits, octets, texte UTF-8, négatifs, booléens, null, tableaux, tables)');
chk(Array.from(encoder({ off: 0 })).join(',') === [0xa1, 0x63, 0x6f, 0x66, 0x66, 0x00].join(','), 'CBOR : {off:0} encodé comme mcumgr l\'attend');

// --- SMP : appareil simulé (mcumgr) qui reçoit l'image par morceaux, répond en 2 notifications, puis liste les images
const b64 = (u: Uint8Array) => { let x = ''; for (let i = 0; i < u.length; i++) x += String.fromCharCode(u[i]); return btoa(x); };
function fauxAppareil(mtu: number) {
  let cb: ((e: unknown, c: { value: string } | null) => void) | null = null;
  const recu: number[] = []; let etat: Record<string, unknown> | null = null; let reset = false;
  const repondre = (hdr: Uint8Array, corps: Record<string, unknown>) => {
    const d = encoder(corps as never), p = new Uint8Array(8 + d.length);
    p.set([hdr[0] + 1, 0, d.length >> 8, d.length & 0xff, hdr[4], hdr[5], hdr[6], hdr[7]]); p.set(d, 8);
    const coupe = Math.ceil(p.length / 2); // réponse en deux morceaux, comme quand elle dépasse le MTU
    setTimeout(() => { cb?.(null, { value: b64(p.slice(0, coupe)) }); cb?.(null, { value: b64(p.slice(coupe)) }); }, 1);
  };
  const dev = {
    id: 'faux', mtu,
    discoverAllServicesAndCharacteristics: async () => dev,
    monitorCharacteristicForService: (_s: string, _c: string, f: typeof cb) => { cb = f; return { remove: () => { cb = null; } }; },
    writeCharacteristicWithoutResponseForService: async (_s: string, _c: string, v: string) => {
      const p = Uint8Array.from(atob(v), (ch) => ch.charCodeAt(0));
      if (p.length > mtu - 3) throw new Error(`paquet trop long (${p.length} > ${mtu - 3})`);
      const len = (p[2] << 8) | p[3], grp = (p[4] << 8) | p[5], id = p[7];
      const c = decoder(p.slice(8, 8 + len)) as Record<string, unknown>;
      if (grp === 1 && id === 1) { // upload
        if ((c.off as number) !== recu.length) { repondre(p, { rc: 0, off: recu.length }); return; }
        recu.push(...(c.data as Uint8Array)); repondre(p, { rc: 0, off: recu.length });
      } else if (grp === 1 && id === 0 && p[0] === 0) repondre(p, { images: [{ slot: 0, version: '0.0.0', hash: new Uint8Array([1]), active: true, confirmed: true }, { slot: 1, version: '0.1.0', hash: new Uint8Array([9, 9]) }] });
      else if (grp === 1 && id === 0) { etat = c; repondre(p, { images: [] }); }
      else if (grp === 0 && id === 5) { reset = true; repondre(p, {}); }
    },
  };
  return { dev, recu, etat: () => etat, reset: () => reset };
}
(async () => {
  const img = Uint8Array.from({ length: 50000 }, (_, i) => (i * 7) & 0xff);
  const f = fauxAppareil(185);
  const smp = new Smp(f.dev as never, 185);
  await smp.ouvrir();
  const imgs = await smp.images();
  chk(imgs.length === 2 && imgs[0].active && imgs[1].version === '0.1.0', 'SMP : liste des images (réponse en 2 notifications)');
  let derniers = 0;
  await smp.envoyer(img, (fait) => { derniers = fait; }, () => false);
  chk(f.recu.length === img.length && f.recu.every((x, i) => x === img[i]), `SMP : image de 50 ko reçue intacte en paquets ≤ MTU (avancement ${derniers})`);
  await smp.installer();
  const e = f.etat();
  chk(!!e && e.confirm === false && egal(e.hash, new Uint8Array([9, 9])) && f.reset(), 'SMP : image marquée « à essayer » puis redémarrage');
  smp.fermer();

  // --- paquet de mise à jour
  const manifest = { name: 'rx_v2', time: 1794378107, files: [{ file: 'rx_v2.signed.bin', size: 4, version_MCUBOOT: '1.2.0+0' }] };
  const zip = zipSync({ 'manifest.json': strToU8(JSON.stringify(manifest)), 'rx_v2.signed.bin': new Uint8Array([1, 2, 3, 4]) });
  const p = lirePaquet(zip, 'x.zip');
  chk(p.appareil === 'portatif' && p.version === '1.2.0' && p.image.length === 4, 'Paquet : portatif reconnu, version et image lues');
  let refuse = false; try { lirePaquet(zipSync({ 'a.txt': strToU8('x') }), 'a.zip'); } catch { refuse = true; }
  chk(refuse, 'Paquet : un zip sans manifest est refusé');

  // --- météo
  chk(activite(18, 5, 0) === 3 && activite(13, 5, 0) === 2 && activite(18, 30, 0) === 1 && activite(18, 5, 2) === 0 && activite(5, 0, 0) === 0, 'Météo : niveaux d\'activité');
  const h = [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19].map((x) => ({ h: x, temp: x >= 12 && x < 16 ? 17 : 9, vent: 5, dirVent: 0, pluie: 0, activite: activite(x >= 12 && x < 16 ? 17 : 9, 5, 0) }));
  const cr = meilleurCreneau(h);
  chk(!!cr && cr.debut === 12 && cr.fin === 16, 'Météo : meilleur créneau 12 h – 16 h');

  // --- tuiles IGN
  const z = 15, lat = 45.05, lon = 3.88;
  chk(Math.abs(xVersLon(lonVersX(lon, z), z) - lon) < 1e-9 && Math.abs(yVersLat(latVersY(lat, z), z) - lat) < 1e-9, 'Tuiles : conversions lat/lon ↔ tuile réversibles');
  chk(zoomPour(45, 2.4) === 16 || zoomPour(45, 2.4) === 17, 'Tuiles : niveau adapté à ~2 m/pixel');
  const n = compterTuiles({ lat, lon, largeurKm: 8, hauteurKm: 6, couches: ['plan'] });
  chk(n > 200 && n < 600, `Tuiles : zone 8 × 6 km = ${n} tuiles (niveaux 12 à 16)`);
  chk(tuilesDe(45.06, 3.87, 45.04, 3.89, 16).length > 0, 'Tuiles : rectangle → tuiles');


// --- journal de mise au point
{
  const J = await import('../src/services/journal');
  J.viderJournal();
  J.journaliser('toit', 'recu', 'S,1,2,3', false); J.journaliser('toit', 'recu', 'n\'importe quoi', true);
  J.journaliser('portatif', 'envoye', 'clr'); J.journaliser('maj', 'erreur', 'Nacelle non trouvée');
  for (let i = 0; i < 5100; i++) J.journaliser('toit', 'recu', 'x');
  const l = J.lireJournal();
  const txt = J.texteJournal(l.slice(0, 0).concat([{ n: 1, t: 0, app: 'toit', sens: 'recu', txt: 'abc', incomprise: true }]), ['T']);
  chk(l.length === 5000 && l[l.length - 1].txt === 'x' && txt.includes('1 lignes reçues (1 non comprises)') && txt.includes('< abc   [non comprise]'), 'Journal : limite 5 000 lignes, résumé et format d\'export');
  J.activerJournal(false); J.journaliser('toit', 'recu', 'y'); chk(J.lireJournal().length === 5000, 'Journal : rien n\'est gardé quand l\'enregistrement est coupé');
  J.activerJournal(true); J.viderJournal();
}


// --- banc d'essai
{
  const B = await import('../src/calc/banc');
  const ids = B.CARTES.flatMap((c) => c.etapes.map((x) => x.id));
  chk(new Set(ids).size === ids.length, `Banc : ${ids.length} étapes, identifiants uniques`);
  const v = { unite: 'V', min: 3.2, max: 3.4 };
  chk(B.mesureOk(v, '3,30') === true && B.mesureOk(v, '3.1') === false && B.mesureOk(v, 'abc') === false && B.mesureOk(v, '') === null && B.mesureOk({ unite: 'g' }, '120') === null, 'Banc : jugement des mesures (virgule, hors plage, sans plage)');
  const txt = B.texteBanc({ 'ch-3v3': { ok: true, t: 0, val: '3,1' } }, { chargeur: 'LED 4 faible' });
  chk(txt.includes('3,1 V (HORS PLAGE)') && txt.includes('Notes : LED 4 faible') && txt.includes('(1/'), 'Banc : export de la fiche');
}


// --- sauvegarde du carnet
{
  const Z = await import('../src/calc/sauvegardeZip');
  const s0 = { version: 1 as const, date: 1, nids: [{ id: 1, uid: 'a', photos: JSON.stringify(['file:///x/photos/nid1_1.jpg', 'file:///x/photos/perdue.jpg']), supprime: 0 }], tags: [{ id: 7 }], ruchers: [], reglages: [{ cle: 'alertes', valeur: '{}' }] };
  const r = Z.construireZip(s0, (u) => (u.includes('perdue') ? null : new Uint8Array([1, 2, 3])));
  const l = Z.lireZip(r.zip);
  chk(r.photos === 1 && r.manquantes === 1 && l.photos['nid1_1.jpg']?.length === 3 && JSON.parse(String(l.s.nids[0].photos))[0] === 'nid1_1.jpg' && l.s.tags.length === 1,
    'Sauvegarde : zip avec photos, photo manquante signalée, relecture');
  let refuse = '';
  try { Z.lireZip(new Uint8Array([1, 2, 3])); } catch (e) { refuse = (e as Error).message; }
  chk(/pas un zip/.test(refuse), 'Sauvegarde : fichier quelconque refusé avec un message clair');
}


// --- saison : pièges, ruchers, comparaison, densité, recharge
{
  const Sa = await import('../src/calc/saison');
  const J = 86400000, t0 = new Date(2026, 6, 15).getTime();
  const nid = (id: number, lat: number, lon: number, t: number, etat = 'trouve', traite_ms: number | null = null) => ({
    id, tag: -1, t, lat, lon, err: 20, etat, note: '', sources: '', support: '', hauteur: '', diametre: '', activite: '', photos: [], inter_ms: null,
    methode: '', produit: '', quantite: '', operateur: '', traite_ms, verifie_ms: null, uid: String(id), maj_ms: t, auteur: '' }) as any;
  const r = { id: 1, nom: 'Bas', ruches: 10, lat: 45.0, lon: 3.88, note: '', pressions: '[]', uid: 'r', maj_ms: 0, auteur: '' };
  const nids = [nid(1, 45.005, 3.88, t0, 'traite', t0 + 2 * J), nid(2, 45.02, 3.88, t0 + 3 * J), nid(3, 45.0, 3.88, new Date(2025, 7, 1).getTime(), 'mort', new Date(2025, 7, 5).getTime())];
  const pg = { id: 1, nom: 'P', lat: 45.001, lon: 3.881, appat: '', pose_ms: new Date(2026, 2, 1).getTime(), retire_ms: null, note: '', uid: 'p', maj_ms: 0, auteur: '',
    releves: [{ t: new Date(2026, 2, 10).getTime(), frelons: 3, autres: 1, note: '' }, { t: new Date(2026, 2, 20).getTime(), frelons: 5, autres: 0, note: '' }, { t: new Date(2025, 3, 1).getTime(), frelons: 9, autres: 0, note: '' }] };
  const st = Sa.statsRucher(r, nids, [pg], 2026);
  chk(st.n1km === 1 && st.n3km === 2 && st.detruits === 1 && st.aTraiter === 1 && Math.abs(st.plusProche!.d - 556) < 5 && st.pieges === 1 && st.captures === 8,
    'Saison : statistiques d\'un rucher (1 km / 3 km, détruits, plus proche, pièges)');
  const c = Sa.comparerSaisons(nids, [r], [pg]);
  chk(c.length === 2 && c[0].annee === 2026 && c[0].nids === 2 && c[0].detruits === 1 && Math.abs(c[0].delaiTraitementJ! - 2) < 1e-6 && c[0].captures === 8 && c[1].captures === 9 && c[0].parMois[6] === 2,
    'Saison : comparaison des années (nids, délai de traitement, captures, par mois)');
  chk(Sa.aRelever(pg, new Date(2026, 2, 21).getTime()) === false && Sa.aRelever(pg, new Date(2026, 3, 1).getTime()) === true && Sa.capturesParSemaine([pg], 2026).length === 2,
    'Saison : piège à relever après 7 jours, captures par semaine');
  const pos = (p: { lat: number; lon: number }) => ({ x: (p.lon - 3.88) * 78000 / 10 + 150, y: 150 - (p.lat - 45.0) * 111000 / 10 });
  const g = Sa.grilleDensite([{ lat: 45.0, lon: 3.88 }, { lat: 45.0005, lon: 3.8805 }], pos, 300, 300, 10);
  const pic = g.reduce((a, b) => (b.v > a.v ? b : a), g[0]);
  chk(g.length > 10 && pic.v === 1 && Math.hypot(pic.x - 150, pic.y - 150) < 30 && Sa.grilleDensite([], pos, 300, 300, 10).length === 0, 'Saison : densité centrée sur les nids');
  const f = (o: object) => ({ id: 1, etat: 'dispo', pose_ms: null, appat: null, lat: null, lon: null, note: '', maj_ms: 0, pile: null, pile_ms: null, recharge_ms: null, ...o }) as any;
  const N = new Date(2026, 6, 20).getTime();
  chk(Sa.raisonRecharge(f({ recharge_ms: N - J }), N) === null && Sa.raisonRecharge(f({ recharge_ms: N - 9 * J }), N) === 'ancien'
    && Sa.raisonRecharge(f({ recharge_ms: N - J, pose_ms: N - 3600e3, etat: 'recupere' }), N) === 'pose'
    && Sa.raisonRecharge(f({ recharge_ms: N - 2 * J, pile: 30, pile_ms: N - J }), N) === 'pile' && Sa.raisonRecharge(f({ recharge_ms: N - J, pile: 30, pile_ms: N - 2 * J }), N) === null
    && Sa.raisonRecharge(f({}), N) === 'jamais' && Sa.raisonRecharge(f({ etat: 'perdu' }), N) === null,
    'Saison : raisons de recharge (pile, a servi, ancienne, jamais notée)');
}


// --- export GDSA (classeur Excel)
{
  const X = await import('../src/calc/xlsx'), G = await import('../src/calc/exportGdsa');
  const { unzipSync: dez, strFromU8: txt } = await import('fflate');
  const t = new Date(2026, 6, 1).getTime();
  const nid = { id: 1, tag: -1, t, lat: 45.01, lon: 3.88, err: 25, etat: 'traite', note: 'A & B <test>', sources: '', support: 'chêne', hauteur: '12 m', diametre: '', activite: '', photos: [],
    inter_ms: null, methode: 'perche', produit: '', quantite: '', operateur: 'N. 12345', traite_ms: t + 86400000, verifie_ms: null, uid: 'n', maj_ms: t, auteur: 'Nicolas' } as any;
  const d = { nids: [nid], ruchers: [{ id: 1, nom: 'Bas', ruches: 8, lat: 45.0, lon: 3.88, note: '', pressions: '[]', uid: 'r', maj_ms: 0, auteur: '' }], pieges: [], annee: 2026, auteur: 'Nicolas', maintenant: t };
  const z = dez(X.classeurXlsx(G.feuillesGdsa(d)));
  const wb = txt(z['xl/workbook.xml']), s2 = txt(z['xl/worksheets/sheet2.xml']);
  chk(Object.keys(z).filter((k) => k.startsWith('xl/worksheets/')).length === 5 && wb.includes('name="Relevés des pièges"') && s2.includes('A &amp; B &lt;test&gt;') && s2.includes('<v>45.01</v>'),
    'Export GDSA : classeur de 5 feuilles, texte échappé, nombres');
  const r = G.resumeGdsa(d);
  chk(r.nids === 1 && r.detruits === 1 && r.parRucher[0].n3km === 1 && G.rapportHtml(r).includes('saison 2026'), 'Export GDSA : résumé et rapport');
}


// --- calendrier de saison
{
  const K = await import('../src/calc/calendrier');
  const j10 = new Date(2027, 0, 10).getTime(), n11 = new Date(2026, 10, 11).getTime(), m3 = new Date(2026, 2, 3).getTime();
  const hiver = K.etapesDatees(j10).find((e) => e.id === 'hiver')!;
  chk(hiver.etat === 'en-cours' && hiver.saison === 2026 && new Date(hiver.finMs).getMonth() === 1, 'Calendrier : étape d\'hiver à cheval sur deux années');
  const e11 = K.etapesDatees(n11);
  chk(e11.find((e) => e.id === 'bilan')!.etat === 'en-cours' && e11.find((e) => e.id === 'hiver')!.etat === 'a-venir' && e11.find((e) => e.id === 'pieges')!.etat === 'passee', 'Calendrier : états au 11 novembre');
  const r = K.aRappeler(m3, {}, {});
  chk(r.some((e) => e.id === 'pieges') && K.aRappeler(m3, {}, { 'pieges-2026': true }).every((e) => e.id !== 'pieges') && K.aRappeler(m3, { 'pieges-2026': true }, {}).every((e) => e.id !== 'pieges'),
    'Calendrier : rappel une seule fois, pas si fait');
  chk(K.etapesDatees(new Date(2026, 1, 25).getTime(), -7).find((e) => e.id === 'pieges')!.etat === 'en-cours' && K.etapesDatees(new Date(2026, 1, 25).getTime(), 0).find((e) => e.id === 'pieges')!.etat === 'a-venir',
    'Calendrier : décalage du secteur');
}


// --- paramètres
{
  const Pm = await import('../src/calc/parametres');
  const K = await import('../src/calc/calendrier');
  const p = Pm.normaliser({ tagPerduS: '90', pileFaiblePct: 500, zoneNidM: 'abc', nomToit: '  ', nom: ' Nicolas ', rayonMenaceM: 1234.6, tempMin: '11,5', inconnu: 3 });
  chk(p.tagPerduS === 90 && p.pileFaiblePct === 90 && p.zoneNidM === 10 && p.nomToit === 'TOIT-Frelons' && p.nom === 'Nicolas' && p.rayonMenaceM === 1235 && p.tempMin === 11.5 && !('inconnu' in p),
    'Paramètres : défauts, bornes, entiers, virgule, textes vides');
  const cles = Pm.DEFINITIONS.flatMap((x) => x.params.map((d) => d.cle));
  chk(cles.length === Object.keys(Pm.DEFAUTS).length && new Set(cles).size === cles.length && Pm.listeAppats(p).length === 4 && Pm.depotValide('a-b/c.d') && !Pm.depotValide('pas un dépôt'),
    'Paramètres : chaque valeur a sa ligne dans l\'écran, appâts, dépôt');
  chk(String(K.lireJourMois('15/03')) === '15,3' && K.lireJourMois('31/04') === null && String(K.lireJourMois('29/2')) === '29,2' && K.jourMois([5, 9]) === '05/09',
    'Calendrier : saisie des dates jj/mm');
  const pg = K.etapesDatees(new Date(2026, 1, 20).getTime(), 0, { pieges: { debut: [15, 2], fin: [30, 4] } }).find((e) => e.id === 'pieges')!;
  chk(pg.etat === 'en-cours' && new Date(pg.finMs).getMonth() === 3, 'Calendrier : dates choisies par l\'utilisateur');
}


// --- versions des firmwares
{
  const Vs = await import('../src/calc/versions');
  const { parseToit: pt } = await import('../src/proto/toit');
  const { parsePortatif: pp } = await import('../src/proto/portatif');
  const v = pt('V,1.1.0,1,1,1,0,1') as any, vp = pp('{"type":"ver","fw":"1.0.3","proto":1}') as any;
  chk(v?.kind === 'V' && v.fw === '1.1.0' && v.proto === 1 && v.voies.join() === '1,1,0,1' && vp?.type === 'ver' && vp.fw === '1.0.3' && pt('V') === null,
    'Versions : lignes V du toit et « ver » du portatif');
  const r = (o: object) => ({ fw: '1.3.0', proto: 1, recuMs: 0, ...o });
  chk(Vs.verdict('toit', null) === null && Vs.verdict('toit', r({ voies: [2, 2, 2, 2] }))!.etat === 'ok' && Vs.verdict('portatif', r({ fw: '1.0.3' }))!.etat === 'maj' && Vs.verdict('toit', r({ voies: [2, 1, 0, 2] }))!.etat === 'maj'
    && Vs.verdict('toit', r({ proto: 0 }))!.etat === 'firmware' && Vs.verdict('portatif', r({ proto: 2 }))!.etat === 'appli' && Vs.verdict('toit', r({ absente: true }))!.etat === 'inconnu'
    && Vs.comparerVersions('1.10.0', '1.9.9') === 1 && Vs.comparerVersions('1.1.0+3', '1.1.0') === 0,
    'Versions : verdicts (à jour, mise à jour proposée, firmware ou appli trop ancien, inconnu)');
}


// --- distance d'après le signal
{
  const D = await import('../src/calc/distance');
  const mod = { ref1m: -25, n: 2.5, margeDb: 6 };
  const d = D.distanceRssi(-75, mod)!;
  chk(Math.abs(d.m - 100) < 0.5 && d.min < d.m && d.max > d.m && D.distanceRssi(-128, mod) === null && Math.abs(D.refDepuisMesure(-57.5, 20, 2.5) - (-25)) < 0.05,
    'Distance : 100 m pour −75 dBm, fourchette, voie muette, étalonnage');
  chk(D.arrondiDistance(23) === '25 m' && D.arrondiDistance(123) === '120 m' && D.arrondiDistance(333) === '350 m' && D.arrondiDistance(1530) === '1,5 km' && D.texteDistance(d).court === '≈ 100 m',
    'Distance : arrondis lisibles');
}

  {
    // interventions et registre des traitements
    const IV = await import('../src/calc/intervention');
    const J = 86400000, t0 = Date.UTC(2026, 8, 10, 8);
    const ancien = { interventions: '[]', inter_ms: t0, methode: 'perche', produit: 'Permas-D', quantite: '60 g', operateur: 'NB', hauteur: '12 m', diametre: '40', traite_ms: t0, verifie_ms: null, etat: 'traite', t: t0 - J };
    const la = IV.interventionsDe(ancien);
    chk(la.length === 1 && la[0].type === 'destruction' && la[0].quantiteG === 60 && la[0].hauteurM === 12, 'ancienne intervention reprise');
    const d = IV.interventionVide(t0, 'destruction', { produit: 'Permas-D', quantiteG: 80, hauteurM: 18 });
    const c = IV.interventionVide(t0 + 4 * J, 'controle', { resultat: 'actif' });
    const r = IV.interventionVide(t0 + 5 * J, 'retraitement', { produit: 'Permas-D', quantiteG: 40 });
    let e = IV.etatDepuis([d], 'trouve');
    chk(e.etat === 'traite' && e.traite_ms === t0 && e.quantite === '80 g', 'destruction : nid traité');
    chk(IV.aControler(e, t0 + 2 * J, 3) === false && IV.aControler(e, t0 + 3 * J, 3) === true, 'contrôle dû après 3 jours');
    e = IV.etatDepuis([d, c], 'traite');
    chk(e.etat === 'trouve', 'contrôle actif : à retraiter');
    e = IV.etatDepuis([d, c, r, IV.interventionVide(t0 + 9 * J, 'controle', { resultat: 'mort' })], 'traite');
    chk(e.etat === 'mort' && e.verifie_ms === t0 + 9 * J, 'contrôle mort : vérifié');
    chk(IV.classeHauteur(8) === 'moins de 10 m' && IV.classeHauteur(18) === 'de 10 à 25 m' && IV.classeHauteur(30) === 'plus de 25 m', 'classes de hauteur FREDON');
    const reg = IV.lignesRegistre([{ id: 1, lat: 45, lon: 3.9, l: [d, c, r] }, { id: 2, lat: 45.1, lon: 3.8, l: [IV.interventionVide(Date.UTC(2025, 8, 1), 'destruction', { produit: 'X', quantiteG: 10 })] }], (id) => id, 2026);
    chk(reg.length === 2 && reg[0].inter.type === 'destruction', 'registre : année, sans les contrôles');
    const tot = IV.totauxProduits(reg);
    chk(tot.length === 1 && tot[0].n === 2 && tot[0].g === 120, 'registre : totaux par produit');
    chk(IV.ligneTableau(reg[0]).length === IV.ENTETE_REGISTRE.length, 'registre : colonnes Excel');
  }
  {
    // pression des frelons devant les ruches
    const PR = await import('../src/calc/pression');
    const J = 86400000, t0 = new Date(2026, 8, 20, 10).getTime();
    let l = PR.ajouterReleve([], t0 - 10 * J, 0);
    l = PR.ajouterReleve(l, t0 - 9 * J, 1);
    l = PR.ajouterReleve(l, t0 - 3 * J, 2);
    l = PR.ajouterReleve(l, t0, 1);
    l = PR.ajouterReleve(l, t0 + 3600000, 3);
    chk(l.length === 4 && PR.releveDuJour(l, t0)?.n === 3, 'un relevé par jour, corrigé d\'un appui');
    chk(PR.niveauActuel(l, t0 + 3600000) === 3 || PR.niveauActuel(l, t0 + 3600000) === 2, 'niveau moyen des 7 derniers jours');
    chk(PR.tendance(l, t0 + 3600000) === 'hausse', 'tendance en hausse');
    chk(PR.lirePressions('pas du json').length === 0 && PR.lirePressions(JSON.stringify(l)).length === 4, 'lecture tolérante');
  }
  {
    // tags sans nouvelles, effet des destructions, résultats de saison
    const RS = await import('../src/calc/resultats');
    const IV = await import('../src/calc/intervention');
    const J = 86400000, t0 = new Date(2026, 8, 20, 10).getTime();
    chk(RS.doitNoter({}, { t: t0, lat: 45, lon: 3, par: 'voiture', err: null }), 'premier contact noté');
    chk(!RS.doitNoter({ vu_ms: t0, vu_lat: 45, vu_lon: 3 }, { t: t0 + 60000, lat: 45.0001, lon: 3, par: 'voiture', err: null }), 'contact proche et récent : pas réécrit');
    chk(RS.doitNoter({ vu_ms: t0, vu_lat: 45, vu_lon: 3 }, { t: t0 + 60000, lat: 45.001, lon: 3, par: 'voiture', err: null }), 'contact déplacé de 110 m : noté');
    const fi = [{ etat: 'pose', pose_ms: t0 - 5 * J, vu_ms: t0 - 3 * J }, { etat: 'pose', pose_ms: t0 - 5 * J, vu_ms: t0 - J / 2 }, { etat: 'dispo', pose_ms: null }];
    chk(RS.sansNouvelles(fi, t0, 2).length === 1, 'tags sans nouvelles depuis 2 jours');
    const nid = (id: number, tag: number, t: number, sources: string, lat: number, extra = {}) => ({ id, tag, t, sources, lat, lon: 3.88, etat: 'trouve', traite_ms: null, interventions: '[]',
      inter_ms: null, methode: '', produit: '', quantite: '', operateur: '', hauteur: '', diametre: '', verifie_ms: null, ...extra });
    const td = t0 - 3 * J;
    const detruit = nid(1, 7, t0 - 6 * J, 'voiture (12 relèvements) + portatif', 45.003, { etat: 'mort', traite_ms: td, interventions: JSON.stringify([IV.interventionVide(td, 'destruction')]) });
    const pr = JSON.stringify([[-9, 2], [-8, 3], [-6, 2], [-5, 3], [-1, 1], [1, 0], [2, 0], [3, 1]].map(([d, n]) => ({ t: td + d * J, n })));
    const ef = RS.effetsDestruction([{ id: 1, nom: 'verger', lat: 45, lon: 3.88, pressions: pr }], [detruit, nid(2, 0, t0, '', 45.5)], 1000);
    chk(ef.length === 1 && ef[0].avant >= 2 && ef[0].apres < 1 && ef[0].variation < -60, `effet d'une destruction : ${ef[0]?.avant.toFixed(1)} → ${ef[0]?.apres.toFixed(1)} (${ef[0]?.variation} %)`);
    const poses = [{ tag: 7, t: t0 - 7 * J }, { tag: 9, t: t0 - 2 * J }, { tag: 7, t: t0 - 40 * J }];
    const r = RS.resultatsSaison([detruit, nid(2, 9, t0 - J, 'chrono (2 appâts)', 45.01), nid(3, 0, t0, '', 45.02)], poses, [{ lat: 45, lon: 3.88 }], 2026, 1000);
    chk(r.poses === 3 && r.nidsParTag === 2 && r.taux === 67, 'poses, nids par un tag, réussite');
    chk(r.delaiMedianH === 24, `délai médian pose → nid (${r.delaiMedianH} h)`);
    chk(r.methodes[0].n === 1 && r.methodes.some((m) => m.m === 'voiture') && r.methodes.some((m) => m.m === 'chrono') && r.methodes.some((m) => m.m === 'main'), 'méthodes qui ont trouvé les nids');
    chk(r.traites === 1 && r.mortsPremierCoup === 1, 'mort au premier traitement');
    chk(RS.methodeDe('portatif + voiture (3)') === 'portatif' && RS.methodeDe('') === 'main', 'méthode principale = la première citée');
  }
  {
    console.log('--- au nid / en chasse, erreurs remontées, flèche du portatif ---');
    const AC = await import('../src/calc/activite');
    const TO = await import('../src/proto/toit');
    const PO = await import('../src/proto/portatif');
    chk(AC.decoderEtat(0) === null && AC.decoderEtat(undefined) === null, 'tag sans octet d\'état : rien');
    const d1 = AC.decoderEtat(0x80 | 62);
    chk(!!d1 && d1.nid && d1.tempC === 22, 'octet 0xBE = au nid, 22 °C');
    chk(AC.decoderEtat(40 + 18)?.nid === false && AC.decoderEtat(0x80)?.tempC === null, 'en chasse ; température inconnue');
    const M = 60000, t0 = new Date(2026, 6, 1, 9, 0).getTime();
    let a = AC.noterEtat(null, { nid: true, tempC: 20 }, t0);
    a = AC.noterEtat(a, { nid: true, tempC: 20 }, t0 + 5 * M);
    a = AC.noterEtat(a, { nid: false, tempC: 24 }, t0 + 5 * M + 6000);   // départ
    a = AC.noterEtat(a, { nid: false, tempC: 24 }, t0 + 20 * M);
    a = AC.noterEtat(a, { nid: true, tempC: 21 }, t0 + 25 * M);           // retour : 20 min dehors
    a = AC.noterEtat(a, { nid: true, tempC: 21 }, t0 + 40 * M - 6000);
    a = AC.noterEtat(a, { nid: false, tempC: 25 }, t0 + 40 * M);          // 2e départ
    a = AC.noterEtat(a, { nid: true, tempC: 22 }, t0 + 50 * M);           // 10 min
    chk(a.sorties.length === 2 && Math.round((a.sorties[0].fin! - a.sorties[0].debut) / M) === 20, `sorties (${a.sorties.length}, 1re ${Math.round((a.sorties[0].fin! - a.sorties[0].debut) / M)} min)`);
    const b = AC.bilanActivite(a, t0 + 55 * M)!;
    chk(b.sortiesJour === 2 && b.dureeMedianeMin === 15 && b.derniereMin === 10 && !b.enCours, `bilan du jour (${b.sortiesJour} sorties, ${b.dureeMedianeMin} min)`);
    chk(AC.texteActivite(a, t0 + 55 * M) === 'Au nid depuis 5 min · 22 °C', `texte (${AC.texteActivite(a, t0 + 55 * M)})`);
    chk(AC.texteActivite(a, t0 + 70 * M) === null, 'information trop vieille : rien');
    const trou = AC.noterEtat(AC.noterEtat(a, { nid: false, tempC: 25 }, t0 + 51 * M), { nid: true, tempC: 22 }, t0 + 120 * M);
    chk(trou.sorties[2].fin === -1 && AC.bilanActivite(trou, t0 + 121 * M)!.dureeMedianeMin === 15, 'long silence : durée inconnue, pas comptée');
    chk(AC.noterEtat(a, { nid: false, tempC: 25 }, t0) === a, 'trame plus ancienne ignorée');
    chk(AC.causeRedemarrage(0x10) === 'chien de garde (blocage logiciel)' && AC.causeAnormale(0x10) && AC.causeAnormale(0x4) && !AC.causeAnormale(0x8) && !AC.causeAnormale(0x2), 'causes de redémarrage');
    const r = TO.parseToit('R,1752000000,7,12,-70,-80,-128,-128,-75,10,120,3,45.1,3.9,90,0,85,190');
    chk(r?.kind === 'R' && r.etat === 190 && r.pile === 85, 'ligne R avec octet d\'état');
    const r0 = TO.parseToit('R,1752000000,7,12,-70,-80,-128,-128,-75,10,120,3,45.1,3.9,90,0,85');
    chk(r0?.kind === 'R' && r0.etat === 0, 'ligne R ancienne (16 champs)');
    const v = TO.parseToit('V,1.2.0,1,2,2,0,2,16,3600,8,8,0,4');
    chk(v?.kind === 'V' && v.rst === 16 && v.upS === 3600 && v.rstVoies?.[3] === 4 && v.voies[2] === 0, 'ligne V 1.2.0');
    const v0 = TO.parseToit('V,1.1.0,1,1,1,1,1');
    chk(v0?.kind === 'V' && v0.rst === undefined, 'ligne V 1.1.0');
    const e = TO.parseToit('E,voie,2,16,chien de garde');
    chk(e?.kind === 'E' && e.qui === 'voie' && e.n === 2 && e.rst === 16 && e.texte === 'chien de garde', 'ligne E');
    chk(PO.cmdPortatif.cible(45.0483716, 3.8839642, 'Nid n° 3 — Écuries') === 'cible 45.048372 3.883964 Nid n 3  Ecuries', `commande cible (${PO.cmdPortatif.cible(45.0483716, 3.8839642, 'Nid n° 3 — Écuries')})`);
    const pv = PO.parsePortatif('{"type":"ver","fw":"1.2.0","proto":1,"rst":16,"up":42}');
    chk(pv?.type === 'ver' && pv.rst === 16 && pv.up === 42, 'version du portatif avec cause de redémarrage');
  }
  {
    console.log('--- tag immobile, carte du signal à pied, mode poche ---');
    const AC = await import('../src/calc/activite');
    const TP = await import('../src/calc/traceAPied');
    const PO = await import('../src/proto/portatif');
    const H = 3600000, j = new Date(2026, 6, 1, 0, 0).getTime();
    chk(AC.minutesDeJour(j + 6 * H, j + 10 * H) === 120 && AC.minutesDeJour(j + 18 * H, j + 33 * H) === 180, 'minutes de jour (8 h - 20 h)');
    const nuit = { nid: true, depuisMs: j + 20 * H, vuMs: j + 33 * H, tempC: 20, sorties: [] };
    chk(AC.immobileDepuis(nuit, j + 33 * H) === null, 'nuit au nid puis 2 h de jour : pas immobile');
    chk(AC.immobileDepuis(nuit, j + 35.5 * H) === null, '… sans trame depuis 2 h 30 : on ne sait pas');
    const im = { ...nuit, vuMs: j + 35.4 * H };
    chk(AC.immobileDepuis(im, j + 35.5 * H) === Math.round(15.5 * 60), 'au nid toute la nuit et 3 h 30 de jour : immobile');
    chk(AC.immobileDepuis({ ...im, depuisMs: j + 33 * H }, j + 35.5 * H) === null, 'seulement 2 h 30 sans bouger : pas encore');
    let l = TP.ajouterPas(undefined, { lat: 45, lon: 3.9, rssi: -90, t: 0 });
    const l1 = TP.ajouterPas(l, { lat: 45.00001, lon: 3.9, rssi: -95, t: 1000 });
    chk(l1 === l, 'à moins de 3 m et plus faible : rien');
    l = TP.ajouterPas(l, { lat: 45.00001, lon: 3.9, rssi: -80, t: 2000 });
    chk(l.length === 1 && l[0].rssi === -80, 'à moins de 3 m et plus fort : on garde le plus fort');
    l = TP.ajouterPas(l, { lat: 45.0001, lon: 3.9, rssi: -70, t: 3000 });
    l = TP.ajouterPas(l, { lat: 45.0002, lon: 3.9, rssi: -60, t: 4000 });
    l = TP.ajouterPas(l, { lat: 45.0003, lon: 3.9, rssi: -75, t: 5000 });
    chk(l.length === 4 && TP.ajouterPas(l, { lat: 0, lon: 0, rssi: -50, t: 6000 }) === l, 'un point tous les 3 m, positions nulles ignorées');
    const pf = TP.pointFort(l)!;
    chk(Math.abs(pf.lat - 45.0002) < 2e-5 && pf.rssi === -60, `point fort (${pf.lat.toFixed(5)}, ${pf.rssi} dBm)`);
    chk(TP.couleurSignal(-100) === 'hsl(220, 85%, 48%)' && TP.couleurSignal(-40) === 'hsl(0, 85%, 48%)', 'couleurs du froid au chaud');
    chk(PO.cmdPortatif.poche(true) === 'poche 1' && PO.cmdPortatif.poche(false) === 'poche 0', 'commande poche');
  }
  {
    console.log('--- vols du drone, rattrapage, contrôle par le tag, carte à pied hors connexion ---');
    const VL = await import('../src/calc/vol');
    const AC = await import('../src/calc/activite');
    const PO = await import('../src/proto/portatif');
    const d = VL.lireLigneD('D,120,45.0483716,3.8839642,630.5,1,12,100,-95,7,2,7:-80:3;12:-99:1;');
    chk(!!d && !d.rattrapee && d.fix && !d.balise && d.tags.length === 2 && d.tags[0][0] === 7 && d.tags[0][1] === -80 && d.alt === 630.5, 'ligne D');
    const dr = VL.lireLigneD('d,118,45.0484,3.884,631,1,12,100,-96,6,1,7:-78:2;');
    chk(!!dr && dr.rattrapee && dr.seq === 118, 'ligne d (rattrapée)');
    chk(VL.lireLigneD('D,5,0,0,0,3,0,100,-90,5,0,')!.balise && VL.lireLigneD('P,80,3900,1,1') === null, 'balise d\'appât ; ligne P ignorée');
    chk(VL.heureDeSeq(118, 120, 10000) === 9000 && VL.heureDeSeq(65535, 1, 10000) === 9000, 'heure d\'une trame rattrapée (y compris au passage de 65535 à 0)');
    let v = VL.volVide(0, 600);
    v = VL.ajouterTrame(v, VL.lireLigneD('D,1,45.0,3.9,600,1,10,100,-90,5,0,')!, 0);
    v = VL.ajouterTrame(v, VL.lireLigneD('D,3,45.001,3.9,630,1,10,100,-90,5,1,7:-85:1;')!, 1000);
    v = VL.ajouterTrame(v, VL.lireLigneD('d,2,45.0005,3.9,615,1,10,100,-90,5,1,7:-70:2;')!, 500);
    v = VL.ajouterTrame(v, VL.lireLigneD('D,4,45.002,3.9,630,1,10,100,-90,5,0,')!, 1500);
    v = VL.ajouterTrame(v, VL.lireLigneD('D,5,45.002,3.9,630,3,10,100,-90,5,1,7:-50:1;')!, 2000); // balise : ignorée
    chk(v.points.length === 4 && v.points[1].t === 500 && v.rattrapees === 1, 'trame rattrapée remise à sa place');
    const r = VL.resumeVol(v);
    chk(r.tags[0].id === 7 && r.tags[0].max === -70 && r.tags[0].h === 15 && r.hMax === 30, `résumé du vol (max ${r.tags[0].max} dBm à ${r.tags[0].h} m)`);
    chk(VL.mesuresTag(v, 7).length === 2, 'mesures d\'un tag');
    const gpx = VL.volGpx(v), csv = VL.volCsv(v);
    chk(gpx.includes('<trkpt lat="45.0005000"') && gpx.includes('<desc>tag 7 -70 dBm</desc>') && csv.split('\n').length === 6, 'export GPX et CSV');
    // contrôle par le tag
    const H = 3600000, T = new Date(2026, 8, 10, 12, 0).getTime();
    let a = AC.noterEtat(null, { nid: true, tempC: 28 }, T - 30 * H);
    for (let h = -29; h < 0; h += 1) a = AC.noterEtat(a, { nid: h % 3 !== 0, tempC: h % 3 !== 0 ? 28 : 22 }, T + h * H); // vie normale : sorties
    const avant = a.sorties.length;
    chk(AC.controleTraitement(a, T, T + H).verdict === 'inconnu', 'pas entendu après le traitement : inconnu');
    let m = a;
    for (let h = 0; h <= 10; h++) m = AC.noterEtat(m, { nid: true, tempC: Math.max(12, 27 - 2 * h) }, T + h * H + 60000);
    const cm = AC.controleTraitement(m, T, T + 10 * H + 120000);
    chk(cm.verdict === 'mort' && cm.cAvant === 28 && (cm.cApres ?? 99) <= 18, `nid qui refroidit sans sortie : mort (${cm.texte})`);
    let m4 = a;
    for (let h = 0; h <= 4; h++) m4 = AC.noterEtat(m4, { nid: true, tempC: Math.max(12, 27 - 2 * h) }, T + h * H + 60000);
    chk(AC.controleTraitement(m4, T, T + 4 * H + 120000).verdict === 'attente', 'moins de 6 h : attente');
    let act = a;
    for (let h = 0; h <= 8; h++) act = AC.noterEtat(act, { nid: h % 4 !== 2, tempC: 28 }, T + h * H + 60000);
    const ca = AC.controleTraitement(act, T, T + 8 * H + 120000);
    chk(ca.verdict === 'actif' && ca.sortiesApres >= 1 && avant > 0, `le frelon ressort : actif (${ca.sortiesApres} sorties)`);
    let tiede = a;
    for (let h = 0; h <= 8; h++) tiede = AC.noterEtat(tiede, { nid: true, tempC: 27 }, T + h * H + 60000);
    chk(AC.controleTraitement(tiede, T, T + 8 * H + 120000).verdict === 'attente', 'pas de sortie mais nid tiède : à revoir');
    const pas = PO.parsePortatif('{"type":"pas","tag":7,"lat":45.048372,"lon":3.883964,"rssi":-77,"utc":1752000000}');
    chk(pas?.type === 'pas' && pas.utc === 1752000000 && pas.rssi === -77, 'point de carte à pied gardé par le portatif');
  }
  {
    console.log('--- plan de vol, étalonnage, nid estimé en marchant ---');
    const PV = await import('../src/calc/planVol');
    const PO = await import('../src/proto/portatif');
    const G = await import('../src/calc/geo');
    const c = { lat: 45.0483716, lon: 3.8839642 };
    const sp = PV.genererPlan(c, PV.PLAN_DEFAUT);
    const der = sp.points[sp.points.length - 1], prem = sp.points[0];
    chk(G.distM(der.lat, der.lon, c.lat, c.lon) < 1 && Math.abs(G.distM(prem.lat, prem.lon, c.lat, c.lon) - 150) < 10, `spirale : de ${Math.round(G.distM(prem.lat, prem.lon, c.lat, c.lon))} m jusqu'au nid`);
    chk(sp.points.length <= PV.MAX_POINTS && sp.points.length > 20 && sp.longueurM > 1000 && sp.longueurM < 2000, `spirale : ${sp.points.length} points, ${sp.longueurM} m, ${sp.dureeMin} min`);
    chk(sp.points.every((p) => G.distM(p.lat, p.lon, c.lat, c.lon) <= 152), 'spirale dans le cercle');
    const qd = PV.genererPlan(c, { ...PV.PLAN_DEFAUT, motif: 'quadrillage' });
    chk(qd.points.length === 12 && qd.points.every((p) => G.distM(p.lat, p.lon, c.lat, c.lon) <= 151), `quadrillage : ${qd.points.length} points`);
    const gros = PV.genererPlan(c, { ...PV.PLAN_DEFAUT, rayonM: 600, espacementM: 15 });
    chk(gros.tronque && gros.points.length <= 99, `plus de 99 points : simplifié (${gros.points.length})`);
    chk(PV.genererPlan(c, { ...PV.PLAN_DEFAUT, hauteurM: 300 }).reglages.hauteurM === 120, 'hauteur limitée à 120 m');
    chk(PV.rayonConseille(10) === 80 && PV.rayonConseille(60) === 180 && PV.rayonConseille(500) === 400, 'rayon conseillé');
    const csv = PV.litchiCsv(sp).trim().split('\n');
    const col = csv[0].split(',');
    chk(col[0] === 'latitude' && col[2] === 'altitude(m)' && col.includes('altitudemode') && csv.length === sp.points.length + 1 && csv.every((l) => l.split(',').length === col.length), 'mission Litchi : en-tête et colonnes');
    const l1 = csv[1].split(',');
    chk(l1[2] === '40' && l1[col.indexOf('speed(m/s)')] === '6' && l1[col.indexOf('altitudemode')] === '0' && l1[col.indexOf('photo_timeinterval')] === '-1', 'mission Litchi : hauteur, vitesse, mode');
    chk(PV.planKml(sp, 'Nid <3>').includes('<LineString>') && PV.planKml(sp, 'Nid <3>').includes('Nid &lt;3&gt;'), 'trace KML');
    const est = PO.parsePortatif('{"type":"est","tag":7,"lat":45.0484,"lon":3.884,"err":32,"ok":1,"n":120,"marche":180,"p1m":-52}');
    chk(est?.type === 'est' && est.ok === 1 && est.err === 32, 'nid estimé en marchant');
    const et = PO.parsePortatif('{"type":"etal","id":7,"p1m":-52,"n":20}');
    chk(et?.type === 'etal' && et.p1m === -52, 'résultat d\'étalonnage');
    chk(PO.cmdPortatif.etal(7) === 'etal 7' && PO.cmdPortatif.p1m(7, -51.6) === 'p1m 7 -52' && PO.cmdPortatif.estRaz() === 'est raz', 'commandes etal, p1m, est raz');
  }
  {
    console.log('--- nid en 3D par le drone, trame longue portée ---');
    const VL = await import('../src/calc/vol');
    const TO = await import('../src/proto/toit');
    let graine = 7; const rnd = () => { graine = (graine * 16807) % 2147483647; return graine / 2147483647; };
    const g = () => Math.sqrt(-2 * Math.log(rnd() + 1e-9)) * Math.cos(2 * Math.PI * rnd());
    const NID = { lat: 45.0483716, lon: 3.8839642 }, kx = 111320 * Math.cos((NID.lat * Math.PI) / 180);
    let v = VL.volVide(0, 600);
    for (let i = 0; i < 360; i++) {
      const a = (i / 360) * 4 * Math.PI, r = 160 * (1 - i / 400), h = 25 + 20 * Math.sin(i / 40);
      const x = r * Math.sin(a) + 30, y = r * Math.cos(a) - 20, d = Math.hypot(x, y, h - 18);
      const rssi = Math.round(-45 - 22 * Math.log10(d) + 3 * g());
      v = VL.ajouterTrame(v, { rattrapee: false, seq: i, lat: NID.lat + y / 111320, lon: NID.lon + x / kx, alt: 600 + (i ? h : 0), fix: true, balise: false, sats: 10, batt: 100, tags: [[7, rssi]] }, i * 500);
    }
    const e = VL.nid3D(v, 7)!;
    const eh = Math.hypot((e.lat - NID.lat) * 111320, (e.lon - NID.lon) * kx);
    chk(!!e && eh < 15 && e.hauteurMin <= 18 && e.hauteurMax >= 18, `nid 3D : ${Math.round(eh)} m du vrai nid, hauteur ${e.hauteurM} m (${e.hauteurMin}-${e.hauteurMax}, vraie 18)`);
    chk(VL.nid3D(VL.volVide(0, 600), 7) === null, 'nid 3D : trop peu de mesures');
    const r = TO.parseToit('R,1752000000,7,12,-90,-128,-128,-128,-95,-1,-1,0,45.1,3.9,90,0,85,190,1');
    chk(r?.kind === 'R' && r.lp && r.etat === 190, 'ligne R : trame longue portée');
    const r2 = TO.parseToit('R,1752000000,7,12,-70,-80,-128,-128,-75,10,120,3,45.1,3.9,90,0,85,190');
    chk(r2?.kind === 'R' && !r2.lp, 'ligne R sans le champ longue portée');
  }
  {
    console.log('--- estimation unique, terrain et recalage du toit appris sur les nids trouvés ---');
    const TE = await import('../src/calc/terrain');
    const FU = await import('../src/calc/fusion');
    const TO = await import('../src/proto/toit');
    const PO = await import('../src/proto/portatif');
    const G = await import('../src/calc/geo');
    const nid = { lat: 45.0483716, lon: 3.8839642 }, kx = 111320 * Math.cos((nid.lat * Math.PI) / 180);
    let graine = 3; const rnd = () => { graine = (graine * 16807) % 2147483647; return graine / 2147483647; };
    const g = () => Math.sqrt(-2 * Math.log(rnd() + 1e-9)) * Math.cos(2 * Math.PI * rnd());
    // terrain : forêt (n = 3,2), points de 10 à 200 m
    const pas = Array.from({ length: 60 }, (_, i) => { const d = 10 + i * 3.2, a = i * 0.7; return { lat: nid.lat + (d * Math.cos(a)) / 111320, lon: nid.lon + (d * Math.sin(a)) / kx, rssi: Math.round(-50 - 32 * Math.log10(d) + 4 * g()), t: i }; });
    const te = TE.exposantTerrain(pas, nid)!;
    chk(!!te && Math.abs(te.n - 3.2) < 0.3 && te.r2 > 0.8, `terrain : exposant ${te?.n} (vrai 3,2), r² ${te?.r2}`);
    chk(TE.exposantTerrain(pas.slice(0, 10), nid) === null, 'terrain : trop peu de points');
    chk(TE.exposantRetenu([{ ...te, n: 3.0 }, { ...te, n: 3.4 }, { ...te, n: 2.0, r2: 0.1 }]) === 3.2, 'exposant retenu : médiane, ajustements nets seulement');
    // recalage : relèvements biaisés de +7°
    const lignes = Array.from({ length: 20 }, (_, i) => { const lat = nid.lat - 0.003 + i * 0.0001, lon = nid.lon - 0.004; return { lat, lon, absDeg: (G.capDeg(lat, lon, nid.lat, nid.lon) + 7 + 3 * g() + 360) % 360, q: 70, t: i, ecartee: false }; });
    const ec = TE.ecartToit(lignes, nid)!;
    chk(!!ec && Math.abs(ec.ecart - 7) < 2, `écart du toit : ${ec?.ecart}° (vrai +7°)`);
    const c1 = TE.correctionToit([ec]);
    chk(c1 === null, 'un seul nid, 20 relèvements : pas encore de correction');
    const c2 = TE.correctionToit([ec, { ecart: 6, n: 15, dispersion: 3 }]);
    chk(!!c2 && c2.rot <= -6 && c2.rot >= -8, `deux nids : correction ${c2?.rot}°`);
    chk(TE.correctionToit([{ ecart: 1.5, n: 40, dispersion: 3 }]) === null, 'écart faible : pas de correction');
    // estimation unique : marche et drone pris en compte
    const f = FU.fusionner({ lignes: [], oeil: [], portatif: [{ lat: nid.lat + 0.0003, lon: nid.lon, errM: 40, src: 'marche' }, { lat: nid.lat - 0.0001, lon: nid.lon, errM: 15, src: 'drone' }] });
    chk(f.ok && f.nMarche === 1 && f.nDrone === 1 && f.nPortatif === 0 && G.distM(f.lat, f.lon, nid.lat, nid.lon) < 20, `estimation unique : marche + drone (${Math.round(G.distM(f.lat, f.lon, nid.lat, nid.lon))} m)`);
    const k = TO.parseToit('K,2,70,-1.0,1.9,-1.8,0.9,10,240,6');
    chk(k?.kind === 'K' && k.type === 'RESULTAT' && k.errDiag === 6, 'ligne K avec diagramme mesuré');
    const k2 = TO.parseToit('K,2,70,-1.0,1.9,-1.8,0.9,10,240,-1');
    chk(k2?.kind === 'K' && k2.type === 'RESULTAT' && k2.errDiag === undefined, 'ligne K : modèle gardé');
    const kr = TO.parseToit('K,ROT,-7.0,355');
    chk(kr?.kind === 'K' && kr.type === 'ROT' && kr.deg === -7, 'ligne K,ROT');
    chk(TO.cmdToit.rot(-6.6) === 'rot -7' && PO.cmdPortatif.nexp(3.24) === 'nexp 3.2', 'commandes rot et nexp');
  }
  {
    console.log('--- recette des cartes, enregistrement des essais ---');
    const RC = await import('../src/calc/recette');
    const PO = await import('../src/proto/portatif');
    const TO = await import('../src/proto/toit');
    const N = ['Avant', 'Droite', 'Arrière', 'Gauche'];
    const m = RC.moyennesVoies([[-60, -75, -90, -80], [-62, -73, -128, -82], [-58, -77, -92, -78]]);
    chk(Math.abs(m[0] + 59.9) < 0.5 && m[2] > -92 && m[2] < -89, `moyennes des voies (${m.join(' ')})`);
    chk(RC.verdictDirection(0, m, N).ok === true, 'tag devant : voie avant la plus forte');
    const inv = RC.verdictDirection(1, m, N);
    chk(inv.ok === false && /Avant/.test(inv.detail), `câbles inversés repérés (${inv.detail})`);
    chk(RC.verdictDirection(0, [-70, -71.5, -90, -90], N).ok === false, 'écart trop faible : à vérifier');
    chk(RC.verdictDirection(2, [-128, -128, -128, -128], N).detail === 'aucune voie ne reçoit le tag', 'aucune voie');
    const v = RC.verifsTag({ id: 7, entendu: true, pile: 85, etat: 0x80 | 62, noirVu: true, lumiereVu: true, p1m: -50 }, -48);
    chk(v.every((x) => x.ok === true), 'tag en bon état : tout vert');
    const v2 = RC.verifsTag({ id: 8, entendu: true, pile: 10, etat: null, noirVu: true, lumiereVu: false, p1m: -58 }, -48);
    chk(v2[1].ok === false && v2[2].ok === null && v2[3].ok === null && v2[4].ok === false, 'tag : pile basse, capteur à finir, antenne faible');
    chk(RC.mediane([-50, -48, -47]) === -48 && RC.mediane([]) === null, 'médiane');
    chk(RC.rapportRecette([{ titre: 'Tag 007', verifs: v2 }], 0).includes('[NON] Antenne'), 'rapport texte');
    chk(PO.cmdPortatif.brut(true) === 'brut 1' && TO.cmdToit.brut(false) === 'brut 0', 'commandes brut');
    const st = PO.parsePortatif('{"type":"st","tag":7,"rssi":-70.5,"raw":-71,"trend":0.1,"age":0.3,"hdg":120,"fix":1,"lat":45.1,"lon":3.9,"sats":9,"bat":80,"lna":0,"etat":190,"poche":0,"cmp":1}');
    chk(st?.type === 'st' && st.cmp === 1, 'état de la boussole du portatif');
  }
  // --- ordres à distance aux tags (firmware tag 7)
  {
    const { parseToit, cmdToit } = await import('../src/proto/toit');
    const { parsePortatif, cmdPortatif } = await import('../src/proto/portatif');
    const k = parseToit('K,TAG,12,rech,OK,4300');
    chk(k?.kind === 'K' && k.type === 'TAG' && k.tag === 12 && k.ordre === 'rech' && k.res === 'ok' && k.ms === 4300, 'toit : réponse à un ordre (OK, délai)');
    const k2 = parseToit('K,TAG,7,off,ECHEC');
    chk(k2?.kind === 'K' && k2.type === 'TAG' && k2.res === 'echec' && k2.ms === undefined, 'toit : ordre sans réponse');
    const po = parsePortatif('{"type":"ordre","tag":5,"ordre":"ping","res":"ok","ms":2100}');
    chk(po?.type === 'ordre' && po.tag === 5 && po.res === 'ok', 'portatif : réponse à un ordre');
    chk(cmdToit.ordre(12, 'rech') === 'ordre 12 rech' && cmdPortatif.ordre(3, 'off') === 'ordre 3 off', 'commandes « ordre » du toit et du portatif');
  }
  // --- réglages automatiques par l'étalonnage
  {
    const { ajusterDistance, refPortatif, etapes, resteAFaire } = await import('../src/calc/etalAuto');
    let g = 7; const bruit = () => { g = (g * 1103515245 + 12345) % 2147483648; return (g / 2147483648 - 0.5) * 8; };
    const pts = Array.from({ length: 200 }, (_, i) => { const d = 25 + (i % 50) * 1.2; return { d, rssi: -27 - 22 * Math.log10(d) + bruit() }; });
    const a = ajusterDistance(pts);
    chk(!!a && Math.abs(a.ref1m + 27) <= 3 && Math.abs(a.n - 2.2) <= 0.4 && a.margeDb >= 2 && a.margeDb <= 4, `distance du toit : ${a?.ref1m} dBm à 1 m, n ${a?.n}, ± ${a?.margeDb} dB (vrai -27, 2,2)`);
    chk(ajusterDistance(pts.map((x) => ({ ...x, d: 40 }))) === null && ajusterDistance(pts.slice(0, 10)) === null, 'distance du toit : distances identiques ou trop peu de mesures → rien');
    const b = ajusterDistance(pts.map((x) => ({ d: x.d, rssi: -30 - 50 * Math.log10(x.d) })));
    chk(!!b && !b.nLibre && b.n === 2, 'distance du toit : exposant aberrant → fixé à 2');
    chk(refPortatif([-24, -20, -31]) === -24 && refPortatif([]) === null, 'signal du portatif à 1 m : médiane des tags');
    const l = etapes({ boussole: true, rf: null, tagsEtalonnes: 2, tagsConnus: 3, toit: { errDeg: 25, date: 0 }, distToit: null, exposant: null, nidsTerrain: 0, maintenant: 1000 });
    chk(l.map((x) => x.etat).join() === 'fait,afaire,afaire,arefaire,auto' && resteAFaire(l) === 3, 'étapes d\'étalonnage : état et reste à faire');
  }
  // --- chrono automatique avec le portatif (appât lâché à la main)
  {
    const { chronoVide, lacher, presencePortatif, tramePortatif, tic, appatActif } = await import('../src/calc/appat');
    const c = chronoVide(), ap = { lat: 45, lon: 3.9 };
    lacher(c, 7, ap.lat, ap.lon, 'main', 0);
    let t = 0, ajout = false;
    const seconde = (niveau: number | null, pres = true) => { t += 1000; if (pres) presencePortatif(c, ap, t); if (niveau !== null) ajout = tramePortatif(c, 7, niveau, t) || ajout; tic(c, t); };
    for (let i = 0; i < 30; i++) seconde(-45);            // au bord de l'appât
    for (let i = 0; i < 25; i++) seconde(null);           // plus rien : parti
    const parti = appatActif(c, 7)!.etat === 2;
    for (let i = 0; i < 180; i++) seconde(null);          // 3 min d'absence
    seconde(-47);                                         // revenu
    chk(parti && ajout && c.appats[0].trajets.length === 1 && Math.abs(c.appats[0].trajets[0].dureeS - 206) <= 3, `chrono au portatif : parti puis revenu (${c.appats[0].trajets[0]?.dureeS} s)`);
    const c2 = chronoVide(); lacher(c2, 8, ap.lat, ap.lon, 'main', 0); t = 0;
    const s2 = (niveau: number | null, pres: boolean) => { t += 1000; if (pres) presencePortatif(c2, ap, t); else presencePortatif(c2, { lat: 45.01, lon: 3.9 }, t); if (niveau !== null) tramePortatif(c2, 8, niveau, t); tic(c2, t); };
    for (let i = 0; i < 30; i++) s2(-45, true);
    for (let i = 0; i < 60; i++) s2(null, false);          // on emporte le portatif à 1 km : rien n'est conclu
    chk(appatActif(c2, 8)!.etat === 1, 'chrono au portatif : portatif emporté loin, pas de faux départ');
  }
  // --- réglages appris sur les sorties, météo du matin, recharge par le chargeur
  {
    const { vitesseApprise, facteurIncertitude } = await import('../src/calc/terrain');
    // nid à 600 m de l'appât, 55 s au nid, frelon à 4 m/s : trajet le plus rapide 600·2/4 + 55 = 355 s
    chk(vitesseApprise([{ distM: 600, durees: [400, 355, 420] }, { distM: 300, durees: [210, 205] }], 55) === 4, 'vitesse de vol apprise (4 m/s)');
    chk(vitesseApprise([{ distM: 600, durees: [355] }], 55) === null, 'vitesse : un seul trajet, rien');
    chk(facteurIncertitude([{ reelM: 60, afficheM: 30 }, { reelM: 40, afficheM: 20 }, { reelM: 50, afficheM: 25 }]) === 2 && facteurIncertitude([{ reelM: 1, afficheM: 1 }]) === null, 'estimations deux fois moins précises qu\'affiché');
    const { creneauxDesJours } = await import('../src/services/meteo');
    const h = (temp: number, vent = 10, pluie = 0) => Array.from({ length: 24 }, (_, i) => ({ h: i, temp: i >= 11 && i < 17 ? temp : 8, vent, dirVent: 0, pluie, activite: (i >= 11 && i < 17 && temp >= 12 && pluie < 0.5 ? 3 : 0) as 0 | 3 }));
    const cr = creneauxDesJours(new Map([['2026-11-15', h(18)], ['2026-11-16', h(18, 10, 2)]]));
    chk(cr.length === 1 && cr[0].debut === 11 && cr[0].fin === 17 && cr[0].temp === 18, 'météo : créneau du jour, journée de pluie ignorée');
    const { parsePortatif } = await import('../src/proto/portatif');
    const c = parsePortatif('{"type":"chg","tag":12,"batt":96,"fw":7,"rssi":-58,"utc":1763100000}');
    chk(c?.type === 'chg' && c.tag === 12 && c.batt === 96, 'tag posé sur le chargeur (ligne chg)');
  }
  // --- rappels, itinéraire des tags sans nouvelles, compte rendu de sortie
  {
    const { rappels, prochaine } = await import('../src/calc/rappels');
    const J = 86400000, now = new Date(2026, 10, 14, 10, 0).getTime();
    const R = { controleJours: 3, releverJours: 7, rechargeSeuilPct: 50, rechargeJours: 7, silenceJours: 2, heureMatin: 9, heureSoir: 18 };
    const nid = { id: 4, etat: 'traite', traite_ms: now - 5 * J } as never, nidFutur = { id: 5, etat: 'traite', traite_ms: now - 1 * J } as never;
    const piege = { id: 1, nom: 'P1', retire_ms: null, pose_ms: now - 10 * J, releves: [] } as never;
    const fiche = { id: 9, etat: 'pose', pose_ms: now - 5 * J, vu_ms: now - 3 * J, pile: 80, pile_ms: now, recharge_ms: now } as never;
    const l = rappels([nid, nidFutur], [piege], [fiche], R, now);
    const demain9 = new Date(2026, 10, 15, 9, 0).getTime();
    chk(l.length === 4 && l.filter((x) => x.titre === 'Contrôle de nid à faire').map((x) => x.date).join() === [demain9, new Date(2026, 10, 16, 9, 0).getTime()].join(), 'rappels : contrôle en retard demain 9 h, contrôle à venir le jour dû');
    chk(prochaine(now - 3 * J, 9, now) === demain9 && prochaine(now, 18, now) === new Date(2026, 10, 14, 18, 0).getTime(), 'rappels : prochaine heure');
    const { lienItineraire, ordreVisite } = await import('../src/calc/itineraire');
    const ordre = ordreVisite({ lat: 45, lon: 3.9 }, [{ lat: 45.02, lon: 3.9, nom: 'loin' }, { lat: 45.005, lon: 3.9, nom: 'près' }]).map((x) => x.nom).join();
    const url = lienItineraire({ lat: 45, lon: 3.9 }, [{ lat: 45.02, lon: 3.9, nom: 'a' }, { lat: 45.005, lon: 3.9, nom: 'b' }]);
    chk(ordre === 'près,loin' && !!url && url.includes('destination=45.020000,3.900000') && url.includes('waypoints=45.005000,3.900000'), 'itinéraire : plus proche d\'abord, lien Google Maps');
    const { texteCompteRendu, resumeCourt } = await import('../src/calc/compteRendu');
    const cr = { debut: now - 130 * 60000, fin: now, kmVoiture: 23.4, kmPied: 1.2, tags: [3, 12], estimations: [{ tag: 12, errM: 28 }], nidsTrouves: [{ id: 4, numero: 7, tag: 3 }], allersRetours: 5, arretes: 0 };
    const t = texteCompteRendu(cr, 'Nicolas');
    chk(resumeCourt(cr) === '2 h 10 · 2 tags · 1 nid trouvé' && t.includes('23,4 km en voiture, 1,2 km à pied') && t.includes('n° 7 (tag 003)') && t.includes('tag 012 à ± 28 m'), 'compte rendu de sortie');
  }
  console.log(ok ? 'OK' : 'ÉCHEC');
  process.exit(ok ? 0 : 1);
})();
