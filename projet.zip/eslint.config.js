// https://docs.expo.dev/guides/using-eslint/
const { defineConfig } = require('eslint/config');
const expoConfig = require('eslint-config-expo/flat');

module.exports = defineConfig([
  expoConfig,
  {
    ignores: ['dist/*'],
  },
  {
    // textes en français : les apostrophes dans <Text> ne posent aucun problème en React Native
    rules: { 'react/no-unescaped-entities': 'off' },
  },
]);
