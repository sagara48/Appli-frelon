/** Calendrier de saison : réglages (décalage, étapes faites) et rappel au démarrage d'une nouvelle étape. */
import { ecrireValeur, lireValeur } from '../db';
import { aRappeler, cleEtape, type Dates, type EtapeDatee } from '../calc/calendrier';

export type ReglagesCalendrier = { decalage: number; faites: Record<string, boolean>; rappelees: Record<string, boolean>; dates: Dates };
export const lireCalendrier = (): ReglagesCalendrier => ({ decalage: 0, faites: {}, rappelees: {}, dates: {}, ...(lireValeur<ReglagesCalendrier>('calendrier') ?? {}) });
export const ecrireCalendrier = (c: ReglagesCalendrier) => ecrireValeur('calendrier', c);

/** Au démarrage : une étape qui vient de commencer est rappelée une seule fois. */
export function rappelCalendrier(prevenir: (e: EtapeDatee) => void) {
  const c = lireCalendrier();
  const l = aRappeler(Date.now(), c.faites, c.rappelees, c.decalage, 14, c.dates);
  if (!l.length) return;
  const e = l[l.length - 1]; // la plus récente
  ecrireCalendrier({ ...c, rappelees: { ...c.rappelees, ...Object.fromEntries(l.map((x) => [cleEtape(x), true])) } });
  prevenir(e);
}
