/** Notifications locales (expo-notifications) : chaque famille (« meteo », « rappels »…) remplace ses notifications
 *  programmées à chaque calcul. Un appui sur la notification ouvre l'écran indiqué (data.url). Rien sur le web. */
import { Platform } from 'react-native';
import { router } from 'expo-router';
import { ecrireValeur, lireValeur } from '../db';

export type Notif = { date: number | null; titre: string; texte: string; url?: string }; // date null = tout de suite
type N = typeof import('expo-notifications');
let mod: N | null = null;
const notif = (): N | null => {
  if (Platform.OS === 'web') return null;
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  if (!mod) { try { mod = require('expo-notifications') as N; brancher(mod); } catch { mod = null; } }
  return mod;
};

function brancher(n: N) {
  n.setNotificationHandler({ handleNotification: async () => ({ shouldPlaySound: true, shouldSetBadge: false, shouldShowBanner: true, shouldShowList: true }) });
  n.addNotificationResponseReceivedListener((r) => {
    const url = r.notification.request.content.data?.url;
    if (typeof url === 'string' && url) { try { router.push(url as never); } catch { /* appli pas prête */ } }
  });
}

let autorise: boolean | null = null;
async function permission(n: N): Promise<boolean> {
  if (autorise !== null) return autorise;
  const p = await n.getPermissionsAsync();
  autorise = p.granted || (p.canAskAgain && (await n.requestPermissionsAsync()).granted);
  return autorise;
}

/** Remplace toutes les notifications programmées de la famille par celles-ci. */
export async function programmerFamille(famille: string, l: Notif[]) {
  const n = notif();
  if (!n) return;
  const cle = `notifs-${famille}`;
  for (const id of lireValeur<string[]>(cle) ?? []) await n.cancelScheduledNotificationAsync(id).catch(() => {});
  const ids: string[] = [];
  if (l.length && (await permission(n))) {
    for (const x of l) {
      const content = { title: x.titre, body: x.texte, data: x.url ? { url: x.url } : {} };
      const id = await n.scheduleNotificationAsync({
        content,
        trigger: x.date && x.date > Date.now() + 5000 ? { type: n.SchedulableTriggerInputTypes.DATE, date: new Date(x.date) } : null,
      }).catch(() => null);
      if (id && x.date) ids.push(id);
    }
  }
  ecrireValeur(cle, ids);
}

/** Notification immédiate (non remplacée). */
export async function notifier(titre: string, texte: string, url?: string) {
  const n = notif();
  if (!n || !(await permission(n))) return;
  await n.scheduleNotificationAsync({ content: { title: titre, body: texte, data: url ? { url } : {} }, trigger: null }).catch(() => {});
}

/** Le même jour (local) à heure:minute. */
export function aHeure(t: number, heure: number): number {
  const d = new Date(t); d.setHours(Math.floor(heure), Math.round((heure % 1) * 60), 0, 0);
  return d.getTime();
}
