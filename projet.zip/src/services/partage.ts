/** Partage entre téléphones (Supabase) : les nids, ruchers et pièges de toute l'équipe, synchronisés dans les deux sens.
 *  - Chaque téléphone envoie ses fiches modifiées, puis reçoit celles des autres ; en cas de conflit, la modification la plus récente gagne.
 *  - L'équipe est un code secret partagé : le serveur ne montre à chacun que les fiches de son code (voir SQL_PARTAGE).
 *  - Pas de bibliothèque : l'API REST de Supabase suffit (fetch). Les photos restent sur le téléphone qui les a prises. */
import { appliquerFiche, ecrireValeur, fichesModifiees, lireValeur, type FichePartagee } from '../db';
import { brancherSurModif, chargerCarnet } from './carnet';
import { journaliser } from './journal';
import { param } from './parametres';

export type ConfigPartage = { url: string; cle: string; equipe: string; nom: string; actif: boolean };
type Curseurs = { envoiMs: number; recu: string };
export type EtatPartage = { enCours: boolean; dernierOk: number; erreur: string; envoyees: number; recues: number };

const CLE_CONFIG = 'partage', CLE_CURSEURS = 'partageCurseurs';
let etat: EtatPartage = { enCours: false, dernierOk: 0, erreur: '', envoyees: 0, recues: 0 };
const abonnes = new Set<() => void>();
const publier = (p: Partial<EtatPartage>) => { etat = { ...etat, ...p }; abonnes.forEach((f) => f()); };
export const etatPartage = () => etat;
export const abonnerPartage = (f: () => void) => { abonnes.add(f); return () => { abonnes.delete(f); }; };

export const lireConfig = (): ConfigPartage => ({ url: '', cle: '', equipe: '', nom: '', actif: false, ...(lireValeur<ConfigPartage>(CLE_CONFIG) ?? {}) });
export const configComplete = (c: ConfigPartage) => /^https:\/\/.+/.test(c.url.trim()) && c.cle.trim().length > 20 && c.equipe.trim().length >= 16;

/** Nouveau code d'équipe : 24 caractères faciles à dicter (sans 0/O, 1/l). */
export function nouveauCode(): string {
  const a = 'abcdefghjkmnpqrstuvwxyz23456789';
  let s = '';
  for (let i = 0; i < 24; i++) s += a[Math.floor(Math.random() * a.length)];
  return s.replace(/(.{6})(?!$)/g, '$1-');
}

export function enregistrerConfig(c: ConfigPartage) {
  const avant = lireConfig();
  ecrireValeur(CLE_CONFIG, c);
  // autre serveur ou autre équipe : tout renvoyer et tout relire
  if (avant.url !== c.url || avant.equipe !== c.equipe) ecrireValeur(CLE_CURSEURS, { envoiMs: 0, recu: '1970-01-01T00:00:00Z' });
  if (c.actif && configComplete(c)) synchroniser();
}

const entetes = (c: ConfigPartage) => ({
  apikey: c.cle.trim(), Authorization: `Bearer ${c.cle.trim()}`, 'Content-Type': 'application/json', 'x-equipe': c.equipe.trim(),
});
const racine = (c: ConfigPartage) => `${c.url.trim().replace(/\/+$/, '')}/rest/v1/partage`;

async function verifier(r: Response, quoi: string) {
  if (r.ok) return;
  let detail = '';
  try { detail = (await r.text()).slice(0, 300); } catch {}
  throw new Error(`${quoi} : erreur ${r.status}${detail ? ` ${detail}` : ''}`);
}

type Ligne = { uid: string; equipe: string; type: FichePartagee['type']; data: Record<string, unknown>; maj_ms: number; supprime: boolean; auteur: string | null; recu: string };

let enCours: Promise<void> | null = null;
let dernierEssai = 0;
/** Envoie puis reçoit. Sans effet si le partage n'est pas réglé. Une seule synchronisation à la fois. */
export function synchroniser(): Promise<void> {
  const c = lireConfig();
  if (!c.actif || !configComplete(c)) return Promise.resolve();
  if (enCours) return enCours;
  dernierEssai = Date.now();
  enCours = (async () => {
    publier({ enCours: true });
    try {
      const cur = { envoiMs: 0, recu: '1970-01-01T00:00:00Z', ...(lireValeur<Curseurs>(CLE_CURSEURS) ?? {}) };
      // 1. envoi des fiches modifiées ici (le curseur est l'heure du début de l'envoi : une modification faite pendant l'envoi partira la fois suivante)
      const debut = Date.now() - 1;
      const aEnvoyer = fichesModifiees(cur.envoiMs);
      let envoyees = 0;
      for (let i = 0; i < aEnvoyer.length; i += 200) {
        const lot = aEnvoyer.slice(i, i + 200).map((f) => ({ uid: f.uid, equipe: c.equipe.trim(), type: f.type, data: f.data, maj_ms: f.maj_ms, supprime: f.supprime, auteur: f.auteur || param().nom || c.nom.trim() || null }));
        const r = await fetch(`${racine(c)}?on_conflict=uid`, { method: 'POST', headers: { ...entetes(c), Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify(lot) });
        await verifier(r, 'Envoi');
        envoyees += lot.length;
      }
      cur.envoiMs = Math.max(cur.envoiMs, debut);
      ecrireValeur(CLE_CURSEURS, cur);

      // 2. réception (avec 2 min de recouvrement : une écriture lente peut arriver avec une heure un peu plus ancienne)
      const depuis = new Date(Math.max(0, Date.parse(cur.recu) - 120000)).toISOString();
      let recues = 0, change = false, dernier = cur.recu;
      for (let page = 0; page < 50; page++) {
        const q = `select=*&equipe=eq.${encodeURIComponent(c.equipe.trim())}&recu=gt.${encodeURIComponent(depuis)}&order=recu.asc&limit=1000&offset=${page * 1000}`;
        const r = await fetch(`${racine(c)}?${q}`, { headers: entetes(c) });
        await verifier(r, 'Réception');
        const lignes = (await r.json()) as Ligne[];
        for (const l of lignes) {
          if (appliquerFiche({ uid: l.uid, type: l.type, data: l.data, maj_ms: Number(l.maj_ms), supprime: l.supprime, auteur: l.auteur ?? '' })) { change = true; recues++; }
          if (Date.parse(l.recu) > Date.parse(dernier)) dernier = l.recu;
        }
        if (lignes.length < 1000) break;
      }
      ecrireValeur(CLE_CURSEURS, { ...cur, recu: dernier });
      if (change) chargerCarnet();
      if (envoyees || recues) journaliser('partage', 'etat', `${envoyees} fiche${envoyees > 1 ? 's' : ''} envoyée${envoyees > 1 ? 's' : ''}, ${recues} reçue${recues > 1 ? 's' : ''}`);
      publier({ enCours: false, dernierOk: Date.now(), erreur: '', envoyees: etat.envoyees + envoyees, recues: etat.recues + recues });
    } catch (e) {
      const msg = String((e as Error).message ?? e);
      journaliser('partage', 'erreur', msg);
      publier({ enCours: false, erreur: /Network request failed|Failed to fetch/i.test(msg) ? 'Pas de réseau : nouvel essai plus tard.' : msg });
    } finally { enCours = null; }
  })();
  return enCours;
}

let minuterie: ReturnType<typeof setInterval> | null = null;
let attente: ReturnType<typeof setTimeout> | null = null;
/** Démarrage : synchronise tout de suite, à l'intervalle réglé (2 min par défaut), et 5 s après chaque modification du carnet. */
export function demarrerPartage() {
  brancherSurModif(() => {
    if (attente) clearTimeout(attente);
    attente = setTimeout(() => { attente = null; synchroniser(); }, 5000);
  });
  // vérifie chaque minute si l'intervalle réglé (Paramètres → Partage) est écoulé
  if (!minuterie) minuterie = setInterval(() => { if (Date.now() - dernierEssai >= param().syncMin * 60000 - 1000) synchroniser(); }, 60000);
  synchroniser();
  return () => { brancherSurModif(null); if (minuterie) clearInterval(minuterie); minuterie = null; };
}

/** Script à coller une fois dans Supabase (SQL Editor → New query → Run). */
export const SQL_PARTAGE = `-- Partage des nids et ruchers entre téléphones (Appli Frelons)
create table if not exists partage (
  uid text primary key,
  equipe text not null,
  type text not null,
  data jsonb not null,
  maj_ms bigint not null,
  supprime boolean not null default false,
  auteur text,
  recu timestamptz not null default clock_timestamp()
);
create index if not exists partage_equipe_recu on partage (equipe, recu);
alter table partage drop constraint if exists partage_type_check;
alter table partage add constraint partage_type_check check (type in ('nid', 'rucher', 'piege'));

-- la modification la plus récente gagne ; date de réception posée par le serveur
create or replace function partage_avant() returns trigger language plpgsql as $$
begin
  if tg_op = 'UPDATE' and (new.maj_ms <= old.maj_ms or new.equipe <> old.equipe) then
    return null;
  end if;
  new.recu := clock_timestamp();
  return new;
end $$;
drop trigger if exists partage_avant on partage;
create trigger partage_avant before insert or update on partage
  for each row execute function partage_avant();

-- chacun ne voit que les fiches de son code d'équipe (envoyé par l'appli dans l'en-tête x-equipe)
create or replace function equipe_demandee() returns text language sql stable as $$
  select coalesce(current_setting('request.headers', true)::json ->> 'x-equipe', '')
$$;
alter table partage enable row level security;
drop policy if exists partage_equipe on partage;
create policy partage_equipe on partage for all to anon
  using (equipe = equipe_demandee() and length(equipe) >= 16)
  with check (equipe = equipe_demandee() and length(equipe) >= 16);
grant select, insert, update on partage to anon;
`;
