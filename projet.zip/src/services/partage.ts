/** Partage entre téléphones (Supabase) : les nids, ruchers et pièges de toute l'équipe, synchronisés dans les deux sens.
 *  - Chacun se connecte avec son compte (services/auth.ts) et fait partie d'une équipe (créée par un responsable,
 *    rejointe avec un code d'invitation). Le serveur ne montre à chacun que les fiches de ses équipes (voir sqlPartage.ts).
 *  - Chaque téléphone envoie ses fiches modifiées, puis reçoit celles des autres ; en cas de conflit, la modification la plus récente gagne.
 *  - Pas de bibliothèque : l'API REST de Supabase suffit (fetch). Les photos restent sur le téléphone qui les a prises. */
import { appliquerFiche, ecrireValeur, fichesModifiees, lireValeur } from '../db';
import { abonnerSession, jetonValide, lireServeur, serveurComplet, sessionActuelle } from './auth';
import { brancherSurModif, chargerCarnet } from './carnet';
import { journaliser } from './journal';
import { param } from './parametres';
export { SQL_PARTAGE } from './sqlPartage';

export type Equipe = { id: string; nom: string; code: string };
export type Membre = { utilisateur: string; nom: string | null; email: string | null; admin: boolean; rejoint_le: string };
export type ConfigPartage = { actif: boolean; equipe: Equipe | null };
type Curseurs = { envoiMs: number; recu: string };
export type EtatPartage = { enCours: boolean; dernierOk: number; erreur: string; envoyees: number; recues: number };

const CLE_CONFIG = 'partageEquipe', CLE_CURSEURS = 'partageCurseurs';
const CURSEURS_VIDES: Curseurs = { envoiMs: 0, recu: '1970-01-01T00:00:00Z' };
let etat: EtatPartage = { enCours: false, dernierOk: 0, erreur: '', envoyees: 0, recues: 0 };
const abonnes = new Set<() => void>();
const publier = (p: Partial<EtatPartage>) => { etat = { ...etat, ...p }; abonnes.forEach((f) => f()); };
export const etatPartage = () => etat;
export const abonnerPartage = (f: () => void) => { abonnes.add(f); return () => { abonnes.delete(f); }; };

export const lireConfig = (): ConfigPartage => ({ actif: true, equipe: null, ...(lireValeur<ConfigPartage>(CLE_CONFIG) ?? {}) });
function ecrireConfig(c: ConfigPartage) {
  const avant = lireConfig();
  ecrireValeur(CLE_CONFIG, c);
  // autre équipe : tout renvoyer et tout relire
  if (avant.equipe?.id !== c.equipe?.id) ecrireValeur(CLE_CURSEURS, CURSEURS_VIDES);
  publier({});
}
export function activerPartage(actif: boolean) { ecrireConfig({ ...lireConfig(), actif }); if (actif) synchroniser(); }

/* ---------- appels au serveur ---------- */
async function requete<T>(chemin: string, init: RequestInit & { prefer?: string } = {}): Promise<T> {
  const s = lireServeur();
  if (!serveurComplet(s)) throw new Error('Serveur de l\'équipe non réglé.');
  const jeton = await jetonValide();
  if (!jeton) throw new Error('Connectez-vous pour partager.');
  let r: Response;
  try {
    r = await fetch(`${s.url}/rest/v1/${chemin}`, {
      ...init,
      headers: { apikey: s.cle, Authorization: `Bearer ${jeton}`, 'Content-Type': 'application/json', ...(init.prefer ? { Prefer: init.prefer } : {}) },
    });
  } catch { throw new Error('Pas de réseau : nouvel essai plus tard.'); }
  const t = await r.text();
  let j: unknown = null;
  try { j = t ? JSON.parse(t) : null; } catch {}
  if (!r.ok) {
    const m = (j as { message?: string } | null)?.message ?? t.slice(0, 200);
    if (/relation .* does not exist|Could not find the (table|function)/i.test(m)) throw new Error('Le serveur n\'est pas préparé : lancez le script SQL de l\'écran Partage dans Supabase.');
    throw new Error(m || `Erreur ${r.status}`);
  }
  return j as T;
}
const rpc = <T>(fonction: string, args: Record<string, unknown>) => requete<T>(`rpc/${fonction}`, { method: 'POST', body: JSON.stringify(args) });
const monNom = () => param().nom || sessionActuelle()?.utilisateur.nom || sessionActuelle()?.utilisateur.email.split('@')[0] || '';

/* ---------- équipe ---------- */
export async function creerEquipe(nom: string): Promise<Equipe> {
  const e = await rpc<Equipe>('creer_equipe', { p_nom: nom, p_mon_nom: monNom() });
  ecrireConfig({ actif: true, equipe: { id: e.id, nom: e.nom, code: e.code } });
  journaliser('partage', 'etat', `Équipe créée : ${e.nom}`);
  synchroniser();
  return e;
}
export async function rejoindreEquipe(code: string): Promise<Equipe> {
  const e = await rpc<Equipe>('rejoindre_equipe', { p_code: code, p_mon_nom: monNom() });
  ecrireConfig({ actif: true, equipe: { id: e.id, nom: e.nom, code: e.code } });
  journaliser('partage', 'etat', `Équipe rejointe : ${e.nom}`);
  synchroniser();
  return e;
}
/** Équipe (nom, code à jour) et membres, relus sur le serveur. Si l'on a été retiré de l'équipe, on la quitte ici aussi. */
export async function lireEquipe(): Promise<{ equipe: Equipe; membres: Membre[] } | null> {
  const c = lireConfig();
  if (!c.equipe) return null;
  const [eqs, membres] = await Promise.all([
    requete<Equipe[]>(`equipe?select=id,nom,code&id=eq.${c.equipe.id}`),
    requete<Membre[]>(`membre?select=utilisateur,nom,email,admin,rejoint_le&equipe=eq.${c.equipe.id}&order=rejoint_le.asc`),
  ]);
  if (!eqs.length) { ecrireConfig({ ...c, equipe: null }); throw new Error('Vous ne faites plus partie de cette équipe.'); }
  if (eqs[0].nom !== c.equipe.nom || eqs[0].code !== c.equipe.code) ecrireConfig({ ...c, equipe: eqs[0] });
  return { equipe: eqs[0], membres };
}
export const changerCode = async () => { const c = lireConfig(); const code = await rpc<string>('changer_code', { p_equipe: c.equipe?.id }); if (c.equipe) ecrireConfig({ ...c, equipe: { ...c.equipe, code } }); return code; };
export const nommerResponsable = (utilisateur: string, admin: boolean) => rpc<null>('nommer_admin', { p_equipe: lireConfig().equipe?.id, p_utilisateur: utilisateur, p_admin: admin });
export const retirerMembre = (utilisateur: string) => requete<null>(`membre?equipe=eq.${lireConfig().equipe?.id}&utilisateur=eq.${utilisateur}`, { method: 'DELETE' });
export async function quitterEquipe() {
  const s = sessionActuelle();
  if (s && lireConfig().equipe) await retirerMembre(s.utilisateur.id).catch(() => {});
  ecrireConfig({ ...lireConfig(), equipe: null });
}
/** Après une déconnexion : l'équipe est oubliée sur ce téléphone (un autre compte peut s'y connecter). */
export function oublierEquipe() { ecrireConfig({ ...lireConfig(), equipe: null }); }

/* ---------- synchronisation ---------- */
type Ligne = { uid: string; equipe: string; type: 'nid' | 'rucher' | 'piege'; data: Record<string, unknown>; maj_ms: number; supprime: boolean; auteur: string | null; recu: string };

let enCours: Promise<void> | null = null;
let dernierEssai = 0;
let aRelancer = false;
/** Prêt à synchroniser : serveur réglé, connecté, membre d'une équipe, partage activé. */
export const partagePret = () => { const c = lireConfig(); return c.actif && !!c.equipe && !!sessionActuelle() && serveurComplet(lireServeur()); };

/** Envoie puis reçoit. Sans effet si le partage n'est pas prêt. Une seule synchronisation à la fois. */
export function synchroniser(): Promise<void> {
  if (!partagePret()) return Promise.resolve();
  // déjà en cours : on relancera à la fin, pour envoyer ce qui a changé entre-temps
  if (enCours) { aRelancer = true; return enCours; }
  const equipe = lireConfig().equipe!.id;
  dernierEssai = Date.now();
  enCours = (async () => {
    publier({ enCours: true });
    try {
      const cur = { ...CURSEURS_VIDES, ...(lireValeur<Curseurs>(CLE_CURSEURS) ?? {}) };
      // 1. envoi des fiches modifiées ici (le curseur est l'heure du début de l'envoi : une modification faite pendant l'envoi partira la fois suivante)
      const debut = Date.now() - 1;
      const aEnvoyer = fichesModifiees(cur.envoiMs);
      let envoyees = 0;
      for (let i = 0; i < aEnvoyer.length; i += 200) {
        const lot = aEnvoyer.slice(i, i + 200).map((f) => ({ uid: f.uid, equipe, type: f.type, data: f.data, maj_ms: f.maj_ms, supprime: f.supprime, auteur: f.auteur || monNom() || null }));
        await requete<null>('fiche?on_conflict=uid', { method: 'POST', prefer: 'resolution=merge-duplicates,return=minimal', body: JSON.stringify(lot) });
        envoyees += lot.length;
      }
      cur.envoiMs = Math.max(cur.envoiMs, debut);
      ecrireValeur(CLE_CURSEURS, cur);

      // 2. réception (avec 2 min de recouvrement : une écriture lente peut arriver avec une heure un peu plus ancienne)
      const depuis = new Date(Math.max(0, Date.parse(cur.recu) - 120000)).toISOString();
      let recues = 0, change = false, dernier = cur.recu;
      for (let page = 0; page < 50; page++) {
        const lignes = await requete<Ligne[]>(`fiche?select=*&equipe=eq.${equipe}&recu=gt.${encodeURIComponent(depuis)}&order=recu.asc&limit=1000&offset=${page * 1000}`);
        for (const l of lignes) {
          if (appliquerFiche({ uid: l.uid, type: l.type, data: l.data, maj_ms: Number(l.maj_ms), supprime: l.supprime, auteur: l.auteur ?? '' })) { change = true; recues++; }
          if (Date.parse(l.recu) > Date.parse(dernier)) dernier = l.recu;
        }
        if (lignes.length < 1000) break;
      }
      ecrireValeur(CLE_CURSEURS, { ...cur, recu: dernier });
      if (change) chargerCarnet();
      if (envoyees || recues) journaliser('partage', 'etat', `${envoyees} fiche${envoyees > 1 ? 's' : ''} envoyée${envoyees > 1 ? 's' : ''}, ${recues} reçue${recues > 1 ? 's' : ''}`);
      publier({ enCours: false, dernierOk: Date.now(), erreur: '', envoyees: etat.envoyees + envoyees, recues: etat.recues + recues });
    } catch (e) {
      const msg = String((e as Error).message ?? e);
      journaliser('partage', 'erreur', msg);
      publier({ enCours: false, erreur: msg });
    } finally {
      enCours = null;
      if (aRelancer) { aRelancer = false; setTimeout(() => { synchroniser(); }, 500); }
    }
  })();
  return enCours;
}

let minuterie: ReturnType<typeof setInterval> | null = null;
let attente: ReturnType<typeof setTimeout> | null = null;
/** Démarrage : synchronise tout de suite, à l'intervalle réglé (2 min par défaut), 5 s après chaque modification du carnet,
 *  et dès qu'on se connecte. */
export function demarrerPartage() {
  brancherSurModif(() => {
    if (attente) clearTimeout(attente);
    attente = setTimeout(() => { attente = null; synchroniser(); }, 5000);
  });
  if (!minuterie) minuterie = setInterval(() => { if (Date.now() - dernierEssai >= param().syncMin * 60000 - 1000) synchroniser(); }, 60000);
  const stopSession = abonnerSession(() => { publier({}); synchroniser(); });
  synchroniser();
  return () => { brancherSurModif(null); stopSession(); if (minuterie) clearInterval(minuterie); minuterie = null; };
}
