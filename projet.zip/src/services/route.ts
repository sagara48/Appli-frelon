/** Approche par la route : routes autour du nid demandées à OpenStreetMap (service Overpass), puis guidage Google Maps
 *  jusqu'au point de route le plus proche. Réseau nécessaire ; résultat gardé pour la position. */
import { Alert, Linking } from 'react-native';
import { routePourCroiser, type Croisement } from '../calc/croiser';
import { approche, CARROSSABLES, lienApproche, texteApproche, type Approche, type Voie } from '../calc/route';

const cache = new Map<string, Approche | null>();
async function voiesAutour(lat: number, lon: number, rayonM: number): Promise<Voie[]> {
  const q = `[out:json][timeout:20];way(around:${rayonM},${lat},${lon})[highway~"^(${CARROSSABLES.join('|')})$"];out geom tags;`;
  const r = await fetch('https://overpass-api.de/api/interpreter', { method: 'POST', body: `data=${encodeURIComponent(q)}`, headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });
  if (!r.ok) throw new Error(`OpenStreetMap ne répond pas (${r.status})`);
  const j = await r.json() as { elements?: { tags?: { highway?: string; name?: string }; geometry?: { lat: number; lon: number }[] }[] };
  return (j.elements ?? []).filter((e) => e.geometry?.length).map((e) => ({ type: e.tags?.highway ?? '', nom: e.tags?.name, points: e.geometry! }));
}

/** « Où rouler pour croiser » : point de route le plus proche du point idéal, puis guidage Google Maps. */
export async function routePourCroiserEnLigne(nid: { lat: number; lon: number }, c: Croisement) {
  try {
    const voies = await voiesAutour(c.lat, c.lon, Math.max(600, c.distM));
    const p = routePourCroiser(nid, c, voies);
    if (!p) { Alert.alert('Pour croiser', 'Pas de route ni de chemin carrossable dans ce secteur : relevé à pied (portatif, tour sur soi-même) ou au drone.'); return; }
    Alert.alert('Pour croiser', `${p.nom ? `${p.nom}, ` : ''}${p.type === 'track' ? 'chemin' : 'route'} à ${p.distNidM} m du nid, ${p.ecartDeg}° de l'axe idéal. Garez-vous là et laissez le toit relever une minute.`,
      [{ text: 'Annuler', style: 'cancel' }, { text: 'Guider', onPress: () => Linking.openURL(lienApproche(p)).catch(() => {}) }]);
  } catch (e) {
    Alert.alert('Pour croiser', `${(e as Error).message}. Guidage vers le point idéal ?`, [{ text: 'Annuler', style: 'cancel' }, { text: 'Guider', onPress: () => Linking.openURL(lienApproche(c)).catch(() => {}) }]);
  }
}
export async function chercherApproche(lat: number, lon: number, rayonM = 800): Promise<Approche | null> {
  const cle = `${lat.toFixed(4)},${lon.toFixed(4)}`;
  if (cache.has(cle)) return cache.get(cle)!;
  const voies = await voiesAutour(lat, lon, rayonM);
  const a = approche({ lat, lon }, voies);
  cache.set(cle, a);
  return a;
}

/** Bouton « Y aller par la route » : cherche le point d'approche, l'annonce, ouvre le guidage. */
export async function allerParLaRoute(lat: number, lon: number) {
  try {
    const a = await chercherApproche(lat, lon);
    if (!a) { Alert.alert('Approche par la route', 'Aucune route ni chemin carrossable à moins de 800 m du nid : itinéraire jusqu\'au nid lui-même.', [{ text: 'Annuler', style: 'cancel' }, { text: 'Y aller', onPress: () => Linking.openURL(lienApproche({ lat, lon })).catch(() => {}) }]); return; }
    Alert.alert('Approche par la route', `${texteApproche(a)}.`, [{ text: 'Annuler', style: 'cancel' }, { text: 'Guider', onPress: () => Linking.openURL(lienApproche(a)).catch(() => {}) }]);
  } catch (e) {
    Alert.alert('Approche par la route', `${(e as Error).message}. Itinéraire jusqu'au nid lui-même ?`, [{ text: 'Annuler', style: 'cancel' }, { text: 'Y aller', onPress: () => Linking.openURL(lienApproche({ lat, lon })).catch(() => {}) }]);
  }
}
