/** Choix du fond de carte (plan IGN, photo aérienne, aucun), gardé dans le téléphone. */
import { ecrireValeur, lireValeur } from '../db';
import { store } from '../store/store';

export type Fond = 'plan' | 'photo' | 'aucun';
let fond: Fond | null = null;
export const fondCarte = (): Fond => (fond ??= lireValeur<Fond>('fond') ?? 'plan');
export function definirFond(f: Fond) { fond = f; ecrireValeur('fond', f); store.set({}); /* redessine la carte */ }
