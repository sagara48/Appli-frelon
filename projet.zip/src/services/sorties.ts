/** Compte rendu automatique de chaque sortie (Paramètres → Automatismes) : une sortie commence à la connexion du toit
 *  ou du portatif, se termine 30 min après la dernière déconnexion (ou à « Terminer la sortie »). Le résumé est gardé
 *  (50 derniers, Menu → Comptes rendus de sortie), noté dans le journal, et annoncé par une notification. */
import { useSyncExternalStore } from 'react';
import { ecrireValeur, lireValeur } from '../db';
import { store } from '../store/store';
import { distM } from '../calc/geo';
import { interventionsDe } from '../calc/intervention';
import { resumeCourt, type CompteRendu } from '../calc/compteRendu';
import { numeroNid } from './carnet';
import { notifier } from './notifs';
import { param } from './parametres';

type EnCours = { debut: number; tags: number[]; kmVoiture: number; kmPied: number; derV: { lat: number; lon: number } | null; derP: { lat: number; lon: number } | null; vuMs: number };
let cours: EnCours | null = lireValeur<EnCours>('sortieEnCours');
let liste: CompteRendu[] = lireValeur<CompteRendu[]>('comptesRendus') ?? [];
const abonnes = new Set<() => void>();
export const useComptesRendus = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, () => liste, () => liste);
export function supprimerCompteRendu(debut: number) { liste = liste.filter((c) => c.debut !== debut); ecrireValeur('comptesRendus', liste); abonnes.forEach((f) => f()); }

function terminer(fin: number) {
  const c = cours; cours = null; ecrireValeur('sortieEnCours', null);
  if (!c || fin - c.debut < 5 * 60000 || !param().autoCompteRendu) return;
  const e = store.get();
  const dans = (t: number | null | undefined) => !!t && t >= c.debut && t <= fin + 60000;
  const cr: CompteRendu = {
    debut: c.debut, fin, kmVoiture: Math.round(c.kmVoiture) / 1000, kmPied: Math.round(c.kmPied) / 1000, tags: [...c.tags].sort((a, b) => a - b),
    estimations: Object.values(e.tags).filter((t) => t.fusion?.ok).map((t) => ({ tag: t.id, errM: t.fusion!.errM })),
    nidsTrouves: e.nids.filter((n) => dans(n.t)).map((n) => ({ id: n.id, numero: numeroNid(e.nids, n.id), tag: n.tag })),
    allersRetours: e.chrono.appats.reduce((s, a) => s + a.trajets.filter((t) => dans(t.finMs)).length, 0),
    arretes: e.nids.filter((n) => interventionsDe(n).some((i) => (i.type === 'destruction' || i.type === 'retraitement') && dans(i.t))).length,
  };
  liste = [cr, ...liste].slice(0, 50);
  ecrireValeur('comptesRendus', liste);
  abonnes.forEach((f) => f());
  store.evenement(`Sortie terminée : ${resumeCourt(cr)}`);
  notifier('Sortie terminée', `${resumeCourt(cr)}. Compte rendu : Menu → Comptes rendus de sortie.`, '/sorties').catch(() => {});
}

let dernierEvt = '';
store.abonner(() => {
  const e = store.get();
  if (e.source === 'simulation') return;
  const connecte = (e.source === 'toit' && e.connexion === 'connecte') || (e.portatif.source === 'ble' && e.portatif.connexion === 'connecte');
  const now = Date.now();
  if (e.evenements[0] === 'Sortie terminée' && e.evenements[0] !== dernierEvt && cours) { dernierEvt = e.evenements[0]; terminer(now); return; }
  dernierEvt = e.evenements[0] ?? '';
  if (!connecte) return;
  if (!cours) cours = { debut: now, tags: [], kmVoiture: 0, kmPied: 0, derV: null, derP: null, vuMs: now };
  const c = cours;
  c.vuMs = now;
  for (const k of Object.keys(e.tags)) if (!c.tags.includes(Number(k))) c.tags.push(Number(k));
  const st = e.portatif.st;
  if (st && st.tag >= 0 && st.age < 10 && !c.tags.includes(st.tag)) c.tags.push(st.tag);
  if (e.toit && e.toit.lat && e.connexion === 'connecte') {
    const p = { lat: e.toit.lat, lon: e.toit.lon };
    if (!c.derV) c.derV = p; else { const d = distM(c.derV.lat, c.derV.lon, p.lat, p.lon); if (d > 15 && d < 3000) { c.kmVoiture += d; c.derV = p; } }
  }
  const dansVoiture = !!(st && e.toit && e.toit.lat && e.connexion === 'connecte' && distM(st.lat, st.lon, e.toit.lat, e.toit.lon) < 30); // portatif posé dans la voiture
  if (st && st.fix && e.portatif.connexion === 'connecte' && !dansVoiture) {
    const p = { lat: st.lat, lon: st.lon };
    if (!c.derP) c.derP = p; else { const d = distM(c.derP.lat, c.derP.lon, p.lat, p.lon); if (d > 8 && d < 500) { c.kmPied += d; c.derP = p; } }
  }
});
// sauvegarde de la sortie en cours, et fin 30 min après la dernière connexion
setInterval(() => {
  if (!cours) return;
  ecrireValeur('sortieEnCours', cours);
  if (Date.now() - cours.vuMs > 30 * 60000) terminer(cours.vuMs);
}, 60000);
