/** Paquets de mise à jour des appareils, gardés dans le téléphone (un par appareil, le plus récent importé), et
 *  proposition de mise à jour à la connexion d'un appareil en retard (Paramètres → Automatismes).
 *  Sans paquet gardé, l'appli cherche un fichier « …_mise_a_jour_bluetooth.zip » dans la dernière version publiée
 *  du dépôt (Paramètres → Partage et mises à jour). */
import { Alert, Platform } from 'react-native';
import { router } from 'expo-router';
import { Directory, File, Paths } from 'expo-file-system';
import { lirePaquet, LIBELLES, type Appareil, type Paquet } from '../dfu/paquet';
import { comparerVersions } from '../calc/versions';
import { journaliser } from './journal';
import { depot } from './majAppli';
import { param } from './parametres';
import { store } from '../store/store';

const dossier = () => { const d = new Directory(Paths.document, 'paquets'); if (!d.exists) d.create(); return d; };

/** Garde le paquet (remplace un paquet plus ancien du même appareil). */
export function garderPaquet(zip: Uint8Array, p: Paquet) {
  try {
    const avant = lirePaquetsGardes()[p.appareil];
    if (avant && comparerVersions(avant.version, p.version) > 0) return; // on garde le plus récent
    const f = new File(dossier(), `${p.appareil}.zip`);
    if (f.exists) f.delete();
    f.create(); f.write(zip);
  } catch { /* stockage indisponible (web) */ }
}
export function lirePaquetsGardes(): Partial<Record<Appareil, Paquet>> {
  const r: Partial<Record<Appareil, Paquet>> = {};
  try {
    for (const x of dossier().list()) {
      if (!(x instanceof File) || !x.name.endsWith('.zip')) continue;
      try { const p = lirePaquet(x.bytesSync(), x.name); r[p.appareil] = p; } catch { /* fichier abîmé */ }
    }
  } catch { /* web */ }
  return r;
}

const PREFIXES: Partial<Record<Appareil, string>> = { toit: 'chef', portatif: 'portatif' };
/** Cherche le paquet de l'appareil dans la dernière version publiée du dépôt ; le garde s'il est trouvé. */
export async function telechargerPaquet(app: Appareil): Promise<Paquet | null> {
  const pre = PREFIXES[app];
  if (!pre) return null;
  const r = await fetch(`https://api.github.com/repos/${depot()}/releases/latest`, { headers: { Accept: 'application/vnd.github+json' } });
  if (!r.ok) return null;
  const j = await r.json() as { assets?: { name: string; browser_download_url: string }[] };
  const a = j.assets?.find((x) => x.name.startsWith(pre) && x.name.endsWith('_mise_a_jour_bluetooth.zip'));
  if (!a) return null;
  const z = new Uint8Array(await (await fetch(a.browser_download_url)).arrayBuffer());
  const p = lirePaquet(z, a.name);
  garderPaquet(z, p);
  journaliser(app === 'toit' ? 'toit' : 'portatif', 'etat', `paquet ${p.version} téléchargé depuis le dépôt`);
  return p;
}

/** À la connexion d'un appareil en retard : propose la mise à jour (une fois par connexion). */
const proposes = new Set<string>();
export async function proposerMiseAJour(app: 'toit' | 'portatif', installee: string) {
  if (Platform.OS === 'web' || !param().autoMajFirmware) return;
  const cle = `${app}:${installee}`;
  if (proposes.has(cle)) return;
  proposes.add(cle);
  let p: Paquet | null | undefined = lirePaquetsGardes()[app];
  if (!p || comparerVersions(p.version, installee) <= 0) p = await telechargerPaquet(app).catch(() => null);
  if (!p || comparerVersions(p.version, installee) <= 0) {
    store.set({ bandeau: { texte: `${LIBELLES[app]} en ${installee} : une version plus récente existe. Importez son paquet (Menu → Mises à jour).`, grave: false, ms: Date.now() } });
    return;
  }
  const v = p.version;
  Alert.alert(`Mettre à jour le ${app === 'toit' ? 'toit' : 'portatif'} ?`,
    `Installé : ${installee}. Disponible : ${v}.\nEnviron 2 minutes, appareil allumé à moins de 2 m du téléphone. Si la nouvelle version ne démarre pas, l'ancienne revient.`,
    [{ text: 'Plus tard', style: 'cancel' }, { text: 'Mettre à jour', onPress: () => router.push({ pathname: '/mises-a-jour', params: { auto: app } }) }]);
}
