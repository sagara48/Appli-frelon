/**
 * Météo d'activité des frelons (Open-Meteo, gratuit, sans clé) : prévisions heure par heure et sur 4 jours.
 * Activité : forte au-dessus de 12 °C, gênée au-delà de 25 km/h de vent, nulle sous la pluie (seuils du cahier des charges).
 */
export type Heure = { h: number; temp: number; vent: number; dirVent: number; pluie: number; activite: 0 | 1 | 2 | 3 };
export type Jour = { date: string; tmax: number; ventMax: number; pluie: number; activite: 0 | 1 | 2 | 3 };
export type Meteo = { heures: Heure[]; jours: Jour[]; coucher: string; recuMs: number };
export type Seuils = { tempMin: number; ventMax: number };
export const seuilsDefaut: Seuils = { tempMin: 12, ventMax: 25 };

/** 0 nulle, 1 faible, 2 moyenne, 3 forte. */
export function activite(temp: number, vent: number, pluie: number, s: Seuils = seuilsDefaut): 0 | 1 | 2 | 3 {
  if (pluie >= 0.5) return 0;
  if (temp < s.tempMin - 4) return 0;
  let a: 0 | 1 | 2 | 3 = temp >= s.tempMin + 4 ? 3 : temp >= s.tempMin ? 2 : 1;
  if (vent > s.ventMax) a = Math.max(0, a - 2) as 0 | 1;
  else if (vent > s.ventMax * 0.7) a = Math.max(0, a - 1) as 0 | 1 | 2;
  return a;
}

export async function chargerMeteo(lat: number, lon: number, s: Seuils = seuilsDefaut): Promise<Meteo> {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat.toFixed(4)}&longitude=${lon.toFixed(4)}` +
    '&hourly=temperature_2m,precipitation,wind_speed_10m,wind_direction_10m&daily=temperature_2m_max,precipitation_sum,wind_speed_10m_max,sunset' +
    '&timezone=auto&forecast_days=4';
  const r = await fetch(url);
  if (!r.ok) throw new Error(`Météo indisponible (${r.status})`);
  const j = await r.json();
  const aujourdhui = String(j.daily.time[0]);
  const heures: Heure[] = [];
  (j.hourly.time as string[]).forEach((t, i) => {
    if (!t.startsWith(aujourdhui)) return;
    const h = Number(t.slice(11, 13));
    const temp = j.hourly.temperature_2m[i], vent = j.hourly.wind_speed_10m[i], pluie = j.hourly.precipitation[i];
    heures.push({ h, temp, vent, dirVent: j.hourly.wind_direction_10m[i], pluie, activite: activite(temp, vent, pluie, s) });
  });
  const jours: Jour[] = (j.daily.time as string[]).map((d, i) => ({
    date: d, tmax: j.daily.temperature_2m_max[i], ventMax: j.daily.wind_speed_10m_max[i], pluie: j.daily.precipitation_sum[i],
    activite: activite(j.daily.temperature_2m_max[i], j.daily.wind_speed_10m_max[i] * 0.8, j.daily.precipitation_sum[i] > 2 ? 1 : 0, s),
  }));
  return { heures, jours, coucher: String(j.daily.sunset[0]).slice(11, 16), recuMs: Date.now() };
}

/** Meilleur créneau du jour : plus longue suite d'heures à activité ≥ 2 entre 8 h et 19 h. */
export function meilleurCreneau(h: Heure[]): { debut: number; fin: number } | null {
  let best: { debut: number; fin: number } | null = null, debut = -1;
  const jour = h.filter((x) => x.h >= 8 && x.h <= 19);
  jour.forEach((x, i) => {
    if (x.activite >= 2) { if (debut < 0) debut = x.h; }
    if ((x.activite < 2 || i === jour.length - 1) && debut >= 0) {
      const fin = x.activite >= 2 ? x.h + 1 : x.h;
      if (!best || fin - debut > best.fin - best.debut) best = { debut, fin };
      debut = -1;
    }
  });
  return best;
}
