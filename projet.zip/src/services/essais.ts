/** Enregistrement des essais : toutes les mesures brutes d'une sortie dans un fichier texte, pour régler les seuils et
 *  les modèles sur de vraies données. Une ligne par mesure : « heure_ms;source;ligne ».
 *  Sources : T toit (lignes du chef, niveaux non lissés pendant l'essai), P portatif (dont « f » = chaque trame reçue),
 *  D drone (dos de l'écran), G GPS du téléphone (toutes les 5 s), R repère noté par l'utilisateur, I informations. */
import { useSyncExternalStore } from 'react';
import { Alert, Platform } from 'react-native';
import Constants from 'expo-constants';
import * as Sharing from 'expo-sharing';
import { Directory, File, Paths } from 'expo-file-system';
import { espionnerLignes, store } from '../store/store';
import { cmdToit } from '../proto/toit';
import { cmdPortatif } from '../proto/portatif';
import { envoyerToit } from '../sources/commandesToit';
import { envoyerPortatif } from '../sources/portatif';
import { param } from './parametres';

type Etat = { actif: boolean; auto: boolean; debut: number; nom: string; lignes: number; parSource: Record<string, number>; octets: number; dernierRepere: string };
let etat: Etat = { actif: false, auto: false, debut: 0, nom: '', lignes: 0, parSource: {}, octets: 0, dernierRepere: '' };
const abonnes = new Set<() => void>();
const publier = (p: Partial<Etat>) => { etat = { ...etat, ...p }; abonnes.forEach((f) => f()); };
export const useEssai = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, () => etat, () => etat);

const dossier = () => { const d = new Directory(Paths.document, 'essais'); if (!d.exists) d.create(); return d; };
let tampon: string[] = [], fichier: File | null = null;
let minuteur: ReturnType<typeof setInterval> | null = null;

/** Ajoute une ligne à l'essai en cours (sans effet sinon). */
export function noterEssai(src: string, ligne: string) {
  if (!etat.actif) return;
  tampon.push(`${Date.now()};${src};${ligne.replace(/[\r\n]+/g, ' ').trim()}`);
  const ps = { ...etat.parSource, [src]: (etat.parSource[src] ?? 0) + 1 };
  etat = { ...etat, lignes: etat.lignes + 1, parSource: ps };
}
function vider() {
  if (!fichier || !tampon.length) return;
  const txt = tampon.join('\n') + '\n';
  tampon = [];
  try { fichier.write(txt, { append: true }); } catch { /* disque plein ? */ }
  publier({ octets: etat.octets + txt.length });
}
/** Mode brut des appareils connectés (et à chaque reconnexion pendant l'essai). */
function brut(on: boolean) {
  const e = store.get();
  if (e.source === 'toit' && e.connexion === 'connecte') envoyerToit(cmdToit.brut(on)).catch(() => {});
  if (e.portatif.connexion === 'connecte' && e.portatif.source === 'ble') envoyerPortatif(cmdPortatif.brut(on)).catch(() => {});
}

/** Essai à la main (mode brut, repères) ; auto = enregistrement de la sortie, lancé seul à la connexion d'un appareil,
 *  sans mode brut (le comportement des appareils ne change pas), fichier « sortie_… » (10 gardés). */
export function demarrerEssai(auto = false) {
  if (etat.actif && etat.auto && !auto) arreterEssai(); // un essai à la main remplace l'enregistrement automatique
  if (etat.actif) return;
  const d = new Date(), z = (n: number) => String(n).padStart(2, '0');
  const nom = `${auto ? 'sortie' : 'essai'}_${d.getFullYear()}${z(d.getMonth() + 1)}${z(d.getDate())}_${z(d.getHours())}${z(d.getMinutes())}.txt`;
  try { fichier = new File(dossier(), nom); if (!fichier.exists) fichier.create(); }
  catch (err) { if (!auto) Alert.alert('Essai', `Impossible de créer le fichier : ${(err as Error).message}`); fichier = null; return; }
  if (auto) elaguer();
  const e = store.get(), P = param();
  const entete = [
    `# Essai frelons ${d.toISOString()}`,
    `# appli ${Constants.expoConfig?.version ?? '?'} ${Platform.OS} ${Platform.Version}`,
    `# toit ${e.versionToit?.fw ?? '-'} voies ${(e.versionToit?.voies ?? []).join('/')} ; portatif ${e.portatif.version?.fw ?? '-'}`,
    `# modele distance toit ref1m ${P.distRefToit} portatif ref1m ${P.distRefPortatif} exposant ${P.distExposant}`,
    `# etalonnage toit ${JSON.stringify(e.etalonnage.resultat ?? null)}`,
    '# format : heure_ms;source;ligne  (T toit, P portatif, D drone, G GPS telephone, R repere, I info)',
  ].join('\n') + '\n';
  fichier.write(entete);
  tampon = [];
  publier({ actif: true, auto, debut: Date.now(), nom, lignes: 0, parSource: {}, octets: entete.length, dernierRepere: '' });
  if (!auto) brut(true);
  let k = 0, connToit = '', connPort = '';
  minuteur = setInterval(() => {
    vider();
    const s = store.get();
    if (++k % 5 === 0 && s.telephone && Date.now() - s.telephone.recuMs < 10000)
      noterEssai('G', `${s.telephone.lat.toFixed(7)},${s.telephone.lon.toFixed(7)},${Math.round(s.telephone.precision)}`);
    // un appareil (re)connecté pendant l'essai passe en mode brut
    const ct = `${s.connexion}`, cp = `${s.portatif.connexion}`;
    if (ct !== connToit || cp !== connPort) { connToit = ct; connPort = cp; if (!etat.auto) brut(true); noterEssai('I', `toit ${ct} portatif ${cp}`); }
  }, 1000);
}
export function arreterEssai() {
  if (!etat.actif) return;
  noterEssai('I', 'fin');
  if (!etat.auto) brut(false);
  if (minuteur) clearInterval(minuteur);
  minuteur = null;
  vider();
  publier({ actif: false });
  fichier = null;
}
/** Repère de terrain (vérité du terrain) : « nid ici », « tag posé ici », note libre ; avec la position du téléphone. */
export function repere(texte: string) {
  const s = store.get(), t = s.telephone;
  noterEssai('R', `${texte}${t ? `;${t.lat.toFixed(7)},${t.lon.toFixed(7)},${Math.round(t.precision)}` : ';'}`);
  publier({ dernierRepere: texte });
}

export type FichierEssai = { nom: string; taille: number; uri: string };
export function listerEssais(): FichierEssai[] {
  try {
    return dossier().list().filter((x): x is File => x instanceof File && x.name.endsWith('.txt'))
      .map((f) => ({ nom: f.name, taille: f.size ?? 0, uri: f.uri })).sort((a, b) => b.nom.localeCompare(a.nom));
  } catch { return []; }
}
export const partagerEssai = (f: FichierEssai) => Sharing.shareAsync(f.uri, { mimeType: 'text/plain', dialogTitle: f.nom });
export function supprimerEssai(f: FichierEssai) { try { new File(f.uri).delete(); } catch { /* ignore */ } publier({}); }

espionnerLignes((src, l) => noterEssai(src, l));

/** Garde les 10 derniers enregistrements automatiques de sortie. */
function elaguer() {
  try {
    const l = dossier().list().filter((x): x is File => x instanceof File && x.name.startsWith('sortie_')).sort((a, b) => b.name.localeCompare(a.name));
    for (const f of l.slice(10)) f.delete();
  } catch { /* ignore */ }
}

/* enregistrement automatique : dès qu'un vrai appareil est connecté ; arrêté 10 min après la dernière déconnexion */
let plusRienDepuis = 0;
if (Platform.OS !== 'web') {
  setInterval(() => {
    const e = store.get();
    const connecte = (e.source === 'toit' && e.connexion === 'connecte') || (e.portatif.source === 'ble' && e.portatif.connexion === 'connecte');
    if (connecte) {
      plusRienDepuis = 0;
      if (!etat.actif && param().autoEssai) demarrerEssai(true);
    } else if (etat.actif && etat.auto) {
      if (!plusRienDepuis) plusRienDepuis = Date.now();
      else if (Date.now() - plusRienDepuis > 10 * 60000) { arreterEssai(); plusRienDepuis = 0; }
    }
  }, 5000);
}
