/** Voiture garée (point de départ à pied) : notée quand le toit est arrêté depuis 30 s (position GPS du toit), ou
 *  envoyée par le portatif 1.4.0 (il entend le toit tout près). Gardée dans la base, transmise au portatif à chaque
 *  connexion (« voit lat lon ») : sa flèche « Retour à la voiture » marche ensuite même sans téléphone.
 *  Retour : flèche du portatif, guidage à pied dans Google Maps, repère « P » sur la carte. */
import { useSyncExternalStore } from 'react';
import { Linking } from 'react-native';
import { ecrireValeur, lireValeur } from '../db';
import { distM } from '../calc/geo';
import { ecouterLignes, store } from '../store/store';
import { cmdPortatif } from '../proto/portatif';
import { envoyerPortatif } from '../sources/portatif';

export type Voiture = { lat: number; lon: number; t: number; src: 'toit' | 'portatif' | 'main' };
let V: Voiture | null | undefined;
const abonnes = new Set<() => void>();
const lire = (): Voiture | null => { if (V === undefined) { try { V = lireValeur<Voiture>('voiture') ?? null; } catch { V = null; } } return V; };
export const voitureGaree = lire;
export const useVoiture = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, lire, lire);

let envoyeeAuPortatif = '';
function noter(v: Voiture) {
  const a = lire();
  if (a && distM(a.lat, a.lon, v.lat, v.lon) < 10 && v.src === a.src) return;
  V = v;
  try { ecrireValeur('voiture', v); } catch { /* ignore */ }
  abonnes.forEach((f) => f());
  versPortatif();
}
export const noterVoitureIci = (lat: number, lon: number) => noter({ lat, lon, t: Date.now(), src: 'main' });

function versPortatif() {
  const v = lire(), p = store.get().portatif;
  if (!v || p.connexion !== 'connecte' || p.source !== 'ble') return;
  const cle = `${v.lat.toFixed(6)},${v.lon.toFixed(6)}`;
  if (cle === envoyeeAuPortatif) return;
  envoyeeAuPortatif = cle;
  envoyerPortatif(cmdPortatif.voiture(v.lat, v.lon)).catch(() => { envoyeeAuPortatif = ''; });
}

/** Flèche du portatif vers la voiture (et guidage Google Maps à pied si demandé). */
export async function retourVoiture(guidage = false) {
  const v = lire();
  if (!v) return false;
  const p = store.get().portatif;
  if (p.connexion === 'connecte') {
    await envoyerPortatif(cmdPortatif.cible(v.lat, v.lon, 'VOITURE')).catch(() => {});
    store.portatif({ cible: 'VOITURE' });
  }
  if (guidage) Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${v.lat.toFixed(6)},${v.lon.toFixed(6)}&travelmode=walking`).catch(() => {});
  return true;
}

/* toit arrêté depuis 30 s : la voiture est garée là */
let arretDepuis = 0, avantToit: unknown = null, avantPort = '';
store.abonner(() => {
  const e = store.get();
  if (e.toit !== avantToit) {
    avantToit = e.toit;
    const t = e.toit;
    if (t && e.source === 'toit' && e.connexion === 'connecte' && t.lat && t.sats >= 4) {
      if (t.vitesse < 1) {
        if (!arretDepuis) arretDepuis = Date.now();
        else if (Date.now() - arretDepuis > 30000) noter({ lat: t.lat, lon: t.lon, t: Date.now(), src: 'toit' });
      } else arretDepuis = 0;
    }
  }
  const pc = `${e.portatif.connexion}/${e.portatif.source}`;
  if (pc !== avantPort) { avantPort = pc; if (e.portatif.connexion !== 'connecte') envoyeeAuPortatif = ''; versPortatif(); }
});

/* portatif 1.4.0 : il a entendu le toit tout près */
ecouterLignes((src, ligne) => {
  if (src !== 'P' || !ligne.includes('"voit"')) return;
  try {
    const o = JSON.parse(ligne) as { type: string; lat: number; lon: number; utc: number };
    if (o.type !== 'voit' || !o.lat) return;
    const a = lire();
    const t = o.utc > 1e9 ? o.utc * 1000 : Date.now();
    if (a && a.t > t) return; // plus ancienne que celle qu'on a
    envoyeeAuPortatif = `${o.lat.toFixed(6)},${o.lon.toFixed(6)}`; // il l'a déjà
    noter({ lat: o.lat, lon: o.lon, t, src: 'portatif' });
  } catch { /* ignore */ }
});
