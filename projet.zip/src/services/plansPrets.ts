/** Plan de vol prêt d'avance : dès que le nid estimé d'un tag passe sous ± 30 m (incertitude corrigée de l'écart
 *  réel appris sur les nids trouvés), la mission Litchi (spirale) est calculée et gardée ; refaite si l'estimation bouge
 *  de plus de 15 m ou s'affine nettement. Menu → Vols du drone → Plans prêts. Paramètres → Automatismes. */
import { useSyncExternalStore } from 'react';
import { store } from '../store/store';
import { distM } from '../calc/geo';
import { genererPlan, litchiCsv, PLAN_DEFAUT, rayonConseille } from '../calc/planVol';
import { idTag } from '../ui/theme';
import { param } from './parametres';
import { facteurEstimations } from './terrain';

export type PlanPret = { tag: number; lat: number; lon: number; errM: number; errBrutM: number; t: number; points: number; dureeMin: number; rayonM: number; csv: string };
let plans: Record<number, PlanPret> = {};
const abonnes = new Set<() => void>();
const publier = (p: Record<number, PlanPret>) => { plans = p; abonnes.forEach((f) => f()); };
export const usePlansPrets = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, () => plans, () => plans);

const SEUIL_M = 30;
function verifier() {
  if (!param().autoPlanVol) return;
  const e = store.get(), k = facteurEstimations() ?? 1;
  let n = plans, change = false;
  for (const t of Object.values(e.tags)) {
    const f = t.fusion;
    if (!f?.ok) continue;
    const err = f.errM * k;
    if (err > SEUIL_M) continue;
    const avant = n[t.id];
    if (avant && distM(avant.lat, avant.lon, f.lat, f.lon) < 15 && err > avant.errM * 0.7) continue;
    const plan = genererPlan({ lat: f.lat, lon: f.lon }, { ...PLAN_DEFAUT, rayonM: rayonConseille(err) });
    n = { ...n, [t.id]: { tag: t.id, lat: f.lat, lon: f.lon, errM: Math.round(err), errBrutM: Math.round(f.errM), t: Date.now(), points: plan.points.length, dureeMin: plan.dureeMin, rayonM: plan.reglages.rayonM, csv: litchiCsv(plan) } };
    change = true;
    if (!avant) {
      const txt = `Plan de vol prêt pour le tag ${idTag(t.id)} (nid à ± ${Math.round(err)} m) : Menu → Vols du drone`;
      store.set({ bandeau: { texte: txt, grave: false, ms: Date.now() } });
      store.evenement(txt);
    }
  }
  if (change) publier(n);
}
setInterval(() => { try { verifier(); } catch { /* jamais bloquant */ } }, 5000);
