/** Ordres à distance aux tags (firmware tag 7), relayés par le portatif ou par le toit de la voiture
 *  (le téléphone ne parle pas directement aux tags) :
 *  - « Répond ? » : le tag accuse réception ; il marche et il a le firmware 7 ;
 *  - mode recherche : une trame toutes les 0,5 s pendant 10 min, pour finir plus vite au portatif ;
 *  - fin du mode recherche ;
 *  - désactivation : le tag s'éteint et ne se rallume que posé sur le chargeur.
 *  Le tag n'écoute qu'une trame sur cinq : un ordre met en général 5 à 20 s à passer, 60 s au plus. */
import { useSyncExternalStore } from 'react';
import { Alert } from 'react-native';
import { ecouterLignes, store } from '../store/store';
import { cmdPortatif, parsePortatif, type OrdreTag } from '../proto/portatif';
import { cmdToit, parseToit } from '../proto/toit';
import { envoyerPortatif } from '../sources/portatif';
import { envoyerToit } from '../sources/commandesToit';
import { idTag } from '../ui/theme';

export type Relais = 'portatif' | 'toit';
export type SuiviOrdre = { ordre: OrdreTag; etat: 'envoi' | 'ok' | 'echec' | 'occupe'; t: number; par: Relais; ms?: number };
export const LIBELLE_ORDRE: Record<OrdreTag, string> = { ping: 'Répond ?', rech: 'Mode recherche 10 min', fin: 'Fin du mode recherche', off: 'Désactivation' };
export const RECH_MS = 10 * 60000;
const DELAI_APPLI_MS = 75000; // le relais abandonne à 60 s ; au-delà, la réponse a été perdue

type Etat = { suivis: Record<number, SuiviOrdre>; rechJusqua: Record<number, number> };
let etat: Etat = { suivis: {}, rechJusqua: {} };
const abonnes = new Set<() => void>();
const publier = (p: Partial<Etat>) => { etat = { ...etat, ...p }; abonnes.forEach((f) => f()); };
export const useOrdres = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, () => etat, () => etat);
export const etatOrdres = () => etat;

/** Par où passer : le portatif d'abord (il est près du nid quand on cherche), sinon le toit. */
export function relaisOrdre(): Relais | null {
  const e = store.get();
  if (e.portatif.connexion === 'connecte' && e.portatif.source === 'ble') return 'portatif';
  if (e.source === 'toit' && e.connexion === 'connecte') return 'toit';
  return null;
}

/** Texte d'état d'un tag pour l'écran (dernier ordre, mode recherche en cours). */
export function texteOrdre(tag: number, maintenant: number): string | null {
  const s = etat.suivis[tag], r = etat.rechJusqua[tag];
  const rech = r && r > maintenant ? `Mode recherche encore ${Math.ceil((r - maintenant) / 60000)} min` : null;
  if (!s || maintenant - s.t > 10 * 60000) return rech;
  const quoi = LIBELLE_ORDRE[s.ordre].toLowerCase();
  const txt = s.etat === 'envoi' ? `Ordre « ${quoi} » en cours (via le ${s.par})…`
    : s.etat === 'ok' ? (s.ordre === 'ping' ? `Le tag répond (${Math.round((s.ms ?? 0) / 1000)} s)` : s.ordre === 'off' ? 'Tag désactivé : posez-le sur le chargeur pour le rallumer' : rech ?? `${LIBELLE_ORDRE[s.ordre]} : fait`)
    : s.etat === 'occupe' ? 'Un autre ordre est en cours, réessayez dans une minute'
    : `Pas de réponse à « ${quoi} » : tag trop loin, au nid profond, ou ancien firmware`;
  return s.etat === 'ok' && s.ordre === 'rech' ? txt : rech && s.etat !== 'envoi' ? `${txt} · ${rech}` : txt;
}

function noter(tag: number, p: Partial<SuiviOrdre> & { ordre: OrdreTag }, par: Relais) {
  const avant = etat.suivis[tag];
  const meme = avant && avant.ordre === p.ordre;
  const s: SuiviOrdre = { etat: 'envoi', t: meme ? avant.t : Date.now(), ...p, par: meme ? avant.par : par };
  const rechJusqua = { ...etat.rechJusqua };
  if (s.etat === 'ok' && s.ordre === 'rech') rechJusqua[tag] = Date.now() + RECH_MS; // le tag compte ses 10 min dès la réception
  if (s.etat === 'ok' && (s.ordre === 'fin' || s.ordre === 'off')) delete rechJusqua[tag];
  publier({ suivis: { ...etat.suivis, [tag]: s }, rechJusqua });
  if (p.etat === 'ok' || p.etat === 'echec') {
    store.evenement(p.etat === 'ok' ? `Tag ${idTag(tag)} : ${LIBELLE_ORDRE[s.ordre].toLowerCase()} OK` : `Tag ${idTag(tag)} : pas de réponse à « ${LIBELLE_ORDRE[s.ordre].toLowerCase()} »`);
  }
}

/** Envoie un ordre (sans confirmation). Renvoie false s'il n'y a ni portatif ni toit connecté. */
export async function envoyerOrdre(tag: number, ordre: OrdreTag): Promise<boolean> {
  const par = relaisOrdre();
  if (!par) return false;
  publier({ suivis: { ...etat.suivis, [tag]: { ordre, etat: 'envoi', t: Date.now(), par } } });
  try {
    await (par === 'portatif' ? envoyerPortatif(cmdPortatif.ordre(tag, ordre)) : envoyerToit(cmdToit.ordre(tag, ordre)));
  } catch {
    noter(tag, { ordre, etat: 'echec' }, par);
    return true;
  }
  setTimeout(() => { const s = etat.suivis[tag]; if (s && s.ordre === ordre && s.etat === 'envoi' && Date.now() - s.t >= DELAI_APPLI_MS - 100) noter(tag, { ordre, etat: 'echec' }, par); }, DELAI_APPLI_MS);
  return true;
}

/** Ordre avec les explications et la confirmation qui vont avec (désactivation surtout). */
export function demanderOrdre(tag: number, ordre: OrdreTag) {
  const par = relaisOrdre();
  if (!par) { Alert.alert('Ordre au tag', 'Connectez le portatif (ou le toit de la voiture) : ce sont eux qui transmettent l\'ordre au tag.'); return; }
  const go = () => { envoyerOrdre(tag, ordre).catch(() => {}); };
  if (ordre === 'off') {
    Alert.alert(`Désactiver le tag ${idTag(tag)} ?`,
      'Le tag s\'éteint et ne se rallume QUE posé sur le chargeur (la lumière ne le réveille pas). Sur un frelon, il ne sera plus jamais entendu.\n\n'
      + 'Si le nid vient d\'être traité, attendez la fin du contrôle par le tag (6 h au moins) avant de le désactiver.',
      [{ text: 'Annuler', style: 'cancel' }, { text: 'Désactiver', style: 'destructive', onPress: go }]);
    return;
  }
  go();
}

/* réponses des relais */
ecouterLignes((src, ligne) => {
  if (src === 'P') {
    const l = parsePortatif(ligne);
    if (l && l.type === 'ordre' && l.res !== 'go') noter(l.tag, { ordre: l.ordre, etat: l.res, ...(l.ms !== undefined ? { ms: l.ms } : {}) }, 'portatif');
  } else {
    const l = parseToit(ligne);
    if (l && l.kind === 'K' && l.type === 'TAG' && l.res !== 'go') noter(l.tag, { ordre: l.ordre, etat: l.res, ...(l.ms !== undefined ? { ms: l.ms } : {}) }, 'toit');
  }
});
