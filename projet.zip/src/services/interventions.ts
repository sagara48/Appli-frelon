/** Interventions sur les nids (enregistrées dans la fiche du nid, donc partagées avec l'équipe) et produits biocides. */
import { useSyncExternalStore } from 'react';
import { ecrireValeur, lireValeur, type Nid } from '../db';
import { etatDepuis, interventionVide, interventionsDe, PRODUITS_DEFAUT, type Intervention, type Produit, type TypeInter } from '../calc/intervention';
import { majNid } from './carnet';
import { param } from './parametres';
import { store } from '../store/store';

export const interventionsNid = (n: Nid) => interventionsDe(n);

/** Nouvelle intervention, préremplie : opérateur et Certibiocide du profil, client, produit et hauteur de la précédente. */
export function preparerIntervention(n: Nid, type: TypeInter): Intervention {
  const avant = interventionsDe(n);
  const der = avant[avant.length - 1];
  const p = param();
  const prod = der?.produit ? { produit: der.produit, substance: der.substance, amm: der.amm, lot: der.lot } : (() => {
    const p0 = lireProduits()[0];
    return p0 ? { produit: p0.nom, substance: p0.substance, amm: p0.amm } : {};
  })();
  return interventionVide(Date.now(), type, {
    operateur: p.operateur, certibiocide: p.certibiocide,
    client: der?.client ?? { nom: '', adresse: '', commune: '', tel: '' },
    hauteurM: der?.hauteurM ?? null, diametreCm: der?.diametreCm ?? null, methode: der?.methode ?? '',
    ...(type === 'controle' || type === 'deplacement' ? {} : prod),
  });
}

/** Ajoute ou remplace une intervention ; l'état du nid (traité, vérifié mort, à retraiter) en découle. */
export function enregistrerIntervention(nidId: number, i: Intervention) {
  const n = store.get().nids.find((x) => x.id === nidId);
  if (!n) return;
  const l = interventionsDe(n).filter((x) => x.id !== i.id);
  l.push(i);
  l.sort((a, b) => a.t - b.t);
  majNid(nidId, { interventions: JSON.stringify(l), ...(etatDepuis(l, n.etat) as Partial<Nid>) });
}
export function supprimerIntervention(nidId: number, id: string) {
  const n = store.get().nids.find((x) => x.id === nidId);
  if (!n) return;
  const l = interventionsDe(n).filter((x) => x.id !== id);
  majNid(nidId, { interventions: JSON.stringify(l), ...(etatDepuis(l, l.length ? n.etat : 'trouve') as Partial<Nid>) });
}

/* ---------- produits biocides ---------- */
let produits: Produit[] | null = null;
const abonnes = new Set<() => void>();
export function lireProduits(): Produit[] {
  if (!produits) { try { produits = lireValeur<Produit[]>('produits') ?? PRODUITS_DEFAUT; } catch { produits = PRODUITS_DEFAUT; } }
  return produits;
}
export function ecrireProduits(l: Produit[]) {
  produits = l.filter((p) => p.nom.trim());
  ecrireValeur('produits', produits);
  abonnes.forEach((f) => f());
}
const abonner = (f: () => void) => { abonnes.add(f); return () => { abonnes.delete(f); }; };
export const useProduits = () => useSyncExternalStore(abonner, lireProduits, lireProduits);
