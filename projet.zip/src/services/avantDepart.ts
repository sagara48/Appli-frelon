/** « Avant de partir » : ce que l'appli vérifie seule (batteries, GPS, versions, étalonnage, tags, carte, météo).
 *  À la connexion du toit ou du portatif (une fois par jour et par appareil), un bandeau dit ce qui manque.
 *  Paramètres → Automatismes. */
import { lireValeur } from '../db';
import { store, type Etat } from '../store/store';
import { raisonRecharge } from '../calc/saison';
import { verdict } from '../calc/versions';
import { idTag } from '../ui/theme';
import { reglagesRecharge } from './suiviTags';
import { param } from './parametres';
import { resteEtalonnage } from './etalonnages';
import type { Zone } from './tuiles';
import type { Meteo } from './meteo';

export type Point = { titre: string; detail: string; ok: boolean | null; valeur?: string; url?: string }; // null = inconnu

export function pointsAvantDepart(e: Etat, maint: number, resteEtal: number): Point[] {
  const toitOk = e.source === 'toit' && e.connexion === 'connecte' && e.toit;
  const portOk = e.portatif.connexion === 'connecte' && e.portatif.source === 'ble';
  const p = portOk ? e.portatif.st : null;
  const dispo = Object.values(e.fichesTags).filter((f) => f.etat === 'dispo').length;
  const rr = reglagesRecharge();
  const recharger = Object.values(e.fichesTags).filter((f) => f.etat !== 'pose' && f.etat !== 'perdu' && raisonRecharge(f, maint, rr.seuil, rr.jours) !== null);
  const zones = lireValeur<Zone[]>('zones') ?? [];
  const vt = toitOk ? verdict('toit', e.versionToit) : null, vp = portOk ? verdict('portatif', e.portatif.version) : null;
  const versionsOk = !toitOk && !portOk ? null : (!vt || vt.etat === 'ok') && (!vp || vp.etat === 'ok');
  const m = lireValeur<Meteo>('meteo');
  const auj = new Date(maint).toISOString().slice(0, 10);
  const cr = m && maint - m.recuMs < 24 * 3600000 ? (m.creneaux ?? []).find((c) => c.date === auj) : undefined;
  return [
    { titre: 'Toit chargé', detail: toitOk ? (e.toit!.charge ? 'en charge' : 'batterie') : 'connectez le toit pour vérifier', ok: toitOk ? e.toit!.battPct >= 50 : null, valeur: toitOk ? `${e.toit!.battPct} %` : undefined },
    { titre: 'GPS et voies du toit', detail: toitOk ? `${e.toit!.sats} satellites · ${[0, 1, 2, 3].filter((k) => (e.toit!.voiesOk >> k) & 1).length} voies sur 4` : 'connectez le toit pour vérifier', ok: toitOk ? e.toit!.sats >= 6 && e.toit!.voiesOk === 15 : null },
    { titre: 'Portatif', detail: p ? (p.bat < 50 ? 'à recharger : moins de 3 h d\'autonomie' : p.cmp === 2 ? 'chargé, boussole pas calibrée' : 'chargé') : 'connectez le portatif pour vérifier', ok: p ? p.bat >= 50 && p.cmp !== 2 : null, valeur: p ? `${p.bat} %` : undefined },
    { titre: 'Firmwares à jour', detail: versionsOk === null ? 'connectez un appareil pour vérifier' : versionsOk ? 'toit et portatif à jour' : [vt?.etat !== 'ok' ? vt?.texte : '', vp?.etat !== 'ok' ? vp?.texte : ''].filter(Boolean).join(' · '), ok: versionsOk, url: '/mises-a-jour' },
    { titre: 'Étalonnage', detail: resteEtal ? `${resteEtal} étape${resteEtal > 1 ? 's' : ''} à faire` : 'tout est étalonné', ok: resteEtal === 0, url: '/etalonnages' },
    { titre: 'Tags prêts', detail: 'tags marqués disponibles dans « Mes tags »', ok: dispo > 0, valeur: String(dispo), url: '/tags' },
    { titre: 'Tags rechargés', detail: recharger.length ? `à recharger : ${recharger.slice(0, 8).map((f) => idTag(f.id)).join(', ')}${recharger.length > 8 ? '…' : ''}` : 'tous rechargés récemment', ok: recharger.length === 0, valeur: recharger.length ? String(recharger.length) : undefined, url: '/tags?filtre=recharge' },
    { titre: 'Carte de la zone hors ligne', detail: zones.length ? zones.map((z) => z.nom).join(', ') : 'aucune zone téléchargée', ok: zones.length > 0, url: '/cartes-hors-ligne' },
    { titre: 'Météo du jour', detail: !m ? 'pas encore de prévision' : cr ? `bon créneau ${cr.debut} h – ${cr.fin} h, ${cr.temp} °C` : 'pas de bon créneau annoncé aujourd\'hui', ok: m ? !!cr : null, url: '/meteo' },
  ];
}

/* bandeau à la connexion : une fois par jour et par appareil, 15 s après (le temps des versions et de l'état) */
const vus = new Set<string>();
let attente: ReturnType<typeof setTimeout> | null = null;
store.abonner(() => {
  const e = store.get();
  const auj = new Date().toDateString();
  for (const [app, ok] of [['toit', e.source === 'toit' && e.connexion === 'connecte'], ['portatif', e.portatif.source === 'ble' && e.portatif.connexion === 'connecte']] as const) {
    const cle = `${app}:${auj}`;
    if (!ok || vus.has(cle) || attente || !param().autoAvantDepart) continue;
    vus.add(cle);
    attente = setTimeout(() => {
      attente = null;
      const l = pointsAvantDepart(store.get(), Date.now(), resteEtalonnage()).filter((x) => x.ok === false);
      const texte = l.length ? `Avant de partir : ${l.length} point${l.length > 1 ? 's' : ''} à voir (${l.slice(0, 3).map((x) => x.titre.toLowerCase()).join(', ')}${l.length > 3 ? '…' : ''}) : Menu → Avant de partir` : 'Avant de partir : tout ce que l\'appli peut vérifier est prêt.';
      store.set({ bandeau: { texte, grave: false, ms: Date.now() } });
      store.evenement(texte);
    }, 15000);
  }
});
