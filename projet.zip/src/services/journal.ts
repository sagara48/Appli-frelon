/** Journal de mise au point : tout ce qui passe par Bluetooth (lignes reçues, commandes envoyées, connexions, erreurs).
 *  Gardé en mémoire (5 000 dernières entrées), visible dans Menu → Journal, exportable en fichier texte. */

export type Appareil = 'toit' | 'portatif' | 'drone' | 'maj' | 'appli' | 'partage';
export type Sens = 'recu' | 'envoye' | 'etat' | 'erreur';
export type Entree = { n: number; t: number; app: Appareil; sens: Sens; txt: string; incomprise?: boolean };

const MAX = 5000;
let entrees: Entree[] = [];
let numero = 0;
let actif = true;
const abonnes = new Set<() => void>();
let prevu = false;
let version = 0;
/** Change à chaque modification du journal (pour les écrans). */
export const versionJournal = () => version;

/** Prévient les écrans au plus 4 fois par seconde (le toit envoie plusieurs lignes par seconde). */
function prevenir() {
  if (prevu) return;
  prevu = true;
  setTimeout(() => { prevu = false; abonnes.forEach((f) => f()); }, 250);
}

export function journaliser(app: Appareil, sens: Sens, txt: string, incomprise = false) {
  if (!actif) return;
  entrees.push({ n: ++numero, t: Date.now(), app, sens, txt: txt.length > 500 ? txt.slice(0, 500) + '…' : txt, ...(incomprise ? { incomprise } : {}) });
  if (entrees.length > MAX) entrees = entrees.slice(-MAX);
  version++;
  prevenir();
}

export const lireJournal = () => entrees;
export const journalActif = () => actif;
export function activerJournal(v: boolean) { actif = v; version++; prevenir(); }
export function viderJournal() { entrees = []; version++; prevenir(); }
export function abonnerJournal(f: () => void) { abonnes.add(f); return () => { abonnes.delete(f); }; }

const SENS: Record<Sens, string> = { recu: '<', envoye: '>', etat: '*', erreur: '!' };
const heure = (t: number) => {
  const d = new Date(t), p = (x: number, n = 2) => String(x).padStart(n, '0');
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}.${p(d.getMilliseconds(), 3)}`;
};
export const ligneJournal = (e: Entree) => `${heure(e.t)} ${e.app.padEnd(8)} ${SENS[e.sens]} ${e.txt}${e.incomprise ? '   [non comprise]' : ''}`;

/** Texte complet à exporter : en-tête, résumé, puis une ligne par entrée. */
export function texteJournal(liste: Entree[], entete: string[]) {
  const nb = (f: (e: Entree) => boolean) => liste.filter(f).length;
  const resume = [
    `Entrées : ${liste.length}`,
    `Toit : ${nb((e) => e.app === 'toit' && e.sens === 'recu')} lignes reçues (${nb((e) => e.app === 'toit' && !!e.incomprise)} non comprises), ${nb((e) => e.app === 'toit' && e.sens === 'envoye')} commandes`,
    `Portatif : ${nb((e) => e.app === 'portatif' && e.sens === 'recu')} lignes reçues (${nb((e) => e.app === 'portatif' && !!e.incomprise)} non comprises), ${nb((e) => e.app === 'portatif' && e.sens === 'envoye')} commandes`,
    `Erreurs : ${nb((e) => e.sens === 'erreur')}`,
  ];
  return [...entete, ...resume, 'Légende : < reçu   > envoyé   * connexion   ! erreur', '', ...liste.map(ligneJournal)].join('\n') + '\n';
}
