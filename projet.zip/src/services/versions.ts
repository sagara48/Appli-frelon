/** Contrôle des versions à chaque connexion : le toit et le portatif annoncent firmware et protocole (« ver ») ;
 *  l'appli compare avec ce qu'elle comprend, l'écrit dans le journal et prévient si une mise à jour est nécessaire.
 *  Un firmware qui ne répond pas dans les 8 s date d'avant le contrôle des versions. */
import { store } from '../store/store';
import { verdict, type VersionAppareil } from '../calc/versions';
import { journaliser } from './journal';
import { causeAnormale, causeRedemarrage } from '../calc/activite';

/** Cause du dernier redémarrage (firmware 1.2.0) : notée une fois par démarrage de l'appareil.
 *  Un blocage (chien de garde) ou une tension trop basse est aussi affiché en bandeau. */
const demarragesVus = new Set<string>();
function noterRedemarrage(app: 'toit' | 'portatif', v: VersionAppareil | null) {
  if (!v || v.rst === undefined || v.upS === undefined) return;
  const depuis = Math.round((v.recuMs - v.upS * 1000) / 60000); // minute du démarrage (même valeur à chaque « ver »)
  const cle = `${app}:${depuis}:${v.rst}`;
  if ([...demarragesVus].some((k) => { const [a, m, r] = k.split(':'); return a === app && r === String(v.rst) && Math.abs(Number(m) - depuis) <= 1; })) return;
  demarragesVus.add(cle);
  const nom = app === 'toit' ? 'Le chef du toit' : 'Le portatif';
  const min = Math.round(v.upS / 60);
  const txt = `${nom} a démarré il y a ${min < 1 ? "moins d'une minute" : `${min} min`} : ${causeRedemarrage(v.rst)}`;
  journaliser(app, causeAnormale(v.rst) ? 'erreur' : 'etat', txt);
  if (causeAnormale(v.rst)) store.set({ bandeau: { texte: `${nom} a redémarré tout seul (${causeRedemarrage(v.rst)}). Si cela se répète, regardez le Journal.`, grave: false, ms: Date.now() } });
  (v.rstVoies ?? []).forEach((r, i) => { if (causeAnormale(r)) journaliser(app, 'erreur', `Voie ${i + 1} du toit : dernier redémarrage par ${causeRedemarrage(r)}`); });
}

const ATTENTE_MS = 8000;
type Suivi = { depuis: number; annonce: string };
const suivi: Record<'toit' | 'portatif', Suivi | null> = { toit: null, portatif: null };

function examiner(app: 'toit' | 'portatif', connecte: boolean, v: VersionAppareil | null, marquerAbsente: () => void) {
  if (!connecte) { suivi[app] = null; return; }
  const s = suivi[app] ?? (suivi[app] = { depuis: Date.now(), annonce: '' });
  if (!v && Date.now() - s.depuis > ATTENTE_MS) { marquerAbsente(); return; }
  const vd = verdict(app, v);
  if (!vd) return;
  const cle = `${vd.etat}:${v?.fw}:${v?.proto}:${v?.voies?.join('.') ?? ''}`;
  if (s.annonce === cle) return; // une seule annonce par connexion et par résultat
  s.annonce = cle;
  journaliser(app, vd.etat === 'ok' || vd.etat === 'maj' ? 'etat' : 'erreur', vd.texte);
  if (vd.etat === 'firmware' || vd.etat === 'appli' || vd.etat === 'inconnu')
    store.set({ bandeau: { texte: vd.texte, grave: vd.etat !== 'inconnu', ms: Date.now() } });
}

function verifier() {
  const e = store.get();
  if (e.source === 'toit') noterRedemarrage('toit', e.versionToit);
  if (e.portatif.source === 'ble') noterRedemarrage('portatif', e.portatif.version);
  examiner('toit', e.source === 'toit' && e.connexion === 'connecte', e.versionToit,
    () => store.set({ versionToit: { fw: '', proto: NaN, recuMs: Date.now(), absente: true } }));
  examiner('portatif', e.portatif.source === 'ble' && e.portatif.connexion === 'connecte', e.portatif.version,
    () => store.portatif({ version: { fw: '', proto: NaN, recuMs: Date.now(), absente: true } }));
}

/** À appeler une fois au démarrage. */
export function surveillerVersions() {
  const stop = store.abonner(verifier);
  const i = setInterval(verifier, 2000); // pour l'attente des 8 s même sans nouvelle ligne
  return () => { stop(); clearInterval(i); };
}
