/** Mise à jour de l'appli elle-même : chaque compilation GitHub publie l'APK dans une « Release » du dépôt
 *  (étiquette apk-<numéro>). L'appli compare ce numéro au sien et propose de télécharger la nouvelle version. */
import * as Linking from 'expo-linking';
import { lireValeur, ecrireValeur } from '../db';
import { journaliser } from './journal';
import { param } from './parametres';

/** Dépôt GitHub où chercher les versions (Paramètres → Partage et mises à jour). */
export const depot = () => param().depot;
/** Numéro de compilation, inscrit par GitHub au moment de la compilation (0 = compilée ailleurs). */
export const BUILD = Number(process.env.EXPO_PUBLIC_BUILD ?? 0) || 0;

export type VersionDispo = { build: number; url: string; taille: number; date: string; notes: string; page: string };

/** Lecture de la réponse GitHub (testable). null si elle ne contient pas d'APK. */
export function lireRelease(j: { tag_name?: string; html_url?: string; published_at?: string; body?: string | null; assets?: { name: string; browser_download_url: string; size: number }[] }): VersionDispo | null {
  const build = Number(/(\d+)$/.exec(j.tag_name ?? '')?.[1] ?? NaN);
  const apk = j.assets?.find((a) => a.name.endsWith('.apk'));
  if (!Number.isFinite(build) || !apk) return null;
  return { build, url: apk.browser_download_url, taille: apk.size, date: j.published_at ?? '', notes: (j.body ?? '').trim(), page: j.html_url ?? '' };
}

export async function derniereVersion(): Promise<VersionDispo | null> {
  const r = await fetch(`https://api.github.com/repos/${depot()}/releases/latest`, { headers: { Accept: 'application/vnd.github+json' } });
  if (r.status === 404) return null; // pas encore de release
  if (!r.ok) throw new Error(`GitHub : erreur ${r.status}`);
  const v = lireRelease(await r.json());
  ecrireValeur('majAppli', { verifieMs: Date.now(), dispo: v });
  return v;
}

export const plusRecente = (v: VersionDispo | null) => !!v && v.build > BUILD;

/** Ouvre le téléchargement de l'APK dans le navigateur ; Android propose ensuite de l'installer. */
export const telechargerApk = (v: VersionDispo) => Linking.openURL(v.url);

/** Au démarrage, au plus deux fois par jour : prévient s'il y a une nouvelle version. */
export async function verifierAuDemarrage(prevenir: (v: VersionDispo) => void) {
  const d = lireValeur<{ verifieMs: number; dispo: VersionDispo | null }>('majAppli');
  if (d && Date.now() - d.verifieMs < param().verifMajH * 3600e3) { if (plusRecente(d.dispo)) prevenir(d.dispo!); return; }
  try { const v = await derniereVersion(); if (plusRecente(v)) prevenir(v!); }
  catch (e) { journaliser('appli', 'etat', `Vérification de mise à jour impossible : ${String((e as Error).message ?? e)}`); }
}
