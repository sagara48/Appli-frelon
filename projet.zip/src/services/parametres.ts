/** Paramètres réglables (écran Paramètres) : lus une fois dans la base, gardés en mémoire, partagés par toute l'appli. */
import { useSyncExternalStore } from 'react';
import { ecrireValeur, lireValeur } from '../db';
import { DEFAUTS, normaliser, type Parametres } from '../calc/parametres';

let cache: Parametres | null = null;
const abonnes = new Set<() => void>();

/** Valeurs actuelles (défauts tant que la base n'est pas lisible). */
export function param(): Parametres {
  if (!cache) {
    try { cache = normaliser(lireValeur<Partial<Parametres>>('parametres')); } catch { return { ...DEFAUTS }; }
  }
  return cache;
}
export function changerParametres(p: Partial<Parametres>) {
  cache = normaliser({ ...param(), ...p });
  ecrireValeur('parametres', cache);
  abonnes.forEach((f) => f());
}
export function remettreDefauts(cles?: (keyof Parametres)[]) {
  const n = { ...param() } as Record<string, unknown>;
  for (const c of cles ?? (Object.keys(DEFAUTS) as (keyof Parametres)[])) n[c] = DEFAUTS[c];
  changerParametres(n as Partial<Parametres>);
}
export const abonnerParametres = (f: () => void) => { abonnes.add(f); return () => { abonnes.delete(f); }; };
/** Pour les écrans : se redessine quand un paramètre change. */
export const useParametres = () => useSyncExternalStore(abonnerParametres, param, param);
/** Relit la base (après une restauration de sauvegarde). */
export function relireParametres() { cache = null; param(); abonnes.forEach((f) => f()); }

/** Exposant du terrain appris sur les nids trouvés (services/terrain), pour le portatif ; null = réglage. */
let exposantAppris: () => number | null = () => null;
export const definirExposantAppris = (f: () => number | null) => { exposantAppris = f; };
/** Modèle de distance du toit ou du portatif (Paramètres → Distance estimée). */
export const modeleDistance = (r: 'toit' | 'portatif', p: Parametres = param()) =>
  ({ ref1m: r === 'toit' ? p.distRefToit : p.distRefPortatif, n: (r === 'portatif' && exposantAppris()) || p.distExposant, margeDb: p.distMargeDb });
