/** Boîte noire du toit (1.4.0) : le toit enregistre chaque relevé dans sa mémoire, téléphone connecté ou non. À chaque
 *  connexion, l'appli demande les relevés reçus par le toit depuis le dernier qu'elle a vu (12 h au plus) : une coupure
 *  Bluetooth ou un téléphone resté à la maison ne fait plus perdre de mesures. */
import { ecrireValeur, lireValeur } from '../db';
import { ecouterLignes, store } from '../store/store';
import { cmdToit, parseToit } from '../proto/toit';
import { envoyerToit } from '../sources/commandesToit';

let dernierUtc = lireValeur<number>('bnDernierUtc') ?? 0;
let ecrit = 0, demande = false;

ecouterLignes((src, ligne) => {
  if (src !== 'T') return;
  if (ligne.startsWith('R,') || ligne.startsWith('b,R,')) {
    const u = Number(ligne.split(',')[ligne.startsWith('b,') ? 2 : 1]);
    if (u > dernierUtc && u * 1000 <= Date.now() + 60000) {
      dernierUtc = u;
      if (Date.now() - ecrit > 15000) { ecrit = Date.now(); ecrireValeur('bnDernierUtc', dernierUtc); }
    }
    return;
  }
  const l = parseToit(ligne);
  if (l?.kind === 'K' && l.type === 'BN') {
    ecrireValeur('bnDernierUtc', dernierUtc);
    if (l.n > 0) store.evenement(`Boîte noire du toit : ${l.n} relevé${l.n > 1 ? 's' : ''} récupéré${l.n > 1 ? 's' : ''}${l.fin === 'TRONQUE' ? ' (les plus anciens laissés dans le toit)' : ''}`);
  }
});

// à chaque connexion du toit : relevés manqués depuis le dernier vu (au plus 12 h)
store.abonner(() => {
  const e = store.get();
  const ok = e.source === 'toit' && e.connexion === 'connecte';
  if (!ok) { demande = false; return; }
  if (demande) return;
  demande = true;
  setTimeout(() => {
    const maintenant = Date.now() / 1000;
    const depuis = Math.max(dernierUtc, maintenant - 12 * 3600);
    if (maintenant - depuis > 20) envoyerToit(cmdToit.boiteNoire(depuis)).catch(() => {});
  }, 4000);
});
