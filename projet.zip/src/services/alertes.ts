/**
 * Moteur d'alertes (écran « Sons et alertes ») : vérifie l'état une fois par seconde et prévient par
 * un bandeau, une vibration et une annonce vocale. Chaque alerte ne sonne qu'une fois par cause.
 */
import { distM } from '../calc/geo';
import { idTag } from '../ui/theme';
import { ageS, agePortatif, meilleurePosition, store } from '../store/store';
import { annoncer, vibrer } from './sons';

const dejaVu = new Set<string>();
let silenceZoneJusque = 0;
let minuterie: ReturnType<typeof setInterval> | null = null;
let dernierMsgChrono = '';
let ouvrirZone: ((nidId: number, dist: number) => void) | null = null;

export const couperZone = (minutes: number) => { silenceZoneJusque = Date.now() + minutes * 60000; };

function alerter(cle: string, texte: string, voix: string, grave = false) {
  if (dejaVu.has(cle)) return;
  dejaVu.add(cle);
  store.set({ bandeau: { texte, grave, ms: Date.now() } });
  vibrer(grave);
  annoncer(voix);
}
/** Oublie une cause (le tag est revenu, la batterie remontée…) pour qu'elle puisse sonner de nouveau. */
const oublier = (cle: string) => dejaVu.delete(cle);

function verifier() {
  const e = store.get();
  const a = e.alertes;
  // tags
  const entendus = new Map<number, number>(); // id → âge (s)
  for (const t of Object.values(e.tags)) entendus.set(t.id, ageS(e, t));
  const p = e.portatif.connexion === 'connecte' ? e.portatif.st : null;
  if (p && p.tag >= 0 && p.age < 600) entendus.set(p.tag, Math.min(entendus.get(p.tag) ?? 1e9, agePortatif(e)));
  for (const t of Object.values(e.portatif.autres)) if (t.age < 600) entendus.set(t.id, Math.min(entendus.get(t.id) ?? 1e9, t.age + (Date.now() - e.portatif.recuMs) / 1000));
  for (const [id, age] of entendus) {
    if (a.nouveauTag && age < 30) alerter(`nouveau-${id}`, `Nouveau tag entendu : ${idTag(id)}`, `Nouveau tag, ${id}`);
    if (age > 120) { if (a.tagPerdu) alerter(`perdu-${id}`, `Tag ${idTag(id)} perdu : plus rien depuis 2 min`, `Tag ${id} perdu`); }
    else oublier(`perdu-${id}`);
  }
  for (const t of Object.values(e.tags)) {
    if (a.pileFaible && t.pile >= 0 && t.pile < 20) alerter(`pile-${t.id}`, `Pile du tag ${idTag(t.id)} faible (${t.pile} %)`, `Pile faible, tag ${t.id}`);
    if (a.nidLocalise && t.fusion?.ok && t.fusion.errM < 30) alerter(`nid-${t.id}`, `Nid du tag ${idTag(t.id)} localisé à ± ${Math.round(t.fusion.errM)} m`, `Nid localisé, tag ${t.id}`);
  }
  // retour à l'appât (message du chrono)
  if (e.chrono.message && e.chrono.message !== dernierMsgChrono) {
    dernierMsgChrono = e.chrono.message;
    if (a.retourAppat) { dejaVu.delete('chrono'); alerter('chrono', e.chrono.message, e.chrono.message.split(':')[0]); }
  }
  // batteries
  const bt = e.connexion === 'connecte' && e.source === 'toit' && e.toit ? e.toit.battPct : 100;
  const bp = p ? p.bat : 100;
  if (a.batterie && bt < 15) alerter('batt-toit', `Batterie du toit faible (${bt} %)`, 'Batterie du toit faible'); else if (bt > 25) oublier('batt-toit');
  if (a.batterie && bp < 15) alerter('batt-port', `Batterie du portatif faible (${bp} %)`, 'Batterie du portatif faible'); else if (bp > 25) oublier('batt-port');
  // approche d'un nid connu (encore actif) : écran rouge
  const pos = meilleurePosition(e);
  if (a.approcheNid && pos && pos.source !== 'voiture' && Date.now() > silenceZoneJusque && ouvrirZone) {
    for (const n of e.nids) {
      if (n.etat === 'mort') continue;
      const d = distM(pos.lat, pos.lon, n.lat, n.lon);
      if (d < 10) {
        if (!dejaVu.has(`zone-${n.id}`)) { dejaVu.add(`zone-${n.id}`); vibrer(true); annoncer('Attention, nid tout proche'); ouvrirZone(n.id, d); }
      } else if (d > 25) oublier(`zone-${n.id}`);
    }
  }
}

export function demarrerAlertes(surZone: (nidId: number, dist: number) => void) {
  ouvrirZone = surZone;
  if (!minuterie) minuterie = setInterval(() => { try { verifier(); } catch {} }, 1000);
  return () => { if (minuterie) clearInterval(minuterie); minuterie = null; };
}
/** Oublie tout (nouvelle sortie). */
export const remettreAlertes = () => dejaVu.clear();
