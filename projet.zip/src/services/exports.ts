/** Exports partagés : GPX / KML des nids, CSV du bilan, fiche PDF d'un nid. */
import { File, Paths } from 'expo-file-system';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import type { Nid } from '../db';
import { classeurXlsx } from '../calc/xlsx';
import { feuillesGdsa, rapportHtml, resumeGdsa, type DonneesGdsa } from '../calc/exportGdsa';
import { ENTETE_REGISTRE, ligneTableau, totauxProduits, type Intervention, type LigneRegistre } from '../calc/intervention';
import { compteRenduHtml, registreHtml } from '../calc/rapportIntervention';
import { param } from './parametres';

const ETATS: Record<string, string> = { estime: 'À traiter', trouve: 'À traiter', traite: 'Traité', mort: 'Vérifié mort' };
export const libelleEtatNid = (e: string) => ETATS[e] ?? e;
const echapper = (s: string) => s.replace(/[<>&"']/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' })[c]!);
const date = (ms: number) => new Date(ms).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });

export async function partager(nom: string, contenu: string, mime: string) {
  const f = new File(Paths.cache, nom);
  if (f.exists) f.delete();
  f.create();
  f.writeSync(contenu);
  await Sharing.shareAsync(f.uri, { mimeType: mime, dialogTitle: nom });
}

export async function exporterGpx(nids: Nid[], numero: (id: number) => number) {
  const wpt = nids.map((n) => `  <wpt lat="${n.lat.toFixed(7)}" lon="${n.lon.toFixed(7)}">
    <time>${new Date(n.t).toISOString()}</time><name>Nid ${numero(n.id)}</name>
    <desc>${echapper(`${libelleEtatNid(n.etat)} ${n.tag >= 0 ? ` · tag ${n.tag}` : ''} · ± ${Math.round(n.err)} m${n.support ? ` · ${n.support}` : ''}${n.hauteur ? ` · ${n.hauteur}` : ''}`)}</desc>
  </wpt>`).join('\n');
  await partager('nids_frelons.gpx', `<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="Appli Frelons" xmlns="http://www.topografix.com/GPX/1/1">\n${wpt}\n</gpx>\n`, 'application/gpx+xml');
}

export async function exporterKml(nids: Nid[], numero: (id: number) => number) {
  const pm = nids.map((n) => `    <Placemark><name>Nid ${numero(n.id)}</name>
      <description>${echapper(`${libelleEtatNid(n.etat)}${n.tag >= 0 ? ` · tag ${n.tag}` : ''} · ± ${Math.round(n.err)} m · trouvé le ${date(n.t)}${n.support ? ` · ${n.support}` : ''}`)}</description>
      <Point><coordinates>${n.lon.toFixed(7)},${n.lat.toFixed(7)},0</coordinates></Point></Placemark>`).join('\n');
  await partager('nids_frelons.kml', `<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>Nids de frelons asiatiques</name>\n${pm}\n</Document></kml>\n`, 'application/vnd.google-earth.kml+xml');
}

export async function exporterCsv(nom: string, lignes: (string | number)[][]) {
  const csv = lignes.map((l) => l.map((c) => { const v = String(c); return /[;"\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v; }).join(';')).join('\n');
  await partager(nom, '﻿' + csv + '\n', 'text/csv'); // BOM : accents corrects dans Excel
}

/** Fiche PDF d'un nid (déclaration, suivi de l'intervention). */
export async function fichePdf(n: Nid, numero: number) {
  const l = (k: string, v: string) => (v ? `<tr><th>${echapper(k)}</th><td>${echapper(v)}</td></tr>` : '');
  const photos = n.photos.map((p) => `<img src="${p}" />`).join('');
  const html = `<html><head><meta charset="utf-8"><style>
    body{font-family:sans-serif;color:#14202E;padding:24px} h1{margin:0 0 4px} .s{color:#5B6672;margin:0 0 18px}
    table{border-collapse:collapse;width:100%;margin-bottom:18px} th{text-align:left;width:38%;color:#5B6672;font-weight:normal;padding:6px 8px;border-bottom:1px solid #DDE1D8} td{padding:6px 8px;border-bottom:1px solid #DDE1D8}
    h2{font-size:15px;text-transform:uppercase;letter-spacing:1px;color:#5B6672;margin:18px 0 6px} img{width:48%;margin:1%;border-radius:6px}
  </style></head><body>
    <h1>Nid de frelons asiatiques n° ${numero}</h1><p class="s">Trouvé le ${date(n.t)}${n.tag >= 0 ? ` · tag ${n.tag}` : ''} · ${libelleEtatNid(n.etat)}</p>
    <h2>Localisation</h2><table>
      ${l('Coordonnées (WGS84)', `${n.lat.toFixed(6)} N · ${n.lon.toFixed(6)} E`)}${l('Précision', `± ${Math.round(n.err)} m`)}${l('Trouvé par', n.sources)}
      ${l('Support', n.support)}${l('Hauteur', n.hauteur)}${l('Diamètre du nid', n.diametre)}${l('Activité', n.activite)}${l('Remarques', n.note)}
    </table>
    <h2>Intervention</h2><table>
      ${l('Date et heure', n.inter_ms ? new Date(n.inter_ms).toLocaleString('fr-FR') : '')}${l('Méthode', n.methode)}${l('Produit', n.produit)}${l('Quantité', n.quantite)}
      ${l('Opérateur et n° Certibiocide', n.operateur)}${l('Contrôle', n.verifie_ms ? `aucune activité le ${date(n.verifie_ms)}` : '')}
    </table>${photos ? `<h2>Photos</h2>${photos}` : ''}
  </body></html>`;
  const { uri } = await Print.printToFileAsync({ html });
  await Sharing.shareAsync(uri, { mimeType: 'application/pdf', dialogTitle: `Nid ${numero}` });
}

/* ---------- export pour le GDSA ---------- */
/** Classeur Excel de la saison (résumé, nids, ruchers, pièges, relevés). */
export async function exporterGdsaXlsx(d: DonneesGdsa) {
  const f = new File(Paths.cache, `bilan_frelons_GDSA_${d.annee}.xlsx`);
  if (f.exists) f.delete();
  f.create();
  f.writeSync(classeurXlsx(feuillesGdsa(d)));
  await Sharing.shareAsync(f.uri, { mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', dialogTitle: `Bilan ${d.annee} pour le GDSA` });
}
/** Rapport PDF d'une ou deux pages. */
export async function exporterGdsaPdf(d: DonneesGdsa) {
  const { uri } = await Print.printToFileAsync({ html: rapportHtml(resumeGdsa(d)) });
  // nom lisible pour la pièce jointe
  const dest = new File(Paths.cache, `rapport_frelons_GDSA_${d.annee}.pdf`);
  if (dest.exists) dest.delete();
  new File(uri).copySync(dest);
  await Sharing.shareAsync(dest.uri, { mimeType: 'application/pdf', dialogTitle: `Rapport ${d.annee} pour le GDSA` });
}

/* ---------- interventions ---------- */
/** Compte rendu d'intervention à remettre au client (modèle FREDON) : PDF partagé. */
export async function compteRenduPdf(n: Nid, numero: number, i: Intervention) {
  const html = compteRenduHtml(n, numero, i, param());
  const { uri } = await Print.printToFileAsync({ html });
  const dest = new File(Paths.cache, `intervention_nid${numero}_${new Date(i.t).toISOString().slice(0, 10)}.pdf`);
  if (dest.exists) dest.delete();
  new File(uri).copySync(dest);
  await Sharing.shareAsync(dest.uri, { mimeType: 'application/pdf', dialogTitle: `Compte rendu nid ${numero}` });
}

/** Registre des traitements biocides de l'année : PDF (paysage) ou Excel (toutes les colonnes). */
export async function registrePdf(lignes: LigneRegistre[], an: number) {
  const html = registreHtml(lignes, an, param());
  const { uri } = await Print.printToFileAsync({ html, width: 842, height: 595 });
  const dest = new File(Paths.cache, `registre_biocides_${an}.pdf`);
  if (dest.exists) dest.delete();
  new File(uri).copySync(dest);
  await Sharing.shareAsync(dest.uri, { mimeType: 'application/pdf', dialogTitle: `Registre ${an}` });
}
export async function registreXlsx(lignes: LigneRegistre[], an: number) {
  const tot = totauxProduits(lignes);
  const f = new File(Paths.cache, `registre_biocides_${an}.xlsx`);
  if (f.exists) f.delete();
  f.create();
  f.writeSync(classeurXlsx([
    { nom: `Registre ${an}`, lignes: [ENTETE_REGISTRE, ...lignes.map(ligneTableau)] },
    { nom: 'Totaux par produit', lignes: [['Produit', 'Traitements', 'Quantité (g)'], ...tot.map((t) => [t.produit, t.n, Math.round(t.g * 10) / 10])] },
  ]));
  await Sharing.shareAsync(f.uri, { mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', dialogTitle: `Registre ${an}` });
}
