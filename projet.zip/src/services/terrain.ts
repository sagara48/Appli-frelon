/** Apprendre avec les nids trouvés : à chaque nid noté trouvé (ou traité) pour un tag, on compare au vrai emplacement
 *  - les points de la carte du signal à pied → affaiblissement du terrain (exposant), renvoyé au portatif (« nexp ») ;
 *  - les relèvements du toit pris en roulant → erreur d'orientation des antennes, correction proposée (« rot »). */
import { useSyncExternalStore } from 'react';
import { ecrireValeur, lireValeur } from '../db';
import { chronoReglages, store } from '../store/store';
import { correctionToit, ecartToit, exposantRetenu, exposantTerrain, facteurIncertitude, vitesseApprise, type Precision, type Recalage, type Terrain, type VolAppat } from '../calc/terrain';
import { distM } from '../calc/geo';
import { cmdPortatif } from '../proto/portatif';
import { envoyerPortatif } from '../sources/portatif';
import { envoyerToit } from '../sources/commandesToit';
import { cmdToit } from '../proto/toit';
import { definirExposantAppris } from './parametres';

type Appris = { terrains: Record<number, Terrain & { t: number }>; recalages: Record<number, Recalage & { t: number }>; rotAppliqueeMs: number;
  /** réglages appris sur les sorties : écart réel des estimations, allers-retours à l'appât (par nid) */
  precisions?: Record<number, Precision & { t: number }>; vols?: Record<number, VolAppat & { t: number }>; vitesseAppliquee?: number };
let A: Appris | null = null;
const abonnes = new Set<() => void>();
const lire = (): Appris => {
  if (!A) { try { A = lireValeur<Appris>('apprentissage') ?? { terrains: {}, recalages: {}, rotAppliqueeMs: 0 }; } catch { A = { terrains: {}, recalages: {}, rotAppliqueeMs: 0 }; } }
  return A;
};
function ecrire(a: Appris) { A = a; try { ecrireValeur('apprentissage', a); } catch { /* ignore */ } abonnes.forEach((f) => f()); }
export const lireApprentissage = () => lire();
export const useApprentissage = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, lire, lire);

/** Vitesse de vol apprise (m/s) et facteur d'incertitude des estimations (null tant qu'il manque des nids). */
export const vitesseVol = () => vitesseApprise(Object.values(lire().vols ?? {}), store.get().chrono.reglages.auNid);
export const facteurEstimations = () => facteurIncertitude(Object.values(lire().precisions ?? {}));
export const exposant = () => exposantRetenu(Object.values(lire().terrains).sort((a, b) => a.t - b.t));
definirExposantAppris(() => { try { return exposant(); } catch { return null; } });
/** Correction d'orientation du toit proposée (relèvements notés après la dernière correction appliquée). */
export const correction = () => { const a = lire(); return correctionToit(Object.values(a.recalages).filter((r) => r.t > a.rotAppliqueeMs)); };

export async function appliquerCorrection() {
  const c = correction();
  if (!c) return;
  await envoyerToit(cmdToit.rot(c.rot));
  ecrire({ ...lire(), rotAppliqueeMs: Date.now() });
  store.evenement(`Toit : orientation corrigée de ${c.rot > 0 ? '+' : ''}${c.rot}° (${c.nids} nids, ${c.releves} relèvements)`);
}

const vus = new Set<number>();
let envoyePour: unknown = null, nEnvoye: number | null = null;
store.abonner(() => {
  const e = store.get();
  // nids trouvés (ou traités, morts) reliés à un tag : on apprend une fois par nid
  for (const n of e.nids) {
    if (n.tag <= 0 || vus.has(n.id) || !['trouve', 'traite', 'mort'].includes(n.etat)) continue;
    const pas = e.pas[n.tag], lignes = e.tags[n.tag]?.lignes ?? [];
    // réglages appris sur la sortie : écart réel de l'estimation, allers-retours à l'appât de ce tag
    const f0 = e.tags[n.tag]?.fusion, a0 = lire();
    const f = f0 && distM(f0.lat, f0.lon, n.lat, n.lon) > 1 ? f0 : null; // nid créé à l'emplacement même de l'estimation : rien à apprendre
    const appats = e.chrono.appats.filter((x) => x.tag === n.tag && x.trajets.length);
    if ((f?.ok && f.errM > 0 && !a0.precisions?.[n.id]) || (appats.length && !a0.vols?.[n.id])) {
      const precisions = f?.ok && f.errM > 0 && !a0.precisions?.[n.id] ? { ...(a0.precisions ?? {}), [n.id]: { reelM: distM(f.lat, f.lon, n.lat, n.lon), afficheM: f.errM, t: Date.now() } } : a0.precisions;
      const ap = appats[appats.length - 1];
      const vols = ap && !a0.vols?.[n.id] ? { ...(a0.vols ?? {}), [n.id]: { distM: distM(ap.lat, ap.lon, n.lat, n.lon), durees: ap.trajets.map((x) => x.dureeS), t: Date.now() } } : a0.vols;
      ecrire({ ...a0, precisions, vols });
      // vitesse de vol apprise : appliquée au chrono quand elle change nettement
      const v = vitesseVol();
      if (v !== null && Math.abs(v - store.get().chrono.reglages.vitesse) >= 0.2) {
        chronoReglages({ vitesse: v });
        ecrire({ ...lire(), vitesseAppliquee: v });
        store.evenement(`Chrono : vitesse de vol apprise sur les nids trouvés, ${v.toFixed(1).replace('.', ',')} m/s`);
      }
    }
    if ((!pas || pas.length < 15) && lignes.length < 8) continue;
    vus.add(n.id);
    const a = lire();
    if (a.terrains[n.id] && a.recalages[n.id]) continue;
    const ter = pas ? exposantTerrain(pas, n) : null, rec = lignes.length ? ecartToit(lignes, n) : null;
    if (!ter && !rec) continue;
    ecrire({ ...a, terrains: ter ? { ...a.terrains, [n.id]: { ...ter, t: Date.now() } } : a.terrains, recalages: rec ? { ...a.recalages, [n.id]: { ...rec, t: Date.now() } } : a.recalages });
    if (ter) store.evenement(`Terrain appris au nid du tag ${n.tag} : exposant ${ter.n.toFixed(1).replace('.', ',')}`);
  }
  // exposant du terrain renvoyé au portatif à chaque connexion, ou quand il change
  const p = e.portatif, nx = exposant();
  if (p.connexion === 'connecte' && p.version && nx && (envoyePour !== p.version || nEnvoye !== nx)) {
    envoyePour = p.version; nEnvoye = nx;
    envoyerPortatif(cmdPortatif.nexp(nx)).catch(() => {});
  }
  if (p.connexion !== 'connecte') envoyePour = null;
  // orientation du toit : corrigée seule dès qu'un écart net apparaît sur les nids trouvés (toit connecté)
  if (!enCorrection && e.source === 'toit' && e.connexion === 'connecte' && correction()) {
    enCorrection = true;
    appliquerCorrection().catch(() => {}).finally(() => { enCorrection = false; });
  }
});
let enCorrection = false;
