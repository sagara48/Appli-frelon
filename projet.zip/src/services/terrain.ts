/** Apprendre avec les nids trouvés : à chaque nid noté trouvé (ou traité) pour un tag, on compare au vrai emplacement
 *  - les points de la carte du signal à pied → affaiblissement du terrain (exposant), renvoyé au portatif (« nexp ») ;
 *  - les relèvements du toit pris en roulant → erreur d'orientation des antennes, correction proposée (« rot »). */
import { useSyncExternalStore } from 'react';
import { ecrireValeur, lireValeur } from '../db';
import { store } from '../store/store';
import { correctionToit, ecartToit, exposantRetenu, exposantTerrain, type Recalage, type Terrain } from '../calc/terrain';
import { cmdPortatif } from '../proto/portatif';
import { envoyerPortatif } from '../sources/portatif';
import { envoyerToit } from '../sources/commandesToit';
import { cmdToit } from '../proto/toit';
import { definirExposantAppris } from './parametres';

type Appris = { terrains: Record<number, Terrain & { t: number }>; recalages: Record<number, Recalage & { t: number }>; rotAppliqueeMs: number };
let A: Appris | null = null;
const abonnes = new Set<() => void>();
const lire = (): Appris => {
  if (!A) { try { A = lireValeur<Appris>('apprentissage') ?? { terrains: {}, recalages: {}, rotAppliqueeMs: 0 }; } catch { A = { terrains: {}, recalages: {}, rotAppliqueeMs: 0 }; } }
  return A;
};
function ecrire(a: Appris) { A = a; try { ecrireValeur('apprentissage', a); } catch { /* ignore */ } abonnes.forEach((f) => f()); }
export const useApprentissage = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, lire, lire);

export const exposant = () => exposantRetenu(Object.values(lire().terrains).sort((a, b) => a.t - b.t));
definirExposantAppris(() => { try { return exposant(); } catch { return null; } });
/** Correction d'orientation du toit proposée (relèvements notés après la dernière correction appliquée). */
export const correction = () => { const a = lire(); return correctionToit(Object.values(a.recalages).filter((r) => r.t > a.rotAppliqueeMs)); };

export async function appliquerCorrection() {
  const c = correction();
  if (!c) return;
  await envoyerToit(cmdToit.rot(c.rot));
  ecrire({ ...lire(), rotAppliqueeMs: Date.now() });
  store.evenement(`Toit : orientation corrigée de ${c.rot > 0 ? '+' : ''}${c.rot}° (${c.nids} nids, ${c.releves} relèvements)`);
}

const vus = new Set<number>();
let envoyePour: unknown = null, nEnvoye: number | null = null;
store.abonner(() => {
  const e = store.get();
  // nids trouvés (ou traités, morts) reliés à un tag : on apprend une fois par nid
  for (const n of e.nids) {
    if (n.tag <= 0 || vus.has(n.id) || !['trouve', 'traite', 'mort'].includes(n.etat)) continue;
    const pas = e.pas[n.tag], lignes = e.tags[n.tag]?.lignes ?? [];
    if ((!pas || pas.length < 15) && lignes.length < 8) continue;
    vus.add(n.id);
    const a = lire();
    if (a.terrains[n.id] && a.recalages[n.id]) continue;
    const ter = pas ? exposantTerrain(pas, n) : null, rec = lignes.length ? ecartToit(lignes, n) : null;
    if (!ter && !rec) continue;
    ecrire({ ...a, terrains: ter ? { ...a.terrains, [n.id]: { ...ter, t: Date.now() } } : a.terrains, recalages: rec ? { ...a.recalages, [n.id]: { ...rec, t: Date.now() } } : a.recalages });
    if (ter) store.evenement(`Terrain appris au nid du tag ${n.tag} : exposant ${ter.n.toFixed(1).replace('.', ',')}`);
  }
  // exposant du terrain renvoyé au portatif à chaque connexion, ou quand il change
  const p = e.portatif, nx = exposant();
  if (p.connexion === 'connecte' && p.version && nx && (envoyePour !== p.version || nEnvoye !== nx)) {
    envoyePour = p.version; nEnvoye = nx;
    envoyerPortatif(cmdPortatif.nexp(nx)).catch(() => {});
  }
  if (p.connexion !== 'connecte') envoyePour = null;
});
