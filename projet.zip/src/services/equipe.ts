/** Équipe en direct : pendant une sortie (toit ou portatif connecté), chaque téléphone de l'équipe envoie sa position,
 *  le tag qu'il suit et son nid estimé toutes les 30 s, et lit ceux des autres (table « presence », script SQL de
 *  l'écran Partage). Rien n'est envoyé hors sortie ; la ligne est effacée à la fin de la sortie. Se coupe dans
 *  Paramètres → Automatismes. Les équipiers vus depuis plus de 10 min disparaissent de la carte. */
import { useSyncExternalStore } from 'react';
import { AppState } from 'react-native';
import { meilleurePosition, store } from '../store/store';
import { lireConfig, requeteServeur } from './partage';
import { sessionActuelle } from './auth';
import { param } from './parametres';
import { marquerAuto } from './essaisTerrain';

export type Equipier = { utilisateur: string; nom: string; lat: number; lon: number; tag: number | null; nid: { lat: number; lon: number; err: number } | null; majMs: number };
type Ligne = { utilisateur: string; nom: string | null; lat: number; lon: number; tag: number | null; nid_lat: number | null; nid_lon: number | null; nid_err: number | null; maj: string };

let equipiers: Equipier[] = [];
let erreur = '';
const abonnes = new Set<() => void>();
const publier = () => abonnes.forEach((f) => f());
const lire = () => equipiers;
export const useEquipiers = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, lire, lire);
export const erreurEquipe = () => erreur;

const enSortie = () => {
  const e = store.get();
  return (e.source === 'toit' && e.connexion === 'connecte') || (e.portatif.connexion === 'connecte' && e.portatif.source === 'ble');
};
const pret = () => {
  const c = lireConfig();
  return param().equipeDirect && c.actif && !!c.equipe && !!sessionActuelle();
};

let present = false;
async function tour() {
  if (!pret()) { if (equipiers.length) { equipiers = []; publier(); } return; }
  const c = lireConfig(), moi = sessionActuelle()!.utilisateur;
  try {
    if (enSortie()) {
      const p = meilleurePosition(), e = store.get();
      const tag = e.tagChoisi ?? (e.portatif.st && e.portatif.st.tag >= 0 ? e.portatif.st.tag : null);
      const f = tag !== null ? e.tags[tag]?.fusion : null;
      if (p) {
        await requeteServeur('presence?on_conflict=equipe,utilisateur', { method: 'POST', prefer: 'resolution=merge-duplicates,return=minimal', body: JSON.stringify({
          equipe: c.equipe!.id, nom: param().nom || moi.nom || moi.email.split('@')[0], lat: p.lat, lon: p.lon, tag,
          nid_lat: f?.ok ? f.lat : null, nid_lon: f?.ok ? f.lon : null, nid_err: f?.ok ? Math.round(f.errM) : null, maj: new Date().toISOString(),
        }) });
        present = true;
      }
    } else if (present) {
      present = false;
      await requeteServeur(`presence?equipe=eq.${c.equipe!.id}&utilisateur=eq.${moi.id}`, { method: 'DELETE' }).catch(() => {});
    }
    const depuis = new Date(Date.now() - 10 * 60000).toISOString();
    const l = await requeteServeur<Ligne[]>(`presence?equipe=eq.${c.equipe!.id}&maj=gt.${encodeURIComponent(depuis)}&select=*`);
    equipiers = (l ?? []).filter((x) => x.utilisateur !== moi.id).map((x) => ({
      utilisateur: x.utilisateur, nom: x.nom || 'équipier', lat: x.lat, lon: x.lon, tag: x.tag,
      nid: x.nid_lat !== null && x.nid_lon !== null ? { lat: x.nid_lat, lon: x.nid_lon, err: x.nid_err ?? 50 } : null, majMs: Date.parse(x.maj),
    }));
    erreur = '';
    if (equipiers.some((x) => Date.now() - x.majMs < 2 * 60000) && enSortie()) marquerAuto('equipe');
  } catch (err) { erreur = (err as Error).message; }
  publier();
}

let minuterie: ReturnType<typeof setInterval> | null = null;
function suivre() {
  const actif = pret() && (enSortie() || present || AppState.currentState === 'active');
  if (actif && !minuterie) { tour().catch(() => {}); minuterie = setInterval(() => { tour().catch(() => {}); }, 30000); }
  if (!actif && minuterie) { clearInterval(minuterie); minuterie = null; }
}
let avant = '';
store.abonner(() => {
  const e = store.get(), k = `${e.source}/${e.connexion}/${e.portatif.connexion}`;
  if (k !== avant) { avant = k; suivre(); }
});
AppState.addEventListener('change', suivre);
setTimeout(suivre, 5000);
