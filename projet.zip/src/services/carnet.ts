/** Carnet : nids, tags, ruchers. Écrit dans la base puis met l'état à jour (les écrans lisent l'état). */
import * as db from '../db';
import { store } from '../store/store';
import type { Fusion } from '../calc/fusion';

export function chargerCarnet() {
  const tags: Record<number, db.FicheTag> = {};
  for (const t of db.lireTags()) tags[t.id] = t;
  store.set({ nids: db.lireNids(), fichesTags: tags, ruchers: db.lireRuchers() });
}

/** Résumé lisible des sources d'une estimation (« voiture (12 relèvements) + chrono (1 appât) + … »). */
export function sourcesTexte(f: Fusion): string {
  const s: string[] = [];
  if (f.nVoiture) s.push(`voiture (${f.nVoiture} relèvement${f.nVoiture > 1 ? 's' : ''})`);
  if (f.nAnneaux || f.nCapsAppat) s.push(`chrono (${Math.max(f.nAnneaux, f.nCapsAppat)} appât${Math.max(f.nAnneaux, f.nCapsAppat) > 1 ? 's' : ''})`);
  if (f.nOeil) s.push(`${f.nOeil} direction${f.nOeil > 1 ? 's' : ''} à l'œil`);
  if (f.nPortatif) s.push('portatif');
  return s.join(' + ');
}

export function nouveauNid(tag: number, lat: number, lon: number, err: number, sources: string): number {
  const id = db.ajouterNid(tag, lat, lon, err, sources);
  chargerCarnet();
  return id;
}
export function majNid(id: number, champs: Partial<db.Nid>) { db.modifierNid(id, champs); chargerCarnet(); }
export function supprimerNid(id: number) { db.supprimerNid(id); chargerCarnet(); }

/** Fiche d'un tag (créée à la volée pour un tag entendu). */
export function ficheTag(id: number): db.FicheTag {
  return store.get().fichesTags[id] ?? { id, etat: 'dispo', pose_ms: null, appat: null, lat: null, lon: null, note: '', maj_ms: 0 };
}
export function majTag(id: number, champs: Partial<db.FicheTag>) { db.ecrireTag({ ...ficheTag(id), ...champs, id }); chargerCarnet(); }

export function nouveauRucher(nom: string, ruches: number | null, lat: number, lon: number) { db.ajouterRucher(nom, ruches, lat, lon); chargerCarnet(); }
export function supprimerRucher(id: number) { db.supprimerRucher(id); chargerCarnet(); }

/** Numéro d'un nid dans la saison (ordre chronologique), comme sur le carnet papier. */
export function numeroNid(nids: db.Nid[], id: number): number {
  const tri = [...nids].sort((a, b) => a.t - b.t);
  return tri.findIndex((n) => n.id === id) + 1;
}
