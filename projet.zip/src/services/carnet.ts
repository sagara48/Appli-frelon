/** Carnet : nids, tags, ruchers. Écrit dans la base puis met l'état à jour (les écrans lisent l'état). */
import * as db from '../db';
import { ajouterReleve, lirePressions, type Niveau } from '../calc/pression';
import { store } from '../store/store';
import type { Fusion } from '../calc/fusion';

/** Prévenu après chaque modification du carnet (le partage s'en sert pour envoyer les changements). */
let surModif: (() => void) | null = null;
export const brancherSurModif = (f: (() => void) | null) => { surModif = f; };
const modifie = () => { chargerCarnet(); surModif?.(); };

export function chargerCarnet() {
  const tags: Record<number, db.FicheTag> = {};
  for (const t of db.lireTags()) tags[t.id] = t;
  store.set({ nids: db.lireNids(), fichesTags: tags, ruchers: db.lireRuchers(), pieges: db.lirePieges() });
}

/** Résumé lisible des sources d'une estimation (« voiture (12 relèvements) + chrono (1 appât) + … »). */
export function sourcesTexte(f: Fusion): string {
  const s: string[] = [];
  if (f.nVoiture) s.push(`voiture (${f.nVoiture} relèvement${f.nVoiture > 1 ? 's' : ''})`);
  if (f.nAnneaux || f.nCapsAppat) s.push(`chrono (${Math.max(f.nAnneaux, f.nCapsAppat)} appât${Math.max(f.nAnneaux, f.nCapsAppat) > 1 ? 's' : ''})`);
  if (f.nOeil) s.push(`${f.nOeil} direction${f.nOeil > 1 ? 's' : ''} à l'œil`);
  if (f.nPortatif) s.push('portatif (tour sur place)');
  if (f.nMarche) s.push('portatif (en marchant)');
  if (f.nDrone) s.push('drone');
  return s.join(' + ');
}

export function nouveauNid(tag: number, lat: number, lon: number, err: number, sources: string): number {
  const id = db.ajouterNid(tag, lat, lon, err, sources);
  modifie();
  return id;
}
export function majNid(id: number, champs: Partial<db.Nid>) { db.modifierNid(id, champs); modifie(); }
export function supprimerNid(id: number) { db.supprimerNid(id); modifie(); }

/** Fiche d'un tag (créée à la volée pour un tag entendu). */
export function ficheTag(id: number): db.FicheTag {
  return store.get().fichesTags[id] ?? { id, etat: 'dispo', pose_ms: null, appat: null, lat: null, lon: null, note: '', maj_ms: 0, pile: null, pile_ms: null, recharge_ms: null };
}
export function majTag(id: number, champs: Partial<db.FicheTag>) {
  const avant = ficheTag(id);
  // journal des poses (résultats de saison) : chaque passage à « posé »
  if (champs.etat === 'pose' && avant.etat !== 'pose') {
    const j = db.lireValeur<{ tag: number; t: number }[]>('journalPoses') ?? [];
    db.ecrireValeur('journalPoses', [...j, { tag: id, t: champs.pose_ms ?? Date.now() }].slice(-1000));
  }
  db.ecrireTag({ ...avant, ...champs, id });
  chargerCarnet();
}
/** Toutes les poses de tags notées (pour les résultats de saison). */
export const lirePoses = () => db.lireValeur<{ tag: number; t: number }[]>('journalPoses') ?? [];

export function nouveauRucher(nom: string, ruches: number | null, lat: number, lon: number) { const id = db.ajouterRucher(nom, ruches, lat, lon); modifie(); return id; }
export function supprimerRucher(id: number) { db.supprimerRucher(id); modifie(); }
/** Note le nombre de frelons vus devant les ruches (remplace un relevé du même jour). */
export function noterPression(id: number, niveau: Niveau, t = Date.now()) {
  const r = store.get().ruchers.find((x) => x.id === id);
  if (!r) return;
  db.modifierRucher(id, { pressions: JSON.stringify(ajouterReleve(lirePressions(r.pressions), t, niveau)) });
  modifie();
}

export function nouveauPiege(nom: string, lat: number, lon: number, appat: string) { const id = db.ajouterPiege(nom, lat, lon, appat); modifie(); return id; }
export function majPiege(id: number, champs: Partial<db.Piege>) { db.modifierPiege(id, champs); modifie(); }
export function supprimerPiege(id: number) { db.supprimerPiege(id); modifie(); }

/** Numéro d'un nid dans la saison (ordre chronologique), comme sur le carnet papier. */
export function numeroNid(nids: db.Nid[], id: number): number {
  const tri = [...nids].sort((a, b) => a.t - b.t);
  return tri.findIndex((n) => n.id === id) + 1;
}
