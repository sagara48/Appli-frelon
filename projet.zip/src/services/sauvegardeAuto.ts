/** Sauvegarde automatique du carnet sur le serveur (Supabase, compte de l'utilisateur) : chaque jour ou chaque semaine,
 *  sans y penser. Nids et interventions, tags, ruchers, pièges et réglages ; les photos restent dans la sauvegarde .zip.
 *  Les 8 dernières sauvegardes sont gardées ; chacun ne voit que les siennes (règles du script SQL). */
import { Platform } from 'react-native';
import { ecrireValeur, lireValeur, toutLire, toutRemplacer, type Sauvegarde } from '../db';
import { lireServeur, serveurComplet, sessionActuelle } from './auth';
import { chargerCarnet } from './carnet';
import { journaliser } from './journal';
import { param, relireParametres } from './parametres';
import { requeteServeur } from './partage';

export type Reglage = { jours: 0 | 1 | 7 };
export type SauvegardeEnLigne = { id: string; cree_le: string; appareil: string | null; nids: number | null; taille: number | null };
const GARDER = 8;
/** Réglages propres à ce téléphone : jamais sauvegardés ni écrasés par une restauration. */
const LOCAUX = ['session', 'serveur', 'partageEquipe', 'partageCurseurs', 'sauvegardeAuto', 'derniereSauvegardeAuto', 'essaiSauvegardeAuto', 'rappelControle'];

export const reglageAuto = (): Reglage => ({ jours: 7, ...(lireValeur<Reglage>('sauvegardeAuto') ?? {}) });
export const changerReglageAuto = (r: Reglage) => ecrireValeur('sauvegardeAuto', r);
export const derniereAuto = () => lireValeur<number>('derniereSauvegardeAuto');
export const pretEnLigne = () => !!sessionActuelle() && serveurComplet(lireServeur());

/** Envoie une sauvegarde maintenant et ne garde que les 8 dernières. */
export async function sauvegarderEnLigne(): Promise<{ nids: number; taille: number }> {
  if (!pretEnLigne()) throw new Error('Connectez-vous (Menu → Partage entre téléphones) pour sauvegarder sur le serveur.');
  const s = toutLire();
  const donnees: Sauvegarde = { ...s, reglages: s.reglages.filter((r) => !LOCAUX.includes(r.cle)) };
  const nids = s.nids.filter((n) => !n.supprime).length;
  const json = JSON.stringify(donnees);
  try {
    await requeteServeur<null>('sauvegarde', { method: 'POST', prefer: 'return=minimal',
      body: JSON.stringify({ appareil: `${param().nom || 'Téléphone'} · ${Platform.OS}`, nids, taille: json.length, donnees }) });
  } catch (e) {
    const m = (e as Error).message;
    if (/sauvegarde|n'est pas préparé/i.test(m) && /relation|préparé|find/i.test(m)) throw new Error('Le serveur n\'a pas encore la table des sauvegardes : relancez le script SQL (Menu → Partage entre téléphones → Serveur de l\'équipe).');
    throw e;
  }
  ecrireValeur('derniereSauvegardeAuto', Date.now());
  // ménage : au-delà des 8 dernières
  const l = await listeEnLigne().catch(() => [] as SauvegardeEnLigne[]);
  const vieilles = l.slice(GARDER).map((x) => x.id);
  if (vieilles.length) await requeteServeur<null>(`sauvegarde?id=in.(${vieilles.join(',')})`, { method: 'DELETE' }).catch(() => {});
  journaliser('partage', 'etat', `Sauvegarde automatique : ${nids} nid${nids > 1 ? 's' : ''}, ${Math.round(json.length / 1024)} ko`);
  return { nids, taille: json.length };
}

export const listeEnLigne = () => requeteServeur<SauvegardeEnLigne[]>('sauvegarde?select=id,cree_le,appareil,nids,taille&order=cree_le.desc');

/** Remplace le carnet par une sauvegarde du serveur ; la connexion et l'équipe de ce téléphone sont gardées. */
export async function restaurerEnLigne(id: string): Promise<number> {
  const [r] = await requeteServeur<{ donnees: Sauvegarde }[]>(`sauvegarde?select=donnees&id=eq.${id}`);
  if (!r?.donnees) throw new Error('Sauvegarde introuvable.');
  const avant = toutLire().reglages.filter((x) => LOCAUX.includes(x.cle));
  const s = r.donnees;
  toutRemplacer({ ...s, reglages: [...s.reglages.filter((x) => !LOCAUX.includes(x.cle)), ...avant] });
  chargerCarnet();
  relireParametres();
  journaliser('partage', 'etat', 'Carnet restauré depuis une sauvegarde du serveur');
  return s.nids.filter((n) => !n.supprime).length;
}

/** Vérifie au démarrage puis toutes les heures s'il est temps de sauvegarder (après un échec : nouvel essai 6 h plus tard). */
export function demarrerSauvegardeAuto() {
  const verifier = () => {
    const { jours } = reglageAuto();
    if (!jours || !pretEnLigne()) return;
    const now = Date.now(), der = derniereAuto() ?? 0, essai = lireValeur<number>('essaiSauvegardeAuto') ?? 0;
    if (now - der < jours * 86400000 - 3600000 || now - essai < 6 * 3600000) return;
    ecrireValeur('essaiSauvegardeAuto', now);
    sauvegarderEnLigne().catch((e) => journaliser('partage', 'erreur', `Sauvegarde automatique : ${(e as Error).message}`));
  };
  const t0 = setTimeout(verifier, 30000);
  const t1 = setInterval(verifier, 3600000);
  return () => { clearTimeout(t0); clearInterval(t1); };
}
