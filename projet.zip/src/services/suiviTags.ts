/** Mémorise la pile de chaque tag entendue par le vrai toit (pas en simulation), pour le rappel de recharge.
 *  Écrit au plus une fois toutes les 30 min par tag, ou dès que la pile change de 5 % ou plus. */
import { meilleurePosition, store } from '../store/store';
import { doitNoter } from '../calc/resultats';
import { ficheTag, majTag } from './carnet';
import { param } from './parametres';
import { raisonRecharge } from '../calc/saison';

let dernier = 0;
function verifier() {
  const e = store.get();
  const t0 = Date.now();
  if (t0 - dernier < 5000) return;
  dernier = t0;
  noterContacts(e, t0);
  if (e.source !== 'toit') return;
  for (const t of Object.values(e.tags)) {
    if (t.pile < 0 || t.pile > 100) continue;
    const f = ficheTag(t.id);
    if (f.pile === null || Math.abs(f.pile - t.pile) >= 5 || t0 - (f.pile_ms ?? 0) > 30 * 60000) majTag(t.id, { pile: t.pile, pile_ms: t0 });
  }
}

/** Dernier contact de chaque tag (vrai toit ou vrai portatif, pas la simulation) : pour retrouver un tag perdu.
 *  Position : l'estimation du nid si elle existe, sinon la position du récepteur. */
function noterContacts(e: ReturnType<typeof store.get>, t0: number) {
  if (e.source === 'toit') {
    const pos = meilleurePosition(e);
    for (const t of Object.values(e.tags)) {
      if (t0 - t.dernierMs > 60000) continue;
      const f = t.fusion?.ok ? { lat: t.fusion.lat, lon: t.fusion.lon, err: Math.round(t.fusion.errM) } : pos ? { lat: pos.lat, lon: pos.lon, err: null } : null;
      if (!f) continue;
      const v = { t: t.dernierMs, lat: f.lat, lon: f.lon, par: t.fusion?.ok ? 'estimation' : 'voiture', err: f.err };
      if (doitNoter(ficheTag(t.id), v)) majTag(t.id, { vu_ms: v.t, vu_lat: v.lat, vu_lon: v.lon, vu_par: v.par, vu_err: v.err });
    }
  }
  if (e.portatif.source === 'ble') {
    for (const t of Object.values(e.portatif.autres)) {
      if (!t.lat && !t.lon) continue;
      const v = { t: t0 - (t.age ?? 0) * 1000, lat: t.lat, lon: t.lon, par: 'portatif', err: null };
      if (t0 - v.t > 60000) continue;
      if (doitNoter(ficheTag(t.id), v)) majTag(t.id, { vu_ms: v.t, vu_lat: v.lat, vu_lon: v.lon, vu_par: v.par, vu_err: null });
    }
  }
}

export const reglagesRecharge = () => { const p = param(); return { seuil: p.rechargeSeuilPct, jours: p.rechargeJours }; };

/** Tags à recharger (hors « recharge jamais notée », qui ne déclenche pas de rappel). */
export function tagsARecharger(maintenant = Date.now()) {
  const r = reglagesRecharge();
  return Object.values(store.get().fichesTags).filter((f) => { if (f.etat === 'pose') return false; const x = raisonRecharge(f, maintenant, r.seuil, r.jours); return x !== null && x !== 'jamais'; });
}

/** Rappel au démarrage, au plus une fois par jour. */
export function rappelRecharge(prevenir: (n: number, ids: number[]) => void) {
  const l = tagsARecharger();
  if (l.length) prevenir(l.length, l.map((f) => f.id));
}

export function suivreTags() {
  return store.abonner(verifier);
}
