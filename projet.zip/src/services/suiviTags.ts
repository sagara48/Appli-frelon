/** Mémorise la pile de chaque tag entendue par le vrai toit (pas en simulation), pour le rappel de recharge.
 *  Écrit au plus une fois toutes les 30 min par tag, ou dès que la pile change de 5 % ou plus. */
import { store } from '../store/store';
import { ficheTag, majTag } from './carnet';
import { param } from './parametres';
import { raisonRecharge } from '../calc/saison';

let dernier = 0;
function verifier() {
  const e = store.get();
  if (e.source !== 'toit') return;
  const t0 = Date.now();
  if (t0 - dernier < 5000) return;
  dernier = t0;
  for (const t of Object.values(e.tags)) {
    if (t.pile < 0 || t.pile > 100) continue;
    const f = ficheTag(t.id);
    if (f.pile === null || Math.abs(f.pile - t.pile) >= 5 || t0 - (f.pile_ms ?? 0) > 30 * 60000) majTag(t.id, { pile: t.pile, pile_ms: t0 });
  }
}

export const reglagesRecharge = () => { const p = param(); return { seuil: p.rechargeSeuilPct, jours: p.rechargeJours }; };

/** Tags à recharger (hors « recharge jamais notée », qui ne déclenche pas de rappel). */
export function tagsARecharger(maintenant = Date.now()) {
  const r = reglagesRecharge();
  return Object.values(store.get().fichesTags).filter((f) => { if (f.etat === 'pose') return false; const x = raisonRecharge(f, maintenant, r.seuil, r.jours); return x !== null && x !== 'jamais'; });
}

/** Rappel au démarrage, au plus une fois par jour. */
export function rappelRecharge(prevenir: (n: number, ids: number[]) => void) {
  const l = tagsARecharger();
  if (l.length) prevenir(l.length, l.map((f) => f.id));
}

export function suivreTags() {
  return store.abonner(verifier);
}
