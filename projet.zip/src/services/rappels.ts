/** Rappels par notification (Paramètres → Automatismes) : contrôles de nids dus, pièges à relever, tags à recharger,
 *  tags posés sans nouvelles. Recalculés 20 s après chaque changement du carnet, et à chaque ouverture de l'appli. */
import { AppState, Platform } from 'react-native';
import { store } from '../store/store';
import { rappels } from '../calc/rappels';
import { numeroNid } from './carnet';
import { param } from './parametres';
import { programmerFamille } from './notifs';

let minuteur: ReturnType<typeof setTimeout> | null = null;
let signature = '';
export function reprogrammerRappels() {
  const e = store.get(), P = param();
  const l = P.autoRappels ? rappels(e.nids, e.pieges, Object.values(e.fichesTags), {
    controleJours: P.controleJours, releverJours: P.releverJours, rechargeSeuilPct: P.rechargeSeuilPct, rechargeJours: P.rechargeJours,
    silenceJours: P.silenceJours, heureMatin: 9, heureSoir: 18,
  }, Date.now(), (id) => numeroNid(e.nids, id)) : [];
  const sig = JSON.stringify(l.map((x) => [x.date, x.texte]));
  if (sig === signature) return;
  signature = sig;
  programmerFamille('rappels', l.map((x) => ({ date: x.date, titre: x.titre, texte: x.texte, url: x.url }))).catch(() => {});
}

if (Platform.OS !== 'web') {
  let avant: unknown = null;
  store.abonner(() => {
    const e = store.get(), cle = [e.nids, e.pieges, e.fichesTags];
    if (avant && (avant as unknown[]).every((x, i) => x === cle[i])) return;
    avant = cle;
    if (minuteur) clearTimeout(minuteur);
    minuteur = setTimeout(reprogrammerRappels, 20000);
  });
  AppState.addEventListener('change', (s) => { if (s === 'active') { signature = ''; reprogrammerRappels(); } });
}
