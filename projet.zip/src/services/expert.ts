/** Mode expert : affiche les réglages techniques (mesure du toit, gains, maintenance, banc d'essai, journal,
 *  paramètres avancés, niveaux par voie). Désactivé par défaut pour garder l'appli simple. */
import { useSyncExternalStore } from 'react';
import { ecrireValeur, lireValeur } from '../db';

let actif: boolean | undefined;
const abonnes = new Set<() => void>();
export const modeExpert = (): boolean => {
  if (actif === undefined) { try { actif = !!lireValeur<boolean>('modeExpert'); } catch { actif = false; } }
  return actif;
};
export function changerModeExpert(v: boolean) { actif = v; try { ecrireValeur('modeExpert', v); } catch {} abonnes.forEach((f) => f()); }
const abonner = (f: () => void) => { abonnes.add(f); return () => { abonnes.delete(f); }; };
export const useModeExpert = () => useSyncExternalStore(abonner, modeExpert, modeExpert);
