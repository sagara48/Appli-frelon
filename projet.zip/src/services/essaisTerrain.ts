/** Essais sur le terrain : résultats gardés dans le téléphone, et les essais que l'appli voit passer se cochent seuls
 *  (une coche « vu par l'appli » ne remplace jamais un « Problème » noté à la main). */
import { useSyncExternalStore } from 'react';
import { ecrireValeur, lireValeur } from '../db';
import { ecouterLignes, store } from '../store/store';
import { parseToit } from '../proto/toit';
import { comparerVersions } from '../calc/versions';
import { bilanEssais, ESSAIS, type Resultat } from '../calc/essaisTerrain';

let R: Record<string, Resultat> | null = null;
const abonnes = new Set<() => void>();
const lire = (): Record<string, Resultat> => { if (!R) { try { R = lireValeur<Record<string, Resultat>>('essaisTerrain') ?? {}; } catch { R = {}; } } return R; };
function ecrire(n: Record<string, Resultat>) { R = n; try { ecrireValeur('essaisTerrain', n); } catch { /* ignore */ } abonnes.forEach((f) => f()); }
export const useEssaisTerrain = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, lire, lire);
export const resultatsEssais = lire;

export function noterEssai(id: string, etat: 'ok' | 'ko' | null, note?: string) {
  const n = { ...lire() };
  if (etat === null) delete n[id]; else n[id] = { etat, t: Date.now(), ...(note ? { note } : {}) };
  ecrire(n);
}
export function effacerEssais() { ecrire({}); }

/** Un événement vu par l'appli coche l'essai correspondant (sauf s'il est déjà noté à la main). */
export function marquerAuto(evt: string) {
  const e = ESSAIS.find((x) => x.auto === evt);
  if (!e) return;
  const r = lire();
  if (r[e.id]) return;
  ecrire({ ...r, [e.id]: { etat: 'ok', t: Date.now(), auto: true } });
  store.evenement(`Essai réussi : ${e.titre}`);
}

/** Pour le Menu : « 12 / 25 · 1 problème ». */
export function essaisTerrainDetail(): string {
  const b = bilanEssais(lire());
  return `${b.ok + b.ko} / ${b.total} essayés${b.ko ? ` · ${b.ko} problème${b.ko > 1 ? 's' : ''}` : ''}`;
}

ecouterLignes((src, ligne) => {
  const e = store.get();
  if (src === 'P' && e.portatif.source !== 'ble') return; // portatif simulé
  if (src !== 'P' && e.source !== 'toit') return; // sortie simulée
  if (src === 'P') {
    if (!ligne.includes('"type"')) return;
    try {
      const o = JSON.parse(ligne) as { type: string; ctr?: number; res?: string };
      if (o.type === 'tour' && (o.ctr ?? 0) >= 4) marquerAuto('tour');
      else if (o.type === 'voit') marquerAuto('voit');
      else if (o.type === 'ordre' && o.res === 'ok') marquerAuto('ordrePort');
      else if (o.type === 'chg') marquerAuto('chg');
    } catch { /* ignore */ }
    return;
  }
  const l = parseToit(ligne);
  if (!l) return;
  if (l.kind === 'S' && (l.capGyro === 1 || l.capGyro === 2)) marquerAuto('gyro');
  else if (l.kind === 'K' && l.type === 'BN') marquerAuto('bn');
  else if (l.kind === 'K' && l.type === 'TAG' && l.res === 'ok') marquerAuto('ordreToit');
});

let avant = store.get();
store.abonner(() => {
  const e = store.get();
  if (e.source === 'simulation') { avant = e; return; } // la sortie simulée ne prouve rien sur le matériel
  if (e.versionToit !== avant.versionToit && e.versionToit && comparerVersions(e.versionToit.fw, '1.4.0') >= 0) marquerAuto('toit14');
  const pv = e.portatif.version;
  if (pv !== avant.portatif.version && pv && e.portatif.source === 'ble' && comparerVersions(pv.fw, '1.4.0') >= 0) marquerAuto('port14');
  if (e.activites !== avant.activites && Object.values(e.activites).some((a) => a.tempC !== null)) marquerAuto('etatTag');
  if (e.evenements !== avant.evenements && e.evenements[0] && e.evenements[0] !== avant.evenements[0]) {
    if (/^Tag \d+ tombé/.test(e.evenements[0])) marquerAuto('tombe');
    if (e.evenements[0].startsWith('Vol du drone enregistré')) marquerAuto('vol');
  }
  avant = e;
});
