/** Script à coller une fois dans Supabase (SQL Editor → New query → Run) : équipes, membres et fiches partagées,
 *  protégés par les comptes (Supabase Auth). Peut être relancé sans risque. */
export const SQL_PARTAGE = `-- Appli Frelons : équipes et partage des nids, ruchers et pièges (comptes Supabase)

-- équipes et membres
create table if not exists equipe (
  id uuid primary key default gen_random_uuid(),
  nom text not null,
  code text not null unique,            -- code d'invitation, à donner aux équipiers
  cree_le timestamptz not null default now()
);
create table if not exists membre (
  equipe uuid not null references equipe (id) on delete cascade,
  utilisateur uuid not null default auth.uid(),
  nom text,
  email text,
  admin boolean not null default false,
  rejoint_le timestamptz not null default now(),
  primary key (equipe, utilisateur)
);

-- fiches partagées (nids, ruchers, pièges)
create table if not exists fiche (
  uid text primary key,
  equipe uuid not null references equipe (id) on delete cascade,
  type text not null check (type in ('nid', 'rucher', 'piege')),
  data jsonb not null,
  maj_ms bigint not null,
  supprime boolean not null default false,
  auteur text,
  recu timestamptz not null default clock_timestamp()
);
create index if not exists fiche_equipe_recu on fiche (equipe, recu);

-- la modification la plus récente gagne ; date de réception posée par le serveur
create or replace function fiche_avant() returns trigger language plpgsql as $$
begin
  if tg_op = 'UPDATE' and (new.maj_ms <= old.maj_ms or new.equipe <> old.equipe) then
    return null;
  end if;
  new.recu := clock_timestamp();
  return new;
end $$;
drop trigger if exists fiche_avant on fiche;
create trigger fiche_avant before insert or update on fiche for each row execute function fiche_avant();

-- équipes de l'utilisateur connecté, et équipes dont il est responsable
create or replace function mes_equipes() returns setof uuid language sql stable security definer set search_path = public as $$
  select equipe from membre where utilisateur = auth.uid()
$$;
create or replace function est_admin(p_equipe uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from membre where equipe = p_equipe and utilisateur = auth.uid() and admin)
$$;

alter table equipe enable row level security;
alter table membre enable row level security;
alter table fiche enable row level security;
drop policy if exists equipe_lire on equipe;
create policy equipe_lire on equipe for select to authenticated using (id in (select mes_equipes()));
drop policy if exists membre_lire on membre;
create policy membre_lire on membre for select to authenticated using (equipe in (select mes_equipes()));
drop policy if exists membre_retirer on membre;
create policy membre_retirer on membre for delete to authenticated using (utilisateur = auth.uid() or est_admin(equipe));
drop policy if exists membre_nom on membre;
create policy membre_nom on membre for update to authenticated using (utilisateur = auth.uid()) with check (utilisateur = auth.uid());
drop policy if exists fiche_equipe on fiche;
create policy fiche_equipe on fiche for all to authenticated
  using (equipe in (select mes_equipes())) with check (equipe in (select mes_equipes()));
grant select on equipe to authenticated;
grant select, delete, update (nom) on membre to authenticated;
grant select, insert, update on fiche to authenticated;
revoke all on equipe, membre, fiche from anon;

-- créer une équipe (le créateur en est responsable), la rejoindre avec son code, changer le code
create or replace function nouveau_code_aleatoire() returns text language sql volatile as $$
  select upper(substr(md5(random()::text || clock_timestamp()::text), 1, 4) || '-' || substr(md5(random()::text || clock_timestamp()::text), 1, 4))
$$;
create or replace function creer_equipe(p_nom text, p_mon_nom text) returns equipe language plpgsql security definer set search_path = public as $$
declare e equipe;
begin
  if auth.uid() is null then raise exception 'connexion requise'; end if;
  insert into equipe (nom, code) values (coalesce(nullif(trim(p_nom), ''), 'Équipe'), nouveau_code_aleatoire()) returning * into e;
  insert into membre (equipe, utilisateur, nom, email, admin) values (e.id, auth.uid(), p_mon_nom, auth.jwt() ->> 'email', true);
  return e;
end $$;
create or replace function rejoindre_equipe(p_code text, p_mon_nom text) returns equipe language plpgsql security definer set search_path = public as $$
declare e equipe;
begin
  if auth.uid() is null then raise exception 'connexion requise'; end if;
  select * into e from equipe where code = upper(trim(p_code));
  if not found then raise exception 'code d''équipe inconnu'; end if;
  insert into membre (equipe, utilisateur, nom, email) values (e.id, auth.uid(), p_mon_nom, auth.jwt() ->> 'email')
    on conflict (equipe, utilisateur) do update set nom = excluded.nom;
  return e;
end $$;
create or replace function changer_code(p_equipe uuid) returns text language plpgsql security definer set search_path = public as $$
declare c text;
begin
  if not est_admin(p_equipe) then raise exception 'réservé au responsable de l''équipe'; end if;
  update equipe set code = nouveau_code_aleatoire() where id = p_equipe returning code into c;
  return c;
end $$;
create or replace function nommer_admin(p_equipe uuid, p_utilisateur uuid, p_admin boolean) returns void language plpgsql security definer set search_path = public as $$
begin
  if not est_admin(p_equipe) then raise exception 'réservé au responsable de l''équipe'; end if;
  update membre set admin = p_admin where equipe = p_equipe and utilisateur = p_utilisateur;
end $$;
revoke execute on function creer_equipe, rejoindre_equipe, changer_code, nommer_admin, mes_equipes, est_admin from anon, public;
grant execute on function creer_equipe, rejoindre_equipe, changer_code, nommer_admin, mes_equipes, est_admin to authenticated;
-- sauvegardes automatiques du carnet (chacun ne voit que les siennes)
create table if not exists sauvegarde (
  id uuid primary key default gen_random_uuid(),
  utilisateur uuid not null default auth.uid(),
  cree_le timestamptz not null default now(),
  appareil text,
  nids integer,
  taille integer,
  donnees jsonb not null
);
create index if not exists sauvegarde_utilisateur on sauvegarde (utilisateur, cree_le desc);
alter table sauvegarde enable row level security;
drop policy if exists sauvegarde_moi on sauvegarde;
create policy sauvegarde_moi on sauvegarde for all to authenticated using (utilisateur = auth.uid()) with check (utilisateur = auth.uid());
grant select, insert, delete on sauvegarde to authenticated;
revoke all on sauvegarde from anon;
`;
