/** Santé des antennes : les relevés du toit de chaque sortie sont résumés à la fin (déconnexion, ou 30 min sans relevé)
 *  et gardés (40 dernières sorties). Une voie qui faiblit ou décroche depuis 3 sorties donne une notification.
 *  La sortie simulée n'est pas comptée. */
import { useSyncExternalStore } from 'react';
import { ecrireValeur, lireValeur } from '../db';
import { ecouterLignes, store } from '../store/store';
import { parseToit } from '../proto/toit';
import { Accumulateur, diagnosticAntennes, type BilanSortie } from '../calc/santeAntennes';
import { notifier } from './notifs';

let H: BilanSortie[] | null = null;
const abonnes = new Set<() => void>();
const lire = (): BilanSortie[] => { if (!H) { try { H = lireValeur<BilanSortie[]>('santeAntennes') ?? []; } catch { H = []; } } return H; };
export const useSanteAntennes = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, lire, lire);
export const historiqueAntennes = lire;
export function effacerHistoriqueAntennes() { H = []; try { ecrireValeur('santeAntennes', H); } catch { /* ignore */ } abonnes.forEach((f) => f()); }

let acc = new Accumulateur(), dernier = 0;
function clore() {
  const b = acc.bilan(Date.now());
  acc = new Accumulateur();
  if (!b) return;
  const avant = diagnosticAntennes(lire()).filter((x) => x.etat === 'faible' || x.etat === 'coupe').map((x) => x.voie);
  H = [...lire(), b].slice(-40);
  try { ecrireValeur('santeAntennes', H); } catch { /* ignore */ }
  abonnes.forEach((f) => f());
  const nouveaux = diagnosticAntennes(H).filter((x) => (x.etat === 'faible' || x.etat === 'coupe') && !avant.includes(x.voie));
  for (const x of nouveaux) {
    store.evenement(`Antenne ${x.voie} du toit : ${x.texte}`);
    notifier('Antenne du toit', `Voie ${x.voie} : ${x.texte}.`, '/antennes').catch(() => {});
  }
}

ecouterLignes((src, ligne) => {
  if (src === 'P' || store.get().source !== 'toit' || ligne[0] !== 'R') return;
  const l = parseToit(ligne);
  if (!l || l.kind !== 'R' || l.lp) return;
  acc.ajouter(l.r);
  dernier = Date.now();
});
let avantCo = '';
store.abonner(() => {
  const e = store.get(), k = `${e.source}/${e.connexion}`;
  if (k !== avantCo) { const etaitToit = avantCo === 'toit/connecte'; avantCo = k; if (etaitToit && k !== 'toit/connecte') clore(); }
});
setInterval(() => { if (dernier && Date.now() - dernier > 30 * 60000 && acc.trames) { dernier = 0; clore(); } }, 60000);
