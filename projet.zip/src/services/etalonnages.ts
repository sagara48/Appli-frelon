/** Étalonnages : état de chaque étape (écran Étalonnage), lancement depuis l'appli, et réglages calculés seuls.
 *  - Boussole et entrée radio du portatif : lancées par « cmpcal » / « rfcal », résultat renvoyé par le portatif
 *    (lignes « cal ») et rappelé à chaque connexion (ligne « ver » 1.3.0).
 *  - Pendant l'étalonnage du toit, les niveaux du tag (position connue grâce à « calpos ») donnent le signal du toit
 *    à 1 m et l'incertitude : Paramètres → Distance estimée n'a plus à être rempli à la main.
 *  - Le signal du portatif à 1 m suit la médiane des tags étalonnés à 1 m. */
import { useSyncExternalStore } from 'react';
import { Alert } from 'react-native';
import { ecrireValeur, lireValeur } from '../db';
import { ecouterLignes, store, useEtat } from '../store/store';
import { parseToit } from '../proto/toit';
import { cmdPortatif } from '../proto/portatif';
import { envoyerPortatif } from '../sources/portatif';
import { ajusterDistance, distM, etapes, refPortatif, resteAFaire, type AjustementDist, type Etape, type PointDist } from '../calc/etalAuto';
import type { Etat } from '../store/store';
import type { Etal } from './etalonnage';
import { changerParametres, param } from './parametres';
import { lireEtalonnagesTags, abonnerEtalonnagesTags, useEtalonnages } from './etalonnage';
import { exposant, facteurEstimations, lireApprentissage, useApprentissage, vitesseVol } from './terrain';
import { useMaintenant } from '../ui/composants';

export type EtalAuto = {
  boussole?: { ok: boolean; t: number };
  rf?: { att: number; lna: number; t: number };
  distToit?: AjustementDist & { t: number };
};
let E: EtalAuto | null = null;
const abonnes = new Set<() => void>();
const lire = (): EtalAuto => { if (!E) { try { E = lireValeur<EtalAuto>('etalAuto') ?? {}; } catch { E = {}; } } return E; };
function ecrire(p: Partial<EtalAuto>) { E = { ...lire(), ...p }; try { ecrireValeur('etalAuto', E); } catch { /* ignore */ } abonnes.forEach((f) => f()); }
export const useEtalAuto = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, lire, lire);
export const etalAuto = lire;

/* en cours sur le portatif (pour l'écran) */
type EnCours = { quoi: 'cmp' | 'rf' | null; depuis: number; message: string };
let enCours: EnCours = { quoi: null, depuis: 0, message: '' };
const publierEnCours = (p: EnCours) => { enCours = p; abonnes.forEach((f) => f()); };
export const useEnCoursPortatif = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, () => enCours, () => enCours);

const portatifPret = () => { const p = store.get().portatif; return p.connexion === 'connecte' && p.source === 'ble'; };

export function lancerBoussole() {
  if (!portatifPret()) { Alert.alert('Boussole', 'Connectez d\'abord le portatif.'); return; }
  Alert.alert('Calibrer la boussole du portatif',
    'Loin de la voiture et de tout objet métallique (2 à 3 m suffisent), tournez le portatif pendant 20 secondes dans tous les sens : en huit, écran vers le ciel, vers le sol, sur le côté.',
    [{ text: 'Annuler', style: 'cancel' }, { text: 'Démarrer', onPress: () => {
      envoyerPortatif(cmdPortatif.cmpcal()).catch(() => {});
      publierEnCours({ quoi: 'cmp', depuis: Date.now(), message: 'Tournez le portatif dans tous les sens (20 s)…' });
      setTimeout(() => { if (enCours.quoi === 'cmp') publierEnCours({ quoi: null, depuis: 0, message: 'Pas de réponse du portatif (firmware 1.3.0 nécessaire).' }); }, 30000);
    } }]);
}

export function lancerRf() {
  if (!portatifPret()) { Alert.alert('Entrée radio', 'Connectez d\'abord le portatif.'); return; }
  const st = store.get().portatif.st;
  if (!st || st.tag < 0 || st.age > 5) { Alert.alert('Entrée radio', 'Le portatif doit suivre un tag allumé : choisissez-en un dans l\'onglet Portatif ou sur le portatif.'); return; }
  Alert.alert('Mesurer l\'entrée radio du portatif',
    `Posez le tag ${st.tag} à 2 à 5 m du portatif, sans obstacle, et ne bougez plus pendant 20 secondes. Le portatif compare le signal par ses trois chemins (préampli, direct, atténuateur).`,
    [{ text: 'Annuler', style: 'cancel' }, { text: 'Démarrer', onPress: () => {
      envoyerPortatif(cmdPortatif.rfcal()).catch(() => {});
      publierEnCours({ quoi: 'rf', depuis: Date.now(), message: 'Mesure en cours, ne bougez plus (20 s)…' });
      setTimeout(() => { if (enCours.quoi === 'rf') publierEnCours({ quoi: null, depuis: 0, message: 'Pas de réponse du portatif.' }); }, 35000);
    } }]);
}

/* ---------- lignes reçues ---------- */
let posTag: { lat: number; lon: number } | null = null; // position du tag d'étalonnage (« calpos »)
let tagCal: number | null = null;
let points: PointDist[] = [];
/** L'écran d'étalonnage du toit signale le tag choisi au démarrage des tours. */
export function noterTagEtalonnage(id: number) { tagCal = id; points = []; }

ecouterLignes((src, ligne) => {
  if (src === 'P') {
    let o: { type?: string; quoi?: string; ok?: number; att?: number; lna?: number; rfc?: number; cmpc?: number; err?: string } | null = null;
    try { o = JSON.parse(ligne.trim()); } catch { return; }
    if (!o) return;
    if (o.type === 'cal' && o.quoi === 'cmp') {
      if (o.ok) ecrire({ boussole: { ok: true, t: Date.now() } });
      publierEnCours({ quoi: null, depuis: 0, message: o.ok ? 'Boussole calibrée.' : 'Calibration incomplète : recommencez en tournant aussi le portatif sur le côté et tête en bas.' });
      store.evenement(o.ok ? 'Portatif : boussole calibrée' : 'Portatif : calibration de la boussole incomplète');
    } else if (o.type === 'cal' && o.quoi === 'rf') {
      if (o.ok && Number.isFinite(o.att) && Number.isFinite(o.lna)) ecrire({ rf: { att: o.att!, lna: o.lna!, t: Date.now() } });
      publierEnCours({ quoi: null, depuis: 0, message: o.ok ? 'Entrée radio mesurée.' : o.err === 'tag' ? 'Le portatif ne suit aucun tag.' : 'Trop peu de trames : rapprochez le tag (2 à 5 m) et recommencez.' });
    } else if (o.type === 'ver') {
      // le portatif rappelle l'état de ses étalonnages à chaque connexion (1.3.0)
      if (o.cmpc !== undefined && !!o.cmpc !== !!lire().boussole?.ok) ecrire({ boussole: { ok: !!o.cmpc, t: lire().boussole?.t ?? 0 } });
      if (o.rfc && Number.isFinite(o.att) && Number.isFinite(o.lna) && !lire().rf) ecrire({ rf: { att: o.att!, lna: o.lna!, t: 0 } });
    }
    return;
  }
  const l = parseToit(ligne);
  if (!l) return;
  if (l.kind === 'K' && l.type === 'POS') {
    const t = store.get().toit;
    posTag = t && t.lat ? { lat: t.lat, lon: t.lon } : null;
  } else if (l.kind === 'K' && l.type === 'GO') {
    points = [];
  } else if (l.kind === 'R' && posTag && tagCal !== null && l.tag === tagCal && store.get().etalonnage.enCours && l.lat) {
    const r = Math.max(...l.r.filter((x) => Number.isFinite(x) && x > -127));
    if (Number.isFinite(r) && !l.lp && points.length < 2000) points.push({ d: distM(posTag, { lat: l.lat, lon: l.lon }), rssi: r });
  } else if (l.kind === 'K' && l.type === 'RESULTAT') {
    const a = ajusterDistance(points);
    if (a) {
      ecrire({ distToit: { ...a, t: Date.now() } });
      changerParametres({ distRefToit: a.ref1m, distMargeDb: a.margeDb });
      store.evenement(`Distance du toit réglée : ${a.ref1m} dBm à 1 m, ± ${a.margeDb} dB (${a.nPts} mesures)`);
    }
    points = []; tagCal = null;
  }
});

/* signal du portatif à 1 m : médiane des tags étalonnés */
function majRefPortatif() {
  const r = refPortatif(Object.values(lireEtalonnagesTags()).map((e) => e.p1m));
  if (r !== null && r !== param().distRefPortatif) changerParametres({ distRefPortatif: r });
}
abonnerEtalonnagesTags(majRefPortatif);

/* ---------- état des étapes (écran Étalonnage, bandeau du Menu) ---------- */
/** Étapes de la procédure avec leur état, d'après l'état de l'appli et ce qui est gardé dans le téléphone. */
export function etapesEtalonnage(e: Etat, tagsEtal: Record<number, Etal>, exposant: number | null, nidsTerrain: number, maintenant: number, appris: { vitesse?: number | null; facteur?: number | null } = {}): Etape[] {
  const a = lire(), st = e.portatif.connexion === 'connecte' && e.portatif.source === 'ble' ? e.portatif.st : null;
  const boussole = st && st.cmp !== undefined ? st.cmp !== 2 : a.boussole ? a.boussole.ok : null;
  const connus = Object.values(e.fichesTags).filter((f) => f.etat !== 'perdu').map((f) => f.id);
  const ids = new Set<number>([...connus, ...Object.keys(tagsEtal).map(Number)]);
  const r = e.etalonnage.resultat;
  return etapes({
    boussole, rf: a.rf ?? null, tagsEtalonnes: [...ids].filter((id) => tagsEtal[id]).length, tagsConnus: ids.size,
    toit: r ? { errDeg: r.errDeg, date: r.date } : null, distToit: a.distToit ? { ref1m: a.distToit.ref1m, margeDb: a.distToit.margeDb, date: a.distToit.t } : null,
    exposant, nidsTerrain, maintenant, ...appris,
  });
}

/** Nombre d'étapes d'étalonnage à faire ou à refaire (bandeau du Menu et de l'accueil). */
export function useResteEtalonnage(): number {
  const e = useEtat((x) => x);
  const etals = useEtalonnages();
  const appris = useApprentissage();
  useEtalAuto();
  const now = useMaintenant(3600000);
  return resteAFaire(etapesEtalonnage(e, etals, exposant(), Object.keys(appris.terrains).length, now, { vitesse: vitesseVol(), facteur: facteurEstimations() }));
}

/** Même calcul hors écran (bandeau « Avant de partir »). */
export function resteEtalonnage(): number {
  const a = lireApprentissage();
  return resteAFaire(etapesEtalonnage(store.get(), lireEtalonnagesTags(), exposant(), Object.keys(a.terrains).length, Date.now(), { vitesse: vitesseVol(), facteur: facteurEstimations() }));
}
