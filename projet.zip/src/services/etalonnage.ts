/** Étalonnage de chaque tag : le niveau à 1 m (P1m) mesuré par le portatif est gardé dans le téléphone
 *  et renvoyé au portatif à chaque connexion (après une mise à jour ou un changement de portatif). */
import { Alert } from 'react-native';
import { useSyncExternalStore } from 'react';
import { ecrireValeur, lireValeur } from '../db';
import { store } from '../store/store';
import { cmdPortatif } from '../proto/portatif';
import { envoyerPortatif } from '../sources/portatif';
import { cibleImpossible } from './cible';

export type Etal = { p1m: number; t: number };
let table: Record<number, Etal> | null = null;
const abonnes = new Set<() => void>();
const lire = () => { if (!table) { try { table = lireValeur<Record<number, Etal>>('etalonnageTags') ?? {}; } catch { table = {}; } } return table; };
export const lireEtalonnagesTags = () => lire();
export const abonnerEtalonnagesTags = (f: () => void) => { abonnes.add(f); return () => { abonnes.delete(f); }; };
export const useEtalonnages = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, lire, lire);
function ecrire(t: Record<number, Etal>) { table = t; try { ecrireValeur('etalonnageTags', t); } catch { /* ignore */ } abonnes.forEach((f) => f()); }

/** Lance l'étalonnage d'un tag sur le portatif, après la consigne. */
export function etalonner(id: number, num: string) {
  const non = cibleImpossible();
  if (non) { Alert.alert('Étalonner le tag', non); return; }
  Alert.alert(`Étalonner le tag ${num}`,
    "Posez le tag à 1 mètre devant l'antenne du portatif, à la même hauteur, sans obstacle ni personne entre les deux (par exemple sur un piquet, en extérieur). Ne bougez plus pendant 20 à 60 secondes.",
    [{ text: 'Annuler', style: 'cancel' }, { text: 'Démarrer', onPress: () => { envoyerPortatif(cmdPortatif.etal(id)).catch(() => {}); } }]);
}
export function oublierEtalonnage(id: number) { const t = { ...lire() }; delete t[id]; ecrire(t); }

let dernierEtal: unknown = null, envoyePour: unknown = null;
store.abonner(() => {
  const p = store.get().portatif;
  // résultat d'un étalonnage
  if (p.etal && p.etal !== dernierEtal) {
    dernierEtal = p.etal;
    if (p.etal.p1m) ecrire({ ...lire(), [p.etal.id]: { p1m: p.etal.p1m, t: Date.now() } });
  }
  // à la connexion (après la réponse « ver ») : on renvoie les étalonnages connus
  if (p.connexion === 'connecte' && p.version && envoyePour !== p.version) {
    envoyePour = p.version;
    const l = Object.entries(lire());
    (async () => { for (const [id, e] of l) await envoyerPortatif(cmdPortatif.p1m(Number(id), e.p1m)).catch(() => {}); })();
  }
  if (p.connexion !== 'connecte') envoyePour = null;
});
