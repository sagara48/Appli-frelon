/** Mise à jour d'un appareil par Bluetooth à partir d'un paquet importé (voir dfu/smp.ts). */
import type { Device } from 'react-native-ble-plx';
import { NOM_BLE, type Paquet } from '../dfu/paquet';
import { Smp } from '../dfu/smp';
import { ble, permissions, toit } from '../sources/ble';
import { appareilPortatif } from '../sources/portatif';
import { envoyerToit } from '../sources/commandesToit';

export type Etape = { texte: string; fait: number; total: number };

async function chercher(noms: string[], delaiMs: number): Promise<Device | null> {
  const m = ble();
  return new Promise((ok) => {
    const fin = setTimeout(() => { m.stopDeviceScan(); ok(null); }, delaiMs);
    m.startDeviceScan(null, { allowDuplicates: false }, (err, d) => {
      if (err) { clearTimeout(fin); m.stopDeviceScan(); ok(null); return; }
      const n = d?.name ?? d?.localName ?? '';
      if (d && noms.includes(n)) { clearTimeout(fin); m.stopDeviceScan(); ok(d); }
    });
  });
}

async function majUn(d: Device, dejaConnecte: boolean, nom: string, img: Uint8Array, etape: (e: Etape) => void, annule: () => boolean) {
  let dev = d;
  if (!dejaConnecte) dev = await d.connect({ requestMTU: 247 });
  await ble().requestConnectionPriorityForDevice(dev.id, 1).catch(() => dev); // intervalle court : envoi plus rapide
  const smp = new Smp(dev, dev.mtu || 185);
  try {
    await smp.ouvrir();
    const avant = await smp.images().catch(() => []);
    const actuelle = avant.find((i) => i.active)?.version ?? '?';
    etape({ texte: `${nom} (version ${actuelle}) : envoi`, fait: 0, total: img.length });
    const t0 = Date.now();
    await smp.envoyer(img, (fait, total) => {
      const v = fait / Math.max(1, (Date.now() - t0) / 1000);
      etape({ texte: `${nom} : envoi, encore ${Math.max(1, Math.round((total - fait) / Math.max(v, 1) / 60))} min`, fait, total });
    }, annule);
    etape({ texte: `${nom} : installation et redémarrage`, fait: img.length, total: img.length });
    await smp.installer();
  } finally {
    smp.fermer();
    if (!dejaConnecte) await dev.cancelConnection().catch(() => {});
  }
}

/** Met à jour l'appareil du paquet. Renvoie le nombre d'appareils mis à jour. */
export async function mettreAJour(p: Paquet, etape: (e: Etape) => void, annule: () => boolean): Promise<number> {
  if (!(await permissions())) throw new Error('Autorisations Bluetooth refusées');
  const noms = NOM_BLE[p.appareil];
  // déjà connecté par l'appli ?
  const connecte = p.appareil === 'toit' ? toit.appareil : p.appareil === 'portatif' ? appareilPortatif() : null;
  if (connecte) { await majUn(connecte, true, noms[0], p.image, etape, annule); return 1; }
  if (p.appareil === 'voie') {
    // le toit met ses 4 voies en mode mise à jour (10 min, noms VOIE-xx-MAJ), puis on les fait une par une
    if (toit.connecte) await envoyerToit('maj');
    let n = 0;
    const restantes = [...noms];
    while (restantes.length && !annule()) {
      etape({ texte: `Recherche des voies (${restantes.length} restante${restantes.length > 1 ? 's' : ''})…`, fait: n, total: noms.length });
      const d = await chercher(restantes, 30000);
      if (!d) break;
      const nom = d.name ?? d.localName ?? '';
      restantes.splice(restantes.indexOf(nom), 1);
      await majUn(d, false, nom, p.image, etape, annule);
      n++;
    }
    if (!n) throw new Error('Aucune voie trouvée : connectez le toit puis relancez (les voies restent 10 min en mode mise à jour).');
    return n;
  }
  etape({ texte: `Recherche de ${noms[0]}…`, fait: 0, total: 1 });
  const d = await chercher(noms, 30000);
  if (!d) throw new Error(p.appareil === 'nacelle' ? 'Nacelle non trouvée : allumez-la en maintenant le bouton 5 s (mode mise à jour), près du téléphone.'
    : `${noms[0]} non trouvé : allumez l'appareil près du téléphone.`);
  await majUn(d, false, noms[0], p.image, etape, annule);
  return 1;
}
