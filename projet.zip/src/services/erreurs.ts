/** Erreurs de l'appli : toute erreur JavaScript non rattrapée (plantage compris) et toute promesse rejetée sans traitement
 *  vont dans le journal de mise au point. Les 30 dernières sont aussi gardées dans la base, pour être relues après un plantage. */
import { lireValeur, ecrireValeur } from '../db';
import { journaliser } from './journal';

type Erreur = { t: number; txt: string; fatale: boolean };
const CLE = 'erreurs';

const texte = (e: unknown) => {
  if (e instanceof Error) {
    const pile = (e.stack ?? '').split('\n').slice(1, 6).map((l) => l.trim()).join(' | ');
    return `${e.name}: ${e.message}${pile ? `  [${pile}]` : ''}`;
  }
  try { return typeof e === 'string' ? e : JSON.stringify(e); } catch { return String(e); }
};

/** Note une erreur dans le journal et dans la base. */
export function noterErreur(e: unknown, origine: string, fatale = false) {
  const txt = `${origine}${fatale ? ' (plantage)' : ''} : ${texte(e)}`;
  journaliser('appli', 'erreur', txt);
  try {
    const l = lireValeur<Erreur[]>(CLE) ?? [];
    ecrireValeur(CLE, [...l, { t: Date.now(), txt, fatale }].slice(-30));
  } catch {}
}

let installe = false;
/** À appeler une fois au démarrage. */
export function surveillerErreurs() {
  if (installe) return;
  installe = true;
  // erreurs de la session précédente (dont un éventuel plantage)
  const avant = lireValeur<Erreur[]>(CLE) ?? [];
  for (const e of avant.slice(-10)) journaliser('appli', 'erreur', `session précédente, ${new Date(e.t).toLocaleString('fr-FR')} : ${e.txt}`);
  if (avant.length) ecrireValeur(CLE, []);

  const g = globalThis as unknown as {
    ErrorUtils?: { getGlobalHandler: () => (e: unknown, fatal?: boolean) => void; setGlobalHandler: (f: (e: unknown, fatal?: boolean) => void) => void };
    HermesInternal?: { enablePromiseRejectionTracker?: (o: { allRejections: boolean; onUnhandled: (id: number, e: unknown) => void }) => void };
  };
  const precedent = g.ErrorUtils?.getGlobalHandler();
  g.ErrorUtils?.setGlobalHandler((e, fatal) => {
    noterErreur(e, 'Erreur', !!fatal);
    precedent?.(e, fatal);
  });
  g.HermesInternal?.enablePromiseRejectionTracker?.({ allRejections: true, onUnhandled: (_id, e) => noterErreur(e, 'Promesse rejetée') });
}
