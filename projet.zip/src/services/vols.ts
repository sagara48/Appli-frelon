/** Vols du drone : connexion au dos de l'écran de la voiture (« SOL-Frelons »), qui relaie les trames de la nacelle.
 *  Chaque vol est enregistré (trace, hauteur, niveaux des tags), gardé dans le téléphone (20 derniers) et exportable. */
import { useSyncExternalStore } from 'react';
import { LiaisonUart } from '../sources/ble';
import { ecrireValeur, lireValeur } from '../db';
import { ajouterTrame, FIN_VOL_MS, heureDeSeq, lireLigneD, nid3D, volVide, type Nid3D, type Vol } from '../calc/vol';
import { journaliser } from './journal';
import { noterEssai } from './essais';
import { store } from '../store/store';

export const NOM_SOL = 'SOL-Frelons';
const MAX_VOLS = 20;
type EtatVols = { connexion: 'arrete' | 'recherche' | 'connecte' | 'erreur'; message: string; enCours: Vol | null; vols: Vol[]; derniereMs: number; choisi: string | null };
let etat: EtatVols = { connexion: 'arrete', message: '', enCours: null, vols: [], derniereMs: 0, choisi: null };
let charge = false;
const abonnes = new Set<() => void>();
const publier = (p: Partial<EtatVols>) => { etat = { ...etat, ...p }; abonnes.forEach((f) => f()); };
function lire() {
  if (!charge) { charge = true; try { etat = { ...etat, vols: lireValeur<Vol[]>('vols') ?? [] }; } catch { /* base pas prête */ } }
  return etat;
}
export const useVols = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, lire, lire);
export const volsEnregistres = () => lire().vols;

let derSeq = -1, derT = 0;
function ranger(v: Vol) {
  if (v.points.length < 5) return; // trop court : nacelle allumée au sol
  const vols = [v, ...lire().vols.filter((x) => x.id !== v.id)].slice(0, MAX_VOLS);
  try { ecrireValeur('vols', vols); } catch { /* ignore */ }
  publier({ vols });
  store.evenement(`Vol du drone enregistré (${v.points.length} points)`);
  setTimeout(publierNids3D, 0);
}
/** Termine le vol en cours et l'enregistre. */
export function terminerVol() { const v = etat.enCours; publier({ enCours: null }); if (v) ranger(v); }

function surLigne(l: string) {
  noterEssai('D', l);
  const tr = lireLigneD(l);
  if (!tr) return;
  const now = Date.now();
  let t = now;
  if (tr.rattrapee) { if (derSeq < 0) return; t = heureDeSeq(tr.seq, derSeq, derT); }
  else { derSeq = tr.seq; derT = now; }
  let v = etat.enCours;
  if (v && !tr.rattrapee && now - v.fin > FIN_VOL_MS) { ranger(v); v = null; }
  if (!tr.fix || tr.balise) { publier({ derniereMs: now }); return; }
  if (!v) v = volVide(now, tr.alt);
  publier({ enCours: ajouterTrame(v, tr, t), derniereMs: now });
}

const liaison = new LiaisonUart('drone', () => NOM_SOL, surLigne, (connexion, message) => publier({ connexion, message }), (l) => /^[DdP],/.test(l));
export const connecterDrone = () => liaison.connecter();
export async function deconnecterDrone() { await liaison.deconnecter().catch(() => {}); terminerVol(); publier({ connexion: 'arrete', message: '' }); }
/** Nid en 3D d'un tag pour un vol (calcul ~0,2 s : gardé en mémoire). */
const cache3D = new Map<string, Nid3D | null>();
export function nid3DDe(v: Vol, tag: number): Nid3D | null {
  const k = `${v.id}:${tag}:${v.points.length}`;
  if (!cache3D.has(k)) cache3D.set(k, nid3D(v, tag));
  return cache3D.get(k) ?? null;
}
/** Nid en 3D du vol le plus récent de chaque tag → source « drone » de l'estimation unique du nid. */
function publierNids3D() {
  const vus = new Set<number>();
  for (const v of lire().vols) for (const p of v.points) for (const [id] of p.tags) {
    if (vus.has(id)) continue;
    vus.add(id);
    const e3 = nid3DDe(v, id);
    store.estimationExterne(id, 'drone', e3 ? { lat: e3.lat, lon: e3.lon, errM: Math.max(10, e3.errM), src: 'drone' } : null);
  }
}
setTimeout(() => { try { publierNids3D(); } catch { /* base pas prête */ } }, 3000);
/** Vol à montrer sur la carte (null = le plus récent qui a entendu le tag suivi). */
export const choisirVol = (id: string | null) => publier({ choisi: id });
/** Vol à montrer pour un tag : celui choisi, sinon le vol en cours ou le plus récent qui l'a entendu. */
export function volPourTag(e: EtatVols, tag: number): Vol | null {
  const tous = [...(e.enCours ? [e.enCours] : []), ...e.vols];
  if (e.choisi) return tous.find((v) => v.id === e.choisi) ?? null;
  return tous.find((v) => v.points.some((p) => p.tags.some(([id]) => id === tag))) ?? null;
}
export function supprimerVol(id: string) { const vols = lire().vols.filter((v) => v.id !== id); try { ecrireValeur('vols', vols); } catch { /* ignore */ } publier({ vols }); }

// un vol en cours sans nouvelle trame depuis 2 min est rangé
setInterval(() => { if (etat.enCours && Date.now() - etat.derniereMs > FIN_VOL_MS) { journaliser('drone', 'etat', 'Fin du vol (plus de trame depuis 2 min)'); terminerVol(); } }, 15000);

/** Essai sans matériel : un vol simulé de 3 min au-dessus du nid du tag 7 (sortie simulée). */
export function volSimule() {
  const NID = { lat: 45.0483716, lon: 3.8839642 }, t0 = Date.now() - 180000;
  let v = volVide(t0, 600);
  for (let i = 0; i < 360; i++) {
    const a = (i / 360) * 4 * Math.PI, r = 0.0015 * (1 - i / 400);
    const lat = NID.lat + r * Math.cos(a), lon = NID.lon + r * 1.4 * Math.sin(a);
    const d = Math.hypot((lat - NID.lat) * 111000, (lon - NID.lon) * 78000);
    const rssi = Math.round(-55 - 20 * Math.log10(Math.max(d, 10) / 10) + (i % 7) - 3);
    const tags: [number, number][] = rssi > -102 ? [[7, rssi]] : [];
    v = ajouterTrame(v, { rattrapee: false, seq: i, lat, lon, alt: 600 + (i < 20 ? i * 1.5 : 30), fix: true, balise: false, sats: 12, batt: 100, tags }, t0 + i * 500);
  }
  ranger(v);
}
