/** Commandes vocales mains libres (expo-speech-recognition, Android) : le micro écoute en continu tant qu'il est
 *  allumé (bouton micro sur Chrono et Portatif), chaque phrase est analysée par calc/voix.ts et l'appli répond à voix
 *  haute. Reconnaissance sur le téléphone quand Android le permet (hors réseau), sinon par le service Google.
 *  Le micro est coupé pendant que l'appli parle (sinon elle s'entendrait), et après 10 min sans commande.
 *  Rien sur le web. */
import { useSyncExternalStore } from 'react';
import { Platform } from 'react-native';
import { router } from 'expo-router';
import * as Speech from 'expo-speech';
import { analyserPhrase, cardinalParle, phraseNid, PHRASES, type CommandeVoix } from '../calc/voix';
import { capDeg, distM, pointCardinal } from '../calc/geo';
import { appatActif } from '../calc/appat';
import { chronoLacher, chronoManuel, ecouterLignes, store } from '../store/store';
import { cmdPortatif } from '../proto/portatif';
import { envoyerPortatif } from '../sources/portatif';
import { envoyerOrdre, relaisOrdre } from './ordres';
import { param } from './parametres';
import { vibrer } from './sons';
import { marquerAuto } from './essaisTerrain';
import { retourVoiture, voitureGaree } from './voiture';

type M = typeof import('expo-speech-recognition');
let mod: M | null | undefined;
const reco = (): M | null => {
  if (Platform.OS === 'web') return null;
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  if (mod === undefined) { try { mod = require('expo-speech-recognition') as M; } catch { mod = null; } }
  return mod;
};
export const voixDisponible = () => !!reco();

type EtatVoix = { actif: boolean; ecoute: boolean; entendu: string; reponse: string; erreur: string };
let ev: EtatVoix = { actif: false, ecoute: false, entendu: '', reponse: '', erreur: '' };
const abonnes = new Set<() => void>();
const publier = (p: Partial<EtatVoix>) => {
  const micro = ev.actif;
  ev = { ...ev, ...p }; abonnes.forEach((f) => f());
  if (micro !== ev.actif) { try { (require('../widget/majWidget') as typeof import('../widget/majWidget')).majWidgetSortie(); } catch { /* ignore */ } } // eslint-disable-line @typescript-eslint/no-require-imports
};
export const etatVoix = () => ev;
export const useVoix = () => useSyncExternalStore((f) => { abonnes.add(f); return () => { abonnes.delete(f); }; }, () => ev, () => ev);

let branche = false, dernierUsage = 0, parle = false, relance: ReturnType<typeof setTimeout> | null = null;

/** Réponse parlée (toujours, même si les annonces vocales des alertes sont coupées : on vient de la demander). */
function repondre(texte: string) {
  publier({ reponse: texte });
  const m = reco();
  parle = true;
  try { m?.ExpoSpeechRecognitionModule.abort(); } catch { /* ignore */ }
  const fin = () => { parle = false; if (ev.actif) relancer(300); };
  try { Speech.speak(texte, { language: 'fr-FR', rate: 1.05, onDone: fin, onStopped: fin, onError: fin }); } catch { fin(); }
}

function relancer(ms: number) {
  if (relance) clearTimeout(relance);
  relance = setTimeout(() => { relance = null; demarrerEcoute(); }, ms);
}

function demarrerEcoute() {
  const m = reco();
  if (!m || !ev.actif || parle) return;
  if (Date.now() - dernierUsage > 10 * 60000) { arreterVoix('Micro coupé après 10 min sans commande'); return; }
  try {
    m.ExpoSpeechRecognitionModule.start({
      lang: 'fr-FR', interimResults: false, continuous: true, maxAlternatives: 3,
      requiresOnDeviceRecognition: m.ExpoSpeechRecognitionModule.supportsOnDeviceRecognition(),
      androidIntentOptions: { EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS: 1200, EXTRA_LANGUAGE_MODEL: 'web_search' },
      contextualStrings: ['parti', 'revenu', 'lâcher ici', 'nid trouvé', 'mode recherche', 'fin de recherche', 'fais un tour', 'où est le nid', 'signal', 'tag', 'frelon'],
    });
  } catch (e) { publier({ erreur: String(e) }); }
}

function brancher(m: M) {
  if (branche) return;
  branche = true;
  const R = m.ExpoSpeechRecognitionModule;
  R.addListener('start', () => publier({ ecoute: true, erreur: '' }));
  R.addListener('end', () => { publier({ ecoute: false }); if (ev.actif && !parle) relancer(400); });
  R.addListener('error', (e: { error: string; message: string }) => {
    // « no-speech » et « aborted » sont normaux en écoute continue
    if (e.error !== 'no-speech' && e.error !== 'aborted' && e.error !== 'speech-timeout') publier({ erreur: e.message || e.error });
    if (e.error === 'not-allowed') arreterVoix('Micro refusé : autorisez-le dans les réglages Android');
  });
  R.addListener('result', (e: { isFinal: boolean; results: { transcript: string }[] }) => {
    if (!e.isFinal || parle) return;
    for (const r of e.results) {
      const c = analyserPhrase(r.transcript, param().voixMotCle);
      if (c) { publier({ entendu: r.transcript }); dernierUsage = Date.now(); executer(c); return; }
    }
    publier({ entendu: e.results[0]?.transcript ?? '' });
  });
}

export async function demarrerVoix(): Promise<boolean> {
  const m = reco();
  if (!m) { publier({ erreur: 'Commandes vocales : seulement dans l\'appli Android' }); return false; }
  const p = await m.ExpoSpeechRecognitionModule.requestPermissionsAsync().catch(() => ({ granted: false }));
  if (!p.granted) { publier({ erreur: 'Micro refusé' }); return false; }
  if (!m.ExpoSpeechRecognitionModule.isRecognitionAvailable()) { publier({ erreur: 'Reconnaissance vocale absente : installer l\'appli Google' }); return false; }
  brancher(m);
  dernierUsage = Date.now();
  publier({ actif: true, erreur: '', reponse: '' });
  repondre(param().voixMotCle ? 'Je vous écoute. Dites frelon, puis la commande.' : 'Je vous écoute.');
  return true;
}

export function arreterVoix(raison = '') {
  if (relance) { clearTimeout(relance); relance = null; }
  publier({ actif: false, ecoute: false, reponse: raison || ev.reponse });
  try { reco()?.ExpoSpeechRecognitionModule.abort(); } catch { /* ignore */ }
}
export const basculerVoix = () => (ev.actif ? arreterVoix() : void demarrerVoix());

/* ---------- exécution ---------- */
function tagCourant(): number | null {
  const e = store.get();
  if (e.tagChoisi !== null) return e.tagChoisi;
  const st = e.portatif.st;
  if (st && st.tag >= 0) return st.tag;
  const ids = Object.keys(e.tags).map(Number);
  return ids.length ? ids[0] : null;
}
const portatifPret = () => { const p = store.get().portatif; return p.connexion === 'connecte'; };

export function executer(c: CommandeVoix) {
  const e = store.get(), tag = tagCourant(), pst = e.portatif.connexion === 'connecte' ? e.portatif.st : null;
  vibrer();
  if (ev.actif) marquerAuto('voix');
  switch (c.cmd) {
    case 'stop': arreterVoix(); Speech.speak('Micro coupé', { language: 'fr-FR' }); return;
    case 'aide': repondre(`Vous pouvez dire : ${PHRASES.map(([p]) => p.replace(/[«»]/g, '')).join(', ')}.`); return;
    case 'tag':
      store.choisirTag(c.tag);
      if (portatifPret()) envoyerPortatif(cmdPortatif.tag(c.tag)).catch(() => {});
      repondre(`Tag ${c.tag}`); return;
    case 'parti': case 'revenu': {
      if (tag === null) { repondre('Choisissez d\'abord le tag'); return; }
      const a = appatActif(e.chrono, tag);
      if (!a) { repondre('Pas d\'appât ouvert pour ce tag. Dites lâcher ici.'); return; }
      chronoManuel(tag, c.cmd, pst ? Math.round(pst.hdg) : null);
      const apres = appatActif(store.get().chrono, tag);
      repondre(c.cmd === 'parti' ? `Parti${pst ? `, cap ${Math.round(pst.hdg)}` : ''}` : `Revenu${apres && apres.trajets.length ? `, ${apres.trajets.length} aller-retour${apres.trajets.length > 1 ? 's' : ''}` : ''}`);
      return;
    }
    case 'lacher': {
      if (tag === null) { repondre('Choisissez d\'abord le tag'); return; }
      const pos = e.toit && e.toit.lat ? { lat: e.toit.lat, lon: e.toit.lon, src: 'voiture' as const } : pst && pst.fix ? { lat: pst.lat, lon: pst.lon, src: 'main' as const } : null;
      if (!pos) { repondre('Pas de position'); return; }
      chronoLacher(tag, pos.lat, pos.lon, pos.src);
      repondre(`Appât ouvert pour le tag ${tag}`); return;
    }
    case 'nid':
      try { router.push('/nid-ici'); } catch { /* appli pas prête */ }
      repondre('Nid : je prends la position'); return;
    case 'recherche': case 'finRecherche':
      if (tag === null) { repondre('Choisissez d\'abord le tag'); return; }
      if (!relaisOrdre()) { repondre('Connectez le portatif ou le toit'); return; }
      envoyerOrdre(tag, c.cmd === 'recherche' ? 'rech' : 'fin').catch(() => {});
      repondre(c.cmd === 'recherche' ? `Mode recherche demandé au tag ${tag}` : 'Fin de recherche demandée'); return;
    case 'tour':
      if (!portatifPret()) { repondre('Portatif non connecté'); return; }
      envoyerPortatif(cmdPortatif.sweep()).catch(() => {});
      repondre('Tournez lentement sur vous-même, antenne à l\'horizontale'); return;
    case 'point':
      if (!portatifPret()) { repondre('Portatif non connecté'); return; }
      if (!e.portatif.sw?.ok) { repondre('Faites d\'abord un tour'); return; }
      envoyerPortatif(cmdPortatif.fix()).catch(() => {});
      repondre('Point ajouté'); return;
    case 'carte':
      if (!portatifPret()) { repondre('Portatif non connecté'); return; }
      envoyerPortatif(cmdPortatif.carte()).catch(() => {});
      repondre('Carte sur le portatif'); return;
    case 'voiture': {
      const v = voitureGaree();
      if (!v) { repondre('Voiture pas encore notée'); return; }
      retourVoiture().catch(() => {});
      const ici = pst && pst.fix ? pst : e.telephone;
      if (!ici) { repondre('Flèche vers la voiture sur le portatif'); return; }
      const cap = capDeg(ici.lat, ici.lon, v.lat, v.lon), d = distM(ici.lat, ici.lon, v.lat, v.lon);
      repondre(`Voiture à ${d < 1000 ? `${Math.round(d / 10) * 10} mètres` : `${(d / 1000).toFixed(1).replace('.', ',')} kilomètres`}, ${cardinalParle(pointCardinal(cap))}`);
      return;
    }
    case 'ouNid': {
      const f = tag !== null ? e.tags[tag]?.fusion : null;
      const ici = pst && pst.fix ? { lat: pst.lat, lon: pst.lon } : e.toit && e.toit.lat ? { lat: e.toit.lat, lon: e.toit.lon } : e.telephone ? { lat: e.telephone.lat, lon: e.telephone.lon } : null;
      if (!f?.ok) { repondre('Pas encore de nid estimé pour ce tag'); return; }
      if (!ici) { repondre('Pas de position'); return; }
      const cap = capDeg(ici.lat, ici.lon, f.lat, f.lon);
      repondre(phraseNid(distM(ici.lat, ici.lon, f.lat, f.lon), cap, f.errM, pointCardinal(cap)));
      return;
    }
    case 'signal': {
      if (!pst || pst.tag < 0) { repondre('Le portatif ne suit aucun tag'); return; }
      if (pst.age > 10) { repondre(`Tag ${pst.tag} : pas entendu depuis ${Math.round(pst.age)} secondes`); return; }
      repondre(`Moins ${Math.abs(Math.round(pst.rssi))}, ${pst.trend > 0.4 ? 'ça se rapproche' : pst.trend < -0.4 ? 'ça s\'éloigne' : 'stable'}`);
      return;
    }
  }
}

/* résultat d'un tour sur soi-même : annoncé quand le micro est allumé (on a les mains prises) */
ecouterLignes((src, ligne) => {
  if (src !== 'P' || !ev.actif || !ligne.includes('"tour"')) return;
  try {
    const o = JSON.parse(ligne) as { type: string; brg: number; ctr: number };
    if (o.type !== 'tour') return;
    repondre(o.ctr < 4 ? 'Direction peu nette : changez de place' : `Direction ${Math.round(o.brg)}, ${cardinalParle(pointCardinal(o.brg))}`);
  } catch { /* ignore */ }
});
