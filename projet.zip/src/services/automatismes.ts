/** Automatismes de terrain (chacun se coupe dans Paramètres → Automatismes) :
 *  - voiture → pied : voiture arrêtée à moins de 200 m du nid estimé du tag suivi → flèche envoyée au portatif (dès
 *    qu'il est connecté), le portatif suit ce tag, onglet Portatif ouvert ;
 *  - mode recherche du tag (firmware 7) : demandé quand on approche du nid, renouvelé tant qu'on cherche, arrêté
 *    quand le nid est noté ;
 *  - « Nid trouvé ici ? » : portatif qui reçoit le tag très fort, et vous immobile depuis 20 s ;
 *  - fin de vie du tag : le contrôle par le tag conclut « nid mort » → noter le contrôle, désactiver le tag.
 *  Vérification toutes les 2 s. */
import { Alert, AppState } from 'react-native';
import { router } from 'expo-router';
import { ecouterLignes, store, type Etat } from '../store/store';
import { ficheTag, majTag, nouveauNid } from './carnet';
import { distM } from '../calc/geo';
import { controleTraitement } from '../calc/activite';
import { interventionsDe } from '../calc/intervention';
import { cmdPortatif, parsePortatif } from '../proto/portatif';
import { envoyerPortatif } from '../sources/portatif';
import { idTag } from '../ui/theme';
import { ecrireValeur, lireValeur } from '../db';
import { param } from './parametres';
import { envoyerOrdre, etatOrdres, relaisOrdre } from './ordres';
import { lireEtalonnagesTags } from './etalonnage';
import { annoncer, vibrer } from './sons';

const PIED_M = 200, RECH_M = 150, VITESSE_ARRET = 3;
const portatifPret = (e: Etat) => e.portatif.connexion === 'connecte' && e.portatif.source === 'ble';
const bandeau = (texte: string, voix?: string) => { store.set({ bandeau: { texte, grave: false, ms: Date.now() } }); vibrer(false); if (voix) annoncer(voix); };
const nidNote = (e: Etat, tag: number) => e.nids.some((n) => n.tag === tag && ['trouve', 'traite', 'mort'].includes(n.etat));
/** Position à pied : GPS du portatif, sinon du téléphone (jamais celle de la voiture garée plus loin). */
function positionPied(e: Etat): { lat: number; lon: number; err: number } | null {
  const st = e.portatif.st;
  if (portatifPret(e) && st && st.fix) return { lat: st.lat, lon: st.lon, err: 8 };
  const t = e.telephone;
  if (t && Date.now() - t.recuMs < 30000) return { lat: t.lat, lon: t.lon, err: Math.max(5, t.precision) };
  return null;
}

/* ---------- voiture → pied ---------- */
let arretDepuis = 0;
const pietonDeja = new Map<number, number>(); // tag → heure du dernier passage à pied proposé
let cibleEnAttente: { tag: number; lat: number; lon: number } | null = null;
function voiturePied(e: Etat) {
  if (cibleEnAttente && portatifPret(e)) { // portatif allumé après l'arrêt : on lui envoie la flèche maintenant
    const c = cibleEnAttente; cibleEnAttente = null;
    envoyerFleche(c.tag, c.lat, c.lon);
  }
  if (!param().autoPied || e.source !== 'toit' || e.connexion !== 'connecte' || !e.toit || !e.toit.lat) { arretDepuis = 0; return; }
  const id = e.tagChoisi, f = id !== null ? e.tags[id]?.fusion : null;
  if (id === null || !f?.ok || nidNote(e, id)) { arretDepuis = 0; return; }
  const d = distM(e.toit.lat, e.toit.lon, f.lat, f.lon);
  if (d > PIED_M || e.toit.vitesse > VITESSE_ARRET) { arretDepuis = 0; return; }
  if (!arretDepuis) { arretDepuis = Date.now(); return; }
  if (Date.now() - arretDepuis < 15000 || Date.now() - (pietonDeja.get(id) ?? 0) < 30 * 60000) return;
  pietonDeja.set(id, Date.now());
  bandeau(`Nid du tag ${idTag(id)} à ${Math.round(d)} m : continuez à pied${portatifPret(e) ? ', la flèche est sur le portatif' : ' (allumez le portatif : la flèche lui sera envoyée)'}`, `Nid à ${Math.round(d)} mètres, continuez à pied`);
  if (portatifPret(e)) envoyerFleche(id, f.lat, f.lon);
  else cibleEnAttente = { tag: id, lat: f.lat, lon: f.lon };
  if (param().autoRecherche) demanderRecherche(id);
  try { router.navigate('/portatif'); } catch { /* écran pas prêt */ }
}
function envoyerFleche(tag: number, lat: number, lon: number) {
  (async () => {
    await envoyerPortatif(cmdPortatif.tag(tag));
    await envoyerPortatif(cmdPortatif.cible(lat, lon, `Nid tag ${idTag(tag)}`));
    store.portatif({ cible: `Nid tag ${idTag(tag)}` });
    store.evenement(`Portatif : flèche vers le nid du tag ${idTag(tag)} (automatique)`);
  })().catch(() => {});
}

/* ---------- mode recherche automatique ---------- */
const echecs = new Map<number, number>();
const finEnvoyee = new Set<number>();
function demanderRecherche(tag: number) {
  const o = etatOrdres(), s = o.suivis[tag];
  if (s?.etat === 'envoi' || (echecs.get(tag) ?? 0) >= 2 || !relaisOrdre()) return;
  if ((o.rechJusqua[tag] ?? 0) - Date.now() > 60000) return; // encore plus d'une minute de recherche
  envoyerOrdre(tag, 'rech').catch(() => {});
}
function rechercheAuto(e: Etat) {
  if (!param().autoRecherche) return;
  const o = etatOrdres();
  // échecs (tag ancien, trop loin) : on n'insiste pas plus de deux fois
  for (const [k, s] of Object.entries(o.suivis)) if (s.ordre === 'rech' && s.etat === 'echec' && s.t !== dernierEchecVu.get(Number(k))) { dernierEchecVu.set(Number(k), s.t); echecs.set(Number(k), (echecs.get(Number(k)) ?? 0) + 1); }
  // nid noté : fin du mode recherche (une fois)
  for (const k of Object.keys(o.rechJusqua)) {
    const id = Number(k);
    if (o.rechJusqua[id] > Date.now() && nidNote(e, id) && !finEnvoyee.has(id) && relaisOrdre()) { finEnvoyee.add(id); envoyerOrdre(id, 'fin').catch(() => {}); }
  }
  // portatif qui suit un tag près de son nid estimé, ou qui l'entend déjà bien
  const st = portatifPret(e) ? e.portatif.st : null;
  if (!st || st.tag < 0 || nidNote(e, st.tag)) return;
  const f = e.tags[st.tag]?.fusion, pos = positionPied(e);
  const pres = (st.age < 3 && st.rssi > -80) || (!!f?.ok && !!pos && distM(pos.lat, pos.lon, f.lat, f.lon) < RECH_M);
  if (pres) demanderRecherche(st.tag);
}
const dernierEchecVu = new Map<number, number>();

/* ---------- « Nid trouvé ici ? » ---------- */
const fort: { t: number; v: boolean }[] = [];
const positions: { t: number; lat: number; lon: number }[] = [];
const proposeA = new Map<number, number>();
let questionOuverte = false;
function nidIci(e: Etat) {
  if (!param().autoNidIci || questionOuverte || AppState.currentState !== 'active') return;
  const st = portatifPret(e) ? e.portatif.st : null, pos = positionPied(e);
  if (!st || st.tag < 0 || !pos) { fort.length = 0; positions.length = 0; return; }
  const now = Date.now();
  const p1m = lireEtalonnagesTags()[st.tag]?.p1m ?? param().distRefPortatif;
  fort.push({ t: now, v: st.age < 3 && st.rssi >= p1m - 18 }); // environ 5 m ou moins
  positions.push({ t: now, lat: pos.lat, lon: pos.lon });
  while (fort.length && now - fort[0].t > 20000) fort.shift();
  while (positions.length && now - positions[0].t > 20000) positions.shift();
  if (fort.length < 8 || fort.filter((x) => x.v).length < fort.length * 0.8 || now - fort[0].t < 15000) return;
  const immobile = positions.every((p) => distM(p.lat, p.lon, pos.lat, pos.lon) < 8);
  if (!immobile || now - (proposeA.get(st.tag) ?? 0) < 10 * 60000) return;
  if (e.nids.some((n) => n.tag === st.tag && distM(n.lat, n.lon, pos.lat, pos.lon) < 50)) return; // déjà noté ici
  proposeA.set(st.tag, now); questionOuverte = true;
  const tag = st.tag;
  vibrer(false); annoncer('Nid trouvé ici ?');
  Alert.alert(`Nid du tag ${idTag(tag)} ici ?`, 'Le portatif reçoit le tag très fort et vous ne bougez plus depuis 20 secondes. Le nid est-il en vue ?', [
    { text: 'Pas encore', style: 'cancel', onPress: () => { questionOuverte = false; } },
    { text: 'Oui, noter le nid', onPress: () => {
      questionOuverte = false;
      const id = nouveauNid(tag, pos.lat, pos.lon, Math.round(pos.err), 'portatif (proposé automatiquement)');
      if (id) { store.evenement(`Nid du tag ${idTag(tag)} noté sur place`); router.push({ pathname: '/nid/[id]', params: { id: String(id) } }); }
    } },
  ], { cancelable: true, onDismiss: () => { questionOuverte = false; } });
}

/* ---------- recharge notée par le chargeur ---------- */
/** Un tag posé sur le chargeur se signale (trames « chargeur », entendues par le portatif) : il est rechargé,
 *  donc revenu en main : noté rechargé et disponible, pile et firmware relevés. */
ecouterLignes((src, ligne) => {
  if (src !== 'P') return;
  const l = parsePortatif(ligne);
  if (!l || l.type !== 'chg' || l.tag <= 0) return;
  const t = l.utc > 1600000000 && l.utc * 1000 <= Date.now() + 60000 ? l.utc * 1000 : Date.now();
  const f = ficheTag(l.tag);
  if (f.recharge_ms && Math.abs(f.recharge_ms - t) < 30 * 60000) return; // même séance de charge
  majTag(l.tag, { recharge_ms: t, pile: l.batt, pile_ms: t, ...(f.etat === 'perdu' || f.etat === 'recupere' || f.etat === 'pose' ? { etat: 'dispo' as const, pose_ms: null, appat: null } : {}) });
  store.evenement(`Tag ${idTag(l.tag)} posé sur le chargeur : noté rechargé${l.fw ? ` (firmware ${l.fw})` : ''}`);
});

/* ---------- fin de vie du tag ---------- */
type Fin = { faits: number[]; plusTard: Record<number, number>; offEnAttente: number[] };
const lireFin = (): Fin => { try { return { faits: [], plusTard: {}, offEnAttente: [], ...(lireValeur<Fin>('finTags') ?? {}) }; } catch { return { faits: [], plusTard: {}, offEnAttente: [] }; } };
const ecrireFin = (f: Fin) => { try { ecrireValeur('finTags', f); } catch { /* ignore */ } };
let derniereFin = 0;
function finDeVie(e: Etat) {
  const F = lireFin();
  // désactivation demandée quand aucun relais n'était là : envoyée dès que le tag est entendu par un relais
  for (const tag of F.offEnAttente) {
    const entendu = (e.tags[tag] && Date.now() - e.tags[tag].dernierMs < 60000) || (portatifPret(e) && (e.portatif.st?.tag === tag || !!e.portatif.autres[tag]));
    const s = etatOrdres().suivis[tag];
    if (s?.ordre === 'off' && s.etat === 'ok') { ecrireFin({ ...F, offEnAttente: F.offEnAttente.filter((x) => x !== tag) }); continue; }
    if (entendu && relaisOrdre() && s?.etat !== 'envoi') envoyerOrdre(tag, 'off').catch(() => {});
  }
  if (!param().autoFinTag || AppState.currentState !== 'active' || questionOuverte || Date.now() - derniereFin < 60000) return;
  derniereFin = Date.now();
  for (const n of e.nids) {
    if (n.tag <= 0 || n.etat !== 'traite' || !e.activites[n.tag] || F.faits.includes(n.id) || Date.now() < (F.plusTard[n.id] ?? 0)) continue;
    const tT = [...interventionsDe(n)].reverse().find((x) => x.type === 'destruction' || x.type === 'retraitement')?.t ?? n.traite_ms;
    if (!tT) continue;
    const c = controleTraitement(e.activites[n.tag], tT, Date.now());
    if (c.verdict !== 'mort') continue;
    questionOuverte = true;
    const fini = (off: boolean) => {
      questionOuverte = false;
      const f = lireFin();
      ecrireFin({ ...f, faits: [...f.faits, n.id], offEnAttente: off && !f.offEnAttente.includes(n.tag) ? [...f.offEnAttente, n.tag] : f.offEnAttente });
      router.push({ pathname: '/intervention', params: { nid: String(n.id), type: 'controle', resultat: 'mort' } });
    };
    Alert.alert(`Nid du tag ${idTag(n.tag)} : probablement mort`, `${c.texte}\n\nNoter le contrôle (registre) et désactiver le tag ? Le tag ne se rallume que sur le chargeur ; s'il n'est pas à portée, il sera désactivé dès qu'un récepteur l'entendra.`, [
      { text: 'Plus tard', style: 'cancel', onPress: () => { questionOuverte = false; const f = lireFin(); ecrireFin({ ...f, plusTard: { ...f.plusTard, [n.id]: Date.now() + 6 * 3600000 } }); } },
      { text: 'Noter seulement', onPress: () => fini(false) },
      { text: 'Noter + désactiver', onPress: () => fini(true) },
    ], { cancelable: true, onDismiss: () => { questionOuverte = false; } });
    return;
  }
}

setInterval(() => {
  const e = store.get();
  if (e.source === 'simulation') return;
  try { voiturePied(e); rechercheAuto(e); nidIci(e); finDeVie(e); } catch { /* jamais bloquant */ }
}, 2000);
