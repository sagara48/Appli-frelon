/** Comptes de l'équipe (Supabase Auth, par son API REST : pas de bibliothèque).
 *  Connexion facultative : l'appli marche sans compte ; le compte sert au partage entre téléphones.
 *  La session (jetons) est gardée dans la base locale ; le jeton est rafraîchi tout seul avant d'expirer,
 *  dès qu'il y a du réseau. Hors réseau, on reste connecté. */
import { useSyncExternalStore } from 'react';
import { ecrireValeur, lireValeur } from '../db';
import { journaliser } from './journal';

/** Serveur Supabase de l'équipe : adresse du projet et clé publique (anon). */
export type Serveur = { url: string; cle: string };
export type Utilisateur = { id: string; email: string; nom: string };
export type Session = { acces: string; rafraichir: string; expireMs: number; utilisateur: Utilisateur };

const CLE_SERVEUR = 'serveur', CLE_SESSION = 'session';
/** Serveur de l'équipe intégré à l'appli (clé publique : sans danger, la base est protégée par les comptes). Modifiable dans l'écran Partage. */
export const SERVEUR_DEFAUT: Serveur = { url: 'https://rckdxsjgszypliytpwmw.supabase.co', cle: 'sb_publishable_FCV40taeEgQ9GfgxFqMpZA_iVbw2VHI' };

export const lireServeur = (): Serveur => {
  const s = lireValeur<Serveur>(CLE_SERVEUR);
  if (s && serveurComplet(s)) return s;
  const ancien = lireValeur<{ url?: string; cle?: string }>('partage'); // réglage de l'ancien écran Partage
  if (ancien?.url && ancien?.cle) return { url: ancien.url, cle: ancien.cle };
  return SERVEUR_DEFAUT;
};
export const serveurComplet = (s: Serveur) => /^https?:\/\/.+/.test(s.url.trim()) && s.cle.trim().length > 20;
export function enregistrerServeur(s: Serveur) { ecrireValeur(CLE_SERVEUR, { url: s.url.trim().replace(/\/+$/, ''), cle: s.cle.trim() }); prevenir(); }

let session: Session | null | undefined;
const abonnes = new Set<() => void>();
const prevenir = () => abonnes.forEach((f) => f());
export const sessionActuelle = (): Session | null => {
  if (session === undefined) { try { session = lireValeur<Session>(CLE_SESSION); } catch { session = null; } }
  return session ?? null;
};
export const abonnerSession = (f: () => void) => { abonnes.add(f); return () => { abonnes.delete(f); }; };
export const useSession = () => useSyncExternalStore(abonnerSession, sessionActuelle, sessionActuelle);
function garder(s: Session | null) { session = s; ecrireValeur(CLE_SESSION, s); prevenir(); }

/** Message lisible en français pour les erreurs les plus courantes de Supabase Auth. */
export function messageErreur(statut: number, j: Record<string, unknown> | null): string {
  const code = String(j?.error_code ?? j?.code ?? j?.error ?? '');
  const brut = String(j?.msg ?? j?.error_description ?? j?.message ?? '');
  if (/invalid_credentials|invalid_grant/.test(code) || /invalid login/i.test(brut)) return 'E-mail ou mot de passe incorrect.';
  if (/email_not_confirmed/.test(code) || /not confirmed/i.test(brut)) return 'Adresse e-mail pas encore confirmée : ouvrez le lien reçu par e-mail, puis reconnectez-vous.';
  if (/user_already_exists|email_exists/.test(code) || /already registered/i.test(brut)) return 'Un compte existe déjà avec cette adresse : connectez-vous.';
  if (/weak_password/.test(code) || /password should/i.test(brut)) return 'Mot de passe trop faible : 6 caractères au moins.';
  if (/over_email_send_rate_limit|over_request_rate_limit/.test(code) || statut === 429) return 'Trop d\'essais rapprochés : réessayez dans une minute.';
  if (/validation_failed/.test(code) || /invalid format|unable to validate email/i.test(brut)) return 'Adresse e-mail invalide.';
  if (statut === 401 || /invalid api key/i.test(brut)) return 'Clé du serveur refusée : vérifiez la clé « anon public » dans les réglages du serveur.';
  return brut || `Erreur ${statut}`;
}

async function appel(chemin: string, corps: unknown, jeton?: string): Promise<Record<string, unknown>> {
  const s = lireServeur();
  if (!serveurComplet(s)) throw new Error('Réglez d\'abord le serveur de l\'équipe (adresse et clé).');
  let r: Response;
  try {
    r = await fetch(`${s.url}/auth/v1/${chemin}`, {
      method: 'POST',
      headers: { apikey: s.cle, 'Content-Type': 'application/json', ...(jeton ? { Authorization: `Bearer ${jeton}` } : {}) },
      body: JSON.stringify(corps),
    });
  } catch { throw new Error('Pas de réseau : réessayez quand le téléphone est connecté.'); }
  let j: Record<string, unknown> | null = null;
  try { const t = await r.text(); j = t ? (JSON.parse(t) as Record<string, unknown>) : {}; } catch {}
  if (!r.ok) throw new Error(messageErreur(r.status, j));
  return j ?? {};
}

type ReponseJeton = { access_token: string; refresh_token: string; expires_in: number; user: { id: string; email: string; user_metadata?: { nom?: string } } };
function versSession(j: Record<string, unknown>): Session {
  const r = j as unknown as ReponseJeton;
  return {
    acces: r.access_token, rafraichir: r.refresh_token, expireMs: Date.now() + (r.expires_in ?? 3600) * 1000,
    utilisateur: { id: r.user.id, email: r.user.email, nom: r.user.user_metadata?.nom ?? '' },
  };
}

export async function seConnecter(email: string, motDePasse: string): Promise<Session> {
  const s = versSession(await appel('token?grant_type=password', { email: email.trim().toLowerCase(), password: motDePasse }));
  garder(s);
  journaliser('partage', 'etat', `Connecté : ${s.utilisateur.email}`);
  return s;
}

/** Inscription. Renvoie la session si le serveur connecte tout de suite, null s'il faut d'abord confirmer l'e-mail. */
export async function creerCompte(email: string, motDePasse: string, nom: string): Promise<Session | null> {
  const j = await appel('signup', { email: email.trim().toLowerCase(), password: motDePasse, data: { nom: nom.trim() } });
  if (j.access_token) { const s = versSession(j); garder(s); return s; }
  return null; // confirmation par e-mail demandée par le serveur
}

export const motDePasseOublie = (email: string) => appel('recover', { email: email.trim().toLowerCase() }).then(() => undefined);

export async function seDeconnecter() {
  const s = sessionActuelle();
  garder(null);
  if (s) appel('logout', {}, s.acces).catch(() => {}); // sans réseau, la session expirera seule côté serveur
  journaliser('partage', 'etat', 'Déconnecté');
}

let enRafraichissement: Promise<Session | null> | null = null;
/** Jeton d'accès valide (rafraîchi s'il expire dans moins de 2 min). null si pas connecté.
 *  Une session refusée par le serveur (compte supprimé, mot de passe changé) déconnecte. */
export async function jetonValide(): Promise<string | null> {
  const s = sessionActuelle();
  if (!s) return null;
  if (s.expireMs - Date.now() > 120000) return s.acces;
  if (!enRafraichissement) {
    enRafraichissement = appel('token?grant_type=refresh_token', { refresh_token: s.rafraichir })
      .then((j) => { const n = versSession(j); garder({ ...n, utilisateur: { ...n.utilisateur, nom: n.utilisateur.nom || s.utilisateur.nom } }); return sessionActuelle(); })
      .catch((e: Error) => {
        if (/réseau/.test(e.message)) return s; // hors ligne : on garde l'ancienne session
        journaliser('partage', 'erreur', `Session expirée : ${e.message}`);
        garder(null);
        return null;
      })
      .finally(() => { enRafraichissement = null; });
  }
  const n = await enRafraichissement;
  return n && n.expireMs > Date.now() ? n.acces : null;
}
