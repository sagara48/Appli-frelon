/** Météo du matin : à chaque ouverture de l'appli (et toutes les 3 h tant qu'elle est ouverte), la prévision des 4 jours
 *  est relue et une notification est programmée à l'heure choisie (7 h par défaut) pour chaque jour où un bon créneau
 *  est annoncé (au moins 2 h d'activité moyenne ou forte entre 8 h et 19 h). Les notifications déjà programmées sont
 *  remplacées à chaque relecture : la dernière prévision fait foi. Se coupe dans Paramètres → Météo d'activité. */
import { AppState, Platform } from 'react-native';
import { ecrireValeur } from '../db';
import { programmerFamille } from './notifs';
import { meilleurePosition, store } from '../store/store';
import { chargerMeteo, type Creneau, type Meteo } from './meteo';
import { param } from './parametres';

let dernier = 0;

/** Position de référence : la position actuelle, sinon le premier rucher, sinon le dernier nid noté. */
function position(): { lat: number; lon: number } | null {
  const p = meilleurePosition();
  if (p) return p;
  const e = store.get();
  const r = e.ruchers.find((x) => x.lat && x.lon);
  if (r) return { lat: r.lat, lon: r.lon };
  const n = [...e.nids].sort((a, b) => b.t - a.t)[0];
  return n ? { lat: n.lat, lon: n.lon } : null;
}

/** Heure de la notification d'un jour (AAAA-MM-JJ), ou null si elle est déjà passée. */
export function heureNotif(date: string, heure: number, maintenant: number): number | null {
  const [a, m, j] = date.split('-').map(Number);
  const t = new Date(a, m - 1, j, Math.floor(heure), Math.round((heure % 1) * 60)).getTime();
  return t > maintenant + 60000 ? t : null;
}
export const texteCreneau = (c: Creneau) => `Bon créneau pour les frelons : ${c.debut} h – ${c.fin} h, ${c.temp} °C, vent ${c.vent} km/h.`;

async function programmer(m: Meteo) {
  const l = param().meteoMatin ? (m.creneaux ?? []).map((c) => ({ t: heureNotif(c.date, param().meteoHeure, Date.now()), c })).filter((x) => x.t !== null) : [];
  await programmerFamille('meteo', l.map((x) => ({ date: x.t, titre: 'Météo frelons', texte: texteCreneau(x.c), url: '/meteo' })));
}

export async function relireMeteo(force = false) {
  if (Platform.OS === 'web') return;
  if (!force && Date.now() - dernier < 3 * 3600000) return;
  const pos = position();
  if (!pos) return;
  dernier = Date.now();
  const P = param();
  const m = await chargerMeteo(pos.lat, pos.lon, { tempMin: P.tempMin, ventMax: P.ventMax });
  ecrireValeur('meteo', m);
  await programmer(m);
}

if (Platform.OS !== 'web') {
  setTimeout(() => { relireMeteo().catch(() => {}); }, 15000);
  setInterval(() => { if (AppState.currentState === 'active') relireMeteo().catch(() => {}); }, 30 * 60000);
  AppState.addEventListener('change', (s) => { if (s === 'active') relireMeteo().catch(() => {}); });
}
