/**
 * Fond de carte IGN (Géoplateforme, WMTS, sans clé) : plan IGN ou photo aérienne.
 * Les zones téléchargées sont gardées dans le téléphone (documents/tuiles/…) et utilisées en priorité, sans réseau.
 */
import { Directory, File, Paths } from 'expo-file-system';
import { tuilesDe, rectangleZone, ZOOM_HORS_LIGNE, type Couche, type Zone } from '../calc/tuilesGeo';
export * from '../calc/tuilesGeo';

const CFG: Record<Couche, { layer: string; format: string; ext: string }> = {
  plan: { layer: 'GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2', format: 'image/png', ext: 'png' },
  photo: { layer: 'ORTHOIMAGERY.ORTHOPHOTOS', format: 'image/jpeg', ext: 'jpg' },
};

export const urlTuile = (c: Couche, z: number, x: number, y: number) =>
  `https://data.geopf.fr/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=${CFG[c].layer}&STYLE=normal&FORMAT=${encodeURIComponent(CFG[c].format)}` +
  `&TILEMATRIXSET=PM_0_19&TILEMATRIX=${z}&TILEROW=${y}&TILECOL=${x}`;

/* ---------- stockage hors ligne ---------- */
const dossier = () => new Directory(Paths.document, 'tuiles');
const fichier = (c: Couche, z: number, x: number, y: number) => new File(Paths.document, 'tuiles', c, String(z), String(x), `${y}.${CFG[c].ext}`);
const existe = new Map<string, string | null>();

/** Adresse à afficher pour une tuile : fichier local s'il existe, sinon internet. */
export function sourceTuile(c: Couche, z: number, x: number, y: number): string {
  const k = `${c}/${z}/${x}/${y}`;
  let local = existe.get(k);
  if (local === undefined) {
    try { const f = fichier(c, z, x, y); local = f.exists ? f.uri : null; } catch { local = null; }
    existe.set(k, local);
  }
  return local ?? urlTuile(c, z, x, y);
}

/** Télécharge une zone (4 téléchargements en parallèle). avancement(fait, total). Renvoie le nombre d'octets. */
export async function telechargerZone(z: Pick<Zone, 'lat' | 'lon' | 'largeurKm' | 'hauteurKm' | 'couches'>, avancement: (fait: number, total: number) => void, annule: () => boolean): Promise<number> {
  const r = rectangleZone(z);
  const travail: { c: Couche; x: number; y: number; z: number }[] = [];
  for (const c of z.couches) for (const zz of ZOOM_HORS_LIGNE) for (const t of tuilesDe(r.la1, r.lo1, r.la2, r.lo2, zz)) travail.push({ c, ...t });
  let fait = 0, octets = 0, i = 0;
  const ouvrier = async () => {
    while (i < travail.length && !annule()) {
      const t = travail[i++];
      const f = fichier(t.c, t.z, t.x, t.y);
      try {
        if (!f.exists) {
          const d = new Directory(Paths.document, 'tuiles', t.c, String(t.z), String(t.x));
          if (!d.exists) d.create({ intermediates: true });
          await File.downloadFileAsync(urlTuile(t.c, t.z, t.x, t.y), f);
        }
        octets += f.size ?? 0;
        existe.set(`${t.c}/${t.z}/${t.x}/${t.y}`, f.uri);
      } catch { /* tuile absente (bord de zone, mer…) : on continue */ }
      avancement(++fait, travail.length);
    }
  };
  await Promise.all([ouvrier(), ouvrier(), ouvrier(), ouvrier()]);
  return octets;
}

/** Efface toutes les tuiles enregistrées. */
export function effacerTuiles() {
  try { const d = dossier(); if (d.exists) d.delete(); } catch {}
  existe.clear();
}
