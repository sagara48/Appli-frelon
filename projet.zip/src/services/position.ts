/** Position GPS et boussole du téléphone (sert quand ni le toit ni le portatif ne donnent de position, et pour « Cap à l'œil »). */
import * as Location from 'expo-location';
import { store } from '../store/store';

let posSub: Location.LocationSubscription | null = null;
let capSub: Location.LocationSubscription | null = null;
let demande: Promise<boolean> | null = null;

async function autorise(): Promise<boolean> {
  demande ??= Location.requestForegroundPermissionsAsync().then((r) => r.granted).catch(() => false);
  const ok = await demande;
  if (!ok) demande = null; // redemander la prochaine fois
  return ok;
}

/** Suit la position du téléphone (toutes les 2 s ou 3 m). */
export async function suivrePosition(): Promise<boolean> {
  if (posSub) return true;
  if (!(await autorise())) return false;
  try {
    posSub = await Location.watchPositionAsync({ accuracy: Location.Accuracy.High, timeInterval: 2000, distanceInterval: 3 }, (l) =>
      store.set({ telephone: { lat: l.coords.latitude, lon: l.coords.longitude, precision: l.coords.accuracy ?? 99, recuMs: Date.now() } }));
    return true;
  } catch { return false; }
}

/** Suit la boussole du téléphone (cap vrai si disponible). Renvoie une fonction d'arrêt. */
export async function suivreBoussole(): Promise<() => void> {
  if (!(await autorise())) return () => {};
  try {
    capSub?.remove();
    capSub = await Location.watchHeadingAsync((h) => {
      const cap = h.trueHeading >= 0 ? h.trueHeading : h.magHeading;
      store.set({ boussole: { cap, precision: h.accuracy ?? 0 } });
    });
  } catch { /* pas de boussole (aperçu web) */ }
  return () => { capSub?.remove(); capSub = null; };
}
