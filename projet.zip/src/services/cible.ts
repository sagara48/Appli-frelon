/** « Envoyer au portatif » : le portatif (firmware 1.2.0) affiche une flèche et la distance vers ce point (mode NAV). */
import { Alert } from 'react-native';
import { store } from '../store/store';
import { cmdPortatif } from '../proto/portatif';
import { comparerVersions } from '../calc/versions';
import { envoyerPortatif } from '../sources/portatif';

/** Raison pour laquelle on ne peut pas envoyer, ou null si c'est possible. */
export function cibleImpossible(): string | null {
  const p = store.get().portatif;
  if (p.connexion !== 'connecte') return "Le portatif n'est pas connecté : allumez-le et connectez-le (onglet Portatif).";
  if (p.source === 'ble' && p.version && !p.version.absente && comparerVersions(p.version.fw, '1.2.0') < 0)
    return `Le portatif a le firmware ${p.version.fw} : la flèche vers un point demande la 1.2.0 (Menu → Mises à jour).`;
  return null;
}

/** Envoie le point et prévient l'utilisateur du résultat. */
export async function envoyerCible(lat: number, lon: number, nom: string) {
  const non = cibleImpossible();
  if (non) { Alert.alert('Envoyer au portatif', non); return; }
  try {
    await envoyerPortatif(cmdPortatif.cible(lat, lon, nom));
    store.evenement(`Portatif : flèche vers ${nom}`);
    store.portatif({ cible: nom });
    Alert.alert('Envoyé au portatif', `Le portatif montre la direction et la distance de « ${nom} ». Pour l'effacer : onglet Portatif.`);
  } catch (e) { Alert.alert('Envoyer au portatif', (e as Error).message); }
}
export const effacerCible = () => { store.portatif({ cible: null }); return envoyerPortatif(cmdPortatif.cibleOff()).catch(() => {}); };
