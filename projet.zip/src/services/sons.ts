/**
 * Sons : bips qui suivent le signal (plus rapides et plus aigus quand le tag se rapproche), annonces vocales, vibrations.
 * Les bips ne tournent que sur les écrans qui le demandent (Portatif, Mode conduite).
 */
import { createAudioPlayer, setAudioModeAsync, type AudioPlayer } from 'expo-audio';
import * as Haptics from 'expo-haptics';
import * as Speech from 'expo-speech';
import { ageS, agePortatif, store } from '../store/store';
import { niveauPct } from '../calc/geo';

let bips: AudioPlayer[] | null = null;
let minuterie: ReturnType<typeof setTimeout> | null = null;
let demandeurs = 0;

function lecteurs(): AudioPlayer[] {
  if (bips) return bips;
  try {
    setAudioModeAsync({ playsInSilentMode: true, shouldPlayInBackground: true, interruptionMode: 'mixWithOthers' }).catch(() => {});
    bips = [require('../../assets/bip1.wav'), require('../../assets/bip2.wav'), require('../../assets/bip3.wav')].map((s) => createAudioPlayer(s));
  } catch { bips = []; }
  return bips;
}

/** Niveau à suivre : tag du portatif s'il est connecté, sinon tag choisi au toit. null = rien d'entendu récemment. */
function niveauSuivi(): number | null {
  const e = store.get();
  const p = e.portatif.st;
  if (e.portatif.connexion === 'connecte' && p && p.tag >= 0 && agePortatif(e) < 5) return niveauPct(p.rssi);
  const t = e.tagChoisi !== null ? e.tags[e.tagChoisi] : undefined;
  if (t && ageS(e, t) < 5) return niveauPct(Math.max(...t.r));
  return null;
}

function boucle() {
  const e = store.get();
  const pct = e.alertes.sonSignal ? niveauSuivi() : null;
  let attente = 600;
  if (pct !== null) {
    const l = lecteurs();
    const p = l[pct >= 66 ? 2 : pct >= 33 ? 1 : 0];
    if (p) { try { p.volume = e.alertes.volume; p.seekTo(0); p.play(); } catch {} }
    attente = 1400 - pct * 12; // 1,4 s à 0 %, 0,2 s à 100 %
  }
  minuterie = setTimeout(boucle, attente);
}

/** Un écran demande les bips ; renvoie la fonction pour les arrêter. */
export function suivreAuSon(): () => void {
  demandeurs++;
  if (!minuterie) boucle();
  return () => {
    demandeurs = Math.max(0, demandeurs - 1);
    if (!demandeurs && minuterie) { clearTimeout(minuterie); minuterie = null; }
  };
}

export function annoncer(texte: string) {
  if (!store.get().alertes.voix) return;
  try { Speech.speak(texte, { language: 'fr-FR', rate: 1.05 }); } catch {}
}

export function vibrer(grave = false) {
  Haptics.notificationAsync(grave ? Haptics.NotificationFeedbackType.Error : Haptics.NotificationFeedbackType.Warning).catch(() => {});
}
