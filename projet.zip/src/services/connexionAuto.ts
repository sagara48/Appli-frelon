/** Connexion automatique : tant que le toit ou le portatif n'est pas connecté, un court scan Bluetooth toutes les 30 s
 *  (appli au premier plan, ou sortie en cours écran verrouillé) ; dès que l'un est entendu, l'appli s'y connecte.
 *  Ne se mêle de rien après un « Déconnecter » de l'utilisateur, pendant une simulation, ou si c'est coupé
 *  (Paramètres → Automatismes). Les autorisations Bluetooth ne sont jamais demandées d'ici. */
import { AppState, Platform } from 'react-native';
import { ble, permissionsAccordees, toit, connecterToit } from '../sources/ble';
import { connecterPortatif, liaisonPortatif } from '../sources/portatif';
import { store } from '../store/store';
import { param } from './parametres';
import { journaliser } from './journal';

const PERIODE_MS = 30000, SCAN_MS = 6000;
let scanEnCours = false;

async function tour() {
  if (scanEnCours || !param().autoConnexion) return;
  if (AppState.currentState !== 'active' && store.get().source !== 'toit') return; // en arrière-plan : seulement pendant une sortie
  const e = store.get(), P = param();
  const veutToit = e.source !== 'simulation' && e.connexion !== 'connecte' && !toit.refuse && !toit.occupe;
  const veutPort = e.portatif.source !== 'simulation' && e.portatif.connexion !== 'connecte' && !liaisonPortatif.refuse && !liaisonPortatif.occupe;
  if (!veutToit && !veutPort) return;
  if (toit.occupe || liaisonPortatif.occupe) return; // un scan de reconnexion tourne déjà
  if (!(await permissionsAccordees())) return;
  scanEnCours = true;
  const m = ble();
  const trouve = await new Promise<'toit' | 'portatif' | null>((ok) => {
    const fin = setTimeout(() => { m.stopDeviceScan(); ok(null); }, SCAN_MS);
    try {
      m.startDeviceScan(null, { allowDuplicates: false }, (err, d) => {
        if (err) { clearTimeout(fin); m.stopDeviceScan(); ok(null); return; }
        const nom = d?.name ?? d?.localName;
        if (veutToit && nom === P.nomToit) { clearTimeout(fin); m.stopDeviceScan(); ok('toit'); }
        else if (veutPort && nom === P.nomPortatif) { clearTimeout(fin); m.stopDeviceScan(); ok('portatif'); }
      });
    } catch { clearTimeout(fin); ok(null); }
  });
  scanEnCours = false;
  if (!trouve) return;
  journaliser(trouve, 'etat', 'connexion automatique');
  store.evenement(`${trouve === 'toit' ? 'Toit' : 'Portatif'} allumé à portée : connexion automatique`);
  if (trouve === 'toit') connecterToit().catch(() => {}); else connecterPortatif().catch(() => {});
}

if (Platform.OS !== 'web') {
  setTimeout(() => { tour().catch(() => { scanEnCours = false; }); }, 3000);
  setInterval(() => { tour().catch(() => { scanEnCours = false; }); }, PERIODE_MS);
}
