/** Sauvegarde complète du carnet dans un seul fichier .zip : nids (photos comprises), tags, ruchers, appâts et réglages.
 *  Le fichier se garde où l'on veut (Drive, mail, ordinateur) ; la restauration remplace tout le contenu de l'appli. */
import { Directory, File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { toutLire, toutRemplacer } from '../db';
import { construireZip, lireZip } from '../calc/sauvegardeZip';
import { chargerCarnet } from './carnet';

const DOSSIER_PHOTOS = 'photos';
/** Crée la sauvegarde et ouvre le partage Android (Drive, mail…). */
export async function sauvegarder(): Promise<{ nids: number; photos: number; manquantes: number }> {
  const s = toutLire();
  const r = construireZip(s, (uri) => { try { const f = new File(uri); return f.exists ? f.bytesSync() : null; } catch { return null; } });
  const d = new Date();
  const p = (x: number) => String(x).padStart(2, '0');
  const f = new File(Paths.cache, `sauvegarde_frelons_${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}.zip`);
  if (f.exists) f.delete();
  f.create();
  f.writeSync(r.zip);
  await Sharing.shareAsync(f.uri, { mimeType: 'application/zip', dialogTitle: 'Sauvegarde du carnet' });
  return { nids: s.nids.filter((n) => !n.supprime).length, photos: r.photos, manquantes: r.manquantes };
}

/** Restaure une sauvegarde (remplace tout). Les photos sont recopiées dans le dossier de l'appli. */
export async function restaurer(uri: string): Promise<{ nids: number; photos: number }> {
  const { s, photos } = lireZip(await new File(uri).bytes());
  const dir = new Directory(Paths.document, DOSSIER_PHOTOS);
  if (!dir.exists) dir.create({ intermediates: true });
  const nouveaux: Record<string, string> = {};
  for (const [nom, o] of Object.entries(photos)) {
    const f = new File(dir, nom);
    if (f.exists) f.delete();
    f.create();
    f.writeSync(o);
    nouveaux[nom] = f.uri;
  }
  const nids = s.nids.map((n) => {
    let noms: string[] = [];
    try { noms = JSON.parse(String(n.photos ?? '[]')) as string[]; } catch {}
    return { ...n, photos: JSON.stringify(noms.map((x) => nouveaux[x]).filter(Boolean)) } as Record<string, unknown>;
  });
  toutRemplacer({ ...s, nids });
  chargerCarnet();
  return { nids: nids.filter((n) => !n.supprime).length, photos: Object.keys(photos).length };
}
