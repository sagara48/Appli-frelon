/** Fonctionnement écran verrouillé : pendant une vraie sortie (toit ou portatif connecté, ou station fixe), un service Android
 *  de premier plan garde l'appli active. Il s'affiche comme une notification permanente « Frelons : sortie en cours ».
 *  Sans lui, Android peut couper le Bluetooth et retarder les alertes quand l'écran est éteint.
 *  Le service est celui du suivi de position d'expo-location : il donne en plus la position du téléphone en continu. */
import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';
import { PermissionsAndroid, Platform } from 'react-native';
import { store, type Etat } from '../store/store';
import { ecrireValeur, lireValeur } from '../db';
import { journaliser } from './journal';
import { param } from './parametres';

const TACHE = 'frelons-sortie';

// déclarée au chargement du module (exigé par expo-task-manager)
if (Platform.OS !== 'web') {
  TaskManager.defineTask<{ locations?: Location.LocationObject[] }>(TACHE, async ({ data, error }) => {
    if (error) { journaliser('appli', 'erreur', `Suivi écran verrouillé : ${error.message}`); return; }
    const l = data?.locations?.[data.locations.length - 1];
    if (l) store.set({ telephone: { lat: l.coords.latitude, lon: l.coords.longitude, precision: l.coords.accuracy ?? 99, recuMs: Date.now() } });
  });
}

export const arrierePlanActive = () => lireValeur<boolean>('arrierePlan') ?? true;
export function activerArrierePlan(v: boolean) { ecrireValeur('arrierePlan', v); verifier(); }

export type EtatArrierePlan = 'arrete' | 'actif' | 'refuse';
let etatAp: EtatArrierePlan = 'arrete';
const abonnes = new Set<() => void>();
const publier = (e: EtatArrierePlan) => { etatAp = e; abonnes.forEach((f) => f()); };
export const etatArrierePlan = () => etatAp;
export const abonnerArrierePlan = (f: () => void) => { abonnes.add(f); return () => { abonnes.delete(f); }; };

const enSortie = (e: Etat) => (e.source === 'toit' && e.connexion !== 'arrete') || (e.portatif.source === 'ble' && e.portatif.connexion !== 'arrete') || !!e.station;

let occupe = false;
let refusSignale = false;
async function demarrer() {
  const fg = await Location.requestForegroundPermissionsAsync();
  const bg = fg.granted ? await Location.requestBackgroundPermissionsAsync() : fg;
  if (!bg.granted) {
    publier('refuse');
    if (!refusSignale) {
      refusSignale = true;
      journaliser('appli', 'erreur', 'Écran verrouillé : localisation « Toujours autoriser » refusée, le suivi peut s\'arrêter écran éteint.');
      store.set({ bandeau: { texte: 'Pour suivre écran verrouillé : autorisez la position « Toujours » (Réglages Android → Applis → Frelons → Position).', grave: false, ms: Date.now() } });
    }
    return;
  }
  // Android 13 et plus : sans cette autorisation le service tourne quand même, mais sa notification est cachée
  if (Platform.OS === 'android' && Number(Platform.Version) >= 33) await PermissionsAndroid.request('android.permission.POST_NOTIFICATIONS').catch(() => null);
  if (await Location.hasStartedLocationUpdatesAsync(TACHE)) { publier('actif'); return; }
  await Location.startLocationUpdatesAsync(TACHE, {
    accuracy: Location.Accuracy.Balanced, timeInterval: param().gpsArrierePlanS * 1000, distanceInterval: 15, pausesUpdatesAutomatically: false,
    foregroundService: { notificationTitle: 'Frelons : sortie en cours', notificationBody: 'Le suivi des tags continue écran verrouillé.', notificationColor: '#E8A33A', killServiceOnDestroy: true },
  });
  journaliser('appli', 'etat', 'Suivi écran verrouillé démarré');
  publier('actif');
}
async function arreter() {
  if (await Location.hasStartedLocationUpdatesAsync(TACHE)) {
    await Location.stopLocationUpdatesAsync(TACHE);
    journaliser('appli', 'etat', 'Suivi écran verrouillé arrêté');
  }
  publier('arrete');
}

let derniere: boolean | null = null;
/** Démarre ou arrête le service selon l'état de la sortie. */
function verifier() {
  if (Platform.OS !== 'android' || occupe) return;
  const voulu = arrierePlanActive() && enSortie(store.get());
  if (voulu === derniere) return;
  derniere = voulu;
  occupe = true;
  (voulu ? demarrer() : arreter())
    .catch((err) => { journaliser('appli', 'erreur', `Suivi écran verrouillé : ${String((err as Error).message ?? err)}`); publier('arrete'); })
    .finally(() => { occupe = false; if (arrierePlanActive() && enSortie(store.get()) !== voulu) { derniere = null; verifier(); } });
}

/** À appeler une fois au démarrage : suit l'état de la sortie. */
export function surveillerArrierePlan() {
  const stop = store.abonner(verifier);
  verifier();
  return () => { stop(); };
}
