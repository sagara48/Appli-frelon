/** Signature au doigt (client). Le tracé est gardé sous forme de chemin SVG dans un repère 300 × 120,
 *  quelle que soit la taille de l'écran : il se recopie tel quel dans le compte rendu PDF. */
import React, { useEffect, useState } from 'react';
import { PanResponder, Pressable, Text, View, type LayoutChangeEvent } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import { C } from './theme';
import { s } from './composants';

export const SIGNATURE_VB = '0 0 300 120';

type Boite = { d: string; larg: number; onChange: (d: string) => void; geste?: (g: boolean) => void; dessiner: (d: string) => void };
/** Mise à jour de la boîte (appelée hors rendu). */
const regler = (b: Boite, p: Partial<Boite>) => { Object.assign(b, p); };
/** Geste de signature : complète le tracé de la boîte (hors rendu). */
function creerGeste(b: Boite) {
  const pt = (x: number, y: number) => { const k = 300 / b.larg; return `${Math.round(x * k)} ${Math.round(y * k)}`; };
  const fin = () => { b.geste?.(false); b.onChange(b.d); };
  return PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderTerminationRequest: () => false,
    onPanResponderGrant: (e) => { b.geste?.(true); b.d += `M${pt(e.nativeEvent.locationX, e.nativeEvent.locationY)}`; b.dessiner(b.d); },
    onPanResponderMove: (e) => { b.d += `L${pt(e.nativeEvent.locationX, e.nativeEvent.locationY)}`; b.dessiner(b.d); },
    onPanResponderRelease: fin,
    onPanResponderTerminate: fin,
  });
}

/** `geste` : prévenu au début et à la fin du tracé (pour bloquer le défilement de l'écran pendant la signature). */
export function Signature({ valeur, onChange, geste }: { valeur: string; onChange: (d: string) => void; geste?: (enCours: boolean) => void }) {
  const [trace, setTrace] = useState(valeur);
  const [larg, setLarg] = useState(300);
  const [boite] = useState<Boite>(() => ({ d: valeur, larg: 300, onChange, geste, dessiner: setTrace }));
  const [pan] = useState(() => creerGeste(boite));
  useEffect(() => { regler(boite, { onChange, geste }); }, [boite, onChange, geste]);
  const mesurer = (e: LayoutChangeEvent) => { const l = e.nativeEvent.layout.width || 300; regler(boite, { larg: l }); setLarg(l); };
  const effacer = () => { regler(boite, { d: '' }); setTrace(''); onChange(''); };
  return (
    <View>
      <View onLayout={mesurer} {...pan.panHandlers}
        style={{ height: (larg * 120) / 300, borderWidth: 1, borderColor: C.ligne, borderRadius: 8, backgroundColor: '#fff' }}>
        <Svg width="100%" height="100%" viewBox={SIGNATURE_VB} pointerEvents="none">
          <Path d={trace || 'M0 0'} stroke="#14202E" strokeWidth={2.2} fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </Svg>
        {!trace && <Text pointerEvents="none" style={[s.discret, { position: 'absolute', alignSelf: 'center', top: '42%' }]}>Signer ici avec le doigt</Text>}
      </View>
      {!!trace && (
        <Pressable onPress={effacer} style={{ alignSelf: 'flex-end', paddingVertical: 6 }}>
          <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Effacer la signature</Text>
        </Pressable>
      )}
    </View>
  );
}
