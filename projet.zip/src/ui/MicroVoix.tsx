/** Bouton micro des commandes vocales (Chrono, Portatif) : allume / coupe l'écoute, montre la dernière phrase
 *  comprise et la réponse. Absent sur le web (pas de reconnaissance vocale). */
import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { basculerVoix, useVoix, voixDisponible } from '@/services/voix';
import { C, police } from './theme';

export function MicroVoix() {
  const v = useVoix();
  const router = useRouter();
  if (!voixDisponible()) return null;
  return (
    <View style={{ gap: 4 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <Pressable onPress={basculerVoix} accessibilityRole="button" accessibilityLabel={v.actif ? 'Couper le micro' : 'Allumer les commandes vocales'}
          style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 14, minHeight: 40, borderRadius: 20,
            backgroundColor: v.actif ? C.alerte : C.carte, borderWidth: 1, borderColor: v.actif ? C.alerte : C.ligne }}>
          <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: v.actif ? (v.ecoute ? '#fff' : '#ffffff88') : C.discret }} />
          <Text style={{ color: v.actif ? '#fff' : C.encre, fontWeight: '700' }}>{v.actif ? (v.ecoute ? 'J\'écoute…' : 'Micro allumé') : 'Commandes vocales'}</Text>
        </Pressable>
        <Pressable onPress={() => router.push('/parametres')}><Text style={{ color: C.discret, fontSize: police.mini, textDecorationLine: 'underline' }}>phrases</Text></Pressable>
      </View>
      {!!(v.actif && (v.entendu || v.reponse)) && (
        <Text style={{ color: C.discret, fontSize: police.mini }} numberOfLines={2}>
          {v.entendu ? `« ${v.entendu} »` : ''}{v.entendu && v.reponse ? ' → ' : ''}{v.reponse}
        </Text>
      )}
      {!!v.erreur && <Text style={{ color: C.alerte, fontSize: police.mini }}>{v.erreur}</Text>}
    </View>
  );
}
