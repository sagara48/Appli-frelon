/** Pression des frelons devant les ruches d'un rucher : relevé du jour en un appui, et barres des 8 dernières semaines. */
import React from 'react';
import { Pressable, Text, View } from 'react-native';
import Svg, { Line, Rect, Text as T } from 'react-native-svg';
import { C, fmtDist, police } from './theme';
import { s } from './composants';
import { libelleNiveau, lirePressions, niveauActuel, NIVEAUX, releveDuJour, tendance, type Niveau } from '../calc/pression';
import { noterPression } from '../services/carnet';
import type { Rucher } from '../db';

const COUL: Record<Niveau, string> = { 0: '#B9C0B4', 1: '#E8C547', 2: '#E8A317', 3: '#B3412E' };
const JOUR = 86400000, JOURS = 56;

/** effets : destructions de nids proches et pression avant / après (calc/resultats). */
export function PressionRucher({ r, maintenant, largeur, effets = [] }: { r: Rucher; maintenant: number; largeur: number; effets?: { nid: number; numero: number; t: number; distM: number; avant: number; apres: number; variation: number }[] }) {
  const l = lirePressions(r.pressions);
  const auj = releveDuJour(l, maintenant);
  const niv = niveauActuel(l, maintenant), tend = tendance(l, maintenant);
  const debut = new Date(maintenant - (JOURS - 1) * JOUR).setHours(0, 0, 0, 0);
  const W = largeur, H = 54, bw = W / JOURS;
  const recents = l.filter((x) => x.t >= debut);
  return (
    <View style={{ marginTop: 10 }}>
      <View style={[s.ligne, { justifyContent: 'space-between' }]}>
        <Text style={{ color: C.encre, fontWeight: '700' }}>Frelons devant les ruches</Text>
        {niv !== null && (
          <Text style={{ color: niv >= 2 ? C.alerte : C.discret, fontWeight: '700', fontSize: police.mini }}>
            {libelleNiveau(niv).toLowerCase()} en moyenne{tend === 'hausse' ? ' · en hausse' : tend === 'baisse' ? ' · en baisse' : ''}
          </Text>
        )}
      </View>
      <View style={[s.ligne, { gap: 6, marginTop: 6 }]}>
        {NIVEAUX.map(([n, t]) => {
          const choisi = auj?.n === n;
          return (
            <Pressable key={n} onPress={() => noterPression(r.id, n)}
              style={{ flex: 1, paddingVertical: 8, borderRadius: 8, alignItems: 'center', borderWidth: 2, borderColor: choisi ? COUL[n] : C.ligne, backgroundColor: choisi ? `${COUL[n]}33` : 'transparent' }}>
              <Text style={{ color: C.encre, fontWeight: choisi ? '800' : '600', fontSize: police.mini + 1 }}>{t}</Text>
            </Pressable>
          );
        })}
      </View>
      <Text style={[s.discret, { fontSize: police.mini, marginTop: 4 }]}>{auj ? 'Relevé du jour noté (un appui le corrige).' : 'Combien de frelons chassent devant les ruches aujourd\'hui ?'}</Text>
      {recents.length > 0 && (
        <Svg width={W} height={H + 14} style={{ marginTop: 6 }}>
          <Line x1={0} y1={H} x2={W} y2={H} stroke={C.ligne} strokeWidth={1} />
          {recents.map((x) => {
            const i = Math.floor((new Date(x.t).setHours(0, 0, 0, 0) - debut) / JOUR);
            const h = 6 + (x.n / 3) * (H - 8);
            return <Rect key={x.t} x={i * bw + 0.5} y={H - h} width={Math.max(2, bw - 1)} height={h} rx={1} fill={COUL[x.n]} />;
          })}
          <T x={0} y={H + 12} fontSize={10} fill={C.discret}>il y a 8 semaines</T>
          <T x={W} y={H + 12} fontSize={10} fill={C.discret} textAnchor="end">aujourd&apos;hui</T>
        </Svg>
      )}
      {effets.map((x) => (
        <Text key={`${x.nid}-${x.t}`} style={{ color: x.variation <= -30 ? C.ok : C.encre, fontSize: police.mini, marginTop: 4 }}>
          Nid n° {x.numero} détruit le {new Date(x.t).toLocaleDateString('fr-FR')} (à {fmtDist(x.distM)}) : pression {fr1(x.avant)} → {fr1(x.apres)}
          {' '}({x.variation > 0 ? '+' : ''}{x.variation} %){x.variation <= -30 ? ', ce nid gênait ce rucher' : x.variation >= -10 ? ', sans effet net' : ''}
        </Text>
      ))}
    </View>
  );
}
const fr1 = (x: number) => String(Math.round(x * 10) / 10).replace('.', ',');
