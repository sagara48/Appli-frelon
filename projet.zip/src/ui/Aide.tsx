/** Mise en page commune des écrans d'aide. */
import { Stack } from 'expo-router';
import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { Carte, s } from './composants';
import { C, police } from './theme';

export function PageAide({ titre, sousTitre, children }: { titre: string; sousTitre: string; children: React.ReactNode }) {
  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <Stack.Screen options={{ headerShown: true, title: titre, headerStyle: { backgroundColor: C.fond }, headerShadowVisible: false }} />
      <Text style={s.discret}>{sousTitre}</Text>
      {children}
    </ScrollView>
  );
}
export function Bloc({ titre, children }: { titre: string; children: React.ReactNode }) {
  return <Carte><Text style={{ color: C.encre, fontWeight: '800', fontSize: police.normal + 1, marginBottom: 8 }}>{titre}</Text><View style={{ gap: 8 }}>{children}</View></Carte>;
}
export const P = ({ children }: { children: React.ReactNode }) => <Text style={{ color: C.encre, lineHeight: 21 }}>{children}</Text>;
export const Puce = ({ children }: { children: React.ReactNode }) => <Text style={{ color: C.encre, lineHeight: 21 }}>•  {children}</Text>;
export const G = ({ children }: { children: React.ReactNode }) => <Text style={{ fontWeight: '700' }}>{children}</Text>;
