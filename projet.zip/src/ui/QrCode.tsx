/** QR code dessiné en SVG (calc/qr.ts). */
import React, { useMemo } from 'react';
import Svg, { Path, Rect } from 'react-native-svg';
import { cheminQr, matriceQr } from '@/calc/qr';

export function QrCode({ texte, taille }: { texte: string; taille: number }) {
  const { n, d } = useMemo(() => { const m = matriceQr(texte); return { n: m.length + 4, d: cheminQr(m) }; }, [texte]);
  return (
    <Svg width={taille} height={taille} viewBox={`0 0 ${n} ${n}`}>
      <Rect width={n} height={n} fill="#fff" />
      <Path d={d} fill="#000" />
    </Svg>
  );
}
