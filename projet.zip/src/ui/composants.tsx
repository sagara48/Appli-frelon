import React from 'react';
import { Stack } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View, type ViewStyle } from 'react-native';
import { C, R, idTag, nbVoies, police } from './theme';
import { store, useEtat } from '../store/store';

/** Heure courante, rafraîchie toutes les `ms` (pour les « il y a … » et les chronos). */
export function useMaintenant(ms = 1000): number {
  const [t, setT] = React.useState(() => Date.now());
  React.useEffect(() => { const i = setInterval(() => setT(Date.now()), ms); return () => clearInterval(i); }, [ms]);
  return t;
}

export function Carte({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[s.carte, style]}>{children}</View>;
}

export function Titre({ children }: { children: React.ReactNode }) {
  return <Text style={s.titreSection}>{children}</Text>;
}

export function Bouton({ titre, onPress, plein, desactive }: { titre: string; onPress: () => void; plein?: boolean; desactive?: boolean }) {
  return (
    <Pressable onPress={onPress} disabled={desactive} style={({ pressed }) => [s.bouton, plein && s.boutonPlein, (pressed || desactive) && { opacity: 0.6 }]}>
      <Text style={[s.boutonTxt, plein && { color: C.encre }]}>{titre}</Text>
    </Pressable>
  );
}

/** Bandeau d'état du toit, en haut des écrans Direct et Carte. */
export function BandeauToit() {
  const { source, connexion, message, toit } = useEtat((e) => ({ source: e.source, connexion: e.connexion, message: e.message, toit: e.toit }));
  const ok = connexion === 'connecte';
  const titre = source === 'simulation' ? (ok ? 'Simulation en cours' : 'Simulation arrêtée') : ok ? 'Toit connecté' : connexion === 'recherche' ? 'Recherche du toit…' : 'Toit non connecté';
  return (
    <View style={s.bandeau}>
      <View style={s.ligne}>
        <View style={[s.pastille, { backgroundColor: ok ? C.ok : connexion === 'recherche' ? C.accent : C.alerte }]} />
        <Text style={s.bandeauTitre}>{titre}</Text>
      </View>
      {toit ? (
        <View style={[s.ligne, { marginTop: 6, flexWrap: 'wrap', gap: 14 }]}>
          <Info k="Batterie" v={`${toit.battPct} %${toit.charge ? ' ⚡' : ''}`} />
          <Info k="GPS" v={toit.lat ? `${toit.sats} sat.` : 'pas de position'} />
          <Info k="Vitesse" v={`${Math.round(toit.vitesse)} km/h`} />
          <Info k="Voies" v={`${nbVoies(toit.voiesOk)} / 4`} />
        </View>
      ) : (
        !!message && <Text style={{ color: '#A9B4BF', fontSize: police.petit, marginTop: 4 }}>{message}</Text>
      )}
    </View>
  );
}

function Info({ k, v }: { k: string; v: string }) {
  return (
    <Text style={s.info}>
      <Text style={{ color: '#A9B4BF' }}>{k} </Text>
      {v}
    </Text>
  );
}

/** Puces de choix du tag suivi. */
export function ChoixTag() {
  const ids = useEtat((e) => Object.keys(e.tags).map(Number).sort((a, b) => a - b).join(','));
  const choisi = useEtat((e) => e.tagChoisi);
  const liste = ids ? ids.split(',').map(Number) : [];
  if (!liste.length) return null;
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingVertical: 4 }}>
      <Text style={[s.discret, { alignSelf: 'center', marginRight: 2 }]}>TAG</Text>
      {liste.map((id) => (
        <Pressable key={id} onPress={() => store.choisirTag(id)} style={[s.puce, id === choisi && s.puceActive]}>
          <Text style={[s.puceTxt, id === choisi && { color: C.encre, fontWeight: '700' }]}>{idTag(id)}</Text>
        </Pressable>
      ))}
    </ScrollView>
  );
}

export function Vide({ titre, texte }: { titre: string; texte: string }) {
  return (
    <View style={{ alignItems: 'center', padding: 32, gap: 8 }}>
      <Text style={{ fontSize: police.normal + 2, fontWeight: '700', color: C.encre }}>{titre}</Text>
      <Text style={[s.discret, { textAlign: 'center', lineHeight: 20 }]}>{texte}</Text>
    </View>
  );
}

export const s = StyleSheet.create({
  ecran: { flex: 1, backgroundColor: C.fond },
  contenu: { padding: 16, gap: 12, paddingBottom: 32 },
  carte: { backgroundColor: C.carte, borderRadius: R.carte, padding: 14, borderWidth: 1, borderColor: C.ligne },
  titreSection: { fontSize: police.mini, fontWeight: '700', letterSpacing: 1, color: C.discret, textTransform: 'uppercase', marginBottom: 8 },
  ligne: { flexDirection: 'row', alignItems: 'center' },
  pastille: { width: 10, height: 10, borderRadius: 5, marginRight: 8 },
  bandeau: { backgroundColor: C.encre, borderRadius: R.carte, padding: 14 },
  bandeauTitre: { color: '#fff', fontSize: police.normal, fontWeight: '700' },
  info: { color: '#fff', fontSize: police.petit },
  discret: { color: C.discret, fontSize: police.petit },
  puce: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: R.puce, borderWidth: 1, borderColor: C.ligne, backgroundColor: C.carte },
  puceActive: { backgroundColor: C.accent, borderColor: C.accent },
  puceTxt: { color: C.encre, fontSize: police.normal, fontVariant: ['tabular-nums'] },
  bouton: { flex: 1, paddingVertical: 12, borderRadius: 10, borderWidth: 1, borderColor: C.encre, alignItems: 'center' },
  boutonPlein: { backgroundColor: C.accent, borderColor: C.accent },
  boutonTxt: { color: C.encre, fontWeight: '700', fontSize: police.normal },
});

/* ---------- éléments communs des écrans « outils » ---------- */

/** Titre de la page (barre du haut, avec retour). */
export function EnTete({ titre, droite }: { titre: string; droite?: () => React.ReactNode }) {
  return <Stack.Screen options={{ headerShown: true, title: titre, headerStyle: { backgroundColor: C.fond }, headerShadowVisible: false, headerTintColor: C.encre, headerRight: droite }} />;
}

export function Interrupteur({ titre, detail, valeur, onChange }: { titre: string; detail?: string; valeur: boolean; onChange: (v: boolean) => void }) {
  return (
    <View style={[s.ligne, { paddingVertical: 10, borderTopWidth: 1, borderTopColor: C.ligne, gap: 10 }]}>
      <View style={{ flex: 1 }}>
        <Text style={{ color: C.encre, fontSize: police.normal }}>{titre}</Text>
        {!!detail && <Text style={[s.discret, { fontSize: police.mini }]}>{detail}</Text>}
      </View>
      <Switch value={valeur} onValueChange={onChange} trackColor={{ true: C.accent, false: C.ligne }} thumbColor={C.carte} />
    </View>
  );
}

export function Champ({ titre, valeur, onChange, placeholder, clavier, multiligne, genre }: {
  titre: string; valeur: string; onChange: (v: string) => void; placeholder?: string; clavier?: 'default' | 'numeric' | 'decimal-pad'; multiligne?: boolean;
  /** e-mail, mot de passe (masqué) ou adresse web : clavier adapté, pas de majuscule automatique */
  genre?: 'email' | 'motDePasse' | 'url';
}) {
  return (
    <View style={{ paddingVertical: 6 }}>
      <Text style={[s.discret, { fontSize: police.mini, marginBottom: 4 }]}>{titre}</Text>
      <TextInput value={valeur} onChangeText={onChange} placeholder={placeholder} placeholderTextColor="#9AA3AC"
        keyboardType={genre === 'email' ? 'email-address' : genre === 'url' ? 'url' : clavier ?? 'default'}
        secureTextEntry={genre === 'motDePasse'} autoCapitalize={genre ? 'none' : 'sentences'} autoCorrect={!genre}
        autoComplete={genre === 'email' ? 'email' : genre === 'motDePasse' ? 'password' : undefined}
        multiline={multiligne} style={{ borderWidth: 1, borderColor: C.ligne, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 8, color: C.encre, fontSize: police.normal, minHeight: multiligne ? 64 : undefined, textAlignVertical: multiligne ? 'top' : 'center' }} />
    </View>
  );
}

/** Puces de choix (une seule valeur). */
export function Puces<T extends string | number>({ options, valeur, onChange }: { options: [T, string][]; valeur: T | null; onChange: (v: T) => void }) {
  return (
    <View style={[s.ligne, { gap: 8, flexWrap: 'wrap' }]}>
      {options.map(([v, txt]) => (
        <Pressable key={String(v)} onPress={() => onChange(v)} style={[s.puce, v === valeur && s.puceActive]}>
          <Text style={[s.puceTxt, { fontSize: police.petit }, v === valeur && { fontWeight: '700' }]}>{txt}</Text>
        </Pressable>
      ))}
    </View>
  );
}

/** Ligne cliquable vers un autre écran. */
export function LigneLien({ titre, detail, onPress, alerte }: { titre: string; detail?: string; onPress: () => void; alerte?: boolean }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [s.ligne, { paddingVertical: 11, borderTopWidth: 1, borderTopColor: C.ligne, opacity: pressed ? 0.6 : 1 }]}>
      <View style={{ flex: 1 }}>
        <Text style={{ color: C.encre, fontSize: police.normal }}>{titre}</Text>
        {!!detail && <Text style={[s.discret, { fontSize: police.mini, color: alerte ? C.alerte : C.discret }]}>{detail}</Text>}
      </View>
      <Text style={{ color: C.discret, fontSize: 20 }}>›</Text>
    </Pressable>
  );
}

/** Bandeau d'alerte global (moteur d'alertes), affiché quelques secondes en haut de l'écran. */
export function BandeauAlerte() {
  const b = useEtat((e) => e.bandeau);
  const now = useMaintenant(1000);
  if (!b || now - b.ms > 6000) return null;
  return (
    <Pressable onPress={() => store.set({ bandeau: null })} style={{ position: 'absolute', top: 40, left: 12, right: 12, zIndex: 100, backgroundColor: b.grave ? C.alerte : C.encre, borderRadius: 12, padding: 12, elevation: 8 }}>
      <Text style={{ color: '#fff', fontWeight: '700' }}>{b.texte}</Text>
    </Pressable>
  );
}
