/** Animations légères (API Animated de React Native, sur le fil natif) : apparition des cartes, appui des boutons,
 *  bandeau. Coupées si le téléphone demande moins d'animations (Accessibilité → Supprimer les animations). */
import { AccessibilityInfo, LayoutAnimation } from 'react-native';

let reduire = false;
AccessibilityInfo.isReduceMotionEnabled().then((v) => { reduire = v; }).catch(() => {});
AccessibilityInfo.addEventListener?.('reduceMotionChanged', (v) => { reduire = v; });
/** Vrai si le téléphone demande de réduire les animations. */
export const animationsReduites = () => reduire;

export const DUREE = { courte: 160, normale: 220, longue: 300 };

/** Avant un changement de mise en page (section qui s'ouvre, liste filtrée) : les éléments glissent à leur place. */
export function deplier() {
  if (!reduire) LayoutAnimation.configureNext(LayoutAnimation.create(DUREE.normale, LayoutAnimation.Types.easeInEaseOut, LayoutAnimation.Properties.opacity));
}
