/** Carte « Application » de l'écran Mises à jour : version installée, dernière version publiée sur GitHub, téléchargement. */
import React, { useState } from 'react';
import { ActivityIndicator, Text } from 'react-native';
import { Bouton, Carte, Titre, s } from './composants';
import { C, police } from './theme';
import { lireValeur } from '../db';
import { BUILD, derniereVersion, plusRecente, telechargerApk, type VersionDispo } from '../services/majAppli';

export function CarteAppli() {
  const [v, setV] = useState<VersionDispo | null>(() => lireValeur<{ dispo: VersionDispo | null }>('majAppli')?.dispo ?? null);
  const [etat, setEtat] = useState<'' | 'charge' | 'aJour' | string>('');
  const verifier = () => {
    setEtat('charge');
    derniereVersion().then((x) => { setV(x); setEtat(plusRecente(x) ? '' : 'aJour'); }).catch((e) => setEtat(String((e as Error).message ?? e)));
  };
  const nouvelle = plusRecente(v);
  return (
    <Carte style={nouvelle ? { borderColor: C.accent, borderWidth: 2 } : undefined}>
      <Titre>Application</Titre>
      <Text style={{ color: C.encre }}>Version installée : {BUILD ? `n° ${BUILD}` : 'compilée hors GitHub'}</Text>
      {nouvelle && v && (
        <>
          <Text style={{ color: C.encre, fontWeight: '800', marginTop: 6 }}>Nouvelle version n° {v.build}{v.date ? ` du ${new Date(v.date).toLocaleDateString('fr-FR')}` : ''} ({Math.round(v.taille / 1e6)} Mo)</Text>
          {!!v.notes && <Text style={[s.discret, { marginTop: 2 }]}>{v.notes.slice(0, 400)}</Text>}
          <Text style={[s.discret, { fontSize: police.mini, marginVertical: 6 }]}>Le téléchargement s'ouvre dans le navigateur ; touchez ensuite le fichier pour l'installer (Android demande d'autoriser l'installation la première fois). Le carnet et les réglages sont conservés.</Text>
          <Bouton titre="Télécharger et installer" plein onPress={() => telechargerApk(v)} />
        </>
      )}
      {etat === 'charge' ? <ActivityIndicator color={C.encre} style={{ marginTop: 8 }} />
        : <Text style={[s.discret, { marginVertical: 6, color: etat && etat !== 'aJour' ? C.alerte : C.discret }]}>{etat === 'aJour' ? 'L\'appli est à jour.' : etat}</Text>}
      {!nouvelle && <Bouton titre="Chercher une nouvelle version" onPress={verifier} />}
    </Carte>
  );
}
