/** Réglage par boutons − / + . L'envoi est retardé de 0,7 s après le dernier appui (le toit enregistre chaque changement). */
import React, { useEffect, useRef, useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { C, police } from './theme';
import { s } from './composants';

type Props = {
  titre: string; aide?: string; valeur: number | null; pas: number; min: number; max: number;
  format: (v: number) => string; envoyer: (v: number) => void; alerte?: (v: number) => string | null;
};

export function Pas({ titre, aide, valeur, pas, min, max, format, envoyer, alerte }: Props) {
  const [local, setLocal] = useState<number | null>(valeur);
  const minuterie = useRef<ReturnType<typeof setTimeout> | null>(null);
  const enAttente = useRef(false);
  useEffect(() => { if (!enAttente.current) setLocal(valeur); }, [valeur]);
  const changer = (d: number) => {
    if (local === null) return;
    const v = Math.min(max, Math.max(min, +(local + d).toFixed(2)));
    setLocal(v); enAttente.current = true;
    if (minuterie.current) clearTimeout(minuterie.current);
    minuterie.current = setTimeout(() => { enAttente.current = false; envoyer(v); }, 700);
  };
  const b = { width: 40, height: 38, borderRadius: 8, borderWidth: 1, borderColor: C.ligne, alignItems: 'center' as const, justifyContent: 'center' as const, opacity: local === null ? 0.4 : 1 };
  const msg = local !== null && alerte ? alerte(local) : null;
  return (
    <View style={{ paddingVertical: 8, borderTopWidth: 1, borderTopColor: C.ligne }}>
      <View style={s.ligne}>
        <View style={{ flex: 1, paddingRight: 8 }}>
          <Text style={{ color: C.encre, fontSize: police.normal }}>{titre}</Text>
          {!!aide && <Text style={[s.discret, { fontSize: police.mini }]}>{aide}</Text>}
        </View>
        <Pressable onPress={() => changer(-pas)} style={b} disabled={local === null}><Text style={{ fontSize: 20, color: C.encre }}>−</Text></Pressable>
        <Text style={{ width: 78, textAlign: 'center', color: C.encre, fontWeight: '700', fontVariant: ['tabular-nums'] }}>{local === null ? '—' : format(local)}</Text>
        <Pressable onPress={() => changer(pas)} style={b} disabled={local === null}><Text style={{ fontSize: 20, color: C.encre }}>+</Text></Pressable>
      </View>
      {!!msg && <Text style={{ color: C.alerte, fontSize: police.mini, marginTop: 4 }}>{msg}</Text>}
    </View>
  );
}

export const signe = (v: number, dec = 0) => `${v > 0 ? '+' : v < 0 ? '−' : ''}${Math.abs(v).toFixed(dec).replace('.', ',')}`;
