/**
 * Envoi d'une commande au toit : par Bluetooth, ou au toit simulé pendant la sortie simulée.
 * Le toit simulé répond comme le firmware de la carte chef (phone.c, calib.c) : lignes C et K.
 */
import { toit } from './ble';
import { etalonnageSimule, recevoirLigneToit, store } from '../store/store';

const cfg = { fwd: 0, beam: 70, gains: [0, 0, 0, 0], vmin: 4 };
let calMinuterie: ReturnType<typeof setInterval> | null = null;
let calN = -1;

const repondre = (l: string) => setTimeout(() => recevoirLigneToit(l, store.get().horlogeMs), 150);
const ligneC = () => `C,${cfg.fwd.toFixed(0)},${cfg.beam.toFixed(0)},${cfg.gains.map((g) => g.toFixed(1)).join(',')},${cfg.vmin.toFixed(0)}`;

function simuler(c: string) {
  const [cmd, a, b] = c.trim().split(/\s+/);
  switch (cmd) {
    case 'cfg': break;
    case 'fwd': cfg.fwd = Number(a); break;
    case 'beam': cfg.beam = Number(a); break;
    case 'vmin': cfg.vmin = Number(a); break;
    case 'gain': if (Number(a) >= 0 && Number(a) < 4) cfg.gains[Number(a)] = Number(b); break;
    case 'calpos': repondre('K,POS'); return;
    case 'cal':
      repondre('K,GO'); calN = 0;
      if (calMinuterie) clearInterval(calMinuterie);
      calMinuterie = setInterval(() => { calN += 1 + Math.round(Math.random() * 2) * (store.get().vitesseSim >= 10 ? 2 : 1); etalonnageSimule({ n: calN }); }, 1000);
      return;
    case 'calfin': {
      if (calMinuterie) clearInterval(calMinuterie); calMinuterie = null;
      const n = calN; calN = -1;
      if (n < 40) { repondre(`K,ERR,trop peu de trames (${n})`); etalonnageSimule({ n: -1, enCours: false }); return; }
      cfg.fwd = (cfg.fwd + 2 + 360) % 360; cfg.beam = 64; cfg.gains = [0, 1.5, -0.5, 2];
      repondre(`K,${cfg.fwd},${cfg.beam},${cfg.gains.map((g) => g.toFixed(1)).join(',')},9,${n}`);
      return;
    }
    case 'maj': repondre('K,MAJ,TOIT,4'); return;
    case 'nid': repondre('K,NID'); return;
    default: return; // reset, off, auto : pas de réponse
  }
  repondre(ligneC());
}

export async function envoyerToit(cmd: string) {
  if (store.get().source === 'simulation') { simuler(cmd); return; }
  await toit.envoyer(cmd);
}
