/** Récepteur portatif : liaison Bluetooth (« RX-Frelons ») ou portatif simulé, même interface pour l'écran. */
import { LiaisonUart, NOM_PORTATIF } from './ble';
import { PortatifSimule } from '../sim/portatifSimule';
import { recevoirLignePortatif, store } from '../store/store';

const liaison = new LiaisonUart(
  NOM_PORTATIF,
  (l) => recevoirLignePortatif(l),
  (connexion, message) => store.portatif({ connexion, message }),
);
let sim: PortatifSimule | null = null;

export async function connecterPortatif() {
  arreterSimulationPortatif();
  store.portatifAZero({ source: 'ble' });
  await liaison.connecter();
}

export function simulerPortatif() {
  liaison.deconnecter().catch(() => {});
  arreterSimulationPortatif();
  store.portatifAZero({ source: 'simulation', connexion: 'connecte', message: 'Portatif simulé : vous êtes à 170 m du nid du tag 007' });
  sim = new PortatifSimule(recevoirLignePortatif, () => (store.get().vitesseSim >= 10 ? 4 : 1));
  sim.demarrer();
}

function arreterSimulationPortatif() { sim?.arreter(); sim = null; }

export async function deconnecterPortatif() {
  arreterSimulationPortatif();
  await liaison.deconnecter().catch(() => {});
  store.portatif({ connexion: 'arrete', message: '' });
}

/** Envoie une commande au portatif (vrai ou simulé). */
export async function envoyerPortatif(cmd: string) {
  if (sim) { sim.commande(cmd); return; }
  await liaison.envoyer(cmd);
}
