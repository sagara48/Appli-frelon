/** Récepteur portatif : liaison Bluetooth (« RX-Frelons ») ou portatif simulé, même interface pour l'écran. */
import { LiaisonUart } from './ble';
import { param } from '../services/parametres';
import { PortatifSimule } from '../sim/portatifSimule';
import { recevoirLignePortatif, store } from '../store/store';
import { parsePortatif } from '../proto/portatif';
import { FIRMWARE_PREVU, PROTO_PORTATIF } from '../calc/versions';

const liaison = new LiaisonUart(
  'portatif', () => param().nomPortatif,
  (l) => recevoirLignePortatif(l),
  (connexion, message) => { if (store.get().portatif.source === 'ble') store.portatif({ connexion, message }); },
  (l) => parsePortatif(l) !== null,
);
liaison.surConnexion = () => { liaison.envoyer('ver').catch(() => {}); }; // versions du firmware à chaque (re)connexion
let sim: PortatifSimule | null = null;
/** La liaison elle-même (connexion automatique). */
export const liaisonPortatif = liaison;
/** Appareil portatif connecté (pour la mise à jour par Bluetooth). */
export const appareilPortatif = () => liaison.appareil;

export async function connecterPortatif() {
  arreterSimulationPortatif();
  store.portatifAZero({ source: 'ble' });
  await liaison.connecter();
}

export function simulerPortatif() {
  liaison.deconnecter().catch(() => {});
  arreterSimulationPortatif();
  store.portatifAZero({ source: 'simulation', connexion: 'connecte', message: 'Portatif simulé : vous êtes à 170 m du nid du tag 007' });
  sim = new PortatifSimule(recevoirLignePortatif, () => (store.get().vitesseSim >= 10 ? 4 : 1));
  sim.demarrer();
  // le portatif simulé annonce les versions livrées avec l'appli
  recevoirLignePortatif(JSON.stringify({ type: 'ver', fw: FIRMWARE_PREVU.portatif, proto: PROTO_PORTATIF }));
}

function arreterSimulationPortatif() { sim?.arreter(); sim = null; }

export async function deconnecterPortatif() {
  arreterSimulationPortatif();
  await liaison.deconnecter().catch(() => {});
  store.portatif({ connexion: 'arrete', message: '' });
}

/** Envoie une commande au portatif (vrai ou simulé). */
export async function envoyerPortatif(cmd: string) {
  if (sim) { sim.commande(cmd); return; }
  await liaison.envoyer(cmd);
}
