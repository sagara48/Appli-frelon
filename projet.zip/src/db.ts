/**
 * Base locale SQLite (cahier des charges, « Données ») : carnet des nids, tags, ruchers, petites valeurs (réglages, appâts).
 * Les fonctions ne lèvent pas d'exception : en aperçu web ou si la base est indisponible, elles renvoient des valeurs vides.
 */
import * as SQLite from 'expo-sqlite';

let db: SQLite.SQLiteDatabase | null = null;

const SCHEMA = `
  PRAGMA journal_mode = WAL;
  CREATE TABLE IF NOT EXISTS nid (id INTEGER PRIMARY KEY AUTOINCREMENT, tag INTEGER NOT NULL, t INTEGER NOT NULL, lat REAL NOT NULL, lon REAL NOT NULL,
    err REAL, etat TEXT NOT NULL DEFAULT 'estime', note TEXT);
  CREATE TABLE IF NOT EXISTS reglage (cle TEXT PRIMARY KEY, valeur TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS tag (id INTEGER PRIMARY KEY, etat TEXT NOT NULL DEFAULT 'dispo', pose_ms INTEGER, appat INTEGER,
    lat REAL, lon REAL, note TEXT, maj_ms INTEGER NOT NULL DEFAULT 0);
  CREATE TABLE IF NOT EXISTS rucher (id INTEGER PRIMARY KEY AUTOINCREMENT, nom TEXT NOT NULL, ruches INTEGER, lat REAL NOT NULL, lon REAL NOT NULL, note TEXT);
  CREATE TABLE IF NOT EXISTS piege (id INTEGER PRIMARY KEY AUTOINCREMENT, nom TEXT NOT NULL, lat REAL NOT NULL, lon REAL NOT NULL, appat TEXT, pose_ms INTEGER,
    retire_ms INTEGER, releves TEXT NOT NULL DEFAULT '[]', note TEXT, uid TEXT, maj_ms INTEGER NOT NULL DEFAULT 0, supprime INTEGER NOT NULL DEFAULT 0, auteur TEXT);
  CREATE UNIQUE INDEX IF NOT EXISTS piege_uid ON piege(uid);
`;
/** Colonnes du partage entre téléphones : identifiant commun, date de modification, suppression différée, auteur. */
const PARTAGE: [string, string][] = [['uid', 'TEXT'], ['maj_ms', 'INTEGER NOT NULL DEFAULT 0'], ['supprime', 'INTEGER NOT NULL DEFAULT 0'], ['auteur', 'TEXT']];
const UID = 'lower(hex(randomblob(16)))';
/** Colonnes ajoutées au carnet des nids après la première version (migration douce). */
const COLONNES_NID: [string, string][] = [
  ['sources', 'TEXT'], ['support', 'TEXT'], ['hauteur', 'TEXT'], ['diametre', 'TEXT'], ['activite', 'TEXT'], ['photos', "TEXT DEFAULT '[]'"],
  ['inter_ms', 'INTEGER'], ['methode', 'TEXT'], ['produit', 'TEXT'], ['quantite', 'TEXT'], ['operateur', 'TEXT'], ['traite_ms', 'INTEGER'], ['verifie_ms', 'INTEGER'],
  ...PARTAGE,
];

export function base(): SQLite.SQLiteDatabase {
  if (db) return db;
  const d = SQLite.openDatabaseSync('frelons.db');
  d.execSync(SCHEMA);
  const cols = d.getAllSync<{ name: string }>('PRAGMA table_info(nid)').map((c) => c.name);
  for (const [c, type] of COLONNES_NID) if (!cols.includes(c)) d.execSync(`ALTER TABLE nid ADD COLUMN ${c} ${type}`);
  // pile et recharge des tags (rappel de recharge)
  const colsT = d.getAllSync<{ name: string }>('PRAGMA table_info(tag)').map((c) => c.name);
  for (const [c, type] of [['pile', 'INTEGER'], ['pile_ms', 'INTEGER'], ['recharge_ms', 'INTEGER']]) if (!colsT.includes(c)) d.execSync(`ALTER TABLE tag ADD COLUMN ${c} ${type}`);
  const colsR = d.getAllSync<{ name: string }>('PRAGMA table_info(rucher)').map((c) => c.name);
  for (const [c, type] of PARTAGE) if (!colsR.includes(c)) d.execSync(`ALTER TABLE rucher ADD COLUMN ${c} ${type}`);
  // fiches d'avant le partage : identifiant commun et date de modification
  d.execSync(`UPDATE nid SET uid = ${UID} WHERE uid IS NULL; UPDATE nid SET maj_ms = t WHERE maj_ms = 0;
    UPDATE rucher SET uid = ${UID} WHERE uid IS NULL; UPDATE rucher SET maj_ms = 1 WHERE maj_ms = 0;
    CREATE UNIQUE INDEX IF NOT EXISTS nid_uid ON nid(uid); CREATE UNIQUE INDEX IF NOT EXISTS rucher_uid ON rucher(uid);`);
  db = d;
  return d;
}
const sur = <T,>(f: () => T, defaut: T): T => { try { return f(); } catch { return defaut; } };

/* ---------- petites valeurs (JSON) ---------- */
export function lireValeur<T>(cle: string): T | null {
  return sur(() => { const r = base().getFirstSync<{ valeur: string }>('SELECT valeur FROM reglage WHERE cle = ?', cle); return r ? (JSON.parse(r.valeur) as T) : null; }, null);
}
export function ecrireValeur(cle: string, v: unknown) {
  sur(() => base().runSync('INSERT OR REPLACE INTO reglage (cle, valeur) VALUES (?, ?)', cle, JSON.stringify(v)), null);
}

/* ---------- carnet des nids ---------- */
export type EtatNid = 'estime' | 'trouve' | 'traite' | 'mort';
export type Nid = {
  id: number; tag: number; t: number; lat: number; lon: number; err: number; etat: EtatNid; note: string;
  sources: string; support: string; hauteur: string; diametre: string; activite: string; photos: string[];
  inter_ms: number | null; methode: string; produit: string; quantite: string; operateur: string; traite_ms: number | null; verifie_ms: number | null;
  uid: string; maj_ms: number; auteur: string;
};
type LigneNid = Omit<Nid, 'photos'> & { photos: string | null };
const versNid = (r: LigneNid): Nid => ({
  ...r, err: r.err ?? 0, note: r.note ?? '', sources: r.sources ?? '', support: r.support ?? '', hauteur: r.hauteur ?? '', diametre: r.diametre ?? '',
  auteur: r.auteur ?? '', activite: r.activite ?? '', methode: r.methode ?? '', produit: r.produit ?? '', quantite: r.quantite ?? '', operateur: r.operateur ?? '',
  etat: (r.etat === 'estime' ? 'trouve' : r.etat) as EtatNid, photos: sur(() => JSON.parse(r.photos ?? '[]') as string[], []),
});
export const lireNids = (): Nid[] => sur(() => base().getAllSync<LigneNid>('SELECT * FROM nid WHERE supprime = 0 ORDER BY t DESC').map(versNid), []);

export function ajouterNid(tag: number, lat: number, lon: number, err: number, sources: string): number {
  return sur(() => Number(base().runSync(`INSERT INTO nid (tag, t, lat, lon, err, etat, sources, photos, uid, maj_ms) VALUES (?, ?, ?, ?, ?, 'trouve', ?, '[]', ${UID}, ?)`,
    tag, Date.now(), lat, lon, err, sources, Date.now()).lastInsertRowId), 0);
}
const CHAMPS_NID = ['lat', 'lon', 'err', 'etat', 'note', 'support', 'hauteur', 'diametre', 'activite', 'photos', 'inter_ms', 'methode', 'produit', 'quantite', 'operateur', 'traite_ms', 'verifie_ms'] as const;
export function modifierNid(id: number, champs: Partial<Nid>) {
  const cles = CHAMPS_NID.filter((c) => c in champs);
  if (!cles.length) return;
  const vals = cles.map((c) => (c === 'photos' ? JSON.stringify(champs.photos ?? []) : (champs as Record<string, unknown>)[c] ?? null));
  sur(() => base().runSync(`UPDATE nid SET ${cles.map((c) => `${c} = ?`).join(', ')}, maj_ms = ? WHERE id = ?`, ...(vals as SQLite.SQLiteBindValue[]), Date.now(), id), null);
}
/** Suppression différée : la fiche reste marquée supprimée pour que les autres téléphones l'effacent aussi. */
export const supprimerNid = (id: number) => sur(() => base().runSync('UPDATE nid SET supprime = 1, maj_ms = ? WHERE id = ?', Date.now(), id), null);

/* ---------- tags ---------- */
export type EtatTag = 'dispo' | 'pose' | 'recupere' | 'perdu';
export type FicheTag = {
  id: number; etat: EtatTag; pose_ms: number | null; appat: number | null; lat: number | null; lon: number | null; note: string; maj_ms: number;
  pile: number | null; pile_ms: number | null; recharge_ms: number | null; // dernière pile entendue (%) et dernière recharge notée
};
export const lireTags = (): FicheTag[] => sur(() => base().getAllSync<FicheTag>('SELECT * FROM tag ORDER BY id').map((t) => ({ ...t, note: t.note ?? '', pile: t.pile ?? null, pile_ms: t.pile_ms ?? null, recharge_ms: t.recharge_ms ?? null })), []);
export function ecrireTag(t: FicheTag) {
  sur(() => base().runSync('INSERT OR REPLACE INTO tag (id, etat, pose_ms, appat, lat, lon, note, maj_ms, pile, pile_ms, recharge_ms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    t.id, t.etat, t.pose_ms, t.appat, t.lat, t.lon, t.note, Date.now(), t.pile ?? null, t.pile_ms ?? null, t.recharge_ms ?? null), null);
}

/* ---------- ruchers ---------- */
export type Rucher = { id: number; nom: string; ruches: number | null; lat: number; lon: number; note: string; uid: string; maj_ms: number; auteur: string };
export const lireRuchers = (): Rucher[] => sur(() => base().getAllSync<Rucher>('SELECT * FROM rucher WHERE supprime = 0 ORDER BY id').map((r) => ({ ...r, note: r.note ?? '', auteur: r.auteur ?? '' })), []);
export const ajouterRucher = (nom: string, ruches: number | null, lat: number, lon: number) =>
  sur(() => Number(base().runSync(`INSERT INTO rucher (nom, ruches, lat, lon, uid, maj_ms) VALUES (?, ?, ?, ?, ${UID}, ?)`, nom, ruches, lat, lon, Date.now()).lastInsertRowId), 0);
export const supprimerRucher = (id: number) => sur(() => base().runSync('UPDATE rucher SET supprime = 1, maj_ms = ? WHERE id = ?', Date.now(), id), null);

/* ---------- pièges à fondatrices ---------- */
/** Un relevé : frelons asiatiques capturés depuis le relevé précédent, autres insectes, remarque. */
export type Releve = { t: number; frelons: number; autres: number; note: string };
export type Piege = {
  id: number; nom: string; lat: number; lon: number; appat: string; pose_ms: number | null; retire_ms: number | null; releves: Releve[]; note: string;
  uid: string; maj_ms: number; auteur: string;
};
type LignePiege = Omit<Piege, 'releves'> & { releves: string | null };
export const lirePieges = (): Piege[] => sur(() => base().getAllSync<LignePiege>('SELECT * FROM piege WHERE supprime = 0 ORDER BY id').map((r) => ({
  ...r, appat: r.appat ?? '', note: r.note ?? '', auteur: r.auteur ?? '', releves: sur(() => JSON.parse(r.releves ?? '[]') as Releve[], []),
})), []);
export const ajouterPiege = (nom: string, lat: number, lon: number, appat: string) =>
  sur(() => Number(base().runSync(`INSERT INTO piege (nom, lat, lon, appat, pose_ms, releves, uid, maj_ms) VALUES (?, ?, ?, ?, ?, '[]', ${UID}, ?)`, nom, lat, lon, appat, Date.now(), Date.now()).lastInsertRowId), 0);
const CHAMPS_PIEGE = ['nom', 'lat', 'lon', 'appat', 'pose_ms', 'retire_ms', 'releves', 'note'] as const;
export function modifierPiege(id: number, champs: Partial<Piege>) {
  const cles = CHAMPS_PIEGE.filter((c) => c in champs);
  if (!cles.length) return;
  const vals = cles.map((c) => (c === 'releves' ? JSON.stringify(champs.releves ?? []) : (champs as Record<string, unknown>)[c] ?? null));
  sur(() => base().runSync(`UPDATE piege SET ${cles.map((c) => `${c} = ?`).join(', ')}, maj_ms = ? WHERE id = ?`, ...(vals as SQLite.SQLiteBindValue[]), Date.now(), id), null);
}
export const supprimerPiege = (id: number) => sur(() => base().runSync('UPDATE piege SET supprime = 1, maj_ms = ? WHERE id = ?', Date.now(), id), null);

/* ---------- partage entre téléphones ---------- */
/** Champs partagés (les photos restent sur le téléphone qui les a prises). */
export const CHAMPS_PARTAGES = {
  nid: ['tag', 't', 'lat', 'lon', 'err', 'etat', 'note', 'sources', 'support', 'hauteur', 'diametre', 'activite', 'inter_ms', 'methode', 'produit', 'quantite', 'operateur', 'traite_ms', 'verifie_ms'],
  rucher: ['nom', 'ruches', 'lat', 'lon', 'note'],
  piege: ['nom', 'lat', 'lon', 'appat', 'pose_ms', 'retire_ms', 'releves', 'note'],
} as const;
export type TypePartage = keyof typeof CHAMPS_PARTAGES;
export type FichePartagee = { uid: string; type: TypePartage; data: Record<string, unknown>; maj_ms: number; supprime: boolean; auteur: string };

/** Fiches modifiées sur ce téléphone depuis `depuis` (ms), suppressions comprises. */
export function fichesModifiees(depuis: number): FichePartagee[] {
  return sur(() => (Object.keys(CHAMPS_PARTAGES) as TypePartage[]).flatMap((type) =>
    base().getAllSync<Record<string, unknown>>(`SELECT * FROM ${type} WHERE maj_ms > ?`, depuis).map((r) => ({
      uid: String(r.uid), type, maj_ms: Number(r.maj_ms), supprime: !!r.supprime, auteur: String(r.auteur ?? ''),
      data: Object.fromEntries(CHAMPS_PARTAGES[type].map((c) => [c, r[c] ?? null])),
    }))), []);
}

/** Applique une fiche reçue d'un autre téléphone si elle est plus récente que la nôtre. Renvoie vrai si quelque chose a changé. */
export function appliquerFiche(f: FichePartagee): boolean {
  return sur(() => {
    const d = base();
    const loc = d.getFirstSync<{ id: number; maj_ms: number }>(`SELECT id, maj_ms FROM ${f.type} WHERE uid = ?`, f.uid);
    if (loc && loc.maj_ms >= f.maj_ms) return false;
    const champs = CHAMPS_PARTAGES[f.type].filter((c) => c in f.data);
    const vals = champs.map((c) => (f.data[c] ?? null) as SQLite.SQLiteBindValue);
    if (loc) {
      d.runSync(`UPDATE ${f.type} SET ${champs.map((c) => `${c} = ?`).join(', ')}, maj_ms = ?, supprime = ?, auteur = ? WHERE id = ?`, ...vals, f.maj_ms, f.supprime ? 1 : 0, f.auteur, loc.id);
    } else {
      if (f.supprime) return false; // jamais connue ici : rien à effacer
      const extra = f.type === 'nid' ? ", photos" : '';
      d.runSync(`INSERT INTO ${f.type} (${champs.join(', ')}${extra}, uid, maj_ms, supprime, auteur) VALUES (${champs.map(() => '?').join(', ')}${f.type === 'nid' ? ", '[]'" : ''}, ?, ?, 0, ?)`,
        ...vals, f.uid, f.maj_ms, f.auteur);
    }
    return true;
  }, false);
}

/* ---------- sauvegarde complète ---------- */
export type Sauvegarde = { version: 1; date: number; nids: Record<string, unknown>[]; tags: Record<string, unknown>[]; ruchers: Record<string, unknown>[]; pieges?: Record<string, unknown>[]; reglages: { cle: string; valeur: string }[] };
/** Tout le contenu de la base (fiches supprimées comprises, pour le partage). */
export function toutLire(): Sauvegarde {
  const d = base();
  return {
    version: 1, date: Date.now(),
    nids: d.getAllSync<Record<string, unknown>>('SELECT * FROM nid'),
    tags: d.getAllSync<Record<string, unknown>>('SELECT * FROM tag'),
    ruchers: d.getAllSync<Record<string, unknown>>('SELECT * FROM rucher'),
    pieges: d.getAllSync<Record<string, unknown>>('SELECT * FROM piege'),
    reglages: d.getAllSync<{ cle: string; valeur: string }>('SELECT * FROM reglage'),
  };
}
/** Remplace tout le contenu de la base par une sauvegarde (en une transaction : tout ou rien). */
export function toutRemplacer(s: Sauvegarde) {
  const d = base();
  const inserer = (table: string, lignes: Record<string, unknown>[]) => {
    const cols = new Set(d.getAllSync<{ name: string }>(`PRAGMA table_info(${table})`).map((c) => c.name));
    for (const l of lignes) {
      const k = Object.keys(l).filter((c) => cols.has(c));
      d.runSync(`INSERT INTO ${table} (${k.join(', ')}) VALUES (${k.map(() => '?').join(', ')})`, ...k.map((c) => l[c] as SQLite.SQLiteBindValue));
    }
  };
  d.withTransactionSync(() => {
    d.execSync('DELETE FROM nid; DELETE FROM tag; DELETE FROM rucher; DELETE FROM piege; DELETE FROM reglage;');
    inserer('nid', s.nids); inserer('tag', s.tags); inserer('rucher', s.ruchers); inserer('piege', s.pieges ?? []);
    for (const r of s.reglages) d.runSync('INSERT OR REPLACE INTO reglage (cle, valeur) VALUES (?, ?)', r.cle, r.valeur);
    d.execSync(`UPDATE nid SET uid = ${UID} WHERE uid IS NULL; UPDATE rucher SET uid = ${UID} WHERE uid IS NULL; UPDATE piege SET uid = ${UID} WHERE uid IS NULL;`);
  });
}
