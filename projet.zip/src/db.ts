/**
 * Base locale SQLite (cahier des charges, « Données ») : carnet des nids, tags, ruchers, petites valeurs (réglages, appâts).
 * Les fonctions ne lèvent pas d'exception : en aperçu web ou si la base est indisponible, elles renvoient des valeurs vides.
 */
import * as SQLite from 'expo-sqlite';

let db: SQLite.SQLiteDatabase | null = null;

const SCHEMA = `
  PRAGMA journal_mode = WAL;
  CREATE TABLE IF NOT EXISTS nid (id INTEGER PRIMARY KEY AUTOINCREMENT, tag INTEGER NOT NULL, t INTEGER NOT NULL, lat REAL NOT NULL, lon REAL NOT NULL,
    err REAL, etat TEXT NOT NULL DEFAULT 'estime', note TEXT);
  CREATE TABLE IF NOT EXISTS reglage (cle TEXT PRIMARY KEY, valeur TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS tag (id INTEGER PRIMARY KEY, etat TEXT NOT NULL DEFAULT 'dispo', pose_ms INTEGER, appat INTEGER,
    lat REAL, lon REAL, note TEXT, maj_ms INTEGER NOT NULL DEFAULT 0);
  CREATE TABLE IF NOT EXISTS rucher (id INTEGER PRIMARY KEY AUTOINCREMENT, nom TEXT NOT NULL, ruches INTEGER, lat REAL NOT NULL, lon REAL NOT NULL, note TEXT);
`;
/** Colonnes ajoutées au carnet des nids après la première version (migration douce). */
const COLONNES_NID: [string, string][] = [
  ['sources', 'TEXT'], ['support', 'TEXT'], ['hauteur', 'TEXT'], ['diametre', 'TEXT'], ['activite', 'TEXT'], ['photos', "TEXT DEFAULT '[]'"],
  ['inter_ms', 'INTEGER'], ['methode', 'TEXT'], ['produit', 'TEXT'], ['quantite', 'TEXT'], ['operateur', 'TEXT'], ['traite_ms', 'INTEGER'], ['verifie_ms', 'INTEGER'],
];

export function base(): SQLite.SQLiteDatabase {
  if (db) return db;
  const d = SQLite.openDatabaseSync('frelons.db');
  d.execSync(SCHEMA);
  const cols = d.getAllSync<{ name: string }>('PRAGMA table_info(nid)').map((c) => c.name);
  for (const [c, type] of COLONNES_NID) if (!cols.includes(c)) d.execSync(`ALTER TABLE nid ADD COLUMN ${c} ${type}`);
  db = d;
  return d;
}
const sur = <T,>(f: () => T, defaut: T): T => { try { return f(); } catch { return defaut; } };

/* ---------- petites valeurs (JSON) ---------- */
export function lireValeur<T>(cle: string): T | null {
  return sur(() => { const r = base().getFirstSync<{ valeur: string }>('SELECT valeur FROM reglage WHERE cle = ?', cle); return r ? (JSON.parse(r.valeur) as T) : null; }, null);
}
export function ecrireValeur(cle: string, v: unknown) {
  sur(() => base().runSync('INSERT OR REPLACE INTO reglage (cle, valeur) VALUES (?, ?)', cle, JSON.stringify(v)), null);
}

/* ---------- carnet des nids ---------- */
export type EtatNid = 'estime' | 'trouve' | 'traite' | 'mort';
export type Nid = {
  id: number; tag: number; t: number; lat: number; lon: number; err: number; etat: EtatNid; note: string;
  sources: string; support: string; hauteur: string; diametre: string; activite: string; photos: string[];
  inter_ms: number | null; methode: string; produit: string; quantite: string; operateur: string; traite_ms: number | null; verifie_ms: number | null;
};
type LigneNid = Omit<Nid, 'photos'> & { photos: string | null };
const versNid = (r: LigneNid): Nid => ({
  ...r, err: r.err ?? 0, note: r.note ?? '', sources: r.sources ?? '', support: r.support ?? '', hauteur: r.hauteur ?? '', diametre: r.diametre ?? '',
  activite: r.activite ?? '', methode: r.methode ?? '', produit: r.produit ?? '', quantite: r.quantite ?? '', operateur: r.operateur ?? '',
  etat: (r.etat === 'estime' ? 'trouve' : r.etat) as EtatNid, photos: sur(() => JSON.parse(r.photos ?? '[]') as string[], []),
});
export const lireNids = (): Nid[] => sur(() => base().getAllSync<LigneNid>('SELECT * FROM nid ORDER BY t DESC').map(versNid), []);

export function ajouterNid(tag: number, lat: number, lon: number, err: number, sources: string): number {
  return sur(() => Number(base().runSync("INSERT INTO nid (tag, t, lat, lon, err, etat, sources, photos) VALUES (?, ?, ?, ?, ?, 'trouve', ?, '[]')",
    tag, Date.now(), lat, lon, err, sources).lastInsertRowId), 0);
}
const CHAMPS_NID = ['lat', 'lon', 'err', 'etat', 'note', 'support', 'hauteur', 'diametre', 'activite', 'photos', 'inter_ms', 'methode', 'produit', 'quantite', 'operateur', 'traite_ms', 'verifie_ms'] as const;
export function modifierNid(id: number, champs: Partial<Nid>) {
  const cles = CHAMPS_NID.filter((c) => c in champs);
  if (!cles.length) return;
  const vals = cles.map((c) => (c === 'photos' ? JSON.stringify(champs.photos ?? []) : (champs as Record<string, unknown>)[c] ?? null));
  sur(() => base().runSync(`UPDATE nid SET ${cles.map((c) => `${c} = ?`).join(', ')} WHERE id = ?`, ...(vals as SQLite.SQLiteBindValue[]), id), null);
}
export const supprimerNid = (id: number) => sur(() => base().runSync('DELETE FROM nid WHERE id = ?', id), null);

/* ---------- tags ---------- */
export type EtatTag = 'dispo' | 'pose' | 'recupere' | 'perdu';
export type FicheTag = { id: number; etat: EtatTag; pose_ms: number | null; appat: number | null; lat: number | null; lon: number | null; note: string; maj_ms: number };
export const lireTags = (): FicheTag[] => sur(() => base().getAllSync<FicheTag>('SELECT * FROM tag ORDER BY id').map((t) => ({ ...t, note: t.note ?? '' })), []);
export function ecrireTag(t: FicheTag) {
  sur(() => base().runSync('INSERT OR REPLACE INTO tag (id, etat, pose_ms, appat, lat, lon, note, maj_ms) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    t.id, t.etat, t.pose_ms, t.appat, t.lat, t.lon, t.note, Date.now()), null);
}

/* ---------- ruchers ---------- */
export type Rucher = { id: number; nom: string; ruches: number | null; lat: number; lon: number; note: string };
export const lireRuchers = (): Rucher[] => sur(() => base().getAllSync<Rucher>('SELECT * FROM rucher ORDER BY id').map((r) => ({ ...r, note: r.note ?? '' })), []);
export const ajouterRucher = (nom: string, ruches: number | null, lat: number, lon: number) =>
  sur(() => Number(base().runSync('INSERT INTO rucher (nom, ruches, lat, lon) VALUES (?, ?, ?, ?)', nom, ruches, lat, lon).lastInsertRowId), 0);
export const supprimerRucher = (id: number) => sur(() => base().runSync('DELETE FROM rucher WHERE id = ?', id), null);
