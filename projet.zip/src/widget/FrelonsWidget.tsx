/** Widget d'écran d'accueil (Android) : tags posés, nids à traiter et à contrôler, pièges à relever, étape du calendrier,
 *  et deux raccourcis (Nid ici, Poser un tag). Chaque case ouvre l'écran correspondant de l'appli. */
import React from 'react';
import { FlexWidget, TextWidget } from 'react-native-android-widget';
import type { Resume } from './resume';

const FOND = '#14202E', CASE = '#1F2E40', TEXTE = '#F3F1EA', DISCRET = '#9AA7B4', ALERTE = '#F2A33A', ACCENT = '#F2C230';

function Case({ n, titre, uri, alerte }: { n: number; titre: string; uri: string; alerte?: boolean }) {
  return (
    <FlexWidget clickAction="OPEN_URI" clickActionData={{ uri }}
      style={{ flex: 1, height: 'match_parent', backgroundColor: CASE, borderRadius: 12, padding: 8, marginHorizontal: 3, flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
      <TextWidget text={String(n)} style={{ fontSize: 22, fontWeight: 'bold', color: alerte && n > 0 ? ALERTE : TEXTE }} />
      <TextWidget text={titre} maxLines={2} style={{ fontSize: 11, color: DISCRET, textAlign: 'center' }} />
    </FlexWidget>
  );
}
function Raccourci({ titre, uri }: { titre: string; uri: string }) {
  return (
    <FlexWidget clickAction="OPEN_URI" clickActionData={{ uri }}
      style={{ flex: 1, backgroundColor: ACCENT, borderRadius: 18, paddingVertical: 7, marginHorizontal: 3, alignItems: 'center', justifyContent: 'center' }}>
      <TextWidget text={titre} style={{ fontSize: 13, fontWeight: 'bold', color: FOND }} />
    </FlexWidget>
  );
}

export function FrelonsWidget({ r }: { r: Resume }) {
  return (
    <FlexWidget style={{ height: 'match_parent', width: 'match_parent', backgroundColor: FOND, borderRadius: 18, padding: 10, flexDirection: 'column' }}>
      <FlexWidget clickAction="OPEN_APP" style={{ width: 'match_parent', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 4, marginBottom: 6 }}>
        <TextWidget text="Frelons" style={{ fontSize: 15, fontWeight: 'bold', color: TEXTE }} />
        <TextWidget text={r.etape ? r.etape : `à jour ${r.heure}`} maxLines={1} truncate="END" style={{ fontSize: 11, color: DISCRET }} />
      </FlexWidget>
      <FlexWidget style={{ flex: 1, width: 'match_parent', flexDirection: 'row' }}>
        <Case n={r.tagsPoses} titre="tags posés" uri="frelons://tags" />
        <Case n={r.aTraiter} titre="nids à traiter" uri="frelons://nids" alerte />
        <Case n={r.aControler} titre="à contrôler" uri="frelons://registre" alerte />
        <Case n={r.pieges} titre="pièges à relever" uri="frelons://pieges" alerte />
      </FlexWidget>
      <FlexWidget style={{ width: 'match_parent', flexDirection: 'row', marginTop: 8 }}>
        <Raccourci titre="Nid ici" uri="frelons://nid-ici" />
        <Raccourci titre="Poser un tag" uri="frelons://pose-tag" />
      </FlexWidget>
    </FlexWidget>
  );
}
