/** Met le widget à jour depuis l'appli, quelques secondes après chaque changement du carnet (Android seulement). */
import React from 'react';
import { Platform } from 'react-native';
import { store } from '../store/store';
import { FrelonsWidget } from './FrelonsWidget';
import { calculerResume } from './resume';

let attente: ReturnType<typeof setTimeout> | null = null;
export function majWidget() {
  if (Platform.OS !== 'android') return;
  if (attente) clearTimeout(attente);
  attente = setTimeout(() => {
    attente = null;
    try {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const { requestWidgetUpdate } = require('react-native-android-widget') as typeof import('react-native-android-widget');
      requestWidgetUpdate({ widgetName: 'Frelons', renderWidget: () => <FrelonsWidget r={calculerResume(Date.now())} />, widgetNotFound: () => {} }).catch(() => {});
    } catch {}
  }, 3000);
}

/** Suit le carnet (nids, tags, pièges) et le met à jour au démarrage. */
export function demarrerWidget() {
  if (Platform.OS !== 'android') return () => {};
  let avant = store.get();
  majWidget();
  return store.abonner(() => {
    const e = store.get();
    if (e.nids !== avant.nids || e.fichesTags !== avant.fichesTags || e.pieges !== avant.pieges) majWidget();
    avant = e;
  });
}
