/** Met les widgets à jour depuis l'appli (Android seulement) :
 *  - « Frelons » (carnet) quelques secondes après chaque changement des nids, tags ou pièges ;
 *  - « Frelons – Sortie » toutes les 15 s au plus pendant une sortie, tout de suite quand le chrono change.
 *  Le dernier résumé de sortie est gardé dans la base : le widget l'affiche aussi appli fermée. */
import React from 'react';
import { Platform } from 'react-native';
import { ecrireValeur, lireValeur } from '../db';
import { store } from '../store/store';
import { FrelonsWidget } from './FrelonsWidget';
import { SortieWidget } from './SortieWidget';
import { calculerResume } from './resume';
import { resumeSortie, type ResumeSortie } from './sortie';

type Rw = typeof import('react-native-android-widget');
const rw = (): Rw | null => {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  try { return require('react-native-android-widget') as Rw; } catch { return null; }
};

let attente: ReturnType<typeof setTimeout> | null = null;
export function majWidget() {
  if (Platform.OS !== 'android') return;
  if (attente) clearTimeout(attente);
  attente = setTimeout(() => {
    attente = null;
    rw()?.requestWidgetUpdate({ widgetName: 'Frelons', renderWidget: () => <FrelonsWidget r={calculerResume(Date.now())} />, widgetNotFound: () => {} }).catch(() => {});
  }, 3000);
}

/** Résumé de sortie : celui de l'appli si une sortie est en cours, sinon le dernier gardé dans la base. */
export function resumeSortieActuel(): { r: ResumeSortie | null; micro: boolean } {
  let micro = false;
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    micro = (require('../services/voix') as typeof import('../services/voix')).etatVoix().actif;
  } catch { /* ignore */ }
  const e = store.get();
  const vivant = e.source !== 'aucune' || e.portatif.connexion === 'connecte';
  if (vivant) return { r: resumeSortie(e, Date.now()), micro };
  try { return { r: lireValeur<ResumeSortie>('widgetSortie'), micro }; } catch { return { r: null, micro }; }
}

let dernSortie = 0, attenteSortie: ReturnType<typeof setTimeout> | null = null;
function majSortie(tout = false) {
  if (Platform.OS !== 'android') return;
  const faire = () => {
    attenteSortie = null; dernSortie = Date.now();
    const { r, micro } = resumeSortieActuel();
    if (r) { try { ecrireValeur('widgetSortie', r); } catch { /* ignore */ } }
    rw()?.requestWidgetUpdate({ widgetName: 'FrelonsSortie', renderWidget: () => <SortieWidget r={r} maintenant={Date.now()} micro={micro} />, widgetNotFound: () => {} }).catch(() => {});
  };
  if (tout) { if (attenteSortie) clearTimeout(attenteSortie); faire(); return; }
  if (attenteSortie) return;
  attenteSortie = setTimeout(faire, Math.max(0, 15000 - (Date.now() - dernSortie)));
}
export const majWidgetSortie = () => majSortie(true);

/** Suit le carnet et la sortie, et met les widgets à jour au démarrage. */
export function demarrerWidget() {
  if (Platform.OS !== 'android') return () => {};
  let avant = store.get();
  majWidget(); majSortie(true);
  return store.abonner(() => {
    const e = store.get();
    if (e.nids !== avant.nids || e.fichesTags !== avant.fichesTags || e.pieges !== avant.pieges) majWidget();
    if (e.chrono !== avant.chrono || e.tagChoisi !== avant.tagChoisi || e.connexion !== avant.connexion || e.portatif.connexion !== avant.portatif.connexion) majSortie(true);
    else if (e.tags !== avant.tags || e.portatif.st !== avant.portatif.st || e.activites !== avant.activites) majSortie();
    avant = e;
  });
}
