/** Tâche des widgets (appelée par Android, même appli fermée) : ajout, mise à jour périodique, redimensionnement,
 *  et boutons Parti / Revenu du widget « sortie » (agissent si l'appli tourne : sortie en cours). */
import React from 'react';
import type { WidgetTaskHandlerProps } from 'react-native-android-widget';
import { FrelonsWidget } from './FrelonsWidget';
import { SortieWidget } from './SortieWidget';
import { calculerResume } from './resume';
import { resumeSortieActuel } from './majWidget';

export async function widgetTaskHandler({ widgetInfo, widgetAction, clickAction, renderWidget }: WidgetTaskHandlerProps) {
  if (widgetAction === 'WIDGET_DELETED') return;
  if (widgetInfo.widgetName === 'FrelonsSortie') {
    if (widgetAction === 'WIDGET_CLICK' && (clickAction === 'PARTI' || clickAction === 'REVENU')) {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const { executer } = require('../services/voix') as typeof import('../services/voix');
      const r = resumeSortieActuel();
      if (r.r?.actif) executer({ cmd: clickAction === 'PARTI' ? 'parti' : 'revenu' });
    } else if (widgetAction === 'WIDGET_CLICK') return;
    const r = resumeSortieActuel();
    renderWidget(<SortieWidget r={r.r} maintenant={Date.now()} micro={r.micro} />);
    return;
  }
  if (widgetAction === 'WIDGET_CLICK') return;
  renderWidget(<FrelonsWidget r={calculerResume(Date.now())} />);
}
