/** Tâche du widget (appelée par Android, même appli fermée) : ajout, mise à jour périodique, redimensionnement. */
import React from 'react';
import type { WidgetTaskHandlerProps } from 'react-native-android-widget';
import { FrelonsWidget } from './FrelonsWidget';
import { calculerResume } from './resume';

export async function widgetTaskHandler({ widgetAction, renderWidget }: WidgetTaskHandlerProps) {
  if (widgetAction === 'WIDGET_DELETED' || widgetAction === 'WIDGET_CLICK') return;
  renderWidget(<FrelonsWidget r={calculerResume(Date.now())} />);
}
