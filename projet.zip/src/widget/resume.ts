/** Résumé affiché par le widget Android : lu directement dans la base (le widget se met à jour même appli fermée). */
import { lireNids, lirePieges, lireTags } from '../db';
import { aControler } from '../calc/intervention';
import { aRelever, piegeActif } from '../calc/saison';
import { etapesDatees } from '../calc/calendrier';
import { lireCalendrier } from '../services/calendrier';
import { param } from '../services/parametres';

export type Resume = { tagsPoses: number; aTraiter: number; aControler: number; pieges: number; etape: string; heure: string };

export function calculerResume(maintenant: number): Resume {
  const p = param();
  const nids = lireNids();
  const c = lireCalendrier();
  const enCours = etapesDatees(maintenant, c.decalage, c.dates).filter((e) => e.etat === 'en-cours' && !c.faites[`${e.id}-${e.saison}`]);
  return {
    tagsPoses: lireTags().filter((t) => t.etat === 'pose').length,
    aTraiter: nids.filter((n) => n.etat === 'trouve' || n.etat === 'estime').length,
    aControler: nids.filter((n) => aControler(n, maintenant, p.controleJours)).length,
    pieges: lirePieges().filter((x) => piegeActif(x) && aRelever(x, maintenant, p.releverJours)).length,
    etape: enCours.length ? enCours[enCours.length - 1].titre : '',
    heure: new Date(maintenant).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
  };
}
