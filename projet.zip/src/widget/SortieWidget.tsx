/** Second widget (Android) : la sortie en cours d'un coup d'œil, téléphone verrouillé dans la poche de poitrine.
 *  Tag suivi, au nid / en chasse, signal, nid estimé, chrono de l'appât, et trois boutons : Parti, Revenu, Micro
 *  (ouvre le Chrono micro allumé). Parti et Revenu agissent sans ouvrir l'appli quand elle tourne (sortie en cours). */
import React from 'react';
import { FlexWidget, TextWidget } from 'react-native-android-widget';
import { ageResume, type ResumeSortie } from './sortie';

const FOND = '#14202E', TEXTE: `#${string}` = '#F3F1EA', DISCRET: `#${string}` = '#9AA7B4', ACCENT: `#${string}` = '#F2C230', OK: `#${string}` = '#5BB974', ALERTE: `#${string}` = '#F2A33A';

function Bouton({ titre, action, uri, actif = true }: { titre: string; action: string; uri?: string; actif?: boolean }) {
  return (
    <FlexWidget clickAction={action} clickActionData={uri ? { uri } : undefined}
      style={{ flex: 1, backgroundColor: actif ? ACCENT : '#2A3A4D', borderRadius: 18, paddingVertical: 8, marginHorizontal: 3, alignItems: 'center', justifyContent: 'center' }}>
      <TextWidget text={titre} style={{ fontSize: 14, fontWeight: 'bold', color: actif ? FOND : DISCRET }} />
    </FlexWidget>
  );
}

export function SortieWidget({ r, maintenant, micro }: { r: ResumeSortie | null; maintenant: number; micro: boolean }) {
  const vieux = !r || !r.actif || maintenant - r.t > 10 * 60000;
  const ligne = (t: string, c: `#${string}` = TEXTE, taille = 13) => (t ? <TextWidget text={t} maxLines={1} truncate="END" style={{ fontSize: taille, color: c }} /> : null);
  return (
    <FlexWidget clickAction="OPEN_URI" clickActionData={{ uri: 'frelons://' }}
      style={{ height: 'match_parent', width: 'match_parent', backgroundColor: FOND, borderRadius: 18, padding: 10, flexDirection: 'column' }}>
      <FlexWidget style={{ width: 'match_parent', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
        <TextWidget text={r?.tag !== null && r?.tag !== undefined ? `Tag ${r.tag}` : 'Frelons – sortie'} style={{ fontSize: 16, fontWeight: 'bold', color: TEXTE }} />
        <TextWidget text={!r ? 'pas de sortie' : vieux ? `${r.actif ? '' : 'déconnecté · '}${ageResume(r.t, maintenant)}` : 'en direct'} style={{ fontSize: 11, color: vieux ? DISCRET : OK }} />
      </FlexWidget>
      <FlexWidget style={{ flex: 1, width: 'match_parent', flexDirection: 'column', justifyContent: 'center' }}>
        {!r || (!r.etat && !r.signal && !r.nid && !r.chrono)
          ? ligne('Connectez le toit ou le portatif pour suivre un tag.', DISCRET, 12)
          : null}
        {r ? ligne(r.etat, r.etat.startsWith('au nid') ? OK : ALERTE, 14) : null}
        {r ? ligne(r.nid, TEXTE, 14) : null}
        {r ? ligne(r.signal, DISCRET, 12) : null}
        {r ? ligne(r.chrono, ACCENT, 13) : null}
      </FlexWidget>
      <FlexWidget style={{ width: 'match_parent', flexDirection: 'row', marginTop: 6 }}>
        <Bouton titre="Parti" action="PARTI" actif={!!r?.appat && !vieux} />
        <Bouton titre="Revenu" action="REVENU" actif={!!r?.parti && !vieux} />
        <Bouton titre={micro ? 'Micro ●' : 'Micro'} action="OPEN_URI" uri="frelons://chrono?micro=1" actif={!vieux} />
      </FlexWidget>
    </FlexWidget>
  );
}
