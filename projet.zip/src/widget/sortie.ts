/** Résumé « sortie en cours » du second widget (Frelons – Sortie) : tag suivi, au nid / en chasse, signal, nid estimé
 *  et chrono de l'appât. Calcul pur (testé) ; l'appli garde le dernier résumé dans la base pour que le widget
 *  l'affiche aussi appli fermée (marqué « il y a … »). */
import { appatActif } from '../calc/appat';
import { capDeg, distM, pointCardinal } from '../calc/geo';
import type { Etat } from '../store/store';

export type ResumeSortie = {
  t: number; // heure du résumé (ms)
  actif: boolean; // toit ou portatif connecté, ou simulation
  tag: number | null;
  etat: string; // « au nid depuis 12 min » / « en chasse depuis 3 min » / ''
  signal: string; // « portatif −72 dBm, se rapproche » / « toit : avant-droite » / ''
  nid: string; // « nid à 230 m SO (± 25 m) » / ''
  chrono: string; // « parti depuis 2:13 » / « 3 allers-retours, ~420 m » / ''
  parti: boolean; // un frelon est parti de l'appât (bouton « Revenu » utile)
  appat: boolean; // un appât est ouvert pour ce tag
};

const mmss = (ms: number) => { const s = Math.max(0, Math.round(ms / 1000)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
const SIDE = ['avant', 'avant-droite', 'droite', 'arrière-droite', 'arrière', 'arrière-gauche', 'gauche', 'avant-gauche'];

type EtatW = Pick<Etat, 'source' | 'connexion' | 'portatif' | 'tags' | 'tagChoisi' | 'activites' | 'chrono' | 'toit' | 'telephone'>;

export function resumeSortie(e: EtatW, maintenant: number): ResumeSortie {
  const port = e.portatif.connexion === 'connecte' ? e.portatif.st : null;
  const actif = e.source === 'simulation' || (e.source === 'toit' && e.connexion === 'connecte') || !!port;
  const tag = e.tagChoisi ?? (port && port.tag >= 0 ? port.tag : null) ?? (Object.keys(e.tags).map(Number)[0] ?? null);
  const r: ResumeSortie = { t: maintenant, actif, tag, etat: '', signal: '', nid: '', chrono: '', parti: false, appat: false };
  if (tag === null) return r;
  const act = e.activites[tag];
  if (act && maintenant - act.vuMs < 15 * 60000) {
    const min = Math.max(0, Math.round((maintenant - act.depuisMs) / 60000));
    r.etat = `${act.nid ? 'au nid' : 'en chasse'} depuis ${min} min${act.tempC !== null ? ` · ${act.tempC} °C` : ''}`;
  }
  if (port && port.tag === tag && port.age < 10) {
    r.signal = `portatif ${Math.round(port.rssi)} dBm${port.trend > 0.4 ? ', se rapproche' : port.trend < -0.4 ? ', s\'éloigne' : ''}`;
  } else {
    const t = e.tags[tag];
    if (t && t.rel >= 0 && maintenant - t.dernierMs < 30000) r.signal = `toit : ${SIDE[Math.round(t.rel / 45) % 8]}${t.abs >= 0 ? ` (${Math.round(t.abs)}° ${pointCardinal(t.abs)})` : ''}`;
  }
  const f = e.tags[tag]?.fusion;
  const ici = port && port.fix ? { lat: port.lat, lon: port.lon } : e.toit && e.toit.lat ? { lat: e.toit.lat, lon: e.toit.lon } : e.telephone ? { lat: e.telephone.lat, lon: e.telephone.lon } : null;
  if (f?.ok) {
    if (ici) {
      const d = distM(ici.lat, ici.lon, f.lat, f.lon), c = capDeg(ici.lat, ici.lon, f.lat, f.lon);
      r.nid = `nid à ${d < 1000 ? `${d < 100 ? Math.round(d) : Math.round(d / 10) * 10} m` : `${(d / 1000).toFixed(1).replace('.', ',')} km`} ${pointCardinal(c)} (± ${Math.round(f.errM)} m)`;
    } else r.nid = `nid estimé ± ${Math.round(f.errM)} m`;
  }
  const a = appatActif(e.chrono, tag);
  if (a) {
    r.appat = true;
    r.parti = a.etat === 2;
    if (a.etat === 2) r.chrono = `parti depuis ${mmss(maintenant - a.depart)}`;
    else r.chrono = `appât ${a.id} : ${a.trajets.length} aller${a.trajets.length > 1 ? 's' : ''}-retour${a.trajets.length > 1 ? 's' : ''}`;
  }
  return r;
}

/** Âge du résumé en clair (« à l'instant », « il y a 12 min », « il y a 3 h »). */
export function ageResume(t: number, maintenant: number): string {
  const m = Math.round((maintenant - t) / 60000);
  return m < 1 ? 'à l\'instant' : m < 60 ? `il y a ${m} min` : `il y a ${Math.round(m / 60)} h`;
}
