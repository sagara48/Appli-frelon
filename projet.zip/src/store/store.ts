/**
 * État partagé de l'appli. Toutes les sources (simulation, toit Bluetooth) passent par recevoirLigneToit(),
 * exactement comme l'écran de la voiture traite les lignes reçues.
 */
import { useRef, useSyncExternalStore } from 'react';
import { parseToit, type LigneC, type LigneK, type LigneS } from '../proto/toit';
import { parsePortatif, type PortatifSt, type PortatifSw, type PortatifTag } from '../proto/portatif';
import type { VersionAppareil } from '../calc/versions';
import { ajouterReleve, type Ligne } from '../calc/releves';
import { fusionner, type DirectionOeil, type Fusion, type PointPortatif } from '../calc/fusion';
import type { FicheTag, Nid, Piege, Rucher } from '../db';
import { appatActif, chronoVide, lacher, manuel, sourcesFusion, tic, trameToit, type Chrono, type Reglages } from '../calc/appat';

export type TagEtat = {
  id: number;
  r: number[]; // dBm des 5 voies (4 directives + omni), −128 = muette
  rel: number; abs: number; q: number; pile: number;
  dernierMs: number; nReleves: number;
  lignes: Ligne[]; oeil: DirectionOeil[]; portatif: PointPortatif[];
  fusion: Fusion | null;
};
export type PointTrajet = { lat: number; lon: number };
export type Source = 'aucune' | 'simulation' | 'toit';
export type EtatConnexion = 'arrete' | 'recherche' | 'connecte' | 'erreur';

/** Récepteur portatif : connexion séparée de celle du toit (les deux peuvent être connectés ensemble). */
export type PortatifEtat = {
  source: 'aucune' | 'simulation' | 'ble';
  connexion: EtatConnexion;
  message: string;
  st: PortatifSt | null;
  sw: PortatifSw | null;
  autres: Record<number, PortatifTag>;
  recuMs: number; // Date.now() de la dernière ligne reçue
  historique: number[]; // niveau du tag suivi (dBm), 1 par seconde, 120 dernières secondes
  version: VersionAppareil | null; // firmware et protocole annoncés (réponse à « ver »)
};
const portatifInitial = (): PortatifEtat => ({ source: 'aucune', connexion: 'arrete', message: '', st: null, sw: null, autres: {}, recuMs: 0, historique: [], version: null });

/** Étalonnage du toit : nombre de trames recueillies (−1 = pas en cours), dernière réponse K, dernier résultat. */
export type ResultatEtalonnage = { fwd: number; beam: number; gains: number[]; errDeg: number; n: number; date: number };
export type EtalonnageEtat = { n: number; dernierK: (LigneK & { recuMs: number }) | null; resultat: ResultatEtalonnage | null; posOk: boolean; enCours: boolean };
const etalonnageInitial = (): EtalonnageEtat => ({ n: -1, dernierK: null, resultat: null, posOk: false, enCours: false });

/** Position et boussole du téléphone (expo-location). */
export type Telephone = { lat: number; lon: number; precision: number; recuMs: number } | null;
export type Boussole = { cap: number; precision: number } | null; // precision 0..3 (3 = bonne)
/** Réglages des sons et alertes (écran Alertes), sauvegardés. */
export type ReglagesAlertes = {
  sonSignal: boolean; volume: number; voix: boolean;
  nouveauTag: boolean; tagPerdu: boolean; pileFaible: boolean; retourAppat: boolean; nidLocalise: boolean; approcheNid: boolean; batterie: boolean;
};
export const alertesDefaut = (): ReglagesAlertes => ({
  sonSignal: true, volume: 0.7, voix: true, nouveauTag: true, tagPerdu: true, pileFaible: true, retourAppat: true, nidLocalise: true, approcheNid: true, batterie: true,
});

/** Station fixe : le toit sur un trépied au rucher relève les départs de tous les frelons tagués. */
export type Station = { lat: number; lon: number; rucherId: number | null; nom: string; debutMs: number } | null;

export type Etat = {
  station: Station;
  telephone: Telephone;
  boussole: Boussole;
  alertes: ReglagesAlertes;
  bandeau: { texte: string; grave: boolean; ms: number } | null; // dernière alerte affichée en haut des écrans
  nids: Nid[];
  fichesTags: Record<number, FicheTag>;
  ruchers: Rucher[];
  pieges: Piege[];
  etalonnage: EtalonnageEtat;
  arretAutoMin: number; // réglage « auto » envoyé au toit (le toit ne le renvoie pas)
  portatif: PortatifEtat;
  chrono: Chrono; // copie publiée de l'état du chrono à l'appât
  source: Source;
  connexion: EtatConnexion;
  message: string;
  horlogeMs: number; // temps de la source (ms depuis le départ en simulation, Date.now() en direct)
  toit: LigneS | null;
  config: LigneC | null;
  versionToit: VersionAppareil | null; // firmware du chef, protocole, voies (ligne V)
  tags: Record<number, TagEtat>;
  trajet: PointTrajet[];
  tagChoisi: number | null;
  vitesseSim: number;
  evenements: string[];
  reprise: { t: number; toit: boolean; portatif: boolean; nTags: number } | null; // sortie reprise au démarrage après une coupure
};

const initial = (): Etat => ({
  station: null,
  telephone: null, boussole: null, alertes: alertesDefaut(), bandeau: null, nids: [], fichesTags: {}, ruchers: [], pieges: [],
  etalonnage: etalonnageInitial(),
  arretAutoMin: 10,
  portatif: portatifInitial(),
  chrono: chronoVide(),
  source: 'aucune', connexion: 'arrete', message: '', horlogeMs: 0, toit: null, config: null, versionToit: null, tags: {}, trajet: [],
  tagChoisi: null, vitesseSim: 10, evenements: [], reprise: null,
});

/* ---------- reprise après coupure ---------- */
/** Sortie en cours, enregistrée toutes les 10 s pendant une vraie sortie : relevés, directions, trajet, station. */
type SortieSauvee = {
  t: number; tags: Omit<TagEtat, 'fusion'>[]; trajet: PointTrajet[]; tagChoisi: number | null; station: Station; evenements: string[];
  toit: boolean; portatif: boolean;
};
/** Durée pendant laquelle une sortie interrompue est reprise (Paramètres → Sortie, 12 h par défaut). */
const dureeReprise = () => (persistance?.lire<{ repriseH?: number }>('parametres')?.repriseH ?? 12) * 3600e3;
const enSortie = (e: Etat) => e.source === 'toit' || e.portatif.source === 'ble' || !!e.station;
let sortiePrevue: ReturnType<typeof setTimeout> | null = null;
function planifierSortie() {
  if (sortiePrevue || !persistance || !enSortie(etat)) return;
  sortiePrevue = setTimeout(() => {
    sortiePrevue = null;
    const e = etat;
    if (!persistance || !enSortie(e)) return;
    const s: SortieSauvee = {
      t: Date.now(), tags: Object.values(e.tags).map(({ fusion: _f, ...t }) => t), trajet: e.trajet, tagChoisi: e.tagChoisi, station: e.station,
      evenements: e.evenements.slice(0, 20), toit: e.source === 'toit', portatif: e.portatif.source === 'ble',
    };
    persistance.ecrire('sortie', s);
  }, 10000);
}
function sortieRecente(): SortieSauvee | null {
  const s = persistance?.lire<SortieSauvee>('sortie');
  return s && Array.isArray(s.tags) && Date.now() - s.t < dureeReprise() ? s : null;
}
/** Tags d'une sortie enregistrée, avec leur fusion recalculée (le chrono doit être chargé avant). */
function tagsDe(s: SortieSauvee): Record<number, TagEtat> {
  const r: Record<number, TagEtat> = {};
  for (const t of s.tags) { const nt: TagEtat = { ...tagVide(t.id), ...t, fusion: null }; nt.fusion = fus(nt); r[t.id] = nt; }
  return r;
}
/** Termine la sortie : relevés, trajet et directions effacés (les appâts du chrono restent, ils se suppriment à part). */
export function terminerSortie() {
  persistance?.ecrire('sortie', null);
  maj((e) => ({ ...e, tags: {}, trajet: [], tagChoisi: null, reprise: null, evenements: ['Sortie terminée', ...e.evenements].slice(0, 50) }));
}

let etat: Etat = initial();
/** État de travail du chrono (modifié en place par calc/appat), publié en copie dans etat.chrono. */
let chrono: Chrono = chronoVide();
const copieChrono = (): Chrono => ({ ...chrono, reglages: { ...chrono.reglages }, appats: chrono.appats.map((a) => ({ ...a, trajets: [...a.trajets] })) });
/** Fusion d'un tag avec toutes ses sources, appâts compris. */
function fus(t: TagEtat): Fusion {
  const ap = sourcesFusion(chrono, t.id);
  return fusionner({ ...t, anneaux: ap.anneaux, capsAppat: ap.lignes });
}
/** Après un changement du chrono : recalcule les tags concernés et publie. */
let sauvegardePrevue: ReturnType<typeof setTimeout> | null = null;
/** Sauvegarde des appâts réels (pas en simulation), 2 s après le dernier changement. */
function sauverChrono() {
  if (etat.source === 'simulation' || !persistance) return;
  if (sauvegardePrevue) clearTimeout(sauvegardePrevue);
  sauvegardePrevue = setTimeout(() => {
    const p = persistance; if (!p) return;
    p.ecrire('chrono', { reglages: chrono.reglages, prochainId: chrono.prochainId,
      appats: chrono.appats.map((a) => ({ ...a, etat: a.etat === 2 ? 2 : 1, hist: [] })) });
  }, 2000);
}
type Persistance = { lire: <T>(cle: string) => T | null; ecrire: (cle: string, v: unknown) => void };
let persistance: Persistance | null = null;
/** Branche la sauvegarde (appelé au démarrage de l'appli) et recharge les appâts de la dernière session. */
export function brancherPersistance(p: Persistance) {
  persistance = p;
  const r = p.lire<ResultatEtalonnage>('etalonnage');
  const auto = p.lire<number>('arretAuto');
  const al = p.lire<ReglagesAlertes>('alertes');
  maj((e) => ({ ...e, etalonnage: r ? { ...e.etalonnage, resultat: r } : e.etalonnage, arretAutoMin: auto ?? e.arretAutoMin, alertes: al ? { ...alertesDefaut(), ...al } : e.alertes }));
  const c = p.lire<Chrono>('chrono');
  if (c && Array.isArray(c.appats)) {
    chrono = { ...chronoVide(), ...c, message: '' };
    maj((e) => publierChrono(e, chrono.appats.map((a) => a.tag)));
  }
  // sortie interrompue (appli fermée, téléphone redémarré) : on reprend relevés, trajet et station
  const so = sortieRecente();
  if (so && etat.source !== 'simulation') {
    maj((e) => ({ ...e, tags: tagsDe(so), trajet: so.trajet ?? [], tagChoisi: so.tagChoisi, station: so.station ?? e.station,
      evenements: [`Sortie reprise (enregistrée à ${new Date(so.t).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })})`, ...(so.evenements ?? [])].slice(0, 50),
      reprise: { t: so.t, toit: so.toit, portatif: so.portatif, nTags: so.tags.length } }));
  }
}
function publierChrono(e: Etat, tags: number[]): Etat {
  sauverChrono();
  const n = { ...e, chrono: copieChrono(), tags: { ...e.tags } };
  for (const id of new Set(tags)) { const t = n.tags[id] ?? tagVide(id); n.tags[id] = { ...t, fusion: fus(t) }; }
  return n;
}
const abonnes = new Set<() => void>();
let notifPrevue = false;

function publier() {
  planifierSortie();
  // regroupe les rafales de lignes (la simulation en accéléré en envoie beaucoup d'un coup)
  if (notifPrevue) return;
  notifPrevue = true;
  setTimeout(() => { notifPrevue = false; abonnes.forEach((f) => f()); }, 50);
}
function maj(f: (e: Etat) => Etat) { etat = f(etat); publier(); }

export const store = {
  get: () => etat,
  abonner: (f: () => void) => { abonnes.add(f); return () => abonnes.delete(f); },
  set: (p: Partial<Etat>) => maj((e) => ({ ...e, ...p })),
  remettreAZero: (garder: Partial<Etat> = {}) => maj((e) => {
    // en simulation : chrono vierge ; sur le vrai toit : on reprend les appâts sauvegardés (une sortie peut durer des heures)
    const sauve = garder.source !== 'simulation' ? persistance?.lire<Chrono>('chrono') : null;
    chrono = sauve && Array.isArray(sauve.appats) ? { ...chronoVide(), ...sauve, message: '' } : { ...chronoVide(), reglages: chrono.reglages };
    // vrai toit : la sortie en cours (relevés, trajet) continue, même après une coupure
    const so = garder.source === 'toit' ? sortieRecente() : null;
    const suite: Partial<Etat> = so ? { tags: e.source === 'toit' || e.reprise ? e.tags : tagsDe(so), trajet: e.source === 'toit' || e.reprise ? e.trajet : so.trajet, tagChoisi: e.tagChoisi ?? so.tagChoisi, reprise: e.reprise } : {};
    return { ...initial(), ...suite, station: e.station, telephone: e.telephone, boussole: e.boussole, alertes: e.alertes, nids: e.nids, fichesTags: e.fichesTags, ruchers: e.ruchers, pieges: e.pieges, etalonnage: { ...etalonnageInitial(), resultat: e.etalonnage.resultat }, arretAutoMin: e.arretAutoMin, chrono: copieChrono(), portatif: e.portatif, vitesseSim: e.vitesseSim, tagChoisi: e.tagChoisi, ...garder }; }),
  portatif: (p: Partial<PortatifEtat>) => maj((e) => ({ ...e, portatif: { ...e.portatif, ...p } })),
  portatifAZero: (p: Partial<PortatifEtat> = {}) => maj((e) => ({ ...e, portatif: { ...portatifInitial(), ...p } })),
  choisirTag: (id: number | null) => maj((e) => ({ ...e, tagChoisi: id })),
  evenement: (txt: string) => maj((e) => ({ ...e, evenements: [txt, ...e.evenements].slice(0, 50) })),
};

function egalSuperficiel(a: unknown, b: unknown): boolean {
  if (Object.is(a, b)) return true;
  if (typeof a !== 'object' || typeof b !== 'object' || !a || !b || Array.isArray(a) !== Array.isArray(b)) return false;
  const ka = Object.keys(a), kb = Object.keys(b);
  return ka.length === kb.length && ka.every((k) => Object.is((a as any)[k], (b as any)[k]));
}

/** Lit une partie de l'état ; le composant ne se redessine que si cette partie change (comparaison superficielle). */
export function useEtat<T>(sel: (e: Etat) => T): T {
  const cache = useRef<{ v: T } | null>(null);
  const lire = () => {
    const v = sel(etat);
    if (cache.current && egalSuperficiel(cache.current.v, v)) return cache.current.v;
    cache.current = { v };
    return v;
  };
  return useSyncExternalStore(store.abonner, lire, lire);
}

function tagVide(id: number): TagEtat {
  return { id, r: [-128, -128, -128, -128, -128], rel: -1, abs: -1, q: 0, pile: -1, dernierMs: 0, nReleves: 0, lignes: [], oeil: [], portatif: [], fusion: null };
}

const MAX_TRAJET = 4000;

/** Une ligne du toit (texte brut), horodatée par la source. */
export function recevoirLigneToit(texte: string, tMs: number) {
  const l = parseToit(texte);
  if (!l) return;
  maj((e) => {
    const n: Etat = { ...e, horlogeMs: tMs };
    switch (l.kind) {
      case 'S': {
        n.toit = l;
        if (e.source !== 'simulation' && l.calN !== e.etalonnage.n) n.etalonnage = { ...e.etalonnage, n: l.calN, enCours: l.calN >= 0 };
        if (l.lat !== 0) {
          const der = e.trajet[e.trajet.length - 1];
          if (!der || Math.abs(der.lat - l.lat) > 2e-5 || Math.abs(der.lon - l.lon) > 2e-5)
            n.trajet = [...e.trajet.slice(-MAX_TRAJET + 1), { lat: l.lat, lon: l.lon }];
        }
        break;
      }
      case 'R': {
        const t = e.tags[l.tag] ?? tagVide(l.tag);
        const lignes = ajouterReleve(t.lignes, l.lat, l.lon, l.abs, l.q, tMs);
        const nt: TagEtat = { ...t, r: l.r, rel: l.rel, abs: l.abs, q: l.q, pile: l.pile, dernierMs: tMs, nReleves: t.nReleves + 1, lignes };
        if (lignes !== t.lignes) nt.fusion = fus(nt);
        n.tags = { ...e.tags, [l.tag]: nt };
        if (n.tagChoisi === null) n.tagChoisi = l.tag;
        const toitPos = n.toit && n.toit.lat ? { lat: n.toit.lat, lon: n.toit.lon } : null;
        const avantMsg = chrono.message;
        // station fixe : chaque nouveau tag entendu a son « appât » à la station (départs chronométrés et cap de départ)
        if (n.station) {
          const a = appatActif(chrono, l.tag);
          if (!a || a.lat !== n.station.lat || a.lon !== n.station.lon) lacher(chrono, l.tag, n.station.lat, n.station.lon, 'voiture', tMs);
        }
        const tictac = tic(chrono, tMs);
        // à l'arrêt, le toit n'a pas de cap GPS : en station, face avant au nord, la direction relative est la direction absolue
        const absEff = n.station && l.abs < 0 && l.rel >= 0 ? l.rel : l.abs;
        const posEff = n.station ? toitPos ?? { lat: n.station.lat, lon: n.station.lon } : toitPos;
        if (trameToit(chrono, l.tag, Math.max(...l.r), absEff, l.q, posEff, tMs) || tictac) {
          const p = publierChrono(n, [l.tag]);
          if (chrono.message !== avantMsg) p.evenements = [chrono.message, ...n.evenements].slice(0, 50);
          return p;
        }
        if (chrono.appats.some((a) => a.tag === l.tag)) n.chrono = copieChrono(); // état « à l'appât » / niveau max
        break;
      }
      case 'C': n.config = l; break;
      case 'V': n.versionToit = { fw: l.fw, proto: l.proto, voies: l.voies, recuMs: Date.now() }; break;
      case 'N': {
        const t = e.tags[l.tag] ?? tagVide(l.tag);
        const deja = t.portatif[0];
        if (deja && deja.lat === l.lat && deja.lon === l.lon && deja.errM === l.errM) break;
        const nt = { ...t, portatif: [{ lat: l.lat, lon: l.lon, errM: l.errM }] }; // le portatif renvoie toujours son meilleur nid : on remplace
        nt.fusion = fus(nt);
        n.tags = { ...e.tags, [l.tag]: nt };
        n.evenements = [`Nid du portatif reçu pour le tag ${l.tag}`, ...e.evenements].slice(0, 50);
        break;
      }
      case 'K': {
        const et = { ...e.etalonnage, dernierK: { ...l, recuMs: Date.now() } };
        if (l.type === 'ERR') n.evenements = [`Toit : ${l.message}`, ...e.evenements].slice(0, 50);
        if (l.type === 'POS') et.posOk = true;
        if (l.type === 'GO') { et.enCours = true; et.n = 0; }
        if (l.type === 'ERR' && et.enCours && /trames/.test(l.message)) et.enCours = false; // calfin refusé : l'étalonnage est arrêté
        if (l.type === 'RESULTAT') {
          et.resultat = { fwd: l.fwd, beam: l.beam, gains: l.gains, errDeg: l.errDeg, n: l.n, date: Date.now() };
          et.enCours = false; et.n = -1;
          n.config = { kind: 'C', fwd: l.fwd, beam: l.beam, gains: l.gains, vmin: e.config?.vmin ?? 4 };
          if (e.source !== 'simulation') persistance?.ecrire('etalonnage', et.resultat);
          n.evenements = [`Étalonnage terminé : erreur moyenne ${Math.round(l.errDeg)}°`, ...e.evenements].slice(0, 50);
        }
        n.etalonnage = et;
        break;
      }
    }
    return n;
  });
}

/** Direction de vol notée à l'œil (écran « Cap à l'œil », ou événement VIS de la simulation). */
export function ajouterDirectionOeil(tag: number, d: DirectionOeil) {
  maj((e) => {
    const t = e.tags[tag] ?? tagVide(tag);
    const nt = { ...t, oeil: [...t.oeil, d] };
    nt.fusion = fus(nt);
    return { ...e, tags: { ...e.tags, [tag]: nt }, evenements: [`Direction à l'œil ajoutée au tag ${tag}`, ...e.evenements].slice(0, 50) };
  });
}

/** Âge en secondes de la dernière réception d'un tag, selon l'horloge de la source. */
/** Horloge de la source : temps de la sortie rejouée en simulation, heure réelle sinon (l'âge continue d'augmenter si le toit se tait). */
export const horloge = (e: Etat) => (e.source === 'simulation' ? e.horlogeMs : Date.now());
/** Âge en secondes de la dernière réception d'un tag par le toit. */
export const ageS = (e: Etat, t: TagEtat) => Math.max(0, (horloge(e) - t.dernierMs) / 1000);
/** Âge en secondes du dernier signal du tag suivi par le portatif (âge annoncé + temps depuis la dernière ligne reçue). */
export const agePortatif = (e: Etat) => (e.portatif.st ? e.portatif.st.age + Math.max(0, (Date.now() - e.portatif.recuMs) / 1000) : 1e9);

/** Une ligne JSON du portatif. Son nid est versé dans la fusion du tag qu'il suit (comme le relais N du toit). */
export function recevoirLignePortatif(texte: string) {
  const l = parsePortatif(texte);
  if (!l) return;
  maj((e) => {
    const p = { ...e.portatif, recuMs: Date.now() };
    const n: Etat = { ...e, portatif: p };
    switch (l.type) {
      case 'st':
        p.st = l;
        p.historique = l.tag >= 0 && l.age < 5 ? [...p.historique.slice(-119), l.rssi] : [...p.historique.slice(-119), NaN];
        break;
      case 'sw': p.sw = l; break;
      case 'ver': p.version = { fw: l.fw, proto: l.proto, recuMs: Date.now() }; break;
      case 'tag': p.autres = { ...p.autres, [l.id]: l }; break;
      case 'nest': {
        const id = p.st?.tag ?? -1;
        if (id < 0) break;
        const t = e.tags[id] ?? tagVide(id);
        const deja = t.portatif[0];
        if (deja && Math.abs(deja.lat - l.lat) < 1e-6 && Math.abs(deja.lon - l.lon) < 1e-6 && deja.errM === l.err) break;
        const nt = { ...t, portatif: [{ lat: l.lat, lon: l.lon, errM: l.err }] };
        nt.fusion = fus(nt);
        n.tags = { ...e.tags, [id]: nt };
        n.evenements = [`Nid du portatif mis à jour pour le tag ${id}`, ...e.evenements].slice(0, 50);
        break;
      }
    }
    return n;
  });
}

/* ---------- chrono à l'appât ---------- */
/** Horloge de la source : temps de la sortie en simulation, heure réelle sinon. */
export const maintenant = () => (etat.source === 'simulation' ? etat.horlogeMs : Date.now());

/** « Lâcher ici » pour un tag, à la position donnée (voiture si connue, sinon portatif). */
export function chronoLacher(tag: number, lat: number, lon: number, source: 'voiture' | 'main') {
  maj((e) => {
    const a = lacher(chrono, tag, lat, lon, source, maintenant());
    if (!a) return e;
    const n = publierChrono(e, [tag]);
    n.evenements = [`Appât ${a.id} ouvert pour le tag ${tag}`, ...e.evenements].slice(0, 50);
    return n;
  });
}
export function chronoManuel(tag: number, quoi: 'parti' | 'revenu', cap: number | null) {
  maj((e) => {
    const avant = chrono.message;
    manuel(chrono, tag, quoi, maintenant(), cap);
    const n = publierChrono(e, [tag]);
    if (chrono.message !== avant) n.evenements = [chrono.message, ...e.evenements].slice(0, 50);
    return n;
  });
}
export function chronoReglages(r: Partial<Reglages>) {
  maj((e) => { Object.assign(chrono.reglages, r); return publierChrono(e, chrono.appats.map((a) => a.tag)); });
}
export function chronoSupprimer(id: number) {
  maj((e) => { const a = chrono.appats.find((x) => x.id === id); chrono.appats = chrono.appats.filter((x) => x.id !== id); return publierChrono(e, a ? [a.tag] : []); });
}
/** Tic d'une seconde (connexion réelle : la simulation avance avec ses propres lignes). */
export function chronoTic() {
  if (!chrono.appats.length) return;
  const t = maintenant();
  if (tic(chrono, t)) maj((e) => publierChrono(e, chrono.appats.map((a) => a.tag)));
}

/** Étalonnage simulé (pas de vraies lignes S pendant le rejeu) : le simulateur publie le compte de trames. */
export function etalonnageSimule(p: Partial<EtalonnageEtat>) { maj((e) => ({ ...e, etalonnage: { ...e.etalonnage, ...p } })); }
export function definirArretAuto(min: number) { maj((e) => ({ ...e, arretAutoMin: min })); persistance?.ecrire('arretAuto', min); }

export function definirAlertes(a: Partial<ReglagesAlertes>) {
  maj((e) => ({ ...e, alertes: { ...e.alertes, ...a } }));
  persistance?.ecrire('alertes', etat.alertes);
}
/** Meilleure position disponible : voiture (toit), portatif, puis téléphone. */
export function meilleurePosition(e: Etat = etat): { lat: number; lon: number; source: 'voiture' | 'portatif' | 'telephone' } | null {
  if (e.toit && e.toit.lat && e.connexion === 'connecte') return { lat: e.toit.lat, lon: e.toit.lon, source: 'voiture' };
  const p = e.portatif.st;
  if (p && p.fix && e.portatif.connexion === 'connecte') return { lat: p.lat, lon: p.lon, source: 'portatif' };
  if (e.telephone && Date.now() - e.telephone.recuMs < 120000) return { lat: e.telephone.lat, lon: e.telephone.lon, source: 'telephone' };
  return null;
}
/** Appât le plus récent d'un tag (copie publiée). */
export const appatActifDe = (tag: number) => { const a = etat.chrono.appats.filter((x) => x.tag === tag); return a.length ? a[a.length - 1] : null; };

export function demarrerStation(st: NonNullable<Station>) { maj((e) => ({ ...e, station: st })); }
export function arreterStation() { maj((e) => ({ ...e, station: null })); }
