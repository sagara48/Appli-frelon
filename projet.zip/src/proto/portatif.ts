/** Décodage des lignes JSON du récepteur portatif (phone.c du portatif, 1 fois par seconde) et ses commandes. */
export type PortatifSt = {
  type: 'st'; tag: number; rssi: number; raw: number; trend: number; age: number; hdg: number;
  fix: number; lat: number; lon: number; sats: number; bat: number; lna: number; // lna = voie RF : 0 LNA, 1 direct, 2 atténuateur
};
export type PortatifSw = { type: 'sw'; act: number; pct: number; ok: number; brg: number; nfix: number }; // tour de goniométrie
export type PortatifTag = { type: 'tag'; id: number; rssi: number; age: number; lat: number; lon: number };
export type PortatifNid = { type: 'nest'; lat: number; lon: number; err: number };
export type LignePortatif = PortatifSt | PortatifSw | PortatifTag | PortatifNid;

export function parsePortatif(ligne: string): LignePortatif | null {
  try {
    const o = JSON.parse(ligne.trim());
    if (o && (o.type === 'st' || o.type === 'sw' || o.type === 'tag' || o.type === 'nest')) return o as LignePortatif;
  } catch {}
  return null;
}

export type ModeLna = 'auto' | 'on' | 'off' | 'att';
export const VOIES_RF = ['préampli', 'direct', 'atténuateur'];

export const cmdPortatif = {
  tag: (id: number) => `tag ${id}`,
  son: (on: boolean) => `son ${on ? 1 : 0}`,
  lna: (m: ModeLna) => `lna ${m}`,
  rfcal: () => 'rfcal',
  gps: (a: 'int' | 'ext') => `gps ${a}`,
  enroll: () => 'enroll',
  sweep: () => 'sweep', // commence un tour sur place
  fix: () => 'fix', // enregistre le relevé (position + direction du tour)
  clr: () => 'clr', // efface les relevés
  off: () => 'off',
};
