/** Décodage des lignes JSON du récepteur portatif (phone.c du portatif, 1 fois par seconde) et ses commandes. */
export type PortatifSt = {
  type: 'st'; tag: number; rssi: number; raw: number; trend: number; age: number; hdg: number;
  fix: number; lat: number; lon: number; sats: number; bat: number; lna: number; // lna = voie RF : 0 LNA, 1 direct, 2 atténuateur
  etat?: number; // octet d'état du tag suivi (1.2.0) : au nid / température
  poche?: number; // 1 = mode poche (écran éteint, vibreur) (1.2.0)
  cmp?: number; // boussole : 0 bonne, 1 perturbée (métal proche), 2 pas calibrée (1.2.0)
};
export type PortatifSw = { type: 'sw'; act: number; pct: number; ok: number; brg: number; nfix: number }; // tour de goniométrie
export type PortatifTag = { type: 'tag'; id: number; rssi: number; age: number; lat: number; lon: number; etat?: number };
export type PortatifNid = { type: 'nest'; lat: number; lon: number; err: number };
/** Point de la carte du signal gardé par le portatif pendant que le téléphone n'était pas connecté (1.2.0). */
export type PortatifPas = { type: 'pas'; tag: number; lat: number; lon: number; rssi: number; utc: number };
/** Versions du firmware et du protocole (réponse à « ver ») ; 1.2.0 : cause du dernier redémarrage et temps depuis (s). */
export type PortatifVer = { type: 'ver'; fw: string; proto: number; rst?: number; up?: number };
/** Nid estimé en marchant (filtre à particules du portatif, 1.2.0), toutes les 5 s. ok = assez de mesures et de marche. */
export type PortatifEst = { type: 'est'; tag: number; lat: number; lon: number; err: number; ok: number; n: number; marche: number; p1m: number };
/** Résultat de l'étalonnage d'un tag à 1 m (p1m = 0 : raté). */
export type PortatifEtal = { type: 'etal'; id: number; p1m: number; n: number };
/** Ordre à distance à un tag (firmware tag 7) : « go » à l'envoi, puis « ok » (avec le délai) ou « echec » après 60 s. */
export type PortatifOrdre = { type: 'ordre'; tag: number; ordre: OrdreTag; res: 'go' | 'ok' | 'echec' | 'occupe'; ms?: number };
export type LignePortatif = PortatifSt | PortatifSw | PortatifTag | PortatifNid | PortatifVer | PortatifPas | PortatifEst | PortatifEtal | PortatifOrdre;
/** Ordres à distance aux tags : ping (« tu m'entends ? »), rech (mode recherche 10 min), fin (fin du mode recherche), off (désactivation). */
export type OrdreTag = 'ping' | 'rech' | 'fin' | 'off';

export function parsePortatif(ligne: string): LignePortatif | null {
  try {
    const o = JSON.parse(ligne.trim());
    if (o && (o.type === 'st' || o.type === 'sw' || o.type === 'tag' || o.type === 'nest' || o.type === 'pas' || o.type === 'est' || o.type === 'etal' || o.type === 'ordre')) return o as LignePortatif;
    if (o && o.type === 'ver' && typeof o.fw === 'string') return { type: 'ver', fw: o.fw, proto: Number(o.proto), ...(typeof o.rst === 'number' ? { rst: o.rst, up: Number(o.up) || 0 } : {}) };
  } catch {}
  return null;
}

export type ModeLna = 'auto' | 'on' | 'off' | 'att';
export const VOIES_RF = ['préampli', 'direct', 'atténuateur'];

export const cmdPortatif = {
  tag: (id: number) => `tag ${id}`,
  son: (on: boolean) => `son ${on ? 1 : 0}`,
  lna: (m: ModeLna) => `lna ${m}`,
  rfcal: () => 'rfcal',
  gps: (a: 'int' | 'ext') => `gps ${a}`,
  enroll: () => 'enroll',
  sweep: () => 'sweep', // commence un tour sur place
  fix: () => 'fix', // enregistre le relevé (position + direction du tour)
  clr: () => 'clr', // efface les relevés
  off: () => 'off',
  ver: () => 'ver',
  /** flèche vers un point en mode NAV (1.2.0) ; le nom est raccourci à 19 caractères, sans accents */
  cible: (lat: number, lon: number, nom: string) =>
    `cible ${lat.toFixed(6)} ${lon.toFixed(6)} ${nom.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x20-\x7e]/g, '').trim().slice(0, 19) || 'point'}`,
  cibleOff: () => 'cible off',
  /** mode poche : écran éteint, le vibreur bat plus vite à l'approche du tag ; une touche du portatif le quitte */
  poche: (on: boolean) => `poche ${on ? 1 : 0}`,
  /** étalonnage : le tag posé à 1 m devant l'antenne, 20 trames */
  etal: (id: number) => `etal ${id}`,
  /** niveau à 1 m d'un tag déjà étalonné (renvoyé au portatif à chaque connexion) */
  p1m: (id: number, dbm: number) => `p1m ${id} ${Math.round(dbm)}`,
  /** efface le nid estimé en marchant */
  estRaz: () => 'est raz',
  /** exposant du terrain appris sur les nids trouvés (distance affichée, nid estimé en marchant) */
  nexp: (n: number) => `nexp ${n.toFixed(1)}`,
  /** enregistrement d'essai : chaque trame envoyée (ligne « f ») */
  brut: (on: boolean) => `brut ${on ? 1 : 0}`,
  /** ordre à distance à un tag (firmware tag 7) */
  ordre: (tag: number, o: OrdreTag) => `ordre ${tag} ${o}`,
};
