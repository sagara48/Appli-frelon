/**
 * Décodage des lignes envoyées par la carte chef du toit (service UART Nordic, une ligne par message).
 * Format identique à celui que lit l'écran de la voiture (data.c) et au journal de la carte SD.
 */
import type { OrdreTag } from './portatif';
export const NV = 4; // voies directives ; l'indice 4 = antenne omni

export type LigneS = {
  kind: 'S'; battPct: number; vbat: number; charge: boolean; usb: boolean; voiesOk: number; sats: number;
  lat: number; lon: number; cap: number; vitesse: number; nReleves: number; utc: number; calN: number;
};
export type LigneR = {
  kind: 'R'; utc: number; tag: number; seq: number; r: number[]; rel: number; abs: number; q: number;
  lat: number; lon: number; cap: number; vitesse: number; pile: number;
  etat: number; // octet d'état du tag (firmware 4) : au nid / température ; 0 = inconnu
  lp: boolean; // trame longue portée (PHY codée) : détection, sans relèvement
};
export type LigneC = { kind: 'C'; fwd: number; beam: number; gains: number[]; vmin: number };
export type LigneK =
  | { kind: 'K'; type: 'POS' | 'GO' | 'NID' }
  | { kind: 'K'; type: 'ERR'; message: string }
  | { kind: 'K'; type: 'MAJ'; cible: string; n: number }
  | { kind: 'K'; type: 'RESULTAT'; fwd: number; beam: number; gains: number[]; errDeg: number; n: number; errDiag?: number }
  | { kind: 'K'; type: 'ROT'; deg: number; fwd: number }
  /** ordre à distance à un tag (firmware tag 7) : GO à l'envoi, puis OK (délai en ms) ou ECHEC après 60 s */
  | { kind: 'K'; type: 'TAG'; tag: number; ordre: OrdreTag; res: 'go' | 'ok' | 'echec' | 'occupe'; ms?: number };
export type LigneN = { kind: 'N'; tag: number; lat: number; lon: number; errM: number };
/** Versions : firmware du chef, protocole des lignes, firmware de chaque voie (0 = absente). Réponse à « ver » et après « cfg ».
 *  Depuis la 1.2.0 : cause du dernier redémarrage du chef, temps depuis le démarrage (s), cause pour chaque voie. */
export type LigneV = { kind: 'V'; fw: string; proto: number; voies: number[]; rst?: number; upS?: number; rstVoies?: number[] };
/** Erreur remontée par le toit : une voie (ou le chef) a redémarré, avec la cause. */
export type LigneE = { kind: 'E'; qui: 'voie' | 'chef'; n: number; rst: number; texte: string };
export type LigneToit = LigneS | LigneR | LigneC | LigneK | LigneN | LigneV | LigneE;

const num = (s: string | undefined) => (s === undefined || s === '' ? NaN : Number(s));

export function parseToit(ligne: string): LigneToit | null {
  const f = ligne.trim().split(',');
  switch (f[0]) {
    case 'S':
      if (f.length < 12) return null;
      return {
        kind: 'S', battPct: num(f[1]), vbat: num(f[2]), charge: f[3] === '1', usb: f[4] === '1', voiesOk: num(f[5]),
        sats: num(f[6]), lat: num(f[7]), lon: num(f[8]), cap: num(f[9]), vitesse: num(f[10]), nReleves: num(f[11]),
        utc: f.length > 12 ? num(f[12]) : 0, calN: f.length > 13 ? num(f[13]) : -1,
      };
    case 'R':
      // R,utc,id,seq,r0,r1,r2,r3,r4,rel,abs,q,lat,lon,cap,vitesse,batt[,etat]
      if (f.length < 17) return null;
      return {
        kind: 'R', utc: num(f[1]), tag: num(f[2]), seq: num(f[3]), r: [4, 5, 6, 7, 8].map((i) => num(f[i])),
        rel: num(f[9]), abs: num(f[10]), q: num(f[11]), lat: num(f[12]), lon: num(f[13]), cap: num(f[14]),
        vitesse: num(f[15]), pile: num(f[16]), etat: f.length > 17 ? num(f[17]) || 0 : 0, lp: f.length > 18 && f[18] === '1',
      };
    case 'C':
      if (f.length < 8) return null;
      return { kind: 'C', fwd: num(f[1]), beam: num(f[2]), gains: [3, 4, 5, 6].map((i) => num(f[i])), vmin: num(f[7]) };
    case 'K':
      if (f[1] === 'POS' || f[1] === 'GO' || f[1] === 'NID') return { kind: 'K', type: f[1] };
      if (f[1] === 'ERR') return { kind: 'K', type: 'ERR', message: f.slice(2).join(',') };
      if (f[1] === 'MAJ') return { kind: 'K', type: 'MAJ', cible: f[2] ?? '', n: num(f[3]) };
      if (f[1] === 'TAG' && f.length >= 5)
        return { kind: 'K', type: 'TAG', tag: num(f[2]), ordre: f[3] as OrdreTag, res: f[4].toLowerCase() as 'go' | 'ok' | 'echec' | 'occupe', ...(f.length > 5 ? { ms: num(f[5]) } : {}) };
      if (f[1] === 'ROT') return { kind: 'K', type: 'ROT', deg: num(f[2]), fwd: num(f[3]) };
      if (f.length >= 9)
        return { kind: 'K', type: 'RESULTAT', fwd: num(f[1]), beam: num(f[2]), gains: [3, 4, 5, 6].map((i) => num(f[i])), errDeg: num(f[7]), n: num(f[8]), ...(f.length > 9 && num(f[9]) >= 0 ? { errDiag: num(f[9]) } : {}) };
      return null;
    case 'N':
      // N,P,tag,lat,lon,err : nid calculé par le portatif, relayé par le toit
      if (f.length < 6) return null;
      return { kind: 'N', tag: num(f[2]), lat: num(f[3]), lon: num(f[4]), errM: num(f[5]) };
    case 'V':
      // V,firmware,protocole,voie0,voie1,voie2,voie3
      if (f.length < 3 || !f[1]) return null;
      // 1.2.0 : ...,rst,uptime_s,rst_voie0..3
      return {
        kind: 'V', fw: f[1], proto: num(f[2]), voies: [3, 4, 5, 6].map((i) => (f[i] === undefined ? 0 : num(f[i]) || 0)),
        ...(f.length >= 13 ? { rst: num(f[7]) || 0, upS: num(f[8]) || 0, rstVoies: [9, 10, 11, 12].map((i) => num(f[i]) || 0) } : {}),
      };
    case 'E':
      // E,voie,<n>,<rst>,<texte>  ou  E,chef,0,<rst>,<texte>
      if (f.length < 4 || (f[1] !== 'voie' && f[1] !== 'chef')) return null;
      return { kind: 'E', qui: f[1], n: num(f[2]) || 0, rst: num(f[3]) || 0, texte: f.slice(4).join(',') };
    default:
      return null;
  }
}

/** Commandes acceptées par le toit (phone.c). */
export const cmdToit = {
  cfg: () => 'cfg',
  ver: () => 'ver',
  fwd: (deg: number) => `fwd ${deg.toFixed(0)}`,
  beam: (deg: number) => `beam ${deg.toFixed(0)}`,
  gain: (voie: number, db: number) => `gain ${voie} ${db.toFixed(1)}`,
  vmin: (kmh: number) => `vmin ${kmh.toFixed(1)}`,
  auto: (min: number) => `auto ${min.toFixed(0)}`,
  calpos: () => 'calpos',
  cal: (tag: number) => `cal ${tag}`,
  calfin: () => 'calfin',
  /** recalage de l'orientation des antennes (degrés, appris sur les nids trouvés) */
  rot: (deg: number) => `rot ${Math.round(deg)}`,
  /** enregistrement d'essai : niveaux bruts (sans lissage) dans les lignes R */
  brut: (on: boolean) => `brut ${on ? 1 : 0}`,
  nid: (lat: number, lon: number, errM: number, tag: number) => `nid ${lat.toFixed(7)} ${lon.toFixed(7)} ${errM.toFixed(0)} ${tag}`,
  maj: () => 'maj',
  /** ordre à distance à un tag (firmware tag 7) */
  ordre: (tag: number, o: OrdreTag) => `ordre ${tag} ${o}`,
  reset: () => 'reset',
  off: () => 'off',
};
