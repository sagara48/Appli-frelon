/** Mes tags (É13) : tags posés, disponibles, pile faible ; dernier signal et allers-retours. */
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, EnTete, Puces, Vide, s, useMaintenant } from '@/ui/composants';
import { C, fmtAge, idTag, police } from '@/ui/theme';
import { ageS, agePortatif, store, useEtat } from '@/store/store';
import { niveauPct } from '@/calc/geo';
import { ficheTag, majTag } from '@/services/carnet';
import type { EtatTag } from '@/db';

type Vue = { id: number; etat: EtatTag; age: number | null; pile: number | null; pct: number | null; appat: number | null; ar: number; poseMs: number | null };
const ETATS: Record<EtatTag, string> = { pose: 'Posé', dispo: 'Disponible', recupere: 'Récupéré', perdu: 'Perdu' };
const dateHeure = (ms: number) => new Date(ms).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

export default function Tags() {
  const router = useRouter();
  const e = useEtat((x) => ({ tags: x.tags, fiches: x.fichesTags, portatif: x.portatif, chrono: x.chrono, horlogeMs: x.horlogeMs }));
  const now = useMaintenant();
  const [filtre, setFiltre] = useState<'pose' | 'dispo' | 'pile' | 'tous'>('tous');

  const ids = new Set<number>([...Object.keys(e.tags), ...Object.keys(e.fiches), ...Object.keys(e.portatif.autres)].map(Number));
  if (e.portatif.st && e.portatif.st.tag >= 0) ids.add(e.portatif.st.tag);
  const vues: Vue[] = [...ids].sort((a, b) => a - b).map((id) => {
    const t = e.tags[id], f = e.fiches[id] ?? ficheTag(id), p = e.portatif.autres[id];
    const st = e.portatif.st && e.portatif.st.tag === id ? e.portatif.st : null;
    const ages = [t ? ageS(store.get(), t) : null, p ? p.age + (now - e.portatif.recuMs) / 1000 : null, st ? agePortatif(store.get()) : null].filter((x): x is number => x !== null);
    const appats = e.chrono.appats.filter((a) => a.tag === id);
    return {
      id, etat: f.etat, age: ages.length ? Math.min(...ages) : null, pile: t && t.pile >= 0 ? t.pile : null,
      pct: t ? niveauPct(Math.max(...t.r)) : st ? niveauPct(st.rssi) : p ? niveauPct(p.rssi) : null,
      appat: appats.length ? appats[appats.length - 1].id : f.appat, ar: appats.reduce((n, a) => n + a.trajets.length, 0), poseMs: f.pose_ms,
    };
  });
  const poses = vues.filter((v) => v.etat === 'pose'), dispo = vues.filter((v) => v.etat === 'dispo'), pile = vues.filter((v) => v.pile !== null && v.pile < 20);
  const liste = filtre === 'pose' ? poses : filtre === 'dispo' ? dispo : filtre === 'pile' ? pile : vues;

  const actions = (v: Vue) => Alert.alert(`Tag ${idTag(v.id)}`, `État : ${ETATS[v.etat]}`, [
    { text: 'Marquer récupéré', onPress: () => majTag(v.id, { etat: 'recupere' }) },
    { text: 'Marquer perdu', onPress: () => majTag(v.id, { etat: 'perdu' }) },
    { text: 'Remettre disponible', onPress: () => majTag(v.id, { etat: 'dispo', pose_ms: null, appat: null }) },
    { text: 'Annuler', style: 'cancel' },
  ]);

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Mes tags" />
      <Text style={s.discret}>{vues.length} tags connus · {poses.length} posé{poses.length > 1 ? 's' : ''} sur un frelon</Text>
      <Puces options={[['tous', `Tous (${vues.length})`], ['pose', `Posés (${poses.length})`], ['dispo', `Disponibles (${dispo.length})`], ['pile', `Pile faible (${pile.length})`]]} valeur={filtre} onChange={setFiltre} />
      {!liste.length && <Carte><Vide titre="Aucun tag" texte="Les tags apparaissent dès qu'ils sont entendus par le toit ou le portatif, ou quand on en pose un." /></Carte>}
      {liste.map((v) => (
        <Pressable key={v.id} onPress={() => { store.choisirTag(v.id); actions(v); }}>
          <Carte>
            <View style={[s.ligne, { justifyContent: 'space-between' }]}>
              <Text style={{ fontSize: 22, fontWeight: '800', color: C.encre }}>{idTag(v.id)}</Text>
              <Text style={{ color: v.age === null || v.age > 120 ? C.alerte : C.ok, fontWeight: '700' }}>
                {v.age === null ? 'Jamais reçu pendant cette sortie' : v.age > 120 ? `Perdu depuis ${fmtAge(v.age)}` : `Reçu il y a ${fmtAge(v.age)}`}
              </Text>
            </View>
            <View style={[s.ligne, { gap: 16, marginTop: 6, flexWrap: 'wrap' }]}>
              <Text style={s.discret}>Pile <Text style={{ color: v.pile !== null && v.pile < 20 ? C.alerte : C.encre, fontWeight: '700' }}>{v.pile !== null ? `${v.pile} %` : '—'}</Text></Text>
              <Text style={s.discret}>Signal <Text style={{ color: C.encre, fontWeight: '700' }}>{v.pct !== null && (v.age ?? 999) < 30 ? `${v.pct} %` : '—'}</Text></Text>
              {v.appat !== null && <Text style={s.discret}>Appât <Text style={{ color: C.encre, fontWeight: '700' }}>{v.appat}</Text></Text>}
              <Text style={[s.discret, { fontWeight: '700' }]}>{ETATS[v.etat]}</Text>
            </View>
            {(v.poseMs || v.ar > 0) && <Text style={[s.discret, { marginTop: 4, fontSize: police.mini }]}>{v.poseMs ? `Posé le ${dateHeure(v.poseMs)}` : ''}{v.poseMs && v.ar ? ' · ' : ''}{v.ar ? `${v.ar} aller${v.ar > 1 ? 's' : ''}-retour${v.ar > 1 ? 's' : ''}` : ''}</Text>}
          </Carte>
        </Pressable>
      ))}
      <Bouton titre="Poser un tag" plein onPress={() => router.push('/pose-tag')} />
    </ScrollView>
  );
}
