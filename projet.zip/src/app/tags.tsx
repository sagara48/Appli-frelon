/** Mes tags (É13) : tags posés, disponibles, pile faible, sans nouvelles ; dernier contact (pour retrouver un tag perdu), allers-retours. */
import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Linking, Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, EnTete, Puces, Vide, s, useMaintenant } from '@/ui/composants';
import { C, fmtAge, fmtDist, idTag, police } from '@/ui/theme';
import { ageS, agePortatif, maintenant, meilleurePosition, store, useEtat } from '@/store/store';
import { bilanActivite, diagnosticImmobile, texteActivite, type Activite } from '@/calc/activite';
import { envoyerCible } from '@/services/cible';
import { etalonner, useEtalonnages } from '@/services/etalonnage';
import { distM, niveauPct } from '@/calc/geo';
import { ficheTag, majTag } from '@/services/carnet';
import type { EtatTag } from '@/db';
import { LIBELLE_RECHARGE, raisonRecharge, type RaisonRecharge } from '@/calc/saison';
import { reglagesRecharge } from '@/services/suiviTags';
import { modeleDistance, useParametres } from '@/services/parametres';
import { distanceRssi, texteDistance, type Distance } from '@/calc/distance';
import { lienItineraire } from '@/calc/itineraire';
import { autonomieH, resteH, texteDuree } from '@/calc/autonomie';
import { demanderOrdre, relaisOrdre, texteOrdre, useOrdres } from '@/services/ordres';
import type { OrdreTag } from '@/proto/portatif';

type Vue = { act: Activite | null; vu: { t: number; lat: number; lon: number; par: string; err: number | null } | null; dist: Distance | null; id: number; etat: EtatTag; age: number | null; pile: number | null; recharge: RaisonRecharge | null; rechargeMs: number | null; pct: number | null; appat: number | null; ar: number; poseMs: number | null };
const ETATS: Record<EtatTag, string> = { pose: 'Posé', dispo: 'Disponible', recupere: 'Récupéré', perdu: 'Perdu' };
const LIBELLE_PAR: Record<string, string> = { estimation: 'nid estimé', voiture: 'depuis la voiture', portatif: 'au portatif' };
const texteIlYa = (ms: number) => { const m = Math.round(ms / 60000); return m < 60 ? `il y a ${Math.max(1, m)} min` : m < 48 * 60 ? `il y a ${Math.round(m / 60)} h` : `il y a ${Math.round(m / 1440)} j`; };
/** Ouvre la navigation (Google Maps, Waze…) vers un point. */
const allerA = (lat: number, lon: number, nom: string) => { Linking.openURL(`geo:${lat},${lon}?q=${lat},${lon}(${encodeURIComponent(nom)})`).catch(() => Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${lat},${lon}`)); };
const dateHeure = (ms: number) => new Date(ms).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

/** Note la recharge (heure actuelle) des tags donnés. */
function recharges(ids: number[]) { const t0 = Date.now(); for (const id of ids) majTag(id, { recharge_ms: t0 }); }

export default function Tags() {
  const router = useRouter();
  const P = useParametres();
  const etals = useEtalonnages();
  const e = useEtat((x) => ({ activites: x.activites, tags: x.tags, fiches: x.fichesTags, portatif: x.portatif, chrono: x.chrono, horlogeMs: x.horlogeMs }));
  const now = useMaintenant();
  const q = useLocalSearchParams<{ filtre?: string }>();
  const [filtre, setFiltre] = useState<'pose' | 'dispo' | 'pile' | 'recharge' | 'silence' | 'tous'>(q.filtre === 'silence' || q.filtre === 'recharge' ? q.filtre : 'tous');
  const rr = reglagesRecharge();
  const ordres = useOrdres();
  const conso = { capaciteMah: P.tagCapaciteMah, veilleUa: P.tagVeilleUa, trameUc: P.tagTrameUc, lpUc: P.tagLpUc, cnUc: P.tagCnUc };
  const relais = relaisOrdre();

  const ids = new Set<number>([...Object.keys(e.tags), ...Object.keys(e.fiches), ...Object.keys(e.portatif.autres)].map(Number));
  if (e.portatif.st && e.portatif.st.tag >= 0) ids.add(e.portatif.st.tag);
  const vues: Vue[] = [...ids].sort((a, b) => a - b).map((id) => {
    const t = e.tags[id], f = e.fiches[id] ?? ficheTag(id), p = e.portatif.autres[id];
    const st = e.portatif.st && e.portatif.st.tag === id ? e.portatif.st : null;
    const ages = [t ? ageS(store.get(), t) : null, p ? p.age + (now - e.portatif.recuMs) / 1000 : null, st ? agePortatif(store.get()) : null].filter((x): x is number => x !== null);
    const appats = e.chrono.appats.filter((a) => a.tag === id);
    return {
      act: e.activites[id] ?? null, id, etat: f.etat, age: ages.length ? Math.min(...ages) : null, pile: t && t.pile >= 0 ? t.pile : f.pile,
      recharge: raisonRecharge(f, now, rr.seuil, rr.jours), rechargeMs: f.recharge_ms,
      pct: t ? niveauPct(Math.max(...t.r)) : st ? niveauPct(st.rssi) : p ? niveauPct(p.rssi) : null,
      dist: t ? distanceRssi(Math.max(...t.r), modeleDistance('toit', P)) : st ? distanceRssi(st.rssi, { ...modeleDistance('portatif', P), ...(etals[id] ? { ref1m: etals[id].p1m } : {}) }) : p ? distanceRssi(p.rssi, { ...modeleDistance('portatif', P), ...(etals[id] ? { ref1m: etals[id].p1m } : {}) }) : null,
      appat: appats.length ? appats[appats.length - 1].id : f.appat, ar: appats.reduce((n, a) => n + a.trajets.length, 0), poseMs: f.pose_ms,
      vu: f.vu_ms && f.vu_lat != null && f.vu_lon != null ? { t: f.vu_ms, lat: f.vu_lat, lon: f.vu_lon, par: f.vu_par ?? '', err: f.vu_err ?? null } : null,
    };
  });
  const poses = vues.filter((v) => v.etat === 'pose'), dispo = vues.filter((v) => v.etat === 'dispo'), pile = vues.filter((v) => v.pile !== null && v.pile < P.pileFaiblePct);
  const aRecharger = vues.filter((v) => v.recharge !== null && v.etat !== 'pose');
  const silence = vues.filter((v) => v.etat === 'pose' && now - Math.max(v.vu?.t ?? 0, v.poseMs ?? 0) >= P.silenceJours * 86400000);
  const ici = meilleurePosition();
  const liste = filtre === 'pose' ? poses : filtre === 'dispo' ? dispo : filtre === 'pile' ? pile : filtre === 'recharge' ? aRecharger : filtre === 'silence' ? silence : vues;

  // Android n'affiche que 3 boutons par fenêtre : les changements d'état sont dans une seconde fenêtre
  const actions = (v: Vue) => Alert.alert(`Tag ${idTag(v.id)}`, `État : ${ETATS[v.etat]}`, [
    { text: 'Rechargé à l\'instant', onPress: () => recharges([v.id]) },
    { text: 'Changer l\'état…', onPress: () => Alert.alert(`Tag ${idTag(v.id)}`, 'Nouvel état', [
      { text: 'Récupéré', onPress: () => majTag(v.id, { etat: 'recupere' }) },
      { text: 'Perdu', onPress: () => majTag(v.id, { etat: 'perdu' }) },
      { text: 'Disponible', onPress: () => majTag(v.id, { etat: 'dispo', pose_ms: null, appat: null }) },
    ], { cancelable: true }) },
    { text: 'Annuler', style: 'cancel' },
  ]);

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Mes tags" />
      <Text style={s.discret}>Un tag rechargé tient environ {texteDuree(autonomieH(conso))} (11 h de nuit au nid, où il émet moins).</Text>
      <Text style={s.discret}>{vues.length} tags connus · {poses.length} posé{poses.length > 1 ? 's' : ''} sur un frelon</Text>
      <Puces options={[['tous', `Tous (${vues.length})`], ['pose', `Posés (${poses.length})`], ['dispo', `Disponibles (${dispo.length})`], ['pile', `Pile faible (${pile.length})`], ['recharge', `À recharger (${aRecharger.length})`], ['silence', `Sans nouvelles (${silence.length})`]]} valeur={filtre} onChange={setFiltre} />
      {filtre === 'recharge' && aRecharger.length > 0 && (
        <Carte>
          <Text style={{ color: C.encre }}>Après une séance sur le chargeur, notez-les rechargés d'un coup :</Text>
          <View style={{ marginTop: 8 }}><Bouton titre={`Les ${aRecharger.length} sont rechargés`} plein onPress={() => recharges(aRecharger.map((v) => v.id))} /></View>
        </Carte>
      )}
      {filtre === 'silence' && silence.length > 0 && (
        <Carte>
          <Text style={{ color: C.encre }}>Posés et plus entendus depuis {P.silenceJours} jour{P.silenceJours > 1 ? 's' : ''} : allez voir près du dernier contact, ou rayez-les (récupéré, perdu).</Text>
          {(() => {
            const etapes = silence.filter((v) => v.vu).map((v) => ({ lat: v.vu!.lat, lon: v.vu!.lon, nom: `Tag ${idTag(v.id)}` }));
            const url = lienItineraire(ici, etapes);
            return url ? (
              <View style={{ marginTop: 8 }}>
                <Bouton titre={`Itinéraire par ${etapes.length > 1 ? `leurs ${Math.min(10, etapes.length)} derniers contacts` : 'son dernier contact'}`} plein onPress={() => Linking.openURL(url).catch(() => {})} />
                <Text style={[s.discret, { marginTop: 4, fontSize: police.mini }]}>Dans l'ordre du plus proche, en voiture, toit allumé : il les entendra en passant.</Text>
              </View>
            ) : null;
          })()}
        </Carte>
      )}
      {!liste.length && <Carte><Vide titre="Aucun tag" texte="Les tags apparaissent dès qu'ils sont entendus par le toit ou le portatif, ou quand on en pose un." /></Carte>}
      {liste.map((v) => (
        <Pressable key={v.id} onPress={() => { store.choisirTag(v.id); actions(v); }}>
          <Carte>
            <View style={[s.ligne, { justifyContent: 'space-between' }]}>
              <Text style={{ fontSize: 22, fontWeight: '800', color: C.encre }}>{idTag(v.id)}</Text>
              <Text style={{ color: v.age === null || v.age > P.tagPerduS ? C.alerte : C.ok, fontWeight: '700' }}>
                {v.age === null ? 'Jamais reçu pendant cette sortie' : v.age > P.tagPerduS ? `Perdu depuis ${fmtAge(v.age)}` : `Reçu il y a ${fmtAge(v.age)}`}
              </Text>
            </View>
            <View style={[s.ligne, { gap: 16, marginTop: 6, flexWrap: 'wrap' }]}>
              <Text style={s.discret}>Pile <Text style={{ color: v.pile !== null && v.pile < P.pileFaiblePct ? C.alerte : C.encre, fontWeight: '700' }}>{v.pile !== null ? `${v.pile} %` : '—'}</Text>{v.pile !== null && <Text> · encore ~{texteDuree(resteH(conso, v.pile, v.age !== null ? v.age / 3600 : 0))}</Text>}</Text>
              <Text style={s.discret}>Signal <Text style={{ color: C.encre, fontWeight: '700' }}>{v.pct !== null && (v.age ?? 999) < 30 ? `${v.pct} %${v.dist ? ` · ${texteDistance(v.dist).court}` : ''}` : '—'}</Text></Text>
              {v.appat !== null && <Text style={s.discret}>Appât <Text style={{ color: C.encre, fontWeight: '700' }}>{v.appat}</Text></Text>}
              <Text style={[s.discret, { fontWeight: '700' }]}>{ETATS[v.etat]}</Text>
            </View>
            {(() => {
              const tx = texteActivite(v.act, maintenant()), b = bilanActivite(v.act, maintenant());
              if (!tx || !b) return null;
              const im = diagnosticImmobile(v.act, maintenant());
              if (im !== null) return <Text style={{ color: im.cas === 'auNid' ? C.encre : C.alerte, fontWeight: '700', marginTop: 4 }}>{im.texte}</Text>;
              return (
                <Text style={{ color: v.act!.nid ? C.encre : C.ok, fontWeight: '700', marginTop: 4 }}>
                  {tx}{b.sortiesJour ? <Text style={[s.discret, { fontWeight: '400' }]}> · {b.sortiesJour} sortie{b.sortiesJour > 1 ? 's' : ''} aujourd'hui{b.dureeMedianeMin !== null ? `, ${b.dureeMedianeMin} min en moyenne` : ''}</Text> : null}
                </Text>
              );
            })()}
            {v.recharge && v.etat !== 'pose' && <Text style={{ color: C.alerte, fontWeight: '700', marginTop: 4 }}>À recharger : {LIBELLE_RECHARGE[v.recharge]}</Text>}
            {!v.recharge && v.rechargeMs && <Text style={[s.discret, { marginTop: 4, fontSize: police.mini }]}>Rechargé le {dateHeure(v.rechargeMs)}</Text>}
            {(!!etals[v.id] || e.portatif.connexion === 'connecte') && (
              <View style={[s.ligne, { justifyContent: 'space-between', marginTop: 4 }]}>
                <Text style={[s.discret, { fontSize: police.mini }]}>{etals[v.id] ? `Étalonné : ${etals[v.id].p1m} dBm à 1 m` : 'Pas étalonné (distances moins justes)'}</Text>
                {e.portatif.connexion === 'connecte' && (
                  <Pressable onPress={() => etalonner(v.id, idTag(v.id))}><Text style={[s.discret, { fontSize: police.mini, textDecorationLine: 'underline' }]}>{etals[v.id] ? 'Refaire' : 'Étalonner'}</Text></Pressable>
                )}
              </View>
            )}
            {v.vu && (
              <View style={[s.ligne, { justifyContent: 'space-between', marginTop: 6 }]}>
                <Text style={[s.discret, { flex: 1 }]}>
                  Dernier contact {texteIlYa(now - v.vu.t)} · {LIBELLE_PAR[v.vu.par] ?? v.vu.par}{v.vu.err ? ` ±${v.vu.err} m` : ''}
                  {ici ? ` · à ${fmtDist(distM(ici.lat, ici.lon, v.vu.lat, v.vu.lon))}` : ''}
                </Text>
                <View style={[s.ligne, { gap: 6 }]}>
                  <Pressable onPress={() => envoyerCible(v.vu!.lat, v.vu!.lon, `Tag ${idTag(v.id)}`)} style={{ paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, borderWidth: 1, borderColor: C.encre }}>
                    <Text style={{ color: C.encre, fontWeight: '700', fontSize: police.mini }}>Portatif</Text>
                  </Pressable>
                  <Pressable onPress={() => allerA(v.vu!.lat, v.vu!.lon, `Tag ${idTag(v.id)}`)} style={{ paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, borderWidth: 1, borderColor: C.encre }}>
                    <Text style={{ color: C.encre, fontWeight: '700', fontSize: police.mini }}>Y aller</Text>
                  </Pressable>
                </View>
              </View>
            )}
            {(relais !== null || !!texteOrdre(v.id, now)) && (
              <View style={{ marginTop: 8 }}>
                {!!texteOrdre(v.id, now) && <Text style={{ color: C.encre, fontWeight: '700', marginBottom: 6 }}>{texteOrdre(v.id, now)}</Text>}
                {relais !== null && (
                  <View style={[s.ligne, { gap: 6, flexWrap: 'wrap' }]}>
                    {([['ping', 'Répond ?'], (ordres.rechJusqua[v.id] ?? 0) > now ? ['fin', 'Arrêter la recherche'] : ['rech', 'Recherche 10 min'], ['off', 'Désactiver']] as [OrdreTag, string][]).map(([o, t]) => (
                      <Pressable key={o} onPress={() => demanderOrdre(v.id, o)} disabled={ordres.suivis[v.id]?.etat === 'envoi'}
                        style={{ paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, borderWidth: 1, borderColor: o === 'off' ? C.alerte : C.encre, opacity: ordres.suivis[v.id]?.etat === 'envoi' ? 0.4 : 1 }}>
                        <Text style={{ color: o === 'off' ? C.alerte : C.encre, fontWeight: '700', fontSize: police.mini }}>{t}</Text>
                      </Pressable>
                    ))}
                    <Text style={[s.discret, { fontSize: police.mini, alignSelf: 'center' }]}>via le {relais}</Text>
                  </View>
                )}
              </View>
            )}
            {v.etat === 'pose' && !v.vu && <Text style={[s.discret, { marginTop: 4, fontSize: police.mini }]}>Jamais entendu depuis la pose.</Text>}
            {(v.poseMs || v.ar > 0) && <Text style={[s.discret, { marginTop: 4, fontSize: police.mini }]}>{v.poseMs ? `Posé le ${dateHeure(v.poseMs)}` : ''}{v.poseMs && v.ar ? ' · ' : ''}{v.ar ? `${v.ar} aller${v.ar > 1 ? 's' : ''}-retour${v.ar > 1 ? 's' : ''}` : ''}</Text>}
          </Carte>
        </Pressable>
      ))}
      <Bouton titre="Poser un tag" plein onPress={() => router.push('/pose-tag')} />
      <View style={[s.ligne, { gap: 10 }]}>
        <Bouton titre="Scanner un tag" onPress={() => router.push('/scanner')} />
        <Bouton titre="Étiquettes QR" onPress={() => router.push('/etiquettes')} />
      </View>
    </ScrollView>
  );
}
