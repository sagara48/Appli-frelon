/** Mes tags (É13) : tags posés, disponibles, pile faible ; dernier signal et allers-retours. */
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, EnTete, Puces, Vide, s, useMaintenant } from '@/ui/composants';
import { C, fmtAge, idTag, police } from '@/ui/theme';
import { ageS, agePortatif, store, useEtat } from '@/store/store';
import { niveauPct } from '@/calc/geo';
import { ficheTag, majTag } from '@/services/carnet';
import type { EtatTag } from '@/db';
import { LIBELLE_RECHARGE, raisonRecharge, type RaisonRecharge } from '@/calc/saison';
import { reglagesRecharge } from '@/services/suiviTags';
import { modeleDistance, useParametres } from '@/services/parametres';
import { distanceRssi, texteDistance, type Distance } from '@/calc/distance';

type Vue = { dist: Distance | null; id: number; etat: EtatTag; age: number | null; pile: number | null; recharge: RaisonRecharge | null; rechargeMs: number | null; pct: number | null; appat: number | null; ar: number; poseMs: number | null };
const ETATS: Record<EtatTag, string> = { pose: 'Posé', dispo: 'Disponible', recupere: 'Récupéré', perdu: 'Perdu' };
const dateHeure = (ms: number) => new Date(ms).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

/** Note la recharge (heure actuelle) des tags donnés. */
function recharges(ids: number[]) { const t0 = Date.now(); for (const id of ids) majTag(id, { recharge_ms: t0 }); }

export default function Tags() {
  const router = useRouter();
  const P = useParametres();
  const e = useEtat((x) => ({ tags: x.tags, fiches: x.fichesTags, portatif: x.portatif, chrono: x.chrono, horlogeMs: x.horlogeMs }));
  const now = useMaintenant();
  const [filtre, setFiltre] = useState<'pose' | 'dispo' | 'pile' | 'recharge' | 'tous'>('tous');
  const rr = reglagesRecharge();

  const ids = new Set<number>([...Object.keys(e.tags), ...Object.keys(e.fiches), ...Object.keys(e.portatif.autres)].map(Number));
  if (e.portatif.st && e.portatif.st.tag >= 0) ids.add(e.portatif.st.tag);
  const vues: Vue[] = [...ids].sort((a, b) => a - b).map((id) => {
    const t = e.tags[id], f = e.fiches[id] ?? ficheTag(id), p = e.portatif.autres[id];
    const st = e.portatif.st && e.portatif.st.tag === id ? e.portatif.st : null;
    const ages = [t ? ageS(store.get(), t) : null, p ? p.age + (now - e.portatif.recuMs) / 1000 : null, st ? agePortatif(store.get()) : null].filter((x): x is number => x !== null);
    const appats = e.chrono.appats.filter((a) => a.tag === id);
    return {
      id, etat: f.etat, age: ages.length ? Math.min(...ages) : null, pile: t && t.pile >= 0 ? t.pile : f.pile,
      recharge: raisonRecharge(f, now, rr.seuil, rr.jours), rechargeMs: f.recharge_ms,
      pct: t ? niveauPct(Math.max(...t.r)) : st ? niveauPct(st.rssi) : p ? niveauPct(p.rssi) : null,
      dist: t ? distanceRssi(Math.max(...t.r), modeleDistance('toit', P)) : st ? distanceRssi(st.rssi, modeleDistance('portatif', P)) : p ? distanceRssi(p.rssi, modeleDistance('portatif', P)) : null,
      appat: appats.length ? appats[appats.length - 1].id : f.appat, ar: appats.reduce((n, a) => n + a.trajets.length, 0), poseMs: f.pose_ms,
    };
  });
  const poses = vues.filter((v) => v.etat === 'pose'), dispo = vues.filter((v) => v.etat === 'dispo'), pile = vues.filter((v) => v.pile !== null && v.pile < P.pileFaiblePct);
  const aRecharger = vues.filter((v) => v.recharge !== null && v.etat !== 'pose');
  const liste = filtre === 'pose' ? poses : filtre === 'dispo' ? dispo : filtre === 'pile' ? pile : filtre === 'recharge' ? aRecharger : vues;

  // Android n'affiche que 3 boutons par fenêtre : les changements d'état sont dans une seconde fenêtre
  const actions = (v: Vue) => Alert.alert(`Tag ${idTag(v.id)}`, `État : ${ETATS[v.etat]}`, [
    { text: 'Rechargé à l\'instant', onPress: () => recharges([v.id]) },
    { text: 'Changer l\'état…', onPress: () => Alert.alert(`Tag ${idTag(v.id)}`, 'Nouvel état', [
      { text: 'Récupéré', onPress: () => majTag(v.id, { etat: 'recupere' }) },
      { text: 'Perdu', onPress: () => majTag(v.id, { etat: 'perdu' }) },
      { text: 'Disponible', onPress: () => majTag(v.id, { etat: 'dispo', pose_ms: null, appat: null }) },
    ], { cancelable: true }) },
    { text: 'Annuler', style: 'cancel' },
  ]);

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Mes tags" />
      <Text style={s.discret}>{vues.length} tags connus · {poses.length} posé{poses.length > 1 ? 's' : ''} sur un frelon</Text>
      <Puces options={[['tous', `Tous (${vues.length})`], ['pose', `Posés (${poses.length})`], ['dispo', `Disponibles (${dispo.length})`], ['pile', `Pile faible (${pile.length})`], ['recharge', `À recharger (${aRecharger.length})`]]} valeur={filtre} onChange={setFiltre} />
      {filtre === 'recharge' && aRecharger.length > 0 && (
        <Carte>
          <Text style={{ color: C.encre }}>Après une séance sur le chargeur, notez-les rechargés d'un coup :</Text>
          <View style={{ marginTop: 8 }}><Bouton titre={`Les ${aRecharger.length} sont rechargés`} plein onPress={() => recharges(aRecharger.map((v) => v.id))} /></View>
        </Carte>
      )}
      {!liste.length && <Carte><Vide titre="Aucun tag" texte="Les tags apparaissent dès qu'ils sont entendus par le toit ou le portatif, ou quand on en pose un." /></Carte>}
      {liste.map((v) => (
        <Pressable key={v.id} onPress={() => { store.choisirTag(v.id); actions(v); }}>
          <Carte>
            <View style={[s.ligne, { justifyContent: 'space-between' }]}>
              <Text style={{ fontSize: 22, fontWeight: '800', color: C.encre }}>{idTag(v.id)}</Text>
              <Text style={{ color: v.age === null || v.age > P.tagPerduS ? C.alerte : C.ok, fontWeight: '700' }}>
                {v.age === null ? 'Jamais reçu pendant cette sortie' : v.age > P.tagPerduS ? `Perdu depuis ${fmtAge(v.age)}` : `Reçu il y a ${fmtAge(v.age)}`}
              </Text>
            </View>
            <View style={[s.ligne, { gap: 16, marginTop: 6, flexWrap: 'wrap' }]}>
              <Text style={s.discret}>Pile <Text style={{ color: v.pile !== null && v.pile < P.pileFaiblePct ? C.alerte : C.encre, fontWeight: '700' }}>{v.pile !== null ? `${v.pile} %` : '—'}</Text></Text>
              <Text style={s.discret}>Signal <Text style={{ color: C.encre, fontWeight: '700' }}>{v.pct !== null && (v.age ?? 999) < 30 ? `${v.pct} %${v.dist ? ` · ${texteDistance(v.dist).court}` : ''}` : '—'}</Text></Text>
              {v.appat !== null && <Text style={s.discret}>Appât <Text style={{ color: C.encre, fontWeight: '700' }}>{v.appat}</Text></Text>}
              <Text style={[s.discret, { fontWeight: '700' }]}>{ETATS[v.etat]}</Text>
            </View>
            {v.recharge && v.etat !== 'pose' && <Text style={{ color: C.alerte, fontWeight: '700', marginTop: 4 }}>À recharger : {LIBELLE_RECHARGE[v.recharge]}</Text>}
            {!v.recharge && v.rechargeMs && <Text style={[s.discret, { marginTop: 4, fontSize: police.mini }]}>Rechargé le {dateHeure(v.rechargeMs)}</Text>}
            {(v.poseMs || v.ar > 0) && <Text style={[s.discret, { marginTop: 4, fontSize: police.mini }]}>{v.poseMs ? `Posé le ${dateHeure(v.poseMs)}` : ''}{v.poseMs && v.ar ? ' · ' : ''}{v.ar ? `${v.ar} aller${v.ar > 1 ? 's' : ''}-retour${v.ar > 1 ? 's' : ''}` : ''}</Text>}
          </Carte>
        </Pressable>
      ))}
      <Bouton titre="Poser un tag" plein onPress={() => router.push('/pose-tag')} />
    </ScrollView>
  );
}
