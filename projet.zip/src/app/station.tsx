/** Station fixe (É24) : le toit sur un trépied au rucher ; rose des directions de départ de tous les frelons tagués. */
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useKeepAwake } from 'expo-keep-awake';
import React from 'react';
import { Alert, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import Svg, { Circle, Line, Path, Text as T } from 'react-native-svg';
import { Bouton, Carte, EnTete, Titre, s, useMaintenant } from '@/ui/composants';
import { C, fmtAge, fmtDist, police } from '@/ui/theme';
import { arreterStation, demarrerStation, useEtat } from '@/store/store';
import { D2R, pointCardinal } from '@/calc/geo';
import { resume } from '@/calc/appat';
import { envoyerToit } from '@/sources/commandesToit';
import { cmdToit } from '@/proto/toit';

const NS = 16; // secteurs de 22,5°

export default function Station() {
  useKeepAwake();
  const router = useRouter();
  const { rucher } = useLocalSearchParams<{ rucher?: string }>();
  const { width } = useWindowDimensions();
  const e = useEtat((x) => ({ station: x.station, ruchers: x.ruchers, chrono: x.chrono, toit: x.toit, connexion: x.connexion, source: x.source, arretAutoMin: x.arretAutoMin }));
  const st = e.station;
  const now = useMaintenant(5000);
  const r = e.ruchers.find((x) => x.id === Number(rucher)) ?? e.ruchers[0];
  const actif = (e.source === 'toit' || e.source === 'simulation') && e.connexion === 'connecte';

  const demarrer = () => {
    if (!actif) { Alert.alert('Station', 'Connectez d\'abord le toit (posé sur son trépied).'); return; }
    const pos = e.toit && e.toit.lat ? { lat: e.toit.lat, lon: e.toit.lon } : r ? { lat: r.lat, lon: r.lon } : null;
    if (!pos) { Alert.alert('Station', 'Pas de position GPS du toit pour l\'instant.'); return; }
    envoyerToit(cmdToit.auto(0)).catch(() => {}); // pas d'arrêt automatique tant que la station tourne
    demarrerStation({ ...pos, rucherId: r?.id ?? null, nom: r ? `rucher ${r.nom}` : 'station', debutMs: Date.now() });
  };
  const arreter = () => { envoyerToit(cmdToit.auto(e.arretAutoMin)).catch(() => {}); arreterStation(); };

  // départs (et retours) chronométrés à la station
  const appats = st ? e.chrono.appats.filter((a) => a.lat === st.lat && a.lon === st.lon) : [];
  const caps: number[] = [];
  for (const a of appats) for (const t of a.trajets) { if (t.capDep !== null) caps.push(t.capDep); }
  const secteurs = new Array(NS).fill(0);
  for (const c of caps) secteurs[Math.round(c / (360 / NS)) % NS]++;
  let sx = 0, sy = 0; for (const c of caps) { sx += Math.cos(c * D2R); sy += Math.sin(c * D2R); }
  const R = caps.length ? Math.hypot(sx, sy) / caps.length : 0;
  const dom = caps.length ? (Math.atan2(sy, sx) / D2R + 360) % 360 : null;
  const disp = caps.length > 1 ? Math.sqrt(-2 * Math.log(Math.max(R, 1e-6))) / D2R : null;
  const dansAxe = dom !== null ? caps.filter((c) => Math.abs(((c - dom + 540) % 360) - 180) <= 30).length : 0;
  const distances = appats.map((a) => resume(e.chrono, a).rt).filter((x) => x.ok).map((x) => x.r);
  const dMoy = distances.length ? distances.reduce((a, b) => a + b, 0) / distances.length : null;
  const nTrajets = appats.reduce((n, a) => n + a.trajets.length, 0);

  const T0 = Math.min(width - 64, 300), c = T0 / 2, rr = c - 22, maxS = Math.max(1, ...secteurs);
  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre={st ? `Station au ${st.nom}` : 'Station au rucher'} />
      <Text style={s.discret}>{st ? `Toit sur trépied · en écoute depuis ${fmtAge((now - st.debutMs) / 1000)}` : 'Le toit posé au rucher relève la direction de départ de chaque frelon tagué.'}</Text>
      {st && (
        <Carte style={{ alignItems: 'center' }}>
          <Titre>Directions de départ ({caps.length} frelon{caps.length > 1 ? 's' : ''})</Titre>
          <Svg width={T0} height={T0}>
            {[0.33, 0.66, 1].map((k) => <Circle key={k} cx={c} cy={c} r={rr * k} fill="none" stroke={C.ligne} />)}
            {secteurs.map((n, i) => {
              if (!n) return null;
              const a1 = (i - 0.5) * (360 / NS) * D2R, a2 = (i + 0.5) * (360 / NS) * D2R, l = (rr * n) / maxS;
              return <Path key={i} d={`M${c},${c} L${c + Math.sin(a1) * l},${c - Math.cos(a1) * l} A${l},${l} 0 0 1 ${c + Math.sin(a2) * l},${c - Math.cos(a2) * l} Z`} fill={C.accent} opacity={0.85} />;
            })}
            {dom !== null && <Line x1={c} y1={c} x2={c + Math.sin(dom * D2R) * rr} y2={c - Math.cos(dom * D2R) * rr} stroke={C.encre} strokeWidth={3} />}
            {(['N', 'E', 'S', 'O'] as const).map((l, i) => <T key={l} x={c + Math.sin(i * 90 * D2R) * (rr + 12)} y={c - Math.cos(i * 90 * D2R) * (rr + 12) + 5} fontSize={13} fontWeight="700" fill={C.encre} textAnchor="middle">{l}</T>)}
          </Svg>
          <View style={[s.ligne, { justifyContent: 'space-around', alignSelf: 'stretch', marginTop: 8 }]}>
            <Chiffre k="Direction dominante" v={dom !== null ? `${Math.round(dom)}° ${pointCardinal(dom)}` : '—'} />
            <Chiffre k="Dispersion" v={disp !== null ? `± ${Math.round(disp)}°` : '—'} />
            <Chiffre k="Tags suivis" v={String(appats.length)} />
          </View>
          {dom !== null && caps.length >= 3 && (
            <Text style={{ color: C.encre, marginTop: 10, lineHeight: 20 }}>
              {dansAxe} départ{dansAxe > 1 ? 's' : ''} sur {caps.length} vont vers le {pointCardinal(dom)} : {dansAxe / caps.length >= 0.5 ? 'il y a très probablement un nid dans cette direction' : 'les directions sont encore dispersées, plusieurs nids possibles'}.
              {dMoy !== null ? ` Les allers-retours chronométrés ici donnent environ ${fmtDist(dMoy)}.` : ''}
            </Text>
          )}
          {!caps.length && <Text style={s.discret}>{nTrajets ? 'Allers-retours chronométrés, mais sans direction nette pour l\'instant.' : 'En attente des premiers départs…'}</Text>}
        </Carte>
      )}
      <View style={[s.ligne, { gap: 10 }]}>
        {st ? <>
          <Bouton titre="Tracer sur la carte" onPress={() => router.navigate('/carte')} />
          <Bouton titre="Arrêter la station" onPress={arreter} />
        </> : <Bouton titre="Démarrer la station" plein onPress={demarrer} />}
      </View>
      <Text style={[s.discret, { fontSize: police.mini }]}>Posez le toit sur un trépied à 1,5–2 m de haut, face avant au nord, à 10–20 m des ruches. L'arrêt automatique est coupé tant que la station tourne. Le cap de départ n'est connu que si le toit est étalonné.</Text>
    </ScrollView>
  );
}

function Chiffre({ k, v }: { k: string; v: string }) {
  return <View style={{ alignItems: 'center' }}><Text style={[s.discret, { fontSize: police.mini }]}>{k}</Text><Text style={{ color: C.encre, fontWeight: '800', fontSize: police.normal + 1 }}>{v}</Text></View>;
}
