/** Ruchers et nids (É22) : nids connus autour de chaque rucher, priorité, carte, station fixe. */
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import Svg, { Circle, Rect, Text as T } from 'react-native-svg';
import { Bouton, Carte, Champ, EnTete, Vide, s } from '@/ui/composants';
import { C, fmtDist, police } from '@/ui/theme';
import { meilleurePosition, useEtat } from '@/store/store';
import { KY, distM, kxOf } from '@/calc/geo';
import { nouveauRucher, numeroNid, supprimerRucher } from '@/services/carnet';
import type { Nid, Rucher } from '@/db';

const COUL: Record<string, string> = { trouve: C.alerte, estime: C.alerte, traite: C.accent, mort: C.ok };

export default function Ruchers() {
  const router = useRouter();
  const { width } = useWindowDimensions();
  const e = useEtat((x) => ({ ruchers: x.ruchers, nids: x.nids, station: x.station }));
  const [ajout, setAjout] = useState(false);
  const [nom, setNom] = useState('');
  const [ruches, setRuches] = useState('');

  const proche = (r: Rucher) => {
    let best: { n: Nid; d: number } | null = null;
    for (const n of e.nids) { const d = distM(r.lat, r.lon, n.lat, n.lon); if (!best || d < best.d) best = { n, d }; }
    return best;
  };
  const menace = (r: Rucher) => e.nids.filter((n) => n.etat !== 'mort' && n.etat !== 'traite' && distM(r.lat, r.lon, n.lat, n.lon) < 1000);
  const nMenaces = e.ruchers.filter((r) => menace(r).length).length;

  const ajouter = () => {
    const p = meilleurePosition();
    if (!p) { Alert.alert('Rucher', 'Pas de position : placez-vous au rucher avec la localisation activée.'); return; }
    if (!nom.trim()) { Alert.alert('Rucher', 'Donnez un nom au rucher.'); return; }
    nouveauRucher(nom.trim(), parseInt(ruches, 10) || null, p.lat, p.lon);
    setAjout(false); setNom(''); setRuches('');
  };

  // carte : ruchers et nids dans un carré centré sur le premier rucher
  const W = width - 64, H = Math.round(W * 0.75);
  const pts = [...e.ruchers.map((r) => [r.lat, r.lon]), ...e.nids.map((n) => [n.lat, n.lon])];
  let carte = null;
  if (e.ruchers.length) {
    const c0 = e.ruchers[0], kx = kxOf(c0.lat);
    const ext = Math.max(1200, ...pts.map(([la, lo]) => Math.max(Math.abs(la - c0.lat) * KY * (W / H), Math.abs(lo - c0.lon) * kx))) * 1.2;
    const m = (2 * ext) / W;
    const X = (lo: number) => W / 2 + ((lo - c0.lon) * kx) / m, Y = (la: number) => H / 2 - ((la - c0.lat) * KY) / m;
    carte = (
      <Svg width={W} height={H}>
        <Rect x={0} y={0} width={W} height={H} fill="#EEF0E8" rx={10} />
        {e.ruchers.map((r) => <Circle key={`z${r.id}`} cx={X(r.lon)} cy={Y(r.lat)} r={1000 / m} fill={C.accent} opacity={0.08} stroke={C.accent} strokeDasharray="4 4" />)}
        {e.nids.map((n) => <Circle key={n.id} cx={X(n.lon)} cy={Y(n.lat)} r={6} fill={COUL[n.etat]} stroke="#fff" strokeWidth={2} />)}
        {e.ruchers.map((r) => (
          <React.Fragment key={r.id}>
            <Rect x={X(r.lon) - 9} y={Y(r.lat) - 9} width={18} height={18} rx={3} fill={C.encre} />
            <T x={X(r.lon)} y={Y(r.lat) + 5} fontSize={11} fontWeight="700" fill="#fff" textAnchor="middle">{r.nom.slice(0, 1).toUpperCase()}</T>
          </React.Fragment>
        ))}
      </Svg>
    );
  }

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre="Ruchers et nids" />
      <Text style={s.discret}>{e.ruchers.length} rucher{e.ruchers.length > 1 ? 's' : ''} · {nMenaces} avec un nid actif à moins de 1 km</Text>
      {carte && <Carte style={{ alignItems: 'center' }}>{carte}
        <View style={[s.ligne, { gap: 12, marginTop: 8, flexWrap: 'wrap' }]}>
          {[['Rucher', C.encre], ['Nid à traiter', C.alerte], ['Traité', C.accent], ['Vérifié mort', C.ok]].map(([t, c]) => (
            <View key={t} style={[s.ligne, { gap: 4 }]}><View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: c }} /><Text style={[s.discret, { fontSize: police.mini }]}>{t}</Text></View>
          ))}
        </View>
        <Text style={[s.discret, { fontSize: police.mini, marginTop: 4 }]}>Cercles pointillés : 1 km autour de chaque rucher.</Text>
      </Carte>}
      {!e.ruchers.length && <Carte><Vide titre="Aucun rucher" texte="Ajoutez vos ruchers (et ceux des voisins) : l'appli signale les nids à moins de 1 km et sert de point de départ pour la météo et la station fixe." /></Carte>}
      {e.ruchers.map((r) => {
        const m = menace(r), p = proche(r);
        return (
          <Pressable key={r.id} onLongPress={() => Alert.alert(r.nom, 'Supprimer ce rucher ?', [{ text: 'Annuler', style: 'cancel' }, { text: 'Supprimer', style: 'destructive', onPress: () => supprimerRucher(r.id) }])}>
            <Carte>
              <View style={[s.ligne, { justifyContent: 'space-between' }]}>
                <Text style={{ color: C.encre, fontWeight: '800', fontSize: police.normal + 1 }}>Rucher {r.nom}{r.ruches ? ` · ${r.ruches} ruches` : ''}</Text>
                <Text style={{ color: m.length ? C.alerte : C.ok, fontWeight: '700' }}>{m.length ? 'Priorité haute' : 'Calme'}</Text>
              </View>
              <Text style={[s.discret, { marginTop: 4 }]}>
                {m.length ? m.map((n) => `Nid n° ${numeroNid(e.nids, n.id)} à traiter à ${fmtDist(distM(r.lat, r.lon, n.lat, n.lon))}`).join(' · ')
                  : p ? `Nid le plus proche : ${p.n.etat === 'mort' ? 'vérifié mort' : p.n.etat === 'traite' ? 'traité' : 'à traiter'}, à ${fmtDist(p.d)}` : 'Aucun nid connu'}
              </Text>
              <View style={[s.ligne, { gap: 10, marginTop: 10 }]}>
                <Bouton titre={e.station?.rucherId === r.id ? 'Station en cours' : 'Station au rucher'} onPress={() => router.push({ pathname: '/station', params: { rucher: String(r.id) } })} />
                <Bouton titre="Météo" onPress={() => router.push({ pathname: '/meteo', params: { rucher: String(r.id) } })} />
              </View>
            </Carte>
          </Pressable>
        );
      })}
      {ajout ? (
        <Carte>
          <Champ titre="Nom du rucher" valeur={nom} onChange={setNom} placeholder="A, du verger, de Paul…" />
          <Champ titre="Nombre de ruches" valeur={ruches} onChange={setRuches} clavier="numeric" />
          <Text style={[s.discret, { marginVertical: 6 }]}>Le rucher est placé à votre position actuelle.</Text>
          <View style={[s.ligne, { gap: 10 }]}><Bouton titre="Annuler" onPress={() => setAjout(false)} /><Bouton titre="Ajouter ici" plein onPress={ajouter} /></View>
        </Carte>
      ) : <Bouton titre="Ajouter un rucher" plein onPress={() => setAjout(true)} />}
      {e.ruchers.length > 0 && <Text style={[s.discret, { fontSize: police.mini }]}>Appui long sur un rucher pour le supprimer.</Text>}
    </ScrollView>
  );
}
