/** Fiche d'un piège : relevés (frelons asiatiques et autres insectes), retrait, suppression. */
import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Linking, Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, Champ, EnTete, Titre, s } from '@/ui/composants';
import { C, fmtCoord, fmtDist, police } from '@/ui/theme';
import { meilleurePosition, useEtat } from '@/store/store';
import { distM } from '@/calc/geo';
import { capturesPiege, piegeActif } from '@/calc/saison';
import { majPiege, supprimerPiege } from '@/services/carnet';
import type { Releve } from '@/db';
import { useParametres } from '@/services/parametres';

export default function FichePiege() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const p = useEtat((x) => x.pieges.find((y) => y.id === Number(id)) ?? null);
  const P = useParametres();
  const [frelons, setFrelons] = useState(0);
  const [autres, setAutres] = useState('');
  const [note, setNote] = useState('');
  if (!p) return <View style={s.ecran}><EnTete titre="Piège" /><Text style={[s.discret, { padding: 16 }]}>Piège introuvable.</Text></View>;
  const ici = meilleurePosition();
  const d = ici ? distM(ici.lat, ici.lon, p.lat, p.lon) : null;
  const an = new Date().getFullYear();
  const releves = [...p.releves].sort((a, b) => b.t - a.t);

  const noter = () => {
    const r: Releve = { t: Date.now(), frelons, autres: parseInt(autres, 10) || 0, note: note.trim() };
    majPiege(p.id, { releves: [...p.releves, r] });
    setFrelons(0); setAutres(''); setNote('');
  };
  const retirerReleve = (r: Releve) => Alert.alert('Relevé', `Supprimer le relevé du ${new Date(r.t).toLocaleDateString('fr-FR')} (${r.frelons} frelon(s)) ?`, [
    { text: 'Annuler', style: 'cancel' },
    { text: 'Supprimer', style: 'destructive', onPress: () => majPiege(p.id, { releves: p.releves.filter((x) => x.t !== r.t) }) },
  ]);

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre={p.nom} />
      <Text style={s.discret}>{p.appat || 'appât ?'}{p.pose_ms ? ` · posé le ${new Date(p.pose_ms).toLocaleDateString('fr-FR')}` : ''}{p.auteur ? ` · ${p.auteur}` : ''}</Text>
      <View style={[s.ligne, { gap: 10 }]}>
        <View style={[s.carte, { flex: 1, alignItems: 'center' }]}><Text style={{ fontSize: 26, fontWeight: '800', color: C.encre }}>{capturesPiege(p, an)}</Text><Text style={[s.discret, { fontSize: police.mini }]}>frelons en {an}</Text></View>
        <View style={[s.carte, { flex: 1, alignItems: 'center' }]}><Text style={{ fontSize: 26, fontWeight: '800', color: C.encre }}>{p.releves.length}</Text><Text style={[s.discret, { fontSize: police.mini }]}>relevés</Text></View>
      </View>

      {piegeActif(p) && (
        <Carte>
          <Titre>Nouveau relevé</Titre>
          <Text style={s.discret}>Frelons asiatiques depuis le dernier relevé</Text>
          <View style={[s.ligne, { gap: 14, justifyContent: 'center', marginVertical: 8 }]}>
            <Pressable onPress={() => setFrelons(Math.max(0, frelons - 1))} style={rond}><Text style={rondTxt}>−</Text></Pressable>
            <Text style={{ fontSize: 40, fontWeight: '800', color: C.encre, minWidth: 70, textAlign: 'center' }}>{frelons}</Text>
            <Pressable onPress={() => setFrelons(frelons + 1)} style={rond}><Text style={rondTxt}>+</Text></Pressable>
            <Pressable onPress={() => setFrelons(frelons + 10)} style={[rond, { width: 56 }]}><Text style={[rondTxt, { fontSize: 18 }]}>+10</Text></Pressable>
          </View>
          <View style={[s.ligne, { gap: 10 }]}>
            <View style={{ flex: 1 }}><Champ titre="Autres insectes" valeur={autres} onChange={setAutres} clavier="numeric" placeholder="0" /></View>
            <View style={{ flex: 2 }}><Champ titre="Remarque" valeur={note} onChange={setNote} placeholder="appât changé…" /></View>
          </View>
          <Bouton titre="Enregistrer le relevé" plein onPress={noter} />
        </Carte>
      )}

      <Carte>
        <Titre>Relevés</Titre>
        {!releves.length && <Text style={s.discret}>Aucun relevé.</Text>}
        {releves.map((r) => (
          <Pressable key={r.t} onLongPress={() => retirerReleve(r)} style={[s.ligne, { justifyContent: 'space-between', paddingVertical: 7, borderTopWidth: 1, borderTopColor: C.ligne }]}>
            <Text style={{ color: C.encre, width: 92 }}>{new Date(r.t).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</Text>
            <Text style={[s.discret, { flex: 1 }]} numberOfLines={1}>{r.autres ? `${r.autres} autre(s)` : ''}{r.autres && r.note ? ' · ' : ''}{r.note}</Text>
            <Text style={{ color: C.encre, fontWeight: '800', fontSize: police.normal + 1 }}>{r.frelons}</Text>
          </Pressable>
        ))}
        {releves.length > 0 && <Text style={[s.discret, { fontSize: police.mini, marginTop: 4 }]}>Appui long sur un relevé pour le supprimer.</Text>}
      </Carte>

      <Carte>
        <Titre>Emplacement</Titre>
        <Text style={{ color: C.encre }}>{fmtCoord(p.lat, p.lon)}{d !== null ? ` · à ${fmtDist(d)} de vous` : ''}</Text>
        <View style={[s.ligne, { gap: 10, marginTop: 8, flexWrap: 'wrap' }]}>
          <Bouton titre="Y aller" onPress={() => Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${p.lat.toFixed(6)},${p.lon.toFixed(6)}`)} />
          {ici && d !== null && d < P.sousNidM && <Bouton titre="Corriger : je suis au piège" onPress={() => majPiege(p.id, { lat: ici.lat, lon: ici.lon })} />}
        </View>
      </Carte>

      <View style={[s.ligne, { gap: 10 }]}>
        {piegeActif(p)
          ? <Bouton titre="Retirer le piège" onPress={() => majPiege(p.id, { retire_ms: Date.now() })} />
          : <Bouton titre="Remettre en place" onPress={() => majPiege(p.id, { retire_ms: null, pose_ms: Date.now() })} />}
      </View>
      <Pressable onPress={() => Alert.alert('Supprimer', `Supprimer « ${p.nom} » et ses relevés ?`, [{ text: 'Annuler', style: 'cancel' }, { text: 'Supprimer', style: 'destructive', onPress: () => { supprimerPiege(p.id); router.back(); } }])} style={{ alignSelf: 'center', marginTop: 4 }}>
        <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Supprimer le piège</Text>
      </Pressable>
    </ScrollView>
  );
}

const rond = { width: 48, height: 48, borderRadius: 24, borderWidth: 1.5, borderColor: C.encre, alignItems: 'center' as const, justifyContent: 'center' as const };
const rondTxt = { fontSize: 26, fontWeight: '700' as const, color: C.encre };
