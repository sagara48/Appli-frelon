/** Produits biocides proposés sur les interventions : nom commercial, substance active, n° d'autorisation (AMM). */
import React, { useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, Champ, EnTete, s } from '@/ui/composants';
import { C } from '@/ui/theme';
import { ecrireProduits, lireProduits } from '@/services/interventions';
import type { Produit } from '@/calc/intervention';

export default function Produits() {
  const [l, setL] = useState<Produit[]>(() => lireProduits().map((p) => ({ ...p })));
  const [ok, setOk] = useState(false);
  const maj = (k: number, p: Partial<Produit>) => { setOk(false); setL(l.map((x, i) => (i === k ? { ...x, ...p } : x))); };
  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre="Produits biocides" />
      <Text style={s.discret}>Proposés sur chaque intervention et repris dans le registre des traitements. Le n° d'autorisation (AMM) figure sur l'étiquette.</Text>
      {l.map((p, k) => (
        <Carte key={k}>
          <Champ titre="Nom commercial" valeur={p.nom} onChange={(v) => maj(k, { nom: v })} placeholder="Permas-D" />
          <Champ titre="Substance active et teneur" valeur={p.substance} onChange={(v) => maj(k, { substance: v })} placeholder="perméthrine 0,75 %" />
          <Champ titre="N° d'autorisation (AMM)" valeur={p.amm} onChange={(v) => maj(k, { amm: v })} />
          <Pressable onPress={() => { setOk(false); setL(l.filter((_, i) => i !== k)); }} style={{ alignSelf: 'flex-end' }}>
            <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Retirer</Text>
          </Pressable>
        </Carte>
      ))}
      <View style={[s.ligne, { gap: 10 }]}>
        <Bouton titre="+ Produit" onPress={() => setL([...l, { nom: '', substance: '', amm: '' }])} />
        <Bouton titre={ok ? 'Enregistré' : 'Enregistrer'} plein onPress={() => { ecrireProduits(l); setOk(true); }} />
      </View>
      {ok && <Text style={{ color: C.ok, fontWeight: '600' }}>Liste enregistrée.</Text>}
    </ScrollView>
  );
}
