/** Comptes rendus de sortie : enregistrés automatiquement à la fin de chaque sortie, à partager avec l'équipe. */
import React from 'react';
import { Alert, Pressable, ScrollView, Share, Text, View } from 'react-native';
import { Carte, EnTete, Vide, s } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { supprimerCompteRendu, useComptesRendus } from '@/services/sorties';
import { resumeCourt, texteCompteRendu } from '@/calc/compteRendu';
import { useParametres } from '@/services/parametres';

export default function Sorties() {
  const l = useComptesRendus();
  const P = useParametres();
  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Comptes rendus de sortie" />
      <Text style={s.discret}>Un compte rendu est écrit seul à la fin de chaque sortie (30 min après la dernière connexion du toit ou du portatif, ou « Terminer la sortie »). Les 50 derniers sont gardés.</Text>
      {!l.length && <Carte><Vide titre="Aucun compte rendu" texte={P.autoCompteRendu ? 'Le premier arrivera à la fin de votre prochaine sortie.' : 'Activez-les dans Paramètres → Automatismes.'} /></Carte>}
      {l.map((c) => (
        <Carte key={c.debut}>
          <Text style={{ color: C.encre, fontWeight: '800', fontSize: police.normal + 1 }}>{new Date(c.debut).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })}</Text>
          <Text style={[s.discret, { marginBottom: 6 }]}>{resumeCourt(c)}</Text>
          <Text style={{ color: C.encre, lineHeight: 20 }}>{texteCompteRendu(c).split('\n').slice(1).join('\n')}</Text>
          <View style={[s.ligne, { gap: 16, marginTop: 10 }]}>
            <Pressable onPress={() => Share.share({ message: texteCompteRendu(c, P.nom) }).catch(() => {})}><Text style={{ color: C.encre, fontWeight: '700', textDecorationLine: 'underline' }}>Partager</Text></Pressable>
            <Pressable onPress={() => Alert.alert('Supprimer ce compte rendu ?', '', [{ text: 'Annuler', style: 'cancel' }, { text: 'Supprimer', style: 'destructive', onPress: () => supprimerCompteRendu(c.debut) }])}>
              <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Supprimer</Text>
            </Pressable>
          </View>
        </Carte>
      ))}
    </ScrollView>
  );
}
