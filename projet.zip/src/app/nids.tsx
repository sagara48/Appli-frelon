/** Carnet des nids (É14) : à traiter, traités, vérifiés morts ; export GPX / KML. */
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Alert, FlatList, Pressable, Text, View } from 'react-native';
import { Bouton, Carte, EnTete, Puces, Vide, s } from '@/ui/composants';
import { C, fmtCoord, idTag, police } from '@/ui/theme';
import { meilleurePosition, useEtat } from '@/store/store';
import { nouveauNid, numeroNid } from '@/services/carnet';
import { exporterGpx, exporterKml, libelleEtatNid } from '@/services/exports';
import type { EtatNid } from '@/db';

const COULEUR: Record<EtatNid, string> = { estime: C.alerte, trouve: C.alerte, traite: C.accent, mort: C.ok };
const date = (ms: number) => new Date(ms).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });

export default function Nids() {
  const router = useRouter();
  const nids = useEtat((e) => e.nids);
  const [filtre, setFiltre] = useState<'tous' | 'trouve' | 'traite' | 'mort'>('tous');
  const n = (id: number) => numeroNid(nids, id);
  const compte = (e: string) => nids.filter((x) => x.etat === e).length;
  const liste = filtre === 'tous' ? nids : nids.filter((x) => x.etat === filtre);

  const exporter = () => Alert.alert('Exporter le carnet', `${nids.length} nids`, [
    { text: 'GPX (GPS, Géoportail)', onPress: () => exporterGpx(nids, n).catch((e) => Alert.alert('Export', String(e))) },
    { text: 'KML (Google Earth)', onPress: () => exporterKml(nids, n).catch((e) => Alert.alert('Export', String(e))) },
    { text: 'Annuler', style: 'cancel' },
  ]);
  const ajouterIci = () => {
    const p = meilleurePosition();
    if (!p) { Alert.alert('Position', 'Pas de position disponible.'); return; }
    const id = nouveauNid(-1, p.lat, p.lon, 10, 'noté à la main');
    if (id) router.push({ pathname: '/nid/[id]', params: { id: String(id) } });
  };

  const entete = (
    <View style={{ gap: 12 }}>
      <EnTete titre="Carnet des nids" />
      <Text style={s.discret}>Saison {new Date().getFullYear()} · {nids.length} nid{nids.length > 1 ? 's' : ''}</Text>
      <Puces options={[['tous', `Tous (${nids.length})`], ['trouve', `À traiter (${compte('trouve') + compte('estime')})`], ['traite', `Traités (${compte('traite')})`], ['mort', `Vérifiés morts (${compte('mort')})`]]}
        valeur={filtre} onChange={setFiltre} />
      {!liste.length && <Carte><Vide titre="Carnet vide" texte="Ajoutez un nid depuis la Carte (« Ajouter au carnet ») quand l'estimation est bonne, ou notez-le ici à votre position." /></Carte>}
    </View>
  );
  const pied = (
    <View style={{ gap: 12 }}>
      <View style={[s.ligne, { gap: 10 }]}>
        <Bouton titre="Exporter (GPX, KML)" onPress={exporter} desactive={!nids.length} />
        <Bouton titre="Voir sur la carte" onPress={() => router.navigate('/carte')} />
      </View>
      <Bouton titre="Noter un nid à ma position" onPress={ajouterIci} />
    </View>
  );
  // liste virtualisée : seuls les nids visibles sont dessinés (carnet de plusieurs centaines de nids)
  return (
    <FlatList style={s.ecran} contentContainerStyle={s.contenu} data={liste} keyExtractor={(x) => String(x.id)}
      ListHeaderComponent={entete} ListFooterComponent={pied} initialNumToRender={12} windowSize={7} removeClippedSubviews
      renderItem={({ item: x }) => (
        <Pressable onPress={() => router.push({ pathname: '/nid/[id]', params: { id: String(x.id) } })}>
          <Carte sansAnim>
            <View style={[s.ligne, { justifyContent: 'space-between' }]}>
              <Text style={{ fontSize: police.normal + 3, fontWeight: '800', color: C.encre }}>Nid n° {n(x.id)}</Text>
              <View style={{ backgroundColor: COULEUR[x.etat], borderRadius: 999, paddingHorizontal: 10, paddingVertical: 3 }}>
                <Text style={{ color: '#fff', fontWeight: '700', fontSize: police.mini }}>{libelleEtatNid(x.etat)}</Text>
              </View>
            </View>
            {(x.support || x.hauteur) && <Text style={{ color: C.encre, marginTop: 4 }}>{[x.support, x.hauteur && `environ ${x.hauteur}`].filter(Boolean).join(' · ')}</Text>}
            <Text style={[s.discret, { marginTop: 4 }]}>
              {x.etat === 'traite' && x.traite_ms ? `Traité le ${date(x.traite_ms)}${x.methode ? ` (${x.methode})` : ''}` : x.etat === 'mort' && x.verifie_ms ? `Aucune activité le ${date(x.verifie_ms)}` : date(x.t)}
              {x.tag >= 0 ? ` · tag ${idTag(x.tag)}` : ''} · ± {Math.round(x.err)} m · {fmtCoord(x.lat, x.lon)}
            </Text>
          </Carte>
        </Pressable>
      )} />
  );
}
