/** Étalonnage : toutes les étapes au même endroit, dans l'ordre, avec leur état. Chaque étape règle seule ce qu'elle
 *  mesure (plus rien à saisir dans Paramètres). Procédure détaillée : écran « Procédure d'étalonnage ». */
import { useRouter } from 'expo-router';
import React from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, EnTete, Titre, s, useMaintenant } from '@/ui/composants';
import { C, idTag, police } from '@/ui/theme';
import { useEtat } from '@/store/store';
import { etalonner, useEtalonnages } from '@/services/etalonnage';
import { exposant, facteurEstimations, useApprentissage, vitesseVol } from '@/services/terrain';
import { etapesEtalonnage, lancerBoussole, lancerRf, useEnCoursPortatif, useEtalAuto } from '@/services/etalonnages';
import { resteAFaire, type Etape } from '@/calc/etalAuto';

const COULEUR: Record<Etape['etat'], string> = { fait: C.ok, afaire: C.alerte, arefaire: C.accent, auto: C.discret };
const PASTILLE: Record<Etape['etat'], string> = { fait: '✓', afaire: '!', arefaire: '↻', auto: 'A' };

export default function Etalonnages() {
  const router = useRouter();
  const e = useEtat((x) => x);
  const etals = useEtalonnages();
  const appris = useApprentissage();
  useEtalAuto();
  const enCours = useEnCoursPortatif();
  const now = useMaintenant();
  const l = etapesEtalonnage(e, etals, exposant(), Object.keys(appris.terrains).length, now, { vitesse: vitesseVol(), facteur: facteurEstimations() });
  const reste = resteAFaire(l);
  const port = e.portatif.connexion === 'connecte' && e.portatif.source === 'ble';
  const toit = e.source === 'toit' && e.connexion === 'connecte';
  const ids = [...new Set<number>([...Object.values(e.fichesTags).filter((f) => f.etat !== 'perdu').map((f) => f.id), ...Object.keys(etals).map(Number)])].sort((a, b) => a - b);
  const sansEtal = ids.filter((id) => !etals[id]);
  const suivi = e.portatif.st && e.portatif.st.tag >= 0 && e.portatif.st.age < 5 ? e.portatif.st.tag : null;

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Étalonnage" droite={() => <Pressable onPress={() => router.push('/procedure-etalonnage')}><Text style={{ color: C.encre, textDecorationLine: 'underline' }}>Procédure</Text></Pressable>} />
      <Carte style={{ borderColor: reste ? C.accent : C.ok, borderWidth: 2 }}>
        <Text style={{ color: C.encre, fontSize: police.normal + 2, fontWeight: '800' }}>{reste ? `${reste} étape${reste > 1 ? 's' : ''} à faire` : 'Tout est étalonné'}</Text>
        <Text style={[s.discret, { marginTop: 4 }]}>
          Une heure en tout, une fois au début de la saison. Chaque étape règle seule ce qu'elle mesure : plus rien à saisir à la main.
          Le terrain et l'orientation du toit s'affinent ensuite tout seuls à chaque nid trouvé.
        </Text>
        <View style={{ marginTop: 10 }}><Bouton titre="Lire la procédure complète" onPress={() => router.push('/procedure-etalonnage')} /></View>
      </Carte>
      {!!enCours.message && <Carte style={{ borderColor: enCours.quoi ? C.accent : C.encre }}><Text style={{ color: C.encre, fontWeight: '700' }}>{enCours.message}</Text></Carte>}

      {l.map((x, i) => (
        <Carte key={x.cle}>
          <View style={[s.ligne, { alignItems: 'flex-start', gap: 12 }]}>
            <View style={{ width: 30, height: 30, borderRadius: 15, backgroundColor: COULEUR[x.etat], alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ color: '#fff', fontWeight: '800' }}>{x.etat === 'afaire' ? i + 1 : PASTILLE[x.etat]}</Text>
            </View>
            <View style={{ flex: 1, gap: 6 }}>
              <Text style={{ color: C.encre, fontWeight: '700', fontSize: police.normal + 1 }}>{i + 1}. {x.titre}</Text>
              <Text style={[s.discret, { color: x.etat === 'afaire' ? C.alerte : C.discret }]}>{x.detail}</Text>
              {x.cle === 'boussole' && (
                <>
                  <Text style={s.discret}>Portatif loin du métal, tourné 20 s dans tous les sens. Règle la flèche et les relevés à pied.</Text>
                  <Bouton titre={x.etat === 'fait' ? 'Refaire' : 'Calibrer la boussole'} plein={x.etat !== 'fait'} desactive={!port || enCours.quoi !== null} onPress={lancerBoussole} />
                </>
              )}
              {x.cle === 'rf' && (
                <>
                  <Text style={s.discret}>Un tag posé à 2-5 m du portatif, 20 s sans bouger. Règle le passage automatique préampli / direct / atténuateur.</Text>
                  <Bouton titre={x.etat === 'fait' ? 'Refaire' : 'Mesurer'} plein={x.etat !== 'fait'} desactive={!port || enCours.quoi !== null} onPress={lancerRf} />
                  {port && suivi === null && <Text style={[s.discret, { fontSize: police.mini }]}>Le portatif doit d'abord suivre un tag (onglet Portatif).</Text>}
                </>
              )}
              {x.cle === 'tags' && (
                <>
                  <Text style={s.discret}>Chaque tag posé à 1 m devant le portatif, 20 à 60 s. Règle les distances du portatif, pour chaque tag et en moyenne.</Text>
                  {sansEtal.length > 0 && (
                    <View style={[s.ligne, { gap: 6, flexWrap: 'wrap' }]}>
                      {sansEtal.map((id) => (
                        <Pressable key={id} disabled={!port} onPress={() => etalonner(id, idTag(id))} style={[s.puce, { opacity: port ? 1 : 0.45 }]}>
                          <Text style={s.puceTxt}>Tag {idTag(id)}</Text>
                        </Pressable>
                      ))}
                    </View>
                  )}
                  {!sansEtal.length && ids.length > 0 && <Pressable onPress={() => router.push('/tags')}><Text style={[s.discret, { textDecorationLine: 'underline' }]}>Refaire un tag : Mes tags → Refaire</Text></Pressable>}
                </>
              )}
              {x.cle === 'toit' && (
                <>
                  <Text style={s.discret}>Un tag posé au sol, deux tours en voiture autour à 30-60 m. Règle l'avant du boîtier, le lobe, le gain de chaque voie, le diagramme des antennes et la distance du toit.</Text>
                  <Bouton titre={x.etat === 'afaire' ? 'Étalonner le toit' : 'Ouvrir'} plein={x.etat !== 'fait'} onPress={() => router.push('/etalonnage')} />
                  {!toit && <Text style={[s.discret, { fontSize: police.mini }]}>Toit à connecter (Menu → Appareils).</Text>}
                </>
              )}
              {x.cle === 'terrain' && (
                <Text style={s.discret}>Rien à faire : notez chaque nid trouvé (« Nid trouvé ici ») pour le tag suivi. L'appli compare alors le signal mesuré au vrai emplacement, règle l'affaiblissement du terrain, corrige l'orientation du toit si besoin, apprend la vitesse de vol des frelons (chrono à l'appât) et la précision réelle des estimations (rayon des plans de vol, alerte « nid localisé »).</Text>
              )}
            </View>
          </View>
        </Carte>
      ))}
      {!port && <Text style={[s.discret, { textAlign: 'center' }]}>Les étapes 1 à 3 se font avec le portatif connecté (onglet Portatif).</Text>}
      <Carte>
        <Titre>Quand refaire ?</Titre>
        <Text style={s.discret}>
          Boussole : après une chute, un changement de pile ou si le portatif signale « boussole perturbée » loin du métal.{'\n'}
          Tags : après une réparation, un changement d'antenne ou de boîtier.{'\n'}
          Toit : après un changement de voiture, d'antenne, de câble, ou si le boîtier a été tourné.{'\n'}
          Entrée radio : après une réparation du portatif.
        </Text>
      </Carte>
    </ScrollView>
  );
}
