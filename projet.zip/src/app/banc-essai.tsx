/** Banc d'essai : première mise sous tension de chaque carte, étape par étape, avec les mesures à relever.
 *  Ce que l'appli peut constater (connexion, voies, GPS, journal propre) se coche tout seul. */
import React, { useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { Bouton, Carte as Bloc, Champ, EnTete, s, useMaintenant } from '@/ui/composants';
import { C, nbVoies, police } from '@/ui/theme';
import { useEtat } from '@/store/store';
import { lireValeur, ecrireValeur } from '@/db';
import { CARTES, avancement, mesureOk, texteBanc, type Auto, type Carte, type EtatBanc } from '@/calc/banc';
import { lireJournal } from '@/services/journal';
import { partager } from '@/services/exports';
import { verdict } from '@/calc/versions';

/** Lignes reçues et lignes non comprises dans le journal, pour un appareil. */
function bilanJournal(app: 'toit' | 'portatif') {
  let recues = 0, incomprises = 0;
  for (const x of lireJournal()) if (x.app === app && x.sens === 'recu') { recues++; if (x.incomprise) incomprises++; }
  return { recues, incomprises };
}

export default function BancEssai() {
  useMaintenant(2000); // relit le journal toutes les 2 s
  const e = useEtat((x) => ({ source: x.source, connexion: x.connexion, toit: x.toit, p: x.portatif, versionToit: x.versionToit }));
  const [etat, setEtat] = useState<EtatBanc>(() => lireValeur<EtatBanc>('banc') ?? {});
  const [notes, setNotes] = useState<Record<string, string>>(() => lireValeur<Record<string, string>>('bancNotes') ?? {});
  const [ouverte, setOuverte] = useState<string | null>(() => CARTES.find((c) => { const a = avancement(c, lireValeur<EtatBanc>('banc') ?? {}); return a.fait < a.total; })?.id ?? null);

  // ce que l'appli constate elle-même (jamais pendant la simulation)
  const portatifReel = e.p.source === 'ble' && e.p.connexion === 'connecte';
  const toitReel = e.source === 'toit' && e.connexion === 'connecte';
  const jp = bilanJournal('portatif'), jt = bilanJournal('toit');
  const auto: Record<Auto, boolean> = {
    portatifConnecte: portatifReel,
    portatifGps: portatifReel && !!e.p.st?.fix,
    portatifTag: portatifReel && ((e.p.st?.tag ?? -1) >= 0 || Object.keys(e.p.autres).length > 0),
    portatifJournal: jp.recues >= 20 && jp.incomprises === 0,
    toitConnecte: toitReel,
    toitVoies: toitReel && !!e.toit && nbVoies(e.toit.voiesOk) === 4,
    toitGps: toitReel && !!e.toit?.lat && (e.toit?.sats ?? 0) >= 6,
    toitJournal: jt.recues >= 20 && jt.incomprises === 0,
    toitVersion: toitReel && ['ok', 'maj'].includes(verdict('toit', e.versionToit)?.etat ?? ''),
    portatifVersion: portatifReel && ['ok', 'maj'].includes(verdict('portatif', e.p.version)?.etat ?? ''),
  };
  const aCocher = CARTES.flatMap((c) => c.etapes).filter((x) => x.auto && auto[x.auto] && !etat[x.id]?.ok).map((x) => x.id).join(',');
  useEffect(() => {
    if (!aCocher) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect -- une vérification de l'appli vient de réussir : on la coche
    setEtat((o) => {
      const n = { ...o };
      for (const id of aCocher.split(',')) n[id] = { ...n[id], ok: true, t: Date.now(), auto: true };
      ecrireValeur('banc', n);
      return n;
    });
  }, [aCocher]);

  const changer = (id: string, f: (o: EtatBanc[string] | undefined) => EtatBanc[string]) => setEtat((o) => {
    const n = { ...o, [id]: f(o[id]) };
    ecrireValeur('banc', n);
    return n;
  });
  const noter = (id: string, v: string) => setNotes((o) => { const n = { ...o, [id]: v }; ecrireValeur('bancNotes', n); return n; });
  const recommencer = (c: Carte) => Alert.alert('Recommencer', `Décocher toutes les étapes de « ${c.nom} » ?`, [{ text: 'Annuler', style: 'cancel' }, {
    text: 'Décocher', style: 'destructive', onPress: () => setEtat((o) => { const n = { ...o }; c.etapes.forEach((x) => delete n[x.id]); ecrireValeur('banc', n); return n; }),
  }]);
  const exporter = () => partager(`banc_essai_frelons_${new Date().toISOString().slice(0, 10)}.txt`, texteBanc(etat, notes), 'text/plain').catch((err) => Alert.alert('Export', String(err)));
  const total = CARTES.reduce((a, c) => { const x = avancement(c, etat); return { fait: a.fait + x.fait, total: a.total + x.total }; }, { fait: 0, total: 0 });

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre="Banc d'essai" />
      <Text style={s.discret}>Une carte à la fois, dans cet ordre : chacune sert à tester la suivante. Les étapes marquées « appli » se cochent toutes seules quand le vrai matériel répond.</Text>
      <Text style={{ color: C.encre, fontWeight: '700' }}>{total.fait} / {total.total} étapes faites</Text>

      {CARTES.map((c) => {
        const a = avancement(c, etat), fini = a.fait === a.total, ouv = ouverte === c.id;
        const horsPlage = c.etapes.some((x) => mesureOk(x.mesure, etat[x.id]?.val) === false);
        return (
          <Bloc key={c.id}>
            <Pressable onPress={() => setOuverte(ouv ? null : c.id)} style={[s.ligne, { justifyContent: 'space-between' }]}>
              <View style={{ flex: 1 }}>
                <Text style={{ color: C.encre, fontWeight: '800', fontSize: police.normal + 1 }}>{c.nom}</Text>
                <Text style={[s.discret, { fontSize: police.petit }]}>{c.intro}</Text>
              </View>
              <Text style={{ color: horsPlage ? C.alerte : fini ? C.ok : C.discret, fontWeight: '700', marginLeft: 8 }}>{horsPlage ? '⚠ ' : fini ? '✓ ' : ''}{a.fait}/{a.total}</Text>
            </Pressable>
            <View style={{ height: 4, borderRadius: 2, backgroundColor: C.fond, overflow: 'hidden', marginTop: 8 }}>
              <View style={{ width: `${(a.fait / a.total) * 100}%`, height: '100%', backgroundColor: fini ? C.ok : C.accent }} />
            </View>

            {ouv && (
              <View style={{ marginTop: 6 }}>
                {c.etapes.map((x, i) => {
                  const k = etat[x.id], ok = !!k?.ok, juge = mesureOk(x.mesure, k?.val);
                  const vu = x.auto ? auto[x.auto] : false;
                  return (
                    <View key={x.id} style={{ flexDirection: 'row', gap: 10, paddingVertical: 10, borderTopWidth: i ? 1 : 0, borderTopColor: C.ligne }}>
                      <Pressable hitSlop={8} onPress={() => changer(x.id, (o) => ({ ...o, ok: !ok, t: Date.now(), auto: false }))}
                        style={{ width: 26, height: 26, borderRadius: 6, borderWidth: 2, borderColor: ok ? C.ok : C.discret, backgroundColor: ok ? C.ok : 'transparent', alignItems: 'center', justifyContent: 'center', marginTop: 1 }}>
                        {ok && <Text style={{ color: '#fff', fontWeight: '900' }}>✓</Text>}
                      </Pressable>
                      <View style={{ flex: 1 }}>
                        <Text style={{ color: C.encre, fontWeight: '600', textDecorationLine: ok ? 'line-through' : 'none', opacity: ok ? 0.7 : 1 }}>
                          {x.attention ? <Text style={{ color: C.alerte }}>⚠ </Text> : null}{x.titre}
                        </Text>
                        {!!x.detail && <Text style={[s.discret, { fontSize: police.petit, marginTop: 2 }]}>{x.detail}</Text>}
                        {x.auto && (
                          <Text style={{ fontSize: police.mini, marginTop: 4, color: vu ? C.ok : C.discret, fontWeight: '700' }}>
                            APPLI · {vu ? 'vérifié' : 'en attente du vrai matériel'}{k?.auto && ok ? ` le ${new Date(k.t).toLocaleDateString('fr-FR')}` : ''}
                          </Text>
                        )}
                        {x.mesure && (
                          <View style={[s.ligne, { gap: 8, marginTop: 6 }]}>
                            <TextInput value={k?.val ?? ''} onChangeText={(v) => changer(x.id, (o) => ({ ok: o?.ok ?? false, t: o?.t ?? Date.now(), ...o, val: v }))}
                              keyboardType="decimal-pad" placeholder="mesure" placeholderTextColor="#9AA3AC"
                              style={{ width: 90, borderWidth: 1.5, borderColor: juge === false ? C.alerte : juge ? C.ok : C.ligne, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6, color: C.encre, fontSize: police.normal }} />
                            <Text style={{ color: C.encre }}>{x.mesure.unite}</Text>
                            <Text style={[s.discret, { fontSize: police.mini, flex: 1, color: juge === false ? C.alerte : C.discret }]}>
                              {juge === false ? 'hors plage : ne pas continuer, chercher la cause' : x.mesure.min !== undefined && x.mesure.max !== undefined ? `attendu ${String(x.mesure.min).replace('.', ',')} à ${String(x.mesure.max).replace('.', ',')}` : ''}
                            </Text>
                          </View>
                        )}
                      </View>
                    </View>
                  );
                })}
                <Champ titre="Notes" valeur={notes[c.id] ?? ''} onChange={(v) => noter(c.id, v)} multiligne placeholder="mesures, problèmes rencontrés…" />
                <Pressable onPress={() => recommencer(c)}><Text style={[s.discret, { textDecorationLine: 'underline' }]}>Tout décocher pour cette carte</Text></Pressable>
              </View>
            )}
          </Bloc>
        );
      })}

      <Bouton titre="Exporter la fiche" plein onPress={exporter} />
      <Text style={[s.discret, { fontSize: police.mini }]}>Une mesure hors plage s'affiche en rouge : couper l'alimentation et chercher la cause avant d'aller plus loin. Plages : 3V3 entre 3,2 et 3,4 V ; accu ou LiPo entre 3,0 et 4,2 V.</Text>
    </ScrollView>
  );
}
