/** Étalonner la distance estimée : un tag posé à une distance connue du toit ou du portatif ; l'appli mesure le signal
 *  pendant 10 s et en déduit le signal à 1 m. Une seconde mesure, plus loin, donne en plus l'affaiblissement du milieu. */
import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, Champ, EnTete, Puces, Titre, s } from '@/ui/composants';
import { C, idTag, police } from '@/ui/theme';
import { store, useEtat } from '@/store/store';
import { refDepuisMesure } from '@/calc/distance';
import { changerParametres, useParametres } from '@/services/parametres';

type Recepteur = 'toit' | 'portatif';
type Mesure = { d: number; rssi: number; n: number };
const MILIEUX: [string, string][] = [['2', 'Dégagé'], ['2.5', 'Bocage'], ['3.3', 'Bois']];
const fr = (x: number, k = 1) => x.toFixed(k).replace('.', ',');

/** Signal actuel du tag suivi par le récepteur (null s'il n'est pas reçu). */
function signal(r: Recepteur): { tag: number; rssi: number } | null {
  const e = store.get();
  if (r === 'portatif') {
    const st = e.portatif.st;
    return st && st.tag >= 0 && st.age < 3 ? { tag: st.tag, rssi: st.rssi } : null;
  }
  const t = e.tagChoisi !== null ? e.tags[e.tagChoisi] : null;
  return t && Date.now() - t.dernierMs < 3000 ? { tag: t.id, rssi: Math.max(...t.r) } : null;
}

export default function EtalonnageDistance() {
  const P = useParametres();
  const e = useEtat((x) => ({ toitOk: x.source === 'toit' && x.connexion === 'connecte', portOk: x.portatif.source === 'ble' && x.portatif.connexion === 'connecte' }));
  const [r, setR] = useState<Recepteur>(e.portOk || !e.toitOk ? 'portatif' : 'toit');
  const [dist, setDist] = useState('20');
  const [mesures, setMesures] = useState<Mesure[]>([]);
  const [enCours, setEnCours] = useState(false);
  const [nb, setNb] = useState(0);
  const [vu, setVu] = useState<{ tag: number; rssi: number } | null>(null);
  const valeurs = useRef<number[]>([]);
  const collecte = useRef(false);

  // signal en direct ; pendant une mesure, chaque valeur est gardée
  useEffect(() => {
    const i = setInterval(() => {
      const sg = signal(r);
      setVu(sg);
      if (collecte.current && sg) { valeurs.current.push(sg.rssi); setNb(valeurs.current.length); }
    }, 500);
    return () => clearInterval(i);
  }, [r]);
  const mesurer = () => {
    const dm = Number(dist.replace(',', '.'));
    valeurs.current = []; collecte.current = true; setNb(0); setEnCours(true);
    setTimeout(() => {
      collecte.current = false; setEnCours(false);
      const l = valeurs.current;
      if (l.length < 5) return;
      const tri = [...l].sort((x, y) => x - y); // médiane : insensible aux pics
      setMesures((o) => [...o.filter((x) => x.d !== dm), { d: dm, rssi: tri[Math.floor(tri.length / 2)], n: l.length }]);
    }, 10000);
  };

  const d = Number(dist.replace(',', '.'));
  const ordre = [...mesures].sort((a, b) => a.d - b.d);
  // deux distances bien séparées : affaiblissement mesuré ; sinon celui des paramètres
  const nMesure = ordre.length >= 2 && ordre[ordre.length - 1].d / ordre[0].d >= 2
    ? (ordre[0].rssi - ordre[ordre.length - 1].rssi) / (10 * Math.log10(ordre[ordre.length - 1].d / ordre[0].d)) : null;
  const n = nMesure !== null && nMesure >= 1.6 && nMesure <= 4.5 ? nMesure : P.distExposant;
  const ref = ordre.length ? ordre.reduce((a, m) => a + refDepuisMesure(m.rssi, m.d, n), 0) / ordre.length : null;
  const actuel = r === 'toit' ? P.distRefToit : P.distRefPortatif;

  const enregistrer = () => {
    if (ref === null) return;
    changerParametres({ ...(r === 'toit' ? { distRefToit: Math.round(ref * 10) / 10 } : { distRefPortatif: Math.round(ref * 10) / 10 }), ...(nMesure !== null ? { distExposant: Math.round(n * 100) / 100 } : {}) });
    setMesures([]);
  };

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre="Étalonner la distance" />
      <Text style={s.discret}>Posez un tag allumé à une distance connue du récepteur (mesurée au mètre ruban ou au GPS), dans un endroit typique de vos recherches, à hauteur d'homme.</Text>
      <Carte>
        <Titre>Récepteur</Titre>
        <Puces options={[['portatif', 'Portatif'], ['toit', 'Toit']]} valeur={r} onChange={(v) => { setR(v as Recepteur); setMesures([]); }} />
        <Text style={{ color: vu ? C.ok : C.alerte, fontWeight: '700', marginTop: 8 }}>
          {vu ? `Tag ${idTag(vu.tag)} reçu : ${fr(vu.rssi)} dBm` : r === 'toit' ? (e.toitOk ? 'Choisissez le tag dans l\'onglet Direct' : 'Toit non connecté') : (e.portOk ? 'Choisissez le tag dans l\'onglet Portatif' : 'Portatif non connecté')}
        </Text>
        <Text style={[s.discret, { fontSize: police.mini }]}>Signal à 1 m actuel : {fr(actuel)} dBm · affaiblissement {fr(P.distExposant, 2)}</Text>
      </Carte>
      <Carte>
        <Titre>Mesure</Titre>
        <Champ titre="Distance entre le tag et le récepteur (m)" valeur={dist} onChange={setDist} clavier="decimal-pad" />
        {enCours ? (
          <View style={[s.ligne, { gap: 10, marginTop: 6 }]}><ActivityIndicator color={C.encre} /><Text style={{ color: C.encre }}>Mesure… {nb} valeurs, ne bougez pas</Text></View>
        ) : (
          <Bouton titre="Mesurer pendant 10 s" plein desactive={!vu || !(d >= 1)} onPress={mesurer} />
        )}
        {ordre.map((m) => <Text key={m.d} style={{ color: C.encre, marginTop: 6 }}>À {fr(m.d, 0)} m : {fr(m.rssi)} dBm ({m.n} valeurs)</Text>)}
        {ordre.length === 1 && <Text style={[s.discret, { marginTop: 6 }]}>Facultatif : une seconde mesure au moins 2 fois plus loin calcule aussi l'affaiblissement du milieu.</Text>}
      </Carte>
      {ref !== null && (
        <Carte style={{ borderColor: C.accent, borderWidth: 2 }}>
          <Titre>Résultat</Titre>
          <Text style={{ color: C.encre, fontSize: police.normal + 1 }}>Signal à 1 m : <Text style={{ fontWeight: '800' }}>{fr(ref)} dBm</Text> (avant : {fr(actuel)})</Text>
          {nMesure !== null && <Text style={{ color: nMesure === n ? C.encre : C.alerte, marginTop: 4 }}>Affaiblissement mesuré : {fr(nMesure, 2)}{nMesure !== n ? ' : valeur peu plausible, non retenue' : ''}</Text>}
          <View style={{ marginTop: 10 }}><Bouton titre="Enregistrer" plein onPress={enregistrer} /></View>
        </Carte>
      )}
      <Carte>
        <Titre>Milieu habituel</Titre>
        <Text style={[s.discret, { marginBottom: 8 }]}>Sans seconde mesure, choisissez le type de terrain : plus il est fermé, plus le signal baisse vite.</Text>
        <Puces options={MILIEUX} valeur={String(P.distExposant)} onChange={(v) => changerParametres({ distExposant: Number(v) })} />
      </Carte>
      <Text style={[s.discret, { fontSize: police.mini }]}>La distance reste une estimation : feuillage, relief, position du frelon et orientation de l'antenne font varier le signal. La fourchette affichée en tient compte (Paramètres → Distance estimée).</Text>
    </ScrollView>
  );
}
