/** Partage entre téléphones : réglage du serveur Supabase et du code d'équipe, état de la synchronisation. */
import React, { useState, useSyncExternalStore } from 'react';
import { Alert, ScrollView, Share, Text, View } from 'react-native';
import { Bouton, Carte, Champ, EnTete, Interrupteur, Titre, s, useMaintenant } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { SQL_PARTAGE, abonnerPartage, configComplete, enregistrerConfig, etatPartage, lireConfig, nouveauCode, synchroniser, type ConfigPartage } from '@/services/partage';
import { param } from '@/services/parametres';

const ilYa = (ms: number, mainten: number) => {
  const s2 = Math.round((mainten - ms) / 1000);
  return s2 < 60 ? 'à l\'instant' : s2 < 3600 ? `il y a ${Math.round(s2 / 60)} min` : new Date(ms).toLocaleString('fr-FR');
};

export default function Partage() {
  const maint = useMaintenant(10000);
  const et = useSyncExternalStore(abonnerPartage, etatPartage);
  const [c, setC] = useState<ConfigPartage>(lireConfig);
  const [modifie, setModifie] = useState(false);
  const champ = (k: keyof ConfigPartage) => (v: string) => { setC((o) => ({ ...o, [k]: v })); setModifie(true); };
  const ok = configComplete(c);

  const enregistrer = (actif = c.actif) => {
    const n = { ...c, url: c.url.trim(), cle: c.cle.trim(), equipe: c.equipe.trim(), nom: c.nom.trim(), actif };
    setC(n); setModifie(false); enregistrerConfig(n);
  };
  const partagerCode = () => Share.share({ message: `Partage Appli Frelons\nAdresse : ${c.url.trim()}\nClé : ${c.cle.trim()}\nCode d'équipe : ${c.equipe.trim()}\n\nRéglages → Partage entre téléphones, coller ces 3 valeurs puis activer.` });

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre="Partage entre téléphones" />
      <Text style={s.discret}>Les nids et les ruchers de toute l'équipe, sur chaque téléphone. Chacun garde ses photos ; la modification la plus récente l'emporte.</Text>

      <Carte>
        <Interrupteur titre="Partager" detail={ok ? `nids, ruchers et pièges, toutes les ${param().syncMin} min et après chaque modification` : 'remplir d\'abord les réglages ci-dessous'}
          valeur={c.actif && ok} onChange={(v) => { if (v && !ok) { Alert.alert('Partage', 'Il manque l\'adresse, la clé ou le code d\'équipe (16 caractères au moins).'); return; } enregistrer(v); }} />
        {c.actif && ok && (
          <View style={{ marginTop: 6 }}>
            <Text style={{ color: et.erreur ? C.alerte : C.encre, fontWeight: '700' }}>
              {et.enCours ? 'Synchronisation…' : et.erreur ? et.erreur : et.dernierOk ? `À jour (${ilYa(et.dernierOk, maint)})` : 'Pas encore synchronisé'}
            </Text>
            {(et.envoyees > 0 || et.recues > 0) && <Text style={s.discret}>Depuis l'ouverture : {et.envoyees} fiche(s) envoyée(s), {et.recues} reçue(s).</Text>}
            <View style={{ marginTop: 8 }}><Bouton titre="Synchroniser maintenant" desactive={et.enCours} onPress={() => { synchroniser(); }} /></View>
          </View>
        )}
      </Carte>

      <Carte>
        <Titre>Réglages</Titre>
        <Text style={[s.discret, { marginBottom: 4 }]}>Nom affiché sur vos fiches : {param().nom || c.nom || 'non renseigné'} (Paramètres → Profil).</Text>
        <Champ titre="Adresse du projet Supabase" valeur={c.url} onChange={champ('url')} placeholder="https://xxxx.supabase.co" />
        <Champ titre="Clé publique (anon)" valeur={c.cle} onChange={champ('cle')} placeholder="eyJhbGciOi…" />
        <Champ titre="Code d'équipe (le même sur tous les téléphones)" valeur={c.equipe} onChange={champ('equipe')} placeholder="16 caractères au moins" />
        <View style={[s.ligne, { gap: 10, flexWrap: 'wrap', marginTop: 4 }]}>
          {!c.equipe.trim() && <Bouton titre="Créer un code" onPress={() => champ('equipe')(nouveauCode())} />}
          <Bouton titre="Enregistrer" plein desactive={!modifie} onPress={() => enregistrer()} />
          {ok && <Bouton titre="Envoyer à un équipier" onPress={partagerCode} />}
        </View>
        <Text style={[s.discret, { fontSize: police.mini, marginTop: 8 }]}>Le code d'équipe sert de mot de passe : ne le donnez qu'aux personnes de l'équipe. Pour retirer quelqu'un, créez un nouveau code et donnez-le aux autres.</Text>
      </Carte>

      <Carte>
        <Titre>Préparer le serveur (une seule fois)</Titre>
        <Text style={{ color: C.encre, lineHeight: 21 }}>
          1. Créer un projet gratuit sur supabase.com.{'\n'}
          2. SQL Editor → New query : coller le script, puis Run.{'\n'}
          3. Project Settings → API : recopier l'adresse (Project URL) et la clé « anon public » ci-dessus.{'\n'}
          4. Créer un code d'équipe, activer, puis l'envoyer aux équipiers.
        </Text>
        <View style={{ marginTop: 8 }}><Bouton titre="Envoyer le script SQL (mail, Drive…)" onPress={() => Share.share({ message: SQL_PARTAGE })} /></View>
      </Carte>
    </ScrollView>
  );
}
