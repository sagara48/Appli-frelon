/** Partage entre téléphones : compte, équipe (créer, rejoindre, membres, code d'invitation), synchronisation, serveur. */
import { useFocusEffect, useRouter } from 'expo-router';
import React, { useCallback, useState, useSyncExternalStore } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, Share, Text, View } from 'react-native';
import { Bouton, Carte, Champ, EnTete, Interrupteur, Titre, s, useMaintenant } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { SERVEUR_DEFAUT, enregistrerServeur, lireServeur, seDeconnecter, serveurComplet, useSession } from '@/services/auth';
import {
  SQL_PARTAGE, abonnerPartage, activerPartage, changerCode, creerEquipe, etatPartage, lireConfig, lireEquipe, nommerResponsable, oublierEquipe,
  quitterEquipe, rejoindreEquipe, retirerMembre, synchroniser, type Membre,
} from '@/services/partage';

const ilYa = (ms: number, mainten: number) => {
  const s2 = Math.round((mainten - ms) / 1000);
  return s2 < 60 ? 'à l\'instant' : s2 < 3600 ? `il y a ${Math.round(s2 / 60)} min` : new Date(ms).toLocaleString('fr-FR');
};

export default function Partage() {
  const router = useRouter();
  const maint = useMaintenant(10000);
  const session = useSession();
  const et = useSyncExternalStore(abonnerPartage, etatPartage);
  const c = lireConfig(); // relu à chaque affichage (changé par les actions ci-dessous, qui republient l'état)
  const [membres, setMembres] = useState<Membre[] | null>(null);
  const [nomEquipe, setNomEquipe] = useState('');
  const [code, setCode] = useState('');
  const [occupe, setOccupe] = useState('');
  const [erreur, setErreur] = useState('');
  const [serveur, setServeur] = useState(lireServeur);
  const [voirServeur, setVoirServeur] = useState(false);

  const agir = async (quoi: string, f: () => Promise<unknown>) => {
    setOccupe(quoi); setErreur('');
    try { await f(); } catch (e) { setErreur((e as Error).message); } finally { setOccupe(''); }
  };
  const recharger = useCallback(() => {
    if (!session || !lireConfig().equipe) { setMembres(null); return; }
    lireEquipe().then((r) => setMembres(r?.membres ?? null)).catch((e) => setErreur((e as Error).message));
  }, [session]);
  useFocusEffect(recharger);

  const moi = membres?.find((m) => m.utilisateur === session?.utilisateur.id);
  const responsable = !!moi?.admin;
  const inviter = () => {
    const sv = lireServeur();
    const reglage = sv.url === SERVEUR_DEFAUT.url && sv.cle === SERVEUR_DEFAUT.cle ? ''
      : `Avant tout : Réglages → Partage entre téléphones → serveur de l'équipe :\nAdresse : ${sv.url}\nClé : ${sv.cle}\n\n`;
    Share.share({ message: `Rejoignez l'équipe « ${c.equipe?.nom} » dans l'appli Frelons.\n\n${reglage}Créez votre compte (écran de connexion ou Réglages → Partage entre téléphones), puis rejoignez l'équipe avec le code : ${c.equipe?.code}` });
  };
  const actionsMembre = (m: Membre) => {
    if (!responsable || m.utilisateur === session?.utilisateur.id) return;
    Alert.alert(m.nom || m.email || 'Membre', m.email ?? '', [
      { text: m.admin ? 'N\'est plus responsable' : 'Nommer responsable', onPress: () => agir('membre', async () => { await nommerResponsable(m.utilisateur, !m.admin); recharger(); }) },
      { text: 'Retirer de l\'équipe', style: 'destructive', onPress: () => agir('membre', async () => { await retirerMembre(m.utilisateur); recharger(); }) },
      { text: 'Annuler', style: 'cancel' },
    ]);
  };

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre="Partage entre téléphones" />
      <Text style={s.discret}>Les nids, ruchers et pièges de l'équipe sur chaque téléphone. Chacun garde ses photos ; la modification la plus récente l'emporte.</Text>

      {/* compte */}
      <Carte>
        <Titre>Compte</Titre>
        {session ? (
          <>
            <Text style={{ color: C.encre, fontWeight: '700' }}>{session.utilisateur.nom || session.utilisateur.email}</Text>
            <Text style={s.discret}>{session.utilisateur.email}</Text>
            <Pressable onPress={() => Alert.alert('Se déconnecter', 'Le partage s\'arrête sur ce téléphone ; le carnet reste.', [{ text: 'Annuler', style: 'cancel' }, { text: 'Se déconnecter', style: 'destructive', onPress: () => { seDeconnecter(); oublierEquipe(); setMembres(null); } }])} style={{ marginTop: 6 }}>
              <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Se déconnecter</Text>
            </Pressable>
          </>
        ) : (
          <>
            <Text style={[s.discret, { marginBottom: 8 }]}>Pas connecté : le carnet reste sur ce téléphone.</Text>
            <Bouton titre="Se connecter ou créer un compte" plein onPress={() => router.push('/connexion')} />
          </>
        )}
      </Carte>

      {/* équipe */}
      {session && !c.equipe && (
        <Carte>
          <Titre>Équipe</Titre>
          <Text style={[s.discret, { marginBottom: 4 }]}>Rejoignez l'équipe avec le code donné par son responsable, ou créez-la si vous êtes le premier.</Text>
          <Champ titre="Code d'invitation" valeur={code} onChange={setCode} placeholder="AB12-CD34" genre="url" />
          <Bouton titre="Rejoindre l'équipe" plein desactive={!code.trim() || !!occupe} onPress={() => agir('rejoindre', async () => { await rejoindreEquipe(code); setCode(''); recharger(); })} />
          <View style={{ height: 14 }} />
          <Champ titre="Ou créer une équipe" valeur={nomEquipe} onChange={setNomEquipe} placeholder="Frelons Haute-Loire" />
          <Bouton titre="Créer l'équipe" desactive={!nomEquipe.trim() || !!occupe} onPress={() => agir('creer', async () => { await creerEquipe(nomEquipe); setNomEquipe(''); recharger(); })} />
        </Carte>
      )}
      {session && c.equipe && (
        <Carte>
          <View style={[s.ligne, { justifyContent: 'space-between' }]}>
            <Titre>Équipe « {c.equipe.nom} »</Titre>
            {responsable && <Text style={[s.discret, { fontSize: police.mini, marginBottom: 8 }]}>vous êtes responsable</Text>}
          </View>
          <Interrupteur titre="Partager" detail="toutes les quelques minutes et après chaque modification" valeur={c.actif} onChange={(v) => activerPartage(v)} />
          {c.actif && (
            <Text style={{ color: et.erreur ? C.alerte : C.encre, fontWeight: '700', marginTop: 4 }}>
              {et.enCours ? 'Synchronisation…' : et.erreur ? et.erreur : et.dernierOk ? `À jour (${ilYa(et.dernierOk, maint)})` : 'Pas encore synchronisé'}
            </Text>
          )}
          {(et.envoyees > 0 || et.recues > 0) && <Text style={s.discret}>Depuis l'ouverture : {et.envoyees} fiche(s) envoyée(s), {et.recues} reçue(s).</Text>}
          <View style={[s.ligne, { gap: 10, marginTop: 8, flexWrap: 'wrap' }]}>
            <Bouton titre="Synchroniser" desactive={et.enCours || !c.actif} onPress={() => { synchroniser(); }} />
            <Bouton titre="Inviter un équipier" onPress={inviter} />
          </View>
          <Text style={[s.discret, { marginTop: 10 }]}>Code d'invitation : <Text style={{ color: C.encre, fontWeight: '800', letterSpacing: 1 }}>{c.equipe.code}</Text></Text>
          {responsable && (
            <Pressable onPress={() => Alert.alert('Nouveau code', 'L\'ancien code ne permettra plus de rejoindre l\'équipe (les membres actuels restent).', [{ text: 'Annuler', style: 'cancel' }, { text: 'Changer', onPress: () => agir('code', changerCode) }])}>
              <Text style={[s.discret, { textDecorationLine: 'underline', fontSize: police.mini }]}>Changer le code</Text>
            </Pressable>
          )}

          <Text style={[s.discret, { marginTop: 14, marginBottom: 2 }]}>Membres{membres ? ` (${membres.length})` : ''}</Text>
          {!membres && <ActivityIndicator color={C.encre} />}
          {membres?.map((m) => (
            <Pressable key={m.utilisateur} onPress={() => actionsMembre(m)} style={[s.ligne, { justifyContent: 'space-between', paddingVertical: 7, borderTopWidth: 1, borderTopColor: C.ligne }]}>
              <View style={{ flex: 1 }}>
                <Text style={{ color: C.encre, fontWeight: '600' }}>{m.nom || m.email}{m.utilisateur === session.utilisateur.id ? ' (vous)' : ''}</Text>
                {!!m.email && m.nom && <Text style={[s.discret, { fontSize: police.mini }]}>{m.email}</Text>}
              </View>
              {m.admin && <Text style={{ color: C.accent, fontWeight: '700', fontSize: police.mini }}>RESPONSABLE</Text>}
            </Pressable>
          ))}
          {responsable && membres && membres.length > 1 && <Text style={[s.discret, { fontSize: police.mini }]}>Touchez un membre pour le retirer ou le nommer responsable.</Text>}
          <Pressable onPress={() => Alert.alert('Quitter l\'équipe', 'Vos fiches restent dans votre carnet ; vous ne recevrez plus celles de l\'équipe.', [{ text: 'Annuler', style: 'cancel' }, { text: 'Quitter', style: 'destructive', onPress: () => agir('quitter', async () => { await quitterEquipe(); setMembres(null); }) }])} style={{ marginTop: 10 }}>
            <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Quitter l'équipe</Text>
          </Pressable>
        </Carte>
      )}
      {!!occupe && <ActivityIndicator color={C.encre} />}
      {!!erreur && <Text style={{ color: C.alerte, fontWeight: '600' }}>{erreur}</Text>}

      {/* serveur */}
      <Carte>
        <Pressable onPress={() => setVoirServeur(!voirServeur)} style={[s.ligne, { justifyContent: 'space-between' }]}>
          <Titre>Serveur de l'équipe</Titre>
          <Text style={s.discret}>{serveurComplet(lireServeur()) ? 'réglé ' : 'à régler '}{voirServeur ? '▲' : '▼'}</Text>
        </Pressable>
        {voirServeur && (
          <View>
            <Champ titre="Adresse du projet Supabase" valeur={serveur.url} onChange={(v) => setServeur({ ...serveur, url: v })} genre="url" placeholder="https://xxxx.supabase.co" />
            <Champ titre="Clé publique (anon public)" valeur={serveur.cle} onChange={(v) => setServeur({ ...serveur, cle: v })} genre="url" placeholder="eyJhbGciOi…" />
            <Bouton titre="Enregistrer" desactive={!serveurComplet(serveur)} onPress={() => { enregistrerServeur(serveur); Alert.alert('Serveur', 'Enregistré.'); }} />
            <Text style={[s.discret, { marginTop: 12, lineHeight: 20 }]}>
              Préparer le serveur (responsable, une seule fois) :{'\n'}
              1. Créer un projet gratuit sur supabase.com.{'\n'}
              2. SQL Editor → New query : coller le script, puis Run.{'\n'}
              3. Project Settings → API : recopier l'adresse et la clé « anon public » ci-dessus.{'\n'}
              4. Conseillé : Authentication → Sign In / Providers → Email, désactiver « Confirm email » si vous ne voulez pas de lien de confirmation.{'\n'}
              5. Créer son compte, puis l'équipe, et inviter les équipiers.
            </Text>
            <View style={{ marginTop: 8 }}><Bouton titre="Envoyer le script SQL (mail, Drive…)" onPress={() => Share.share({ message: SQL_PARTAGE })} /></View>
          </View>
        )}
      </Carte>
    </ScrollView>
  );
}
