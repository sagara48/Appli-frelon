/** Calendrier de saison : ce qui est à faire en ce moment, ce qui vient, frise de l'année. */
import { useRouter, type Href } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, Text, TextInput, View, useWindowDimensions } from 'react-native';
import Svg, { Line, Rect, Text as T } from 'react-native-svg';
import { Carte, EnTete, Puces, Titre, s, useMaintenant } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { ETAPES, cleEtape, etapesDatees, jourMois, lireJourMois, type EtapeDatee } from '@/calc/calendrier';
import { ecrireCalendrier, lireCalendrier, type ReglagesCalendrier } from '@/services/calendrier';

const MOIS = ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'];
const court = (ms: number) => new Date(ms).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
const DECALAGES: [string, string][] = [['-14', '2 sem. plus tôt'], ['-7', '1 sem. plus tôt'], ['0', 'Moyenne montagne'], ['7', '1 sem. plus tard'], ['14', '2 sem. plus tard']];

export default function Calendrier() {
  const router = useRouter();
  const { width } = useWindowDimensions();
  const maint = useMaintenant(3600000);
  const [c, setC] = useState<ReglagesCalendrier>(lireCalendrier);
  const maj = (n: ReglagesCalendrier) => { setC(n); ecrireCalendrier(n); };
  const etapes = etapesDatees(maint, c.decalage, c.dates);
  const [edition, setEdition] = useState<{ id: string; debut: string; fin: string } | null>(null);
  const enregistrerDates = () => {
    if (!edition) return;
    const d = lireJourMois(edition.debut), f = lireJourMois(edition.fin);
    if (!d || !f) { Alert.alert('Dates', 'Écrire les dates sous la forme jour/mois, par exemple 15/03.'); return; }
    maj({ ...c, dates: { ...c.dates, [edition.id]: { debut: d, fin: f } } });
    setEdition(null);
  };
  const datesParDefaut = (id: string) => { const { [id]: _x, ...reste } = c.dates; maj({ ...c, dates: reste }); setEdition(null); };
  const enCours = etapes.filter((e) => e.etat === 'en-cours');
  const aVenir = etapes.filter((e) => e.etat === 'a-venir');
  const passees = etapes.filter((e) => e.etat === 'passee');

  // frise : année civile en cours, une ligne par étape
  const an = new Date(maint).getFullYear();
  const W = width - 64, LH = 16, H = etapes.length * LH + 24;
  const x0 = new Date(an, 0, 1).getTime(), x1 = new Date(an + 1, 0, 1).getTime();
  const X = (ms: number) => Math.max(0, Math.min(W, ((ms - x0) / (x1 - x0)) * W));
  const segments = (e: EtapeDatee) => {
    // l'étape de cette année civile, coupée au 31 décembre ; plus sa partie de janvier-février si elle vient de l'an passé
    const l: { a: number; b: number }[] = [];
    for (const k of [-1, 0]) {
      const deb = new Date(e.debutMs); deb.setFullYear(deb.getFullYear() + (an + k - e.saison));
      const fin = new Date(e.finMs); fin.setFullYear(fin.getFullYear() + (an + k - e.saison));
      if (fin.getTime() > x0 && deb.getTime() < x1) l.push({ a: X(deb.getTime()), b: X(fin.getTime()) });
    }
    return l;
  };

  // fonction (et non composant) : un composant recréé à chaque affichage ferait perdre le clavier pendant la saisie des dates
  const ligne = (e: EtapeDatee) => {
    const fait = !!c.faites[cleEtape(e)];
    return (
      <View style={{ flexDirection: 'row', gap: 10, paddingVertical: 10, borderTopWidth: 1, borderTopColor: C.ligne }}>
        <Pressable hitSlop={8} onPress={() => maj({ ...c, faites: { ...c.faites, [cleEtape(e)]: !fait } })}
          style={{ width: 24, height: 24, borderRadius: 6, borderWidth: 2, borderColor: fait ? C.ok : C.discret, backgroundColor: fait ? C.ok : 'transparent', alignItems: 'center', justifyContent: 'center', marginTop: 2 }}>
          {fait && <Text style={{ color: '#fff', fontWeight: '900' }}>✓</Text>}
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={{ color: C.encre, fontWeight: '700', textDecorationLine: fait ? 'line-through' : 'none' }}>{e.titre}</Text>
          {edition?.id === e.id ? (
            <View style={{ marginVertical: 6 }}>
              <View style={[s.ligne, { gap: 8 }]}>
                <Text style={s.discret}>du</Text>
                <TextInput value={edition.debut} onChangeText={(v) => setEdition({ ...edition, debut: v })} placeholder="jj/mm" keyboardType="numbers-and-punctuation" style={champDate} />
                <Text style={s.discret}>au</Text>
                <TextInput value={edition.fin} onChangeText={(v) => setEdition({ ...edition, fin: v })} placeholder="jj/mm" keyboardType="numbers-and-punctuation" style={champDate} />
              </View>
              <View style={[s.ligne, { gap: 14, marginTop: 6 }]}>
                <Pressable onPress={enregistrerDates}><Text style={{ color: C.encre, fontWeight: '700', textDecorationLine: 'underline' }}>Enregistrer</Text></Pressable>
                {c.dates[e.id] && <Pressable onPress={() => datesParDefaut(e.id)}><Text style={[s.discret, { textDecorationLine: 'underline' }]}>Dates par défaut</Text></Pressable>}
                <Pressable onPress={() => setEdition(null)}><Text style={[s.discret, { textDecorationLine: 'underline' }]}>Annuler</Text></Pressable>
              </View>
            </View>
          ) : (
            <Pressable onPress={() => { const o = ETAPES.find((x) => x.id === e.id)!; const r = c.dates[e.id] ?? { debut: o.debut, fin: o.fin }; setEdition({ id: e.id, debut: jourMois(r.debut), fin: jourMois(r.fin) }); }}>
              <Text style={[s.discret, { fontSize: police.mini }]}>du {court(e.debutMs)} au {court(e.finMs)}{c.dates[e.id] ? ' (dates modifiées)' : ''} · <Text style={{ textDecorationLine: 'underline' }}>modifier</Text></Text>
            </Pressable>
          )}
          <Text style={[s.discret, { marginTop: 3 }]}>{e.detail}</Text>
          {e.lien && <Pressable onPress={() => router.push(e.lien as Href)}><Text style={{ color: C.encre, textDecorationLine: 'underline', marginTop: 4 }}>{e.lienTitre} ›</Text></Pressable>}
        </View>
      </View>
    );
  };

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Calendrier de saison" />
      <Text style={s.discret}>Les grandes étapes de l'année. Une étape qui commence est rappelée une fois à l'ouverture de l'appli.</Text>
      <Carte style={{ backgroundColor: C.encre }}>
        <Text style={{ color: C.accent, fontWeight: '700', letterSpacing: 1.5, fontSize: police.mini }}>EN CE MOMENT</Text>
        {enCours.length ? enCours.map((e) => <Text key={e.id} style={{ color: '#fff', fontSize: 18, fontWeight: '800', marginTop: 4 }}>{e.titre}</Text>)
          : <Text style={{ color: '#fff', fontSize: 18, fontWeight: '800', marginTop: 4 }}>Rien de prévu</Text>}
        {aVenir[0] && <Text style={{ color: '#A9B4BF', marginTop: 6 }}>Ensuite, le {court(aVenir[0].debutMs)} : {aVenir[0].titre}</Text>}
      </Carte>
      <Carte>
        <Titre>Année {an}</Titre>
        <Svg width={W} height={H}>
          {MOIS.map((m, i) => (
            <React.Fragment key={i}>
              <Rect x={(i * W) / 12} y={0} width={W / 12} height={H - 16} fill={i % 2 ? '#F4F5F0' : '#FFFFFF'} />
              <T x={((i + 0.5) * W) / 12} y={H - 4} fontSize={10} fill={C.discret} textAnchor="middle">{m}</T>
            </React.Fragment>
          ))}
          {etapes.map((e, k) => segments(e).map((g, j) => (
            <Rect key={`${e.id}${j}`} x={g.a} y={k * LH + 3} width={Math.max(3, g.b - g.a)} height={LH - 6} rx={4}
              fill={c.faites[cleEtape(e)] ? C.ok : e.etat === 'en-cours' ? C.accent : '#C9CDC4'} />
          )))}
          <Line x1={X(maint)} x2={X(maint)} y1={0} y2={H - 16} stroke={C.alerte} strokeWidth={2} />
        </Svg>
      </Carte>
      {enCours.length > 0 && <Carte><Titre>En ce moment</Titre>{enCours.map((e) => <React.Fragment key={e.id}>{ligne(e)}</React.Fragment>)}</Carte>}
      {aVenir.length > 0 && <Carte><Titre>À venir</Titre>{aVenir.map((e) => <React.Fragment key={e.id}>{ligne(e)}</React.Fragment>)}</Carte>}
      {passees.length > 0 && <Carte><Titre>Passées</Titre>{passees.map((e) => <React.Fragment key={e.id}>{ligne(e)}</React.Fragment>)}</Carte>}
      <Carte>
        <Titre>Mon secteur</Titre>
        <Text style={[s.discret, { marginBottom: 8 }]}>Dates prévues pour la moyenne montagne. Plus bas ou plus au sud, la saison commence plus tôt. Chaque étape peut aussi avoir ses propres dates (« modifier » sous l'étape) ; le décalage s'ajoute à toutes.</Text>
        <Puces options={DECALAGES} valeur={String(c.decalage)} onChange={(v) => maj({ ...c, decalage: Number(v) })} />
      </Carte>
    </ScrollView>
  );
}

const champDate = { borderWidth: 1, borderColor: C.ligne, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6, width: 80, color: C.encre, textAlign: 'center' as const };
