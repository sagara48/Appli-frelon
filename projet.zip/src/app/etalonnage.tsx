/** Étalonnage du toit (É3) : position du tag, choix du tag, tours autour du tag, calcul. Protocole : calib.c de la carte chef. */
import { Stack, useRouter } from 'expo-router';
import { useKeepAwake } from 'expo-keep-awake';
import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, Titre, s } from '@/ui/composants';
import { C, VOIES, fmtAge, idTag, police } from '@/ui/theme';
import { signe } from '@/ui/Pas';
import { ageS, useEtat } from '@/store/store';
import { envoyerToit } from '@/sources/commandesToit';
import { cmdToit } from '@/proto/toit';
import { niveauPct } from '@/calc/geo';

const envoyer = (cmd: string) => envoyerToit(cmd).catch((e) => Alert.alert('Toit', (e as Error).message));
const qualite = (err: number) => (err <= 10 ? ['Très bon, rien à faire.', C.ok] : err <= 20 ? ['Correct. À refaire plus tard sur un lieu plus dégagé.', C.accent] : ['À recommencer : trop de reflets ou tour incomplet.', C.alerte]) as [string, string];

export default function Etalonnage() {
  useKeepAwake();
  const router = useRouter();
  const e = useEtat((x) => x);
  const [tag, setTag] = useState<number | null>(null);
  const et = e.etalonnage;
  const actif = e.connexion === 'connecte' && (e.source === 'toit' || e.source === 'simulation');
  const sats = e.toit && e.toit.lat ? e.toit.sats : 0;
  const ids = Object.keys(e.tags).map(Number).sort((a, b) => a - b);
  const t = tag !== null ? e.tags[tag] : undefined;
  const k = et.dernierK && Date.now() - et.dernierK.recuMs < 60000 ? et.dernierK : null;
  const r = et.resultat;
  const n = Math.max(et.n, 0);

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <Stack.Screen options={{ headerShown: true, title: 'Étalonnage du toit', headerStyle: { backgroundColor: C.fond }, headerShadowVisible: false,
        headerRight: () => <Pressable onPress={() => router.push('/aide-etalonnage')}><Text style={{ color: C.encre, textDecorationLine: 'underline' }}>Aide</Text></Pressable> }} />
      <Text style={s.discret}>À faire une fois, puis après un changement d'antenne ou de voiture.</Text>
      {!actif && <Carte><Text style={{ color: C.alerte }}>Connectez d'abord le toit (onglet Réglages).</Text></Carte>}
      {k?.type === 'ERR' && <Carte style={{ borderColor: C.alerte }}><Text style={{ color: C.alerte }}>Toit : {k.message}</Text></Carte>}

      <Etape no={1} fait={et.posOk} titre="Poser un tag à côté de la voiture"
        texte={et.posOk ? `Position du tag enregistrée (GPS ${sats} sat.)` : `Tag sur un piquet à 1 m du sol, voiture garée juste à côté. GPS : ${sats ? `${sats} sat.` : 'pas de position'}${sats && sats < 6 ? ' (attendre au moins 6)' : ''}`}>
        <Bouton titre={et.posOk ? 'Refaire la position' : 'Position du tag'} plein={!et.posOk} desactive={!actif} onPress={() => envoyer(cmdToit.calpos())} />
      </Etape>

      <Etape no={2} fait={tag !== null && !!t && ageS(e, t) < 30} titre="Choisir ce tag"
        texte={tag === null ? 'Le numéro du tag posé.' : t ? `Tag ${idTag(tag)} · signal reçu il y a ${fmtAge(ageS(e, t))}` : `Tag ${idTag(tag)} · pas encore entendu`}>
        <View style={[s.ligne, { gap: 8, flexWrap: 'wrap' }]}>
          {ids.length ? ids.map((id) => (
            <Pressable key={id} onPress={() => setTag(id)} style={[s.puce, id === tag && s.puceActive]}>
              <Text style={[s.puceTxt, id === tag && { fontWeight: '700' }]}>{idTag(id)}</Text>
            </Pressable>
          )) : <Text style={s.discret}>Aucun tag entendu par le toit pour l'instant.</Text>}
        </View>
        {t && (
          <View style={[s.ligne, { gap: 10, marginTop: 10, flexWrap: 'wrap' }]}>
            {VOIES.slice(0, 4).map((v, i) => <Text key={v} style={s.discret}>{v} <Text style={{ color: C.encre, fontWeight: '700' }}>{niveauPct(t.r[i]) ?? '—'}</Text></Text>)}
          </View>
        )}
      </Etape>

      <Etape no={3} fait={et.enCours && n >= 120} titre="Faire 2 tours lents autour du tag"
        texte={`À 30–60 m du tag, à vitesse régulière au-dessus de ${e.config?.vmin ?? 4} km/h. Le tag doit passer devant, à droite, derrière et à gauche de la voiture.`}>
        {et.enCours ? (
          <>
            <Text style={{ color: C.encre, fontSize: police.normal + 2 }}><Text style={{ fontWeight: '800' }}>{n}</Text> trames reçues</Text>
            <View style={{ height: 10, borderRadius: 5, backgroundColor: C.fond, overflow: 'hidden', marginTop: 6 }}>
              <View style={{ width: `${Math.min(100, (n / 120) * 100)}%`, height: '100%', backgroundColor: n >= 40 ? C.ok : C.accent }} />
            </View>
            <Text style={[s.discret, { fontSize: police.mini, marginTop: 4 }]}>40 minimum · 120 conseillé · 400 au plus</Text>
          </>
        ) : (
          <Bouton titre="Démarrer" plein desactive={!actif || !et.posOk || tag === null} onPress={() => envoyer(cmdToit.cal(tag!))} />
        )}
      </Etape>

      <Etape no={4} fait={false} titre="Terminer et calculer" texte="Le toit ajuste l'avant, la largeur du lobe et le gain de chaque voie, puis les garde en mémoire.">
        <Bouton titre="Terminer l'étalonnage" plein desactive={!actif || !et.enCours}
          onPress={() => (n < 40
            ? Alert.alert('Pas assez de trames', `Seulement ${n} trames (40 minimum). Terminer quand même ?`, [{ text: 'Continuer à tourner', style: 'cancel' }, { text: 'Terminer', onPress: () => envoyer(cmdToit.calfin()) }])
            : envoyer(cmdToit.calfin()))} />
      </Etape>

      {r && (
        <Carte style={{ borderColor: qualite(r.errDeg)[1], borderWidth: 2 }}>
          <View style={[s.ligne, { justifyContent: 'space-between' }]}>
            <Titre>Dernier résultat</Titre>
            <Text style={[s.discret, { marginBottom: 8 }]}>{r.n} trames · {new Date(r.date).toLocaleDateString('fr-FR')}</Text>
          </View>
          <View style={[s.ligne, { justifyContent: 'space-between' }]}>
            <Chiffre k="Avant" v={`${signe(r.fwd > 180 ? r.fwd - 360 : r.fwd)}°`} />
            <Chiffre k="Lobe" v={`${Math.round(r.beam)}°`} />
            <Chiffre k="Erreur moyenne" v={`${Math.round(r.errDeg)}°`} />
          </View>
          <Text style={[s.discret, { marginTop: 10 }]}>Gains : {VOIES.slice(0, 4).map((v, i) => `${v.toLowerCase()} ${signe(r.gains[i], 1)}`).join(' · ')} dB</Text>
          <Text style={{ color: qualite(r.errDeg)[1], fontWeight: '700', marginTop: 8 }}>{qualite(r.errDeg)[0]}</Text>
          {Math.abs(r.fwd > 180 ? r.fwd - 360 : r.fwd) > 15 && <Text style={[s.discret, { marginTop: 4 }]}>Avant décalé de plus de 15° : remettre le boîtier droit sur le toit et refaire l'étalonnage.</Text>}
          {r.gains.some((g) => Math.abs(g) > 6) && <Text style={[s.discret, { marginTop: 4 }]}>Une voie demande plus de 6 dB : vérifier son antenne et son câble.</Text>}
        </Carte>
      )}
    </ScrollView>
  );
}

function Etape({ no, titre, texte, fait, children }: { no: number; titre: string; texte: string; fait: boolean; children: React.ReactNode }) {
  return (
    <Carte>
      <View style={[s.ligne, { alignItems: 'flex-start', gap: 12 }]}>
        <View style={{ width: 28, height: 28, borderRadius: 14, backgroundColor: fait ? C.ok : C.encre, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: '#fff', fontWeight: '800' }}>{fait ? '✓' : no}</Text>
        </View>
        <View style={{ flex: 1, gap: 8 }}>
          <Text style={{ color: C.encre, fontWeight: '700', fontSize: police.normal + 1 }}>{titre}</Text>
          <Text style={[s.discret, { lineHeight: 19 }]}>{texte}</Text>
          {children}
        </View>
      </View>
    </Carte>
  );
}

function Chiffre({ k, v }: { k: string; v: string }) {
  return (
    <View>
      <Text style={s.discret}>{k}</Text>
      <Text style={{ fontSize: police.normal + 3, fontWeight: '800', color: C.encre }}>{v}</Text>
    </View>
  );
}
