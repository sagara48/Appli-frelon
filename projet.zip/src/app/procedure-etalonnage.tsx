/** Procédure d'étalonnage complète, à lire avant la première sortie (ou à suivre sur place). */
import { useRouter } from 'expo-router';
import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, EnTete, Titre, s } from '@/ui/composants';
import { C, police } from '@/ui/theme';

type Partie = { titre: string; duree?: string; pourquoi: string; etapes: string[]; regle: string; reussi: string; problemes?: string[] };

const PARTIES: Partie[] = [
  {
    titre: '1. Boussole du portatif', duree: '1 min',
    pourquoi: 'La flèche du portatif et le nid estimé en marchant utilisent la boussole. Une boussole pas calibrée peut se tromper de 30° ou plus.',
    etapes: [
      'Allumez le portatif et connectez-le (onglet Portatif).',
      'Éloignez-vous de la voiture et de tout objet métallique : 2 à 3 m suffisent. Retirez montre et téléphone de la main qui tient le portatif.',
      'Menu → Étalonnage → « Calibrer la boussole » → Démarrer.',
      'Pendant 20 secondes, tournez le portatif dans tous les sens : grands huit, écran vers le ciel, vers le sol, posé sur la tranche. Chaque face doit pointer au moins une fois vers le sol.',
    ],
    regle: 'Le décalage et l\'échelle de chaque axe du capteur magnétique, gardés dans le portatif.',
    reussi: '« Boussole calibrée » et un bip aigu. Sinon « calibration incomplète » : un axe n\'a pas assez bougé, recommencez en tournant davantage sur la tranche.',
    problemes: ['« Boussole perturbée » loin de tout métal : refaire la calibration.', 'Un aimant ou une pile neuve collée au boîtier fausse tout : enlevez-le puis recommencez.'],
  },
  {
    titre: '2. Entrée radio du portatif', duree: '1 min',
    pourquoi: 'Le portatif passe seul du préampli (tags lointains) au direct puis à l\'atténuateur (tout près du nid). Pour que le niveau affiché ne saute pas à chaque passage, il doit connaître le gain exact de chaque chemin.',
    etapes: [
      'Allumez un tag et faites-le suivre par le portatif (onglet Portatif, ou bouton du portatif).',
      'Posez le tag à 2 à 5 m du portatif, sans obstacle entre les deux. Posez aussi le portatif : il ne doit plus bouger.',
      'Menu → Étalonnage → « Mesurer » → Démarrer. Ne bougez plus pendant 20 secondes.',
    ],
    regle: 'Le gain du préampli et de l\'atténuateur (ou l\'absence d\'atténuateur sur une carte V2), gardés dans le portatif.',
    reussi: '« Entrée radio mesurée » ; l\'écran Étalonnage affiche par exemple « Préampli +12 dB, atténuateur −18 dB ».',
    problemes: ['« Trop peu de trames » : rapprochez le tag, vérifiez qu\'il est bien suivi.', 'Gain du préampli inchangé : le signal était trop fort pour le mesurer, éloignez le tag à 5 m et recommencez.'],
  },
  {
    titre: '3. Chaque tag à 1 m', duree: '1 min par tag',
    pourquoi: 'Deux tags n\'émettent jamais exactement aussi fort (antenne, soudure, résine). En mesurant chacun à 1 m, la distance affichée par le portatif est juste pour ce tag-là.',
    etapes: [
      'Plantez un piquet (ou un manche à balai) en extérieur, loin des murs et de la voiture. Fixez le tag à 1 m du sol.',
      'Tenez le portatif à 1 m du tag (mesurez avec un mètre), à la même hauteur, antenne vers le tag. Personne entre les deux.',
      'Menu → Étalonnage → touchez le numéro du tag → Démarrer. Ne bougez plus 20 à 60 secondes.',
      'Recommencez pour chaque tag. Les tags déjà faits disparaissent de la liste.',
    ],
    regle: 'Le niveau à 1 m de chaque tag (gardé dans le téléphone et renvoyé au portatif à chaque connexion), et le niveau moyen du portatif à 1 m utilisé pour un tag pas encore étalonné.',
    reussi: '« Tag n étalonné : −xx dBm à 1 m ». Entre −15 et −35 dBm en général.',
    problemes: ['Un tag nettement plus faible que les autres (plus de 8 dB) : antenne ou soudure à vérifier.', 'Résultat « raté » : moins de 20 trames reçues, tag éteint ou trop loin.'],
  },
  {
    titre: '4. Toit de la voiture', duree: '15 min',
    pourquoi: 'Le toit compare les quatre antennes pour donner la direction du tag. Il doit savoir où est l\'avant du boîtier, la largeur de chaque lobe, le gain de chaque voie et la forme réelle des antennes une fois montées sur votre voiture. Les mêmes tours règlent aussi la distance du toit.',
    etapes: [
      'Trouvez un grand parking vide ou un champ avec un chemin autour : au moins 60 m dans chaque direction, sans hangar ni bâtiment métallique proche. Évitez les lignes électriques.',
      'Connectez le toit (Menu → Appareils). Attendez au moins 6 satellites.',
      'Plantez le tag sur son piquet à 1 m du sol, garez la voiture juste à côté (portière à 1 m du tag).',
      'Menu → Étalonnage → « Étalonner le toit ». Étape 1 : « Position du tag ». Étape 2 : choisissez le numéro du tag.',
      'Étape 3 : « Démarrer », puis faites 2 tours complets autour du tag, à 30-60 m, au-dessus de 5 km/h, à vitesse régulière. Le tag doit passer devant, à droite, derrière et à gauche de la voiture. Variez un peu la distance (30 m puis 60 m) : c\'est ce qui règle la distance.',
      'Quand le compteur dépasse 120 trames, étape 4 : « Terminer l\'étalonnage ».',
    ],
    regle: 'Sur le toit : l\'avant du boîtier, la largeur du lobe, le gain des 4 voies, le diagramme réel des antennes (gardé seulement s\'il fait mieux que le modèle). Dans l\'appli : le signal du toit à 1 m et l\'incertitude de la distance.',
    reussi: 'Erreur moyenne de moins de 10° : très bon. 10 à 20° : correct. Plus de 20° : à refaire sur un lieu plus dégagé ou avec un tour plus complet.',
    problemes: [
      '« Avant décalé de plus de 15° » : le boîtier a tourné sur le toit, remettez-le droit et recommencez.',
      'Une voie demande plus de 6 dB : antenne mal vissée ou câble abîmé.',
      'Pas de « distance réglée » dans le résultat : les tours étaient tous à la même distance, refaites-en un plus large.',
    ],
  },
  {
    titre: '5. Terrain et orientation : appris tout seuls', duree: 'rien à faire',
    pourquoi: 'Le signal s\'affaiblit plus vite dans un bois que dans un pré. Ce n\'est mesurable que sur de vrais nids.',
    etapes: [
      'À chaque nid trouvé, notez-le pour le tag suivi (« Nid trouvé ici », ou nid noté trouvé dans le carnet).',
      'L\'appli compare la carte du signal à pied au vrai emplacement : elle en déduit l\'affaiblissement du terrain et l\'envoie au portatif.',
      'Elle compare aussi les directions prises en voiture au vrai nid : si elles tournent toutes du même côté (au moins 2 nids ou 30 directions), la correction est envoyée seule au toit.',
    ],
    regle: 'L\'exposant du terrain (distances du toit et du portatif) et l\'orientation du toit.',
    reussi: 'Menu → Étalonnage, ligne 5 : « Exposant x appris sur n nids ». Le journal note chaque correction du toit.',
  },
];

const AUTO = [
  ['Distance du toit (signal à 1 m, incertitude)', 'étalonnage du toit'],
  ['Distance du portatif (signal à 1 m)', 'tags à 1 m'],
  ['Affaiblissement du terrain', 'nids trouvés'],
  ['Avant du boîtier, lobe, gains des voies, diagramme', 'étalonnage du toit'],
  ['Orientation du toit (recalage)', 'nids trouvés'],
  ['Passage préampli / direct / atténuateur', 'entrée radio du portatif'],
  ['Boussole', 'calibration de la boussole'],
];

export default function ProcedureEtalonnage() {
  const router = useRouter();
  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Procédure d'étalonnage" />
      <Carte>
        <Text style={{ color: C.encre, fontSize: police.normal + 1, lineHeight: 22 }}>
          Une fois en début de saison, environ 1 heure pour 10 tags. Ensuite, plus aucun réglage à saisir : chaque étape règle seule ce qu'elle mesure, et l'appli continue d'apprendre à chaque nid trouvé.
        </Text>
        <Text style={[s.discret, { marginTop: 8 }]}>
          À emporter : portatif et toit chargés, tous les tags chargés, un piquet ou un manche à balai, un mètre ruban, le téléphone avec l'appli. Faites les étapes dans l'ordre : la 2 a besoin d'un tag suivi, la 3 d'une boussole et d'une entrée radio justes.
        </Text>
        <View style={{ marginTop: 10 }}><Bouton titre="Ouvrir l'écran Étalonnage" plein onPress={() => router.push('/etalonnages')} /></View>
      </Carte>

      {PARTIES.map((p) => (
        <Carte key={p.titre}>
          <View style={[s.ligne, { justifyContent: 'space-between' }]}>
            <Titre>{p.titre}</Titre>
            {!!p.duree && <Text style={[s.discret, { marginBottom: 8 }]}>{p.duree}</Text>}
          </View>
          <Text style={{ color: C.encre, lineHeight: 20 }}>{p.pourquoi}</Text>
          <Text style={[s.discret, { fontWeight: '700', marginTop: 10 }]}>Comment</Text>
          {p.etapes.map((x, i) => <Text key={i} style={{ color: C.encre, lineHeight: 20, marginTop: 4 }}>{i + 1}. {x}</Text>)}
          <Text style={[s.discret, { fontWeight: '700', marginTop: 10 }]}>Ce qui est réglé</Text>
          <Text style={{ color: C.encre, lineHeight: 20 }}>{p.regle}</Text>
          <Text style={[s.discret, { fontWeight: '700', marginTop: 10 }]}>C'est réussi si</Text>
          <Text style={{ color: C.encre, lineHeight: 20 }}>{p.reussi}</Text>
          {!!p.problemes?.length && (
            <>
              <Text style={[s.discret, { fontWeight: '700', marginTop: 10 }]}>Si ça ne va pas</Text>
              {p.problemes.map((x, i) => <Text key={i} style={{ color: C.encre, lineHeight: 20, marginTop: 2 }}>• {x}</Text>)}
            </>
          )}
        </Carte>
      ))}

      <Carte>
        <Titre>Ce qui est réglé tout seul</Titre>
        {AUTO.map(([quoi, par]) => (
          <View key={quoi} style={[s.ligne, { justifyContent: 'space-between', paddingVertical: 6, borderTopWidth: 1, borderTopColor: C.ligne, gap: 10 }]}>
            <Text style={{ color: C.encre, flex: 1 }}>{quoi}</Text>
            <Text style={[s.discret, { flex: 1, textAlign: 'right' }]}>{par}</Text>
          </View>
        ))}
        <Text style={[s.discret, { marginTop: 8 }]}>Les réglages à la main restent en mode expert (Menu → Réglages manuels du toit, Paramètres → Distance estimée), seulement pour un dépannage.</Text>
      </Carte>
    </ScrollView>
  );
}
