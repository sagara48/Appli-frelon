/** Mises à jour des appareils (É20) : importer les paquets (.zip) puis les envoyer par Bluetooth. */
import * as DocumentPicker from 'expo-document-picker';
import { File } from 'expo-file-system';
import React, { useRef, useState } from 'react';
import { Alert, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, EnTete, Titre, s } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { LIBELLES, lirePaquet, type Appareil, type Paquet } from '@/dfu/paquet';
import { mettreAJour, type Etape } from '@/services/majAppareils';
import { useEtat } from '@/store/store';

const ORDRE: Appareil[] = ['portatif', 'toit', 'voie', 'nacelle', 'sol'];

export default function MisesAJour() {
  const e = useEtat((x) => ({ connexion: x.connexion, source: x.source, portatif: x.portatif }));
  const [paquets, setPaquets] = useState<Partial<Record<Appareil, Paquet>>>({});
  const [encours, setEncours] = useState<{ app: Appareil; etape: Etape } | null>(null);
  const [fini, setFini] = useState<Partial<Record<Appareil, string>>>({});
  const annule = useRef(false);

  const importer = async () => {
    const r = await DocumentPicker.getDocumentAsync({ type: ['application/zip', 'application/octet-stream', '*/*'], multiple: true, copyToCacheDirectory: true });
    if (r.canceled) return;
    const n: Partial<Record<Appareil, Paquet>> = { ...paquets };
    const erreurs: string[] = [];
    for (const a of r.assets) {
      try { const p = lirePaquet(await new File(a.uri).bytes(), a.name); n[p.appareil] = p; }
      catch (err) { erreurs.push(`${a.name} : ${(err as Error).message}`); }
    }
    setPaquets(n);
    if (erreurs.length) Alert.alert('Import', erreurs.join('\n'));
  };

  const lancer = async (app: Appareil) => {
    const p = paquets[app]; if (!p) return;
    annule.current = false;
    setEncours({ app, etape: { texte: 'Préparation…', fait: 0, total: 1 } });
    try {
      const n = await mettreAJour(p, (etape) => setEncours({ app, etape }), () => annule.current);
      setFini({ ...fini, [app]: `${n > 1 ? `${n} appareils mis à jour` : 'Mis à jour'} en ${p.version} : redémarrage en cours` });
    } catch (err) {
      Alert.alert(LIBELLES[app], `Mise à jour interrompue : ${(err as Error).message}\nL'appareil garde son ancienne version ; vous pouvez relancer.`);
    } finally { setEncours(null); }
  };

  const etatConnexion = (a: Appareil) =>
    a === 'toit' ? (e.source === 'toit' && e.connexion === 'connecte' ? 'connecté' : 'sera cherché')
      : a === 'portatif' ? (e.portatif.connexion === 'connecte' && e.portatif.source === 'ble' ? 'connecté' : 'sera cherché')
        : a === 'voie' ? 'par le toit (connectez-le d\'abord)' : a === 'nacelle' ? 'allumée bouton maintenu 5 s' : 'mode mise à jour depuis son écran';

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Mises à jour" />
      <Text style={s.discret}>{Object.keys(paquets).length ? `${Object.keys(paquets).length} paquet(s) importé(s)` : 'Importez les paquets « …_mise_a_jour_bluetooth.zip » reçus avec les firmwares.'}</Text>
      {ORDRE.map((a) => {
        const p = paquets[a];
        const actif = encours?.app === a;
        return (
          <Carte key={a}>
            <View style={[s.ligne, { justifyContent: 'space-between' }]}>
              <Text style={{ color: C.encre, fontWeight: '700', fontSize: police.normal + 1 }}>{LIBELLES[a]}</Text>
              <Text style={s.discret}>{p ? `paquet ${p.version}` : 'pas de paquet'}</Text>
            </View>
            <Text style={[s.discret, { fontSize: police.mini }]}>{etatConnexion(a)}{p?.date ? ` · paquet du ${new Date(p.date).toLocaleDateString('fr-FR')}` : ''}</Text>
            {actif ? (
              <View style={{ marginTop: 8 }}>
                <Text style={{ color: C.encre }}>{encours!.etape.texte}</Text>
                <View style={{ height: 8, borderRadius: 4, backgroundColor: C.fond, overflow: 'hidden', marginVertical: 6 }}>
                  <View style={{ width: `${(encours!.etape.fait / Math.max(1, encours!.etape.total)) * 100}%`, height: '100%', backgroundColor: C.accent }} />
                </View>
                <Bouton titre="Annuler" onPress={() => { annule.current = true; }} />
              </View>
            ) : fini[a] ? <Text style={{ color: C.ok, marginTop: 8, fontWeight: '700' }}>{fini[a]}</Text>
              : p && <View style={{ marginTop: 8 }}><Bouton titre="Mettre à jour" plein desactive={!!encours} onPress={() => lancer(a)} /></View>}
          </Carte>
        );
      })}
      <Bouton titre="Importer un paquet (.zip)" onPress={importer} desactive={!!encours} />
      <Carte>
        <Titre>Pas par l'appli</Titre>
        <Text style={{ color: C.encre, lineHeight: 21 }}>Tags : par le gabarit de programmation (pas de mise à jour sans fil).</Text>
        <Text style={{ color: C.encre, lineHeight: 21 }}>Écran 7" de la voiture : par câble USB depuis le PC.</Text>
      </Carte>
      <Text style={[s.discret, { fontSize: police.mini }]}>Gardez le téléphone à moins de 2 m et l'appareil allumé (sur secteur si possible). À la fin, il redémarre tout seul sur la nouvelle version ; si elle ne démarre pas, l'ancienne revient.</Text>
    </ScrollView>
  );
}
