/** Plan de vol automatique autour d'un nid estimé : spirale ou quadrillage, à exporter en mission Litchi
 *  (vol par points de passage du Phantom) ou en trace KML. */
import { useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import { Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import Svg, { Circle, Polyline } from 'react-native-svg';
import { Bouton, Carte, EnTete, Puces, Titre, s } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { genererPlan, HAUTEUR_MAX, litchiCsv, MAX_POINTS, planKml, PLAN_DEFAUT, pointsXY, rayonConseille, type Motif, type ReglagesPlan } from '@/calc/planVol';
import { partager } from '@/services/exports';
import { facteurEstimations } from '@/services/terrain';

function Reglage({ titre, valeur, unite, pas, min, max, onChange }: { titre: string; valeur: number; unite: string; pas: number; min: number; max: number; onChange: (v: number) => void }) {
  const b = (txt: string, v: number) => (
    <Pressable onPress={() => onChange(Math.min(max, Math.max(min, v)))} style={{ width: 44, height: 40, borderRadius: 8, borderWidth: 1, borderColor: C.ligne, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color: C.encre, fontSize: 20, fontWeight: '700' }}>{txt}</Text>
    </Pressable>
  );
  return (
    <View style={[s.ligne, { justifyContent: 'space-between', marginTop: 8 }]}>
      <Text style={{ color: C.encre, flex: 1 }}>{titre}</Text>
      <View style={[s.ligne, { gap: 8 }]}>
        {b('−', valeur - pas)}
        <Text style={{ color: C.encre, fontWeight: '800', minWidth: 64, textAlign: 'center' }}>{valeur} {unite}</Text>
        {b('+', valeur + pas)}
      </View>
    </View>
  );
}

export default function PlanVol() {
  const q = useLocalSearchParams<{ lat: string; lon: string; err?: string; titre?: string }>();
  const centre = { lat: Number(q.lat), lon: Number(q.lon) };
  const err = Number(q.err) || 30;
  // rayon : l'incertitude affichée corrigée de l'écart réel mesuré sur les nids trouvés
  const [r, setR] = useState<ReglagesPlan>(() => ({ ...PLAN_DEFAUT, rayonM: rayonConseille(err * (facteurEstimations() ?? 1)) }));
  const { width } = useWindowDimensions();
  if (!Number.isFinite(centre.lat) || !Number.isFinite(centre.lon)) return <View style={s.ecran}><EnTete titre="Plan de vol" /><Text style={[s.discret, { padding: 16 }]}>Position du nid inconnue.</Text></View>;
  const plan = genererPlan(centre, r);
  const xy = pointsXY(plan);
  const W = Math.min(width - 64, 360), k = (W / 2 - 10) / (r.rayonM * 1.05);
  const X = (x: number) => W / 2 + x * k, Y = (y: number) => W / 2 - y * k;
  const nom = `vol_${(q.titre || 'nid').replace(/[^a-zA-Z0-9]+/g, '_')}_${r.motif}`;
  const maj = (p: Partial<ReglagesPlan>) => setR({ ...r, ...p });

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Plan de vol" />
      <Text style={s.discret}>{q.titre ? `${q.titre} · ` : ''}nid estimé à ± {err} m. Le drone vole seul autour du nid ; la nacelle relève les tags et l'écran de la voiture affiche la carte du signal.</Text>
      <Carte>
        <Puces<Motif> options={[['spirale', 'Spirale'], ['quadrillage', 'Quadrillage']]} valeur={r.motif} onChange={(m) => maj({ motif: m })} />
        <Text style={[s.discret, { marginTop: 6 }]}>
          {r.motif === 'spirale' ? "De l'extérieur vers le nid : on finit au-dessus du point le plus probable." : 'Allers-retours réguliers : couvre toute la zone de la même façon.'}
        </Text>
        <Reglage titre="Rayon de la zone" valeur={r.rayonM} unite="m" pas={10} min={30} max={600} onChange={(v) => maj({ rayonM: v })} />
        <Reglage titre="Écart entre passages" valeur={r.espacementM} unite="m" pas={5} min={15} max={150} onChange={(v) => maj({ espacementM: v })} />
        <Reglage titre="Hauteur (au-dessus du décollage)" valeur={r.hauteurM} unite="m" pas={5} min={15} max={HAUTEUR_MAX} onChange={(v) => maj({ hauteurM: v })} />
        <Reglage titre="Vitesse" valeur={r.vitesse} unite="m/s" pas={1} min={2} max={12} onChange={(v) => maj({ vitesse: v })} />
      </Carte>
      <Carte>
        <View style={{ alignItems: 'center' }}>
          <Svg width={W} height={W}>
            <Circle cx={W / 2} cy={W / 2} r={r.rayonM * k} fill="none" stroke={C.ligne} strokeWidth={1} />
            <Circle cx={W / 2} cy={W / 2} r={Math.max(4, err * k)} fill={C.alerte} opacity={0.18} />
            <Polyline points={xy.map((p) => `${X(p.x).toFixed(1)},${Y(p.y).toFixed(1)}`).join(' ')} fill="none" stroke={C.encre} strokeWidth={1.5} />
            {xy.map((p, i) => <Circle key={i} cx={X(p.x)} cy={Y(p.y)} r={i === 0 ? 5 : 2} fill={i === 0 ? C.ok : C.encre} />)}
            <Circle cx={W / 2} cy={W / 2} r={4} fill={C.alerte} />
          </Svg>
          <Text style={[s.discret, { fontSize: police.mini }]}>Point vert : début de la mission · rouge : nid estimé · nord en haut</Text>
        </View>
        <Text style={{ color: C.encre, fontWeight: '700', marginTop: 8 }}>{plan.points.length} points · {(plan.longueurM / 1000).toFixed(2).replace('.', ',')} km · environ {Math.ceil(plan.dureeMin)} min de vol</Text>
        {plan.dureeMin > 17 && <Text style={{ color: C.alerte, fontWeight: '700', marginTop: 4 }}>Trop long pour une batterie (~20 min avec l'aller-retour) : réduisez le rayon, écartez les passages ou accélérez.</Text>}
        {plan.tronque && <Text style={{ color: C.alerte, marginTop: 4 }}>Plus de {MAX_POINTS} points : le plan a été simplifié (Litchi n'en accepte pas plus).</Text>}
      </Carte>
      <Carte>
        <Titre>Exporter</Titre>
        <View style={[s.ligne, { gap: 10, flexWrap: 'wrap' }]}>
          <Bouton titre="Mission Litchi (CSV)" plein onPress={() => partager(`${nom}.csv`, litchiCsv(plan), 'text/csv').catch(() => {})} />
          <Bouton titre="Trace KML" onPress={() => partager(`${nom}.kml`, planKml(plan, q.titre || 'Plan de vol'), 'application/vnd.google-earth.kml+xml').catch(() => {})} />
        </View>
        <Text style={[s.discret, { marginTop: 8 }]}>
          Litchi : ouvrez le Mission Hub (site flylitchi.com), Missions → Importer, choisissez le fichier CSV, vérifiez le plan puis enregistrez ; il apparaît dans l'appli Litchi du téléphone.
          Hauteurs comptées depuis le point de décollage : décollez à peu près au niveau du nid et vérifiez les arbres, lignes et bâtiments sur le trajet.
        </Text>
        <Text style={[s.discret, { marginTop: 6, fontSize: police.mini }]}>Vous restez responsable du vol : vue directe, 120 m au plus, zones autorisées (Géoportail, couche « restrictions UAS »), batterie de retour.</Text>
      </Carte>
    </ScrollView>
  );
}
