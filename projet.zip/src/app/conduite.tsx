/** Mode conduite (É10) : très lisible d'un coup d'œil, annonce vocale toutes les 10 s, bips qui suivent le signal. */
import { Stack, useRouter } from 'expo-router';
import { useKeepAwake } from 'expo-keep-awake';
import React, { useEffect } from 'react';
import { Pressable, Text, View, useWindowDimensions } from 'react-native';
import Svg, { Circle, G, Path, Rect } from 'react-native-svg';
import { C, idTag, libelleRelatif } from '@/ui/theme';
import { ageS, definirAlertes, store, useEtat } from '@/store/store';
import { niveauPct, pointCardinal } from '@/calc/geo';
import { annoncer, suivreAuSon } from '@/services/sons';

const COTES = ['avant', 'avant droit', 'droite', 'arrière droit', 'arrière', 'arrière gauche', 'gauche', 'avant gauche'];
const cote = (rel: number) => COTES[Math.round((((rel % 360) + 360) % 360) / 45) % 8];

export default function Conduite() {
  useKeepAwake();
  const router = useRouter();
  const { width, height } = useWindowDimensions();
  const e = useEtat((x) => ({ tags: x.tags, tagChoisi: x.tagChoisi, horlogeMs: x.horlogeMs, toit: x.toit, alertes: x.alertes }));
  const t = e.tagChoisi !== null ? e.tags[e.tagChoisi] : undefined;
  const age = t ? ageS(store.get(), t) : 999;
  const frais = age < 10 && t && t.rel >= 0;
  const pct = t ? niveauPct(Math.max(...t.r)) : null;

  useEffect(() => suivreAuSon(), []);
  useEffect(() => {
    if (!e.alertes.voix) return;
    const i = setInterval(() => {
      const s = store.get(), tt = s.tagChoisi !== null ? s.tags[s.tagChoisi] : undefined;
      if (!tt) return;
      if (ageS(s, tt) > 10) { annoncer(`Tag ${tt.id}, pas de signal`); return; }
      if (tt.rel >= 0) annoncer(`Tag ${tt.id}, ${cote(tt.rel)}, ${niveauPct(Math.max(...tt.r)) ?? 0} pour cent`);
    }, 10000);
    return () => clearInterval(i);
  }, [e.alertes.voix]);

  const taille = Math.min(width - 40, height * 0.45);
  const c = taille / 2;
  return (
    <View style={{ flex: 1, backgroundColor: C.encre, padding: 20, paddingTop: 50 }}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text style={{ color: '#fff', fontSize: 28, fontWeight: '800' }}>{t ? `Tag ${idTag(t.id)}` : 'Aucun tag'}</Text>
        <Text style={{ color: '#A9B4BF' }}>{e.alertes.voix ? 'Annonce vocale activée' : 'Annonce coupée'}</Text>
      </View>
      <View style={{ alignItems: 'center', marginTop: 16 }}>
        <Svg width={taille} height={taille}>
          <Circle cx={c} cy={c} r={c - 4} fill="none" stroke="#34465A" strokeWidth={3} />
          <Rect x={c - 16} y={c - 30} width={32} height={60} rx={10} fill="#5B6F84" />
          <Rect x={c - 11} y={c - 22} width={22} height={11} rx={3} fill="#9FB3C8" />
          {frais && (
            <G transform={`rotate(${t!.rel} ${c} ${c})`}>
              <Path d={`M${c},${10} L${c + 34},${c - c * 0.35} L${c + 12},${c - c * 0.35} L${c + 12},${c - 40} L${c - 12},${c - 40} L${c - 12},${c - c * 0.35} L${c - 34},${c - c * 0.35} Z`} fill={C.accent} />
            </G>
          )}
        </Svg>
        <Text style={{ color: frais ? '#fff' : '#A9B4BF', fontSize: 40, fontWeight: '800', marginTop: 10, textAlign: 'center' }}>
          {frais ? cote(t!.rel).replace(/^./, (x) => x.toUpperCase()) : t ? `Pas de signal (${Math.round(age)} s)` : 'En écoute…'}
        </Text>
        {frais && <Text style={{ color: '#A9B4BF', fontSize: 16 }}>{libelleRelatif(t!.rel)}</Text>}
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-around', marginTop: 20 }}>
        <Gros k="Signal" v={pct !== null && frais ? `${pct} %` : '—'} />
        <Gros k="Cap" v={frais && t!.abs >= 0 ? `${Math.round(t!.abs)}° ${pointCardinal(t!.abs)}` : '—'} />
        <Gros k="Vitesse" v={e.toit ? `${Math.round(e.toit.vitesse)} km/h` : '—'} />
      </View>
      <View style={{ flex: 1 }} />
      <View style={{ flexDirection: 'row', gap: 12 }}>
        <Pressable onPress={() => definirAlertes({ sonSignal: !e.alertes.sonSignal })} style={{ flex: 1, padding: 18, borderRadius: 14, borderWidth: 2, borderColor: '#5B6F84', alignItems: 'center' }}>
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700' }}>Son : {e.alertes.sonSignal ? 'activé' : 'coupé'}</Text>
        </Pressable>
        <Pressable onPress={() => router.back()} style={{ flex: 1, padding: 18, borderRadius: 14, backgroundColor: C.accent, alignItems: 'center' }}>
          <Text style={{ color: C.encre, fontSize: 18, fontWeight: '800' }}>Quitter</Text>
        </Pressable>
      </View>
    </View>
  );
}

function Gros({ k, v }: { k: string; v: string }) {
  return (
    <View style={{ alignItems: 'center' }}>
      <Text style={{ color: '#A9B4BF' }}>{k}</Text>
      <Text style={{ color: '#fff', fontSize: 24, fontWeight: '800' }}>{v}</Text>
    </View>
  );
}
