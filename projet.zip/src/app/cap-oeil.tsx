/** Direction à l'œil (É11) : le haut du téléphone pointé vers le frelon qui s'éloigne ; la direction rejoint la fusion du tag. */
import { useKeepAwake } from 'expo-keep-awake';
import React, { useEffect } from 'react';
import { Alert, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import Svg, { Circle, G, Line, Path, Text as T } from 'react-native-svg';
import { Bouton, Carte, ChoixTag, EnTete, Titre, s } from '@/ui/composants';
import { C, idTag, police } from '@/ui/theme';
import { ajouterDirectionOeil, appatActifDe, meilleurePosition, useEtat } from '@/store/store';
import { distM, pointCardinal } from '@/calc/geo';
import { suivreBoussole, suivrePosition } from '@/services/position';

const PRECISION = ['mauvaise : faites un 8 avec le téléphone', 'faible : faites un 8 avec le téléphone', 'moyenne', 'bonne'];

export default function CapOeil() {
  useKeepAwake();
  const { width } = useWindowDimensions();
  const e = useEtat((x) => ({ boussole: x.boussole, tagChoisi: x.tagChoisi, tags: x.tags, telephone: x.telephone, toit: x.toit, chrono: x.chrono, connexion: x.connexion, portatif: x.portatif }));
  useEffect(() => { suivrePosition(); let stop = () => {}; suivreBoussole().then((f) => { stop = f; }); return () => stop(); }, []);

  const b = e.boussole;
  const tag = e.tagChoisi;
  const pos = meilleurePosition();
  const tel = e.telephone;
  const appat = tag !== null ? appatActifDe(tag) : null;
  const presVoiture = tel && e.toit && e.toit.lat ? distM(tel.lat, tel.lon, e.toit.lat, e.toit.lon) : null;
  const notees = tag !== null ? (e.tags[tag]?.oeil ?? []).slice().reverse() : [];

  const noter = () => {
    if (tag === null) { Alert.alert('Direction à l\'œil', 'Choisissez d\'abord le tag.'); return; }
    if (!b) { Alert.alert('Direction à l\'œil', 'Boussole du téléphone indisponible.'); return; }
    const p = tel && Date.now() - tel.recuMs < 60000 ? { lat: tel.lat, lon: tel.lon } : pos;
    if (!p) { Alert.alert('Direction à l\'œil', 'Pas de position : activez la localisation du téléphone.'); return; }
    ajouterDirectionOeil(tag, { lat: p.lat, lon: p.lon, deg: Math.round(b.cap), t: Date.now() });
  };

  const taille = Math.min(width - 80, 280), c = taille / 2, r = c - 18;
  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Direction à l'œil" />
      <ChoixTag />
      <Text style={s.discret}>{tag !== null ? `Tag ${idTag(tag)}${appat ? ` · appât ${appat.id}` : ''} · ` : ''}Tenez le téléphone à plat, le haut pointé vers le frelon qui s'éloigne, et appuyez quand il disparaît.</Text>
      <Carte style={{ alignItems: 'center' }}>
        <Svg width={taille} height={taille}>
          <Circle cx={c} cy={c} r={r} fill={C.fond} stroke={C.ligne} strokeWidth={2} />
          {/* la rose tourne : le haut de l'écran = la direction visée */}
          <G transform={`rotate(${-(b?.cap ?? 0)} ${c} ${c})`}>
            {(['N', 'E', 'S', 'O'] as const).map((l, i) => {
              const a = (i * 90 * Math.PI) / 180;
              return <T key={l} x={c + Math.sin(a) * (r - 16)} y={c - Math.cos(a) * (r - 16) + 5} fontSize={15} fontWeight="700" fill={l === 'N' ? C.alerte : C.encre} textAnchor="middle">{l}</T>;
            })}
            {Array.from({ length: 36 }, (_, i) => {
              const a = (i * 10 * Math.PI) / 180, l = i % 9 === 0 ? 10 : 5;
              return <Line key={i} x1={c + Math.sin(a) * r} y1={c - Math.cos(a) * r} x2={c + Math.sin(a) * (r - l)} y2={c - Math.cos(a) * (r - l)} stroke={C.discret} />;
            })}
          </G>
          <Path d={`M${c},${18} L${c + 12},${c - 10} L${c - 12},${c - 10} Z`} fill={C.accent} />
          <Line x1={c} y1={c - 10} x2={c} y2={c + 30} stroke={C.accent} strokeWidth={6} strokeLinecap="round" />
        </Svg>
        <Text style={{ fontSize: 44, fontWeight: '800', color: C.encre }}>{b ? `${Math.round(b.cap)}° ${pointCardinal(b.cap)}` : '—'}</Text>
        <Text style={[s.discret, { color: b && b.precision < 2 ? C.alerte : C.discret }]}>Boussole : {b ? `précision ${PRECISION[Math.max(0, Math.min(3, b.precision))]}` : 'indisponible'}</Text>
        <View style={{ alignSelf: 'stretch', marginTop: 12 }}><Bouton titre="Noter cette direction" plein onPress={noter} desactive={!b || tag === null} /></View>
      </Carte>
      {presVoiture !== null && presVoiture < 5 && <Text style={{ color: C.alerte }}>Vous êtes à moins de 5 m de la voiture : le métal fausse la boussole. Éloignez-vous un peu.</Text>}
      {notees.length > 0 && (
        <Carte>
          <Titre>Déjà notées</Titre>
          {notees.map((o, i) => (
            <View key={i} style={[s.ligne, { paddingVertical: 6, borderTopWidth: i ? 1 : 0, borderTopColor: C.ligne }]}>
              <Text style={{ width: 60, fontWeight: '800', color: C.encre, fontSize: police.normal + 1 }}>{o.deg}°</Text>
              <Text style={s.discret}>{o.t ? new Date(o.t).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : 'simulation'} · ajoutée à la carte</Text>
            </View>
          ))}
        </Carte>
      )}
      <Text style={[s.discret, { fontSize: police.mini }]}>Éloignez-vous d'au moins 5 m de la voiture : le métal fausse la boussole du téléphone.</Text>
    </ScrollView>
  );
}
