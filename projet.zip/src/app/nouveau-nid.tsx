/** Ajouter un nid à la main : à ma position, par coordonnées (décimales, degrés-minutes, DMS, Lambert 93, lien Google
 *  Maps / OpenStreetMap / geo:), par adresse (Base Adresse Nationale, Géoplateforme IGN) ou en le pointant sur la carte.
 *  Date de découverte (pour les nids d'une autre saison), état, support, hauteur, signalé par, note. */
import { useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, Champ, EnTete, Puces, Titre, s, useMaintenant } from '@/ui/composants';
import { C, fmtCoord, police } from '@/ui/theme';
import { meilleurePosition, useEtat } from '@/store/store';
import { majNid, nouveauNid } from '@/services/carnet';
import { suivrePosition } from '@/services/position';
import { lireCoordonnees, lireDate } from '@/calc/coordonnees';
import { distM } from '@/calc/geo';
import type { EtatNid } from '@/db';

type Mode = 'ici' | 'coord' | 'adresse' | 'carte';
type Adresse = { label: string; lat: number; lon: number; type: string };

async function chercherAdresse(q: string): Promise<Adresse[]> {
  const r = await fetch(`https://data.geopf.fr/geocodage/search?q=${encodeURIComponent(q)}&limit=6`);
  if (!r.ok) throw new Error(`service d'adresses indisponible (${r.status})`);
  const j = await r.json() as { features?: { geometry: { coordinates: [number, number] }; properties: { label: string; type: string } }[] };
  return (j.features ?? []).map((f) => ({ label: f.properties.label, type: f.properties.type, lon: f.geometry.coordinates[0], lat: f.geometry.coordinates[1] }));
}
const horloge = () => Date.now();
const PRECISION_ADRESSE: Record<string, number> = { housenumber: 30, street: 150, locality: 300, municipality: 1500 };

export default function NouveauNid() {
  const router = useRouter();
  const tel = useEtat((x) => x.telephone);
  const [mode, setMode] = useState<Mode>('ici');
  const [coord, setCoord] = useState('');
  const [q, setQ] = useState('');
  const [res, setRes] = useState<Adresse[]>([]);
  const [adr, setAdr] = useState<Adresse | null>(null);
  const [cherche, setCherche] = useState('');
  const [quand, setQuand] = useState<'auj' | 'date'>('auj');
  const [date, setDate] = useState('');
  const [etat, setEtat] = useState<EtatNid>('trouve');
  const [support, setSupport] = useState('');
  const [hauteur, setHauteur] = useState('');
  const [signale, setSignale] = useState('');
  const [note, setNote] = useState('');
  useEffect(() => { suivrePosition(); }, []);
  const maintenant = useMaintenant(60000);

  const lu = mode === 'coord' ? lireCoordonnees(coord) : null;
  const ici = meilleurePosition();
  const pos: { lat: number; lon: number; err: number; src: string } | null =
    mode === 'ici' ? (ici ? { lat: ici.lat, lon: ici.lon, err: Math.max(5, Math.round(tel?.precision ?? 10)), src: 'noté à la main, à ma position' } : null)
      : mode === 'coord' ? (lu ? { lat: lu.lat, lon: lu.lon, err: 10, src: `noté à la main, coordonnées (${lu.format})` } : null)
        : mode === 'adresse' ? (adr ? { lat: adr.lat, lon: adr.lon, err: PRECISION_ADRESSE[adr.type] ?? 100, src: `noté à la main, adresse : ${adr.label}` } : null)
          : null;
  const t = quand === 'auj' ? maintenant : lireDate(date, maintenant);

  const chercher = async () => {
    if (q.trim().length < 3) return;
    setCherche('Recherche…'); setAdr(null);
    try { const l = await chercherAdresse(q.trim()); setRes(l); setCherche(l.length ? '' : 'Aucune adresse trouvée.'); }
    catch (e) { setRes([]); setCherche(`${(e as Error).message} : saisissez plutôt des coordonnées.`); }
  };

  const enregistrer = () => {
    if (!pos || t === null) return;
    const tNid = quand === 'auj' ? horloge() : t;
    const sources = signale.trim() ? `${pos.src} · signalé par ${signale.trim()}` : pos.src;
    const id = nouveauNid(-1, pos.lat, pos.lon, pos.err, sources, tNid);
    if (!id) { Alert.alert('Nid', 'Enregistrement impossible.'); return; }
    majNid(id, {
      etat, ...(support.trim() ? { support: support.trim() } : {}), ...(hauteur.trim() ? { hauteur: hauteur.trim() } : {}), ...(note.trim() ? { note: note.trim() } : {}),
      ...(etat === 'traite' ? { traite_ms: tNid } : {}), ...(etat === 'mort' ? { traite_ms: tNid, verifie_ms: tNid } : {}),
    });
    router.replace({ pathname: '/nid/[id]', params: { id: String(id) } });
  };

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre="Ajouter un nid" />
      <Carte>
        <Titre>Où ?</Titre>
        <Puces options={[['ici', 'Ma position'], ['coord', 'Coordonnées'], ['adresse', 'Adresse'], ['carte', 'Sur la carte']]} valeur={mode} onChange={setMode} />
        {mode === 'ici' && (
          <Text style={[s.discret, { marginTop: 8 }]}>
            {ici ? `${fmtCoord(ici.lat, ici.lon)} · ± ${Math.round(tel?.precision ?? 10)} m. Placez-vous au pied de l'arbre ou sous le nid.` : 'En attente de la position GPS…'}
          </Text>
        )}
        {mode === 'coord' && (
          <>
            <Champ titre="Coordonnées ou lien" valeur={coord} onChange={setCoord} placeholder="45.0434, 3.8855 · N 45°02.604 E 3°53.130 · lien Google Maps" genre="url" />
            <Text style={[s.discret, { fontSize: police.mini, color: coord && !lu ? C.alerte : C.discret }]}>
              {!coord ? 'Degrés décimaux (point ou virgule), degrés-minutes, degrés-minutes-secondes, Lambert 93 (X Y), ou un lien Google Maps, OpenStreetMap, geo: collé tel quel.'
                : lu ? `Lu (${lu.format}) : ${fmtCoord(lu.lat, lu.lon)}${ici ? ` · à ${Math.round(distM(ici.lat, ici.lon, lu.lat, lu.lon))} m de vous` : ''}` : 'Format non reconnu.'}
            </Text>
          </>
        )}
        {mode === 'adresse' && (
          <>
            <View style={[s.ligne, { gap: 8, alignItems: 'flex-end' }]}>
              <View style={{ flex: 1 }}><Champ titre="Adresse ou lieu-dit" valeur={q} onChange={setQ} placeholder="12 route de Vals, Le Puy-en-Velay" /></View>
              <View style={{ paddingBottom: 6 }}><Bouton titre="Chercher" onPress={() => { chercher().catch(() => {}); }} /></View>
            </View>
            {!!cherche && <Text style={s.discret}>{cherche}</Text>}
            {res.map((r) => (
              <Pressable key={`${r.label}${r.lat}`} onPress={() => setAdr(r)} style={{ paddingVertical: 8, borderTopWidth: 1, borderTopColor: C.ligne }}>
                <Text style={{ color: C.encre, fontWeight: adr === r ? '800' : '400' }}>{adr === r ? '● ' : ''}{r.label}</Text>
              </Pressable>
            ))}
            <Text style={[s.discret, { fontSize: police.mini }]}>Une adresse place le nid devant la maison (± 30 m) : corrigez ensuite sur place ou au viseur.</Text>
          </>
        )}
        {mode === 'carte' && (
          <View style={{ gap: 8, marginTop: 8 }}>
            <Text style={s.discret}>Sur la carte, un appui long à l'endroit du nid → « Nid trouvé ici » : la fiche s'ouvre, complétez-la (date, état…).</Text>
            <Bouton titre="Ouvrir la carte" onPress={() => router.navigate('/carte')} />
          </View>
        )}
      </Carte>
      {mode !== 'carte' && (
        <>
          <Carte>
            <Titre>Quand ?</Titre>
            <Puces options={[['auj', "Aujourd'hui"], ['date', 'Autre date']]} valeur={quand} onChange={setQuand} />
            {quand === 'date' && (
              <>
                <Champ titre="Date de découverte (JJ/MM/AAAA)" valeur={date} onChange={setDate} placeholder="12/09/2025" clavier="numeric" />
                {!!date && t === null && <Text style={[s.discret, { color: C.alerte }]}>Date non valable.</Text>}
              </>
            )}
            <Titre>État</Titre>
            <Puces options={[['trouve', 'À traiter'], ['traite', 'Traité'], ['mort', 'Mort (vérifié)']]} valeur={etat} onChange={setEtat} />
          </Carte>
          <Carte>
            <Titre>Détails (facultatif)</Titre>
            <View style={[s.ligne, { gap: 10 }]}>
              <View style={{ flex: 1 }}><Champ titre="Support" valeur={support} onChange={setSupport} placeholder="chêne, haie, toit…" /></View>
              <View style={{ flex: 1 }}><Champ titre="Hauteur" valeur={hauteur} onChange={setHauteur} placeholder="12 m" /></View>
            </View>
            <Champ titre="Signalé par" valeur={signale} onChange={setSignale} placeholder="voisin, mairie, plateforme de signalement…" />
            <Champ titre="Note" valeur={note} onChange={setNote} multiligne />
          </Carte>
          <Bouton titre="Ajouter au carnet" plein desactive={!pos || t === null} onPress={enregistrer} />
          {!pos && <Text style={[s.discret, { textAlign: 'center' }]}>{mode === 'adresse' ? 'Choisissez une adresse dans la liste.' : mode === 'coord' ? 'Saisissez des coordonnées lisibles.' : 'Position en attente.'}</Text>}
        </>
      )}
    </ScrollView>
  );
}
