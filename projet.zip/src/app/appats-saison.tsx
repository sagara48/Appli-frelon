/** Où poser les appâts l'an prochain : nids des saisons passées et ruchers → emplacements proposés (calc/appatsSaison). */
import React, { useMemo } from 'react';
import { Linking, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import Svg, { Circle, Rect, Text as T } from 'react-native-svg';
import { Bouton, Carte, EnTete, Titre, Vide, s, useMaintenant } from '@/ui/composants';
import { C, fmtCoord, police } from '@/ui/theme';
import { useEtat } from '@/store/store';
import { KY, kxOf } from '@/calc/geo';
import { emplacementsAppats } from '@/calc/appatsSaison';
import { envoyerCible } from '@/services/cible';

export default function AppatsSaison() {
  const { width } = useWindowDimensions();
  const nids = useEtat((x) => x.nids), ruchers = useEtat((x) => x.ruchers);
  const now = useMaintenant(3600000);
  const l = useMemo(() => emplacementsAppats(nids, ruchers, now), [nids, ruchers, now]);
  const an = new Date(now).getFullYear();
  const W = width - 32, H = Math.round(W * 0.9);
  const pts = [...nids, ...ruchers, ...l].filter((p) => p.lat && p.lon);
  const vue = (() => {
    if (!pts.length) return null;
    let la1 = 1e9, la2 = -1e9, lo1 = 1e9, lo2 = -1e9;
    for (const p of pts) { la1 = Math.min(la1, p.lat); la2 = Math.max(la2, p.lat); lo1 = Math.min(lo1, p.lon); lo2 = Math.max(lo2, p.lon); }
    const cLat = (la1 + la2) / 2, cLon = (lo1 + lo2) / 2, kx = kxOf(cLat);
    const m = Math.max(((la2 - la1) * KY) / (H - 40), ((lo2 - lo1) * kx) / (W - 40), 2);
    return { X: (lon: number) => W / 2 + ((lon - cLon) * kx) / m, Y: (lat: number) => H / 2 - ((lat - cLat) * KY) / m };
  })();

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Appâts de la saison prochaine" />
      <Text style={s.discret}>
        Les fondatrices s'installent souvent à un ou deux kilomètres du nid d'où elles sont sorties, et les ouvrières chassent devant les ruchers.
        Les endroits proposés cumulent les nids des saisons passées (la dernière compte double) et les ruchers proches, d'autant plus qu'ils ont subi de la pression.
        Une aide pour choisir : la carte de densité et votre connaissance du terrain restent juges.
      </Text>
      {!l.length ? (
        <Carte><Vide titre="Pas encore assez de nids" texte="Notez les nids trouvés dans le carnet : les propositions apparaissent dès le premier." /></Carte>
      ) : (
        <>
          {vue && (
            <View style={{ borderRadius: 14, overflow: 'hidden', borderWidth: 1, borderColor: C.ligne, backgroundColor: '#EEF0E8' }}>
              <Svg width={W} height={H}>
                {ruchers.filter((r) => r.lat).map((r) => <Rect key={`r${r.id}`} x={vue.X(r.lon) - 6} y={vue.Y(r.lat) - 6} width={12} height={12} fill={C.ok} stroke="#fff" strokeWidth={1.5} />)}
                {nids.filter((n) => n.lat).map((n) => {
                  const recent = new Date(n.t).getFullYear() >= an;
                  return <Circle key={`n${n.id}`} cx={vue.X(n.lon)} cy={vue.Y(n.lat)} r={recent ? 5 : 4} fill={recent ? C.alerte : '#E0A06A'} opacity={recent ? 0.9 : 0.6} />;
                })}
                {l.map((p, i) => (
                  <React.Fragment key={`p${i}`}>
                    <Circle cx={vue.X(p.lon)} cy={vue.Y(p.lat)} r={13} fill={C.accent} stroke={C.encre} strokeWidth={2} />
                    <T x={vue.X(p.lon)} y={vue.Y(p.lat) + 5} fontSize={13} fontWeight="800" fill={C.encre} textAnchor="middle">{i + 1}</T>
                  </React.Fragment>
                ))}
              </Svg>
            </View>
          )}
          <Text style={[s.discret, { fontSize: police.mini }]}>Rouge : nids de {an} · orange pâle : années d'avant · carrés verts : ruchers · jaune : appâts proposés</Text>
          {l.map((p, i) => (
            <Carte key={i}>
              <View style={[s.ligne, { justifyContent: 'space-between' }]}>
                <Titre>{`Emplacement ${i + 1}`}</Titre>
                <Text style={s.discret}>intérêt {p.score} %</Text>
              </View>
              <Text style={{ color: C.encre }}>{p.raison || 'zone de passage probable'}</Text>
              <Text style={[s.discret, { marginTop: 4 }]}>{fmtCoord(p.lat, p.lon)}</Text>
              <View style={[s.ligne, { gap: 10, marginTop: 10 }]}>
                <Bouton titre="Y aller" onPress={() => Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${p.lat.toFixed(6)},${p.lon.toFixed(6)}`).catch(() => {})} />
                <Bouton titre="Flèche du portatif" onPress={() => { envoyerCible(p.lat, p.lon, `APPAT ${i + 1}`).catch(() => {}); }} />
              </View>
            </Carte>
          ))}
          <Text style={[s.discret, { fontSize: police.mini }]}>Au printemps, ces endroits conviennent aussi aux pièges à fondatrices (Menu → Pièges de printemps).</Text>
        </>
      )}
    </ScrollView>
  );
}
