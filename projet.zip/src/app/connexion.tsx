/** Écran de connexion : compte de l'équipe (e-mail et mot de passe). Facultatif : « Continuer sans compte » ouvre l'appli
 *  normalement ; le compte ne sert qu'au partage entre téléphones. */
import { useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, Champ, Puces, Titre, s } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { creerCompte, enregistrerServeur, lireServeur, motDePasseOublie, seConnecter, serveurComplet } from '@/services/auth';
import { lireConfig } from '@/services/partage';
import { changerParametres, param } from '@/services/parametres';
import { ecrireValeur } from '@/db';
import { store } from '@/store/store';

export default function Connexion() {
  const router = useRouter();
  const [mode, setMode] = useState<'connexion' | 'creation'>('connexion');
  const [email, setEmail] = useState('');
  const [mdp, setMdp] = useState('');
  const [mdp2, setMdp2] = useState('');
  const [nom, setNom] = useState(param().nom);
  const [serveur, setServeur] = useState(lireServeur);
  const [voirServeur, setVoirServeur] = useState(!serveurComplet(lireServeur()));
  const [occupe, setOccupe] = useState(false);
  const [message, setMessage] = useState<{ texte: string; ok: boolean } | null>(null);
  // le bandeau d'information masquerait le haut de l'écran
  useEffect(() => { store.set({ bandeau: null }); }, []);

  const sortir = () => { ecrireValeur('connexionProposee', true); if (router.canGoBack()) router.back(); else router.replace('/'); };
  const avant = () => {
    if (!serveurComplet(serveur)) { setVoirServeur(true); setMessage({ texte: 'Indiquez d\'abord l\'adresse et la clé du serveur de l\'équipe.', ok: false }); return false; }
    enregistrerServeur(serveur);
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) { setMessage({ texte: 'Adresse e-mail invalide.', ok: false }); return false; }
    return true;
  };
  const apres = () => {
    ecrireValeur('connexionProposee', true);
    // sans équipe : on va la créer ou la rejoindre
    if (!lireConfig().equipe) router.replace('/partage'); else sortir();
  };
  const connecter = async () => {
    if (!avant()) return;
    if (!mdp) { setMessage({ texte: 'Mot de passe manquant.', ok: false }); return; }
    setOccupe(true); setMessage(null);
    try {
      const se = await seConnecter(email, mdp);
      if (!param().nom && se.utilisateur.nom) changerParametres({ nom: se.utilisateur.nom });
      apres();
    } catch (e) { setMessage({ texte: (e as Error).message, ok: false }); } finally { setOccupe(false); }
  };
  const creer = async () => {
    if (!avant()) return;
    if (!nom.trim()) { setMessage({ texte: 'Indiquez votre nom (affiché sur vos fiches).', ok: false }); return; }
    if (mdp.length < 6) { setMessage({ texte: 'Mot de passe : 6 caractères au moins.', ok: false }); return; }
    if (mdp !== mdp2) { setMessage({ texte: 'Les deux mots de passe sont différents.', ok: false }); return; }
    setOccupe(true); setMessage(null);
    try {
      changerParametres({ nom: nom.trim() });
      const se = await creerCompte(email, mdp, nom);
      if (se) apres();
      else { setMode('connexion'); setMdp2(''); setMessage({ texte: `Compte créé. Ouvrez le lien de confirmation envoyé à ${email.trim()}, puis connectez-vous ici.`, ok: true }); }
    } catch (e) { setMessage({ texte: (e as Error).message, ok: false }); } finally { setOccupe(false); }
  };
  const oublie = async () => {
    if (!avant()) return;
    setOccupe(true);
    try { await motDePasseOublie(email); setMessage({ texte: `Si un compte existe pour ${email.trim()}, un e-mail de réinitialisation vient d'être envoyé.`, ok: true }); }
    catch (e) { setMessage({ texte: (e as Error).message, ok: false }); } finally { setOccupe(false); }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView style={s.ecran} contentContainerStyle={[s.contenu, { paddingTop: 48 }]} keyboardShouldPersistTaps="handled">
        <Text style={{ color: C.encre, fontSize: 30, fontWeight: '800' }}>Frelons</Text>
        <Text style={[s.discret, { marginBottom: 6 }]}>Compte de l'équipe : vos nids, ruchers et pièges partagés avec les autres téléphones. L'appli marche aussi sans compte.</Text>

        <Carte>
          <Puces options={[['connexion', 'Se connecter'], ['creation', 'Créer un compte']]} valeur={mode} onChange={(v) => { setMode(v as typeof mode); setMessage(null); }} />
          {mode === 'creation' && <Champ titre="Votre nom (affiché sur vos fiches)" valeur={nom} onChange={setNom} placeholder="Nicolas" />}
          <Champ titre="E-mail" valeur={email} onChange={setEmail} genre="email" placeholder="vous@exemple.fr" />
          <Champ titre="Mot de passe" valeur={mdp} onChange={setMdp} genre="motDePasse" />
          {mode === 'creation' && <Champ titre="Mot de passe (encore)" valeur={mdp2} onChange={setMdp2} genre="motDePasse" />}
          {message && <Text style={{ color: message.ok ? C.ok : C.alerte, marginVertical: 6, fontWeight: '600' }}>{message.texte}</Text>}
          {occupe ? <ActivityIndicator color={C.encre} style={{ marginVertical: 12 }} />
            : <Bouton titre={mode === 'connexion' ? 'Se connecter' : 'Créer le compte'} plein onPress={mode === 'connexion' ? connecter : creer} />}
          {mode === 'connexion' && !occupe && (
            <Pressable onPress={oublie} style={{ alignSelf: 'center', marginTop: 10 }}>
              <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Mot de passe oublié ?</Text>
            </Pressable>
          )}
        </Carte>

        <Carte>
          <Pressable onPress={() => setVoirServeur(!voirServeur)} style={[s.ligne, { justifyContent: 'space-between' }]}>
            <Titre>Serveur de l'équipe</Titre>
            <Text style={s.discret}>{serveurComplet(serveur) ? 'réglé ' : 'à régler '}{voirServeur ? '▲' : '▼'}</Text>
          </Pressable>
          {voirServeur && (
            <View>
              <Text style={[s.discret, { marginBottom: 4 }]}>Donnés par le responsable de l'équipe (projet Supabase → Project Settings → API).</Text>
              <Champ titre="Adresse du projet" valeur={serveur.url} onChange={(v) => setServeur({ ...serveur, url: v })} genre="url" placeholder="https://xxxx.supabase.co" />
              <Champ titre="Clé publique (anon public)" valeur={serveur.cle} onChange={(v) => setServeur({ ...serveur, cle: v })} genre="url" placeholder="eyJhbGciOi…" />
            </View>
          )}
        </Carte>

        <Pressable onPress={() => {
          if (!serveurComplet(lireServeur()) && serveurComplet(serveur)) enregistrerServeur(serveur);
          sortir();
        }} style={{ alignSelf: 'center', padding: 12 }}>
          <Text style={{ color: C.encre, fontWeight: '700', textDecorationLine: 'underline', fontSize: police.normal }}>Continuer sans compte</Text>
        </Pressable>
        <Text style={[s.discret, { fontSize: police.mini, textAlign: 'center' }]}>Vous pourrez vous connecter plus tard : Réglages → Partage entre téléphones.</Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

