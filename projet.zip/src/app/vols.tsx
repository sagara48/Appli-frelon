/** Vols du drone : le téléphone se connecte au dos de l'écran de la voiture et enregistre chaque vol
 *  (trace, hauteur, niveaux des tags, trames rattrapées après une coupure). Carte, export GPX / CSV. */
import { useRouter } from 'expo-router';
import React from 'react';
import { Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, EnTete, Titre, Vide, s } from '@/ui/composants';
import { C, idTag, police } from '@/ui/theme';
import { nid3DDe, tourAnalyse, choisirVol, connecterDrone, deconnecterDrone, NOM_SOL, supprimerVol, terminerVol, useVols, volSimule } from '@/services/vols';
import { resumeVol, volCsv, volGpx, type Vol } from '@/calc/vol';
import { partager } from '@/services/exports';
import { store, useEtat } from '@/store/store';
import { distM } from '@/calc/geo';
import { numeroNid } from '@/services/carnet';
import { useModeExpert } from '@/services/expert';
import type { Nid } from '@/db';
import { usePlansPrets } from '@/services/plansPrets';

const quand = (t: number) => new Date(t).toLocaleString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const nomFichier = (v: Vol, ext: string) => `vol_drone_${new Date(v.debut).toISOString().slice(0, 16).replace(/[-:T]/g, '')}.${ext}`;

function LigneVol({ v, live, nids, voir, exporter }: { v: Vol; live?: boolean; nids: Nid[]; voir: (v: Vol, tag: number | null) => void; exporter: (v: Vol) => void }) {
    const r = resumeVol(v);
    return (
      <Carte>
        <View style={[s.ligne, { justifyContent: 'space-between' }]}>
          <Text style={{ color: C.encre, fontWeight: '800', fontSize: police.normal + 1 }}>{live ? 'Vol en cours' : quand(v.debut)}</Text>
          <Text style={s.discret}>{r.dureeMin} min · {r.hMax} m</Text>
        </View>
        <Text style={[s.discret, { marginTop: 4 }]}>{v.points.length} points{v.rattrapees ? ` · ${v.rattrapees} trames rattrapées après coupure` : ''}</Text>
        {!r.tags.length && <Text style={[s.discret, { marginTop: 4 }]}>Aucun tag entendu.</Text>}
        {r.tags.map((t) => {
          const nid = nids.find((n) => n.tag === t.id && distM(n.lat, n.lon, t.lat, t.lon) < 500);
          return (
            <Pressable key={t.id} onPress={() => voir(v, t.id)} style={[s.ligne, { justifyContent: 'space-between', marginTop: 6 }]}>
              <Text style={{ color: C.encre }}>Tag <Text style={{ fontWeight: '800' }}>{idTag(t.id)}</Text> · max {t.max} dBm à {Math.round(t.h)} m{nid ? ` · nid n° ${numeroNid(nids, nid.id)}` : ''}</Text>
              <Text style={{ color: C.encre, textDecorationLine: 'underline' }}>Carte</Text>
            </Pressable>
          );
        })}
        {!live && r.tags.map((t) => {
          const e3 = nid3DDe(v, t.id), tr = tourAnalyse(v, t.id);
          if (!e3 && !tr.stations.length) return null;
          return (
            <View key={`3d${t.id}`}>
              {!!e3 && <Text style={[s.discret, { marginTop: 2 }]}>
                Nid du tag {idTag(t.id)} d'après tout le vol : à ± {e3.errM} m, hauteur ~{e3.hauteurM} m au-dessus du décollage (entre {e3.hauteurMin} et {e3.hauteurMax} m)
              </Text>}
              {tr.stations.length > 0 && <Text style={[s.discret, { marginTop: 2 }]}>
                Tour sur place, tag {idTag(t.id)} : {tr.stations.map((x) => `cap ${x.cap}° (${x.contrasteDb} dB)`).join(' · ')}{tr.nid ? ` → nid à ± ${tr.nid.errM} m` : tr.stations.filter((x) => x.contrasteDb >= 4).length < 2 ? ' → pas assez de stations nettes (4 dB d\'écart au moins)' : ' → caps qui ne se croisent pas'}
              </Text>}
            </View>
          );
        })}
        {!live && (
          <View style={[s.ligne, { gap: 10, marginTop: 10 }]}>
            <Bouton titre="Exporter" onPress={() => exporter(v)} />
            <Pressable onPress={() => Alert.alert('Supprimer', 'Supprimer ce vol ?', [{ text: 'Annuler', style: 'cancel' }, { text: 'Supprimer', style: 'destructive', onPress: () => supprimerVol(v.id) }])} style={{ alignSelf: 'center' }}>
              <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Supprimer</Text>
            </Pressable>
          </View>
        )}
      </Carte>
    );
  }

export default function Vols() {
  const router = useRouter();
  const V = useVols();
  const nids = useEtat((e) => e.nids);
  const expert = useModeExpert();
  const voir = (v: Vol, tag: number | null) => { choisirVol(v.id); if (tag !== null) store.choisirTag(tag); router.navigate('/carte'); };
  const exporter = (v: Vol) => Alert.alert('Exporter le vol', 'Format du fichier', [
    { text: 'GPX (cartes, Google Earth)', onPress: () => partager(nomFichier(v, 'gpx'), volGpx(v), 'application/gpx+xml').catch(() => {}) },
    { text: 'CSV (tableur)', onPress: () => partager(nomFichier(v, 'csv'), volCsv(v), 'text/csv').catch(() => {}) },
    { text: 'Annuler', style: 'cancel' },
  ]);
  const connecte = V.connexion === 'connecte';
  const enCours = V.enCours ? resumeVol(V.enCours) : null;

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Vols du drone" />
      <PlansPrets />
      <Carte>
        <Titre>Dos de l'écran de la voiture</Titre>
        <Text style={s.discret}>
          {connecte ? `Connecté à ${NOM_SOL} : chaque vol est enregistré automatiquement (fin du vol après 2 min sans trame).`
            : `Le téléphone se connecte au dos de l'écran (${NOM_SOL}) en même temps que l'écran, et enregistre les vols : trace, hauteur, niveau des tags.`}
        </Text>
        {!!V.message && !connecte && <Text style={[s.discret, { marginTop: 6 }]}>{V.message}</Text>}
        <View style={[s.ligne, { gap: 10, marginTop: 10, flexWrap: 'wrap' }]}>
          {connecte ? <Bouton titre="Déconnecter" onPress={() => deconnecterDrone()} />
            : <Bouton titre={V.connexion === 'recherche' ? 'Recherche…' : 'Connecter'} plein desactive={V.connexion === 'recherche'} onPress={() => connecterDrone()} />}
          {V.enCours && <Bouton titre="Terminer le vol" onPress={terminerVol} />}
          {(expert || !V.vols.length) && <Bouton titre="Essayer avec un vol simulé" onPress={volSimule} />}
        </View>
      </Carte>
      {V.enCours && enCours && <LigneVol v={V.enCours} live nids={nids} voir={voir} exporter={exporter} />}
      {!V.vols.length && !V.enCours && <Carte><Vide titre="Aucun vol enregistré" texte="Connectez le dos de l'écran avant de décoller : le vol s'enregistre tout seul." /></Carte>}
      {V.vols.map((v) => <LigneVol key={v.id} v={v} nids={nids} voir={voir} exporter={exporter} />)}
    </ScrollView>
  );
}

/** Plans de vol préparés d'avance (nid estimé à ± 30 m ou mieux). */
function PlansPrets() {
  const router = useRouter();
  const plans = Object.values(usePlansPrets()).sort((a, b) => b.t - a.t);
  if (!plans.length) return null;
  return (
    <Carte style={{ borderColor: C.ok, borderWidth: 2 }}>
      <Titre>Plans prêts</Titre>
      {plans.map((p) => (
        <View key={p.tag} style={{ paddingVertical: 8, borderTopWidth: 1, borderTopColor: C.ligne }}>
          <Text style={{ color: C.encre, fontWeight: '700' }}>Tag {idTag(p.tag)} · nid à ± {p.errM} m</Text>
          <Text style={[s.discret, { fontSize: police.mini }]}>Spirale de {p.rayonM} m, {p.points} points, environ {Math.ceil(p.dureeMin)} min de vol</Text>
          <View style={[s.ligne, { gap: 8, marginTop: 6 }]}>
            <Bouton titre="Mission Litchi" plein onPress={() => partager(`vol_tag_${p.tag}_spirale.csv`, p.csv, 'text/csv').catch(() => {})} />
            <Bouton titre="Voir / modifier" onPress={() => router.push({ pathname: '/plan-vol', params: { lat: String(p.lat), lon: String(p.lon), err: String(p.errBrutM), titre: `Tag ${idTag(p.tag)}` } })} />
          </View>
        </View>
      ))}
    </Carte>
  );
}
