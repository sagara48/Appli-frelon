/** Viseur : hauteur du nid par visée au téléphone (calc/viseur.ts). Le réticule sur le nid, « Viser » : position,
 *  direction et hausse sont notées et une photo est jointe à la fiche. Deux visées d'endroits écartés donnent la
 *  hauteur sans rien connaître d'autre ; sinon la position du nid de la fiche, ou une distance mesurée au pied. */
import { useLocalSearchParams, useRouter } from 'expo-router';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { DeviceMotion, Magnetometer } from 'expo-sensors';
import { Directory, File, Paths } from 'expo-file-system';
import React, { useEffect, useRef, useState } from 'react';
import { Alert, Platform, ScrollView, Text, TextInput, View } from 'react-native';
import { Bouton, Carte, EnTete, Titre, s } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { meilleurePosition, store, useEtat } from '@/store/store';
import { suivrePosition } from '@/services/position';
import { majNid } from '@/services/carnet';
import { pointCardinal } from '@/calc/geo';
import { ecartAvecNid, hauteurNid, orientationCamera, type V3, type Visee } from '@/calc/viseur';

export default function Viseur() {
  const router = useRouter();
  const { nid: idNid } = useLocalSearchParams<{ nid?: string }>();
  const n = useEtat((x) => x.nids.find((v) => String(v.id) === idNid) ?? null);
  const [perm, demander] = useCameraPermissions();
  const cam = useRef<CameraView>(null);
  const g = useRef<V3 | null>(null), m = useRef<V3 | null>(null);
  const [o, setO] = useState<{ hausse: number; cap: number } | null>(null);
  const [visees, setVisees] = useState<Visee[]>([]);
  const [dist, setDist] = useState('');
  const [occupe, setOccupe] = useState(false);

  useEffect(() => {
    if (Platform.OS === 'web') return;
    suivrePosition();
    DeviceMotion.setUpdateInterval(100); Magnetometer.setUpdateInterval(100);
    const lisse = (a: V3 | null, b: V3, k: number): V3 => (a ? { x: a.x + k * (b.x - a.x), y: a.y + k * (b.y - a.y), z: a.z + k * (b.z - a.z) } : b);
    const s1 = DeviceMotion.addListener((d) => { if (d.accelerationIncludingGravity) g.current = lisse(g.current, d.accelerationIncludingGravity, 0.25); });
    const s2 = Magnetometer.addListener((v) => { m.current = lisse(m.current, v, 0.25); });
    const t = setInterval(() => { if (g.current && m.current) setO(orientationCamera(g.current, m.current)); }, 150);
    return () => { s1.remove(); s2.remove(); clearInterval(t); };
  }, []);

  if (Platform.OS === 'web') return <View style={s.ecran}><EnTete titre="Hauteur du nid" /><Text style={[s.discret, { padding: 16 }]}>Le viseur demande l'appli Android (appareil photo, boussole, accéléromètre).</Text></View>;
  if (!n) return <View style={s.ecran}><EnTete titre="Hauteur du nid" /><Text style={[s.discret, { padding: 16 }]}>Nid introuvable.</Text></View>;

  const viser = async () => {
    const p = meilleurePosition();
    if (!p) { Alert.alert('Viseur', 'Pas de position GPS : attendez quelques secondes à découvert.'); return; }
    if (!o) return;
    setOccupe(true);
    const v: Visee = { lat: p.lat, lon: p.lon, cap: o.cap, hausse: o.hausse, precision: store.get().telephone?.precision ?? 5, t: Date.now() };
    try {
      const ph = await cam.current?.takePictureAsync({ quality: 0.6 });
      if (ph?.uri) {
        const dir = new Directory(Paths.document, 'photos');
        if (!dir.exists) dir.create({ intermediates: true });
        const dest = new File(dir, `nid${n.id}_${Date.now()}.jpg`);
        new File(ph.uri).copySync(dest);
        v.photo = dest.uri;
        majNid(n.id, { photos: [...n.photos, dest.uri] });
      }
    } catch { /* la visée compte même sans photo */ }
    setVisees((l) => [...l, v]);
    setOccupe(false);
  };

  const d = parseFloat(dist.replace(',', '.'));
  const h = hauteurNid(visees, { lat: n.lat, lon: n.lon, err: n.err || 10 }, Number.isFinite(d) && d > 0 ? d : null);
  const derniere = visees[visees.length - 1];
  const ecart = derniere ? ecartAvecNid(derniere, n) : null;

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre="Hauteur du nid" />
      {!perm?.granted ? (
        <Carte><Text style={{ color: C.encre }}>Le viseur utilise l'appareil photo.</Text><View style={{ marginTop: 10 }}><Bouton titre="Autoriser l'appareil photo" plein onPress={() => { demander().catch(() => {}); }} /></View></Carte>
      ) : (
        <View style={{ height: 380, borderRadius: 14, overflow: 'hidden', backgroundColor: '#000' }}>
          <CameraView ref={cam} style={{ flex: 1 }} facing="back" />
          <View pointerEvents="none" style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' }}>
            <View style={{ width: 70, height: 70, borderRadius: 35, borderWidth: 2, borderColor: '#F2C230' }} />
            <View style={{ position: 'absolute', width: 2, height: 110, backgroundColor: '#F2C230' }} />
            <View style={{ position: 'absolute', width: 110, height: 2, backgroundColor: '#F2C230' }} />
          </View>
          <View pointerEvents="none" style={{ position: 'absolute', left: 10, top: 10, backgroundColor: '#000a', borderRadius: 8, padding: 8 }}>
            <Text style={{ color: '#fff', fontWeight: '800', fontSize: police.normal + 2 }}>{o ? `hausse ${Math.round(o.hausse)}°` : '…'}</Text>
            <Text style={{ color: '#fff' }}>{o ? `cap ${Math.round(o.cap)}° ${pointCardinal(o.cap)}` : ''}</Text>
          </View>
        </View>
      )}
      <Bouton titre={occupe ? 'Visée…' : `Viser le nid (${visees.length + 1}${visees.length ? '' : 're'} visée)`} plein desactive={!perm?.granted || !o || occupe} onPress={() => { viser().catch(() => setOccupe(false)); }} />
      <Text style={s.discret}>
        Téléphone tenu à hauteur des yeux, le réticule sur le nid, tenez immobile une seconde puis « Viser ». Puis éloignez-vous sur le côté
        (au moins 15 à 20 m, en tournant autour de l'arbre) et visez de nouveau : les deux directions se croisent au pied du nid.
        Pour plus de précision, comptez vos pas jusqu'au pied de l'arbre et notez la distance.
      </Text>
      {ecart !== null && ecart > 25 && <Text style={{ color: C.alerte }}>La dernière visée part à {Math.round(ecart)}° de la position du nid de la fiche : bon arbre ? (ou boussole perturbée par du métal)</Text>}
      <Carte>
        <Titre>Résultat</Titre>
        {h ? (
          <>
            <Text style={{ color: C.encre, fontSize: police.normal + 6, fontWeight: '800' }}>{h.hauteurM.toFixed(1).replace('.', ',')} m</Text>
            <Text style={s.discret}>entre {h.minM.toFixed(1).replace('.', ',')} et {h.maxM.toFixed(1).replace('.', ',')} m · {h.methode}</Text>
            {h.detail.map((x, i) => <Text key={i} style={[s.discret, { fontSize: police.mini }]}>visée {i + 1} : {x}</Text>)}
            <View style={[s.ligne, { gap: 10, marginTop: 10 }]}>
              <Bouton titre="Noter dans la fiche" plein onPress={() => { majNid(n.id, { hauteur: `${Math.round(h.hauteurM)} m` }); router.back(); }} />
              {h.pied && <Bouton titre="Corriger la position" onPress={() => Alert.alert('Position du nid', 'Remplacer la position de la fiche par le pied trouvé par les deux visées ?', [{ text: 'Annuler', style: 'cancel' }, { text: 'Remplacer', onPress: () => majNid(n.id, { lat: h.pied!.lat, lon: h.pied!.lon, err: 8 }) }])} />}
            </View>
          </>
        ) : <Text style={s.discret}>{visees.length ? 'Visez plus haut que l\'horizon (hausse entre 3° et 85°).' : 'Pas encore de visée.'}</Text>}
        <View style={[s.ligne, { gap: 8, marginTop: 10 }]}>
          <Text style={{ color: C.encre }}>Distance au pied (pas)</Text>
          <TextInput value={dist} onChangeText={setDist} keyboardType="decimal-pad" placeholder="m" placeholderTextColor="#9AA3AC"
            style={{ width: 90, borderWidth: 1, borderColor: C.ligne, borderRadius: 8, padding: 8, color: C.encre }} />
        </View>
        {visees.length > 0 && <Text style={[s.discret, { marginTop: 8, textDecorationLine: 'underline' }]} onPress={() => setVisees([])}>Recommencer les visées</Text>}
      </Carte>
    </ScrollView>
  );
}
