/** Sons et alertes (É12). */
import React, { useEffect } from 'react';
import { ScrollView, Text } from 'react-native';
import { Bouton, Carte, EnTete, Interrupteur, Titre, s } from '@/ui/composants';
import { Pas } from '@/ui/Pas';
import { police } from '@/ui/theme';
import { definirAlertes, useEtat, type ReglagesAlertes } from '@/store/store';
import { annoncer, suivreAuSon, vibrer } from '@/services/sons';
import { useParametres } from '@/services/parametres';

export default function Alertes() {
  const a = useEtat((e) => e.alertes);
  const set = (p: Partial<ReglagesAlertes>) => definirAlertes(p);
  const [essai, setEssai] = React.useState(false);
  useEffect(() => (essai ? suivreAuSon() : undefined), [essai]);
  const P = useParametres();
  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Sons et alertes" />
      <Carte>
        <Interrupteur titre="Son qui suit le signal" detail="Bips plus rapides et plus aigus quand le tag se rapproche (écrans Portatif et Mode conduite)" valeur={a.sonSignal} onChange={(v) => set({ sonSignal: v })} />
        <Pas titre="Volume" valeur={Math.round(a.volume * 100)} pas={10} min={0} max={100} format={(v) => `${v} %`} envoyer={(v) => set({ volume: v / 100 })} />
        <Interrupteur titre="Annonce vocale" detail={`« Tag 12, avant droit, 77 % » toutes les ${P.annonceS} s en mode conduite, et les alertes`} valeur={a.voix} onChange={(v) => set({ voix: v })} />
        <Bouton titre={essai ? 'Arrêter l\'essai' : 'Essayer le son et la voix'} onPress={() => { if (!essai) { annoncer('Tag 12, avant droit, 77 pour cent'); vibrer(); } setEssai(!essai); }} />
      </Carte>
      <Carte>
        <Titre>Alertes</Titre>
        <Interrupteur titre="Nouveau tag entendu" detail="Un tag pas encore reçu pendant la sortie" valeur={a.nouveauTag} onChange={(v) => set({ nouveauTag: v })} />
        <Interrupteur titre="Tag perdu" detail={`Plus rien reçu depuis ${P.tagPerduS} s`} valeur={a.tagPerdu} onChange={(v) => set({ tagPerdu: v })} />
        <Interrupteur titre="Pile du tag faible" detail={`Sous ${P.pileFaiblePct} %`} valeur={a.pileFaible} onChange={(v) => set({ pileFaible: v })} />
        <Interrupteur titre="Frelon revenu à l'appât" detail="Fin d'un aller-retour au chrono" valeur={a.retourAppat} onChange={(v) => set({ retourAppat: v })} />
        <Interrupteur titre="Nid localisé" detail={`Estimation à moins de ${P.nidLocaliseM} m`} valeur={a.nidLocalise} onChange={(v) => set({ nidLocalise: v })} />
        <Interrupteur titre="Approche d'un nid connu" detail={`Écran rouge et vibration à moins de ${P.zoneNidM} m`} valeur={a.approcheNid} onChange={(v) => set({ approcheNid: v })} />
        <Interrupteur titre="Batterie du toit ou du portatif" detail={`Sous ${P.battFaiblePct} %`} valeur={a.batterie} onChange={(v) => set({ batterie: v })} />
      </Carte>
      <Text style={[s.discret, { fontSize: police.mini }]}>Les seuils se règlent dans Réglages → Paramètres → Alertes. Les alertes sonnent et vibrent tant que l'appli est ouverte et l'écran allumé (les écrans de recherche le gardent allumé). Téléphone verrouillé, Android peut les retarder.</Text>
    </ScrollView>
  );
}
