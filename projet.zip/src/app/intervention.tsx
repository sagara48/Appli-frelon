/** Fiche d'intervention sur un nid (sur le modèle du compte rendu FREDON) : type, méthode, produit et quantité, hauteur,
 *  client (présent ou absent, signature), photos avant / après, météo ; compte rendu PDF à remettre au client. */
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Directory, File, Paths } from 'expo-file-system';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import React, { useCallback, useState } from 'react';
import { ActivityIndicator, Alert, Image, Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, Champ, EnTete, Interrupteur, Puces, Titre, s } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { Signature } from '@/ui/Signature';
import { useEtat } from '@/store/store';
import { numeroNid } from '@/services/carnet';
import { enregistrerIntervention, interventionsNid, preparerIntervention, supprimerIntervention, useProduits } from '@/services/interventions';
import { compteRenduPdf } from '@/services/exports';
import { chargerMeteo } from '@/services/meteo';
import { classeHauteur, dateControle, METHODES, TYPES_INTER, type Intervention, type TypeInter } from '@/calc/intervention';
import { useParametres } from '@/services/parametres';

const fmtDate = (t: number) => {
  const d = new Date(t), z = (n: number) => String(n).padStart(2, '0');
  return `${z(d.getDate())}/${z(d.getMonth() + 1)}/${d.getFullYear()} ${z(d.getHours())}:${z(d.getMinutes())}`;
};
function lireDate(txt: string): number | null {
  const m = /^\s*(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2})[:h](\d{2}))?\s*$/.exec(txt);
  if (!m) return null;
  const d = new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]), Number(m[4] ?? 12), Number(m[5] ?? 0));
  return Number.isNaN(d.getTime()) ? null : d.getTime();
}
/** heure actuelle (hors rendu) */
const maintenant = () => Date.now();
const num = (v: string): number | null => { const n = Number(v.replace(',', '.')); return v.trim() && Number.isFinite(n) ? n : null; };
const txt = (n: number | null) => (n === null ? '' : String(n).replace('.', ','));

export default function FicheIntervention() {
  const { nid, i: idInter, type } = useLocalSearchParams<{ nid: string; i?: string; type?: TypeInter }>();
  const router = useRouter();
  const nids = useEtat((e) => e.nids);
  const produits = useProduits();
  const P = useParametres();
  const n = nids.find((x) => x.id === Number(nid));
  const [it, setIt] = useState<Intervention | null>(() => {
    if (!n) return null;
    return interventionsNid(n).find((x) => x.id === idInter) ?? preparerIntervention(n, type ?? 'destruction');
  });
  const [date, setDate] = useState(() => (it ? fmtDate(it.t) : ''));
  const [nombres, setNombres] = useState(() => ({ q: txt(it?.quantiteG ?? null), h: txt(it?.hauteurM ?? null), d: txt(it?.diametreCm ?? null) }));
  const [occupe, setOccupe] = useState('');
  const [defile, setDefile] = useState(true);
  const geste = useCallback((g: boolean) => setDefile(!g), []);
  const signer = useCallback((d: string) => setIt((o) => (o ? { ...o, signature: d } : o)), []);
  if (!n || !it) return <View style={s.ecran}><EnTete titre="Intervention" /><Text style={[s.discret, { padding: 16 }]}>Nid introuvable.</Text></View>;
  const numero = numeroNid(nids, n.id);
  const existe = interventionsNid(n).some((x) => x.id === it.id);
  const maj = (p: Partial<Intervention>) => setIt({ ...it, ...p });
  const majClient = (p: Partial<Intervention['client']>) => setIt({ ...it, client: { ...it.client, ...p } });
  const ficheComplete = P.ficheComplete;
  const traitement = it.type === 'destruction' || it.type === 'retraitement' || it.type === 'autre_espece';

  const complet = (): Intervention | null => {
    const t = lireDate(date);
    if (t === null) { Alert.alert('Date', 'Date à écrire sous la forme 14/09/2026 10:30.'); return null; }
    return { ...it, t, quantiteG: num(nombres.q), hauteurM: num(nombres.h), diametreCm: num(nombres.d) };
  };
  const enregistrer = () => { const c = complet(); if (!c) return; enregistrerIntervention(n.id, c); router.back(); };
  const pdf = async () => {
    const c = complet(); if (!c) return;
    enregistrerIntervention(n.id, c);
    setOccupe('pdf');
    try { await compteRenduPdf(n, numero, c); } catch (e) { Alert.alert('Compte rendu', String(e)); } finally { setOccupe(''); }
  };
  const adresse = async () => {
    setOccupe('adresse');
    try {
      const perm = await Location.requestForegroundPermissionsAsync();
      if (!perm.granted) throw new Error('Autorisation de position refusée.');
      const [a] = await Location.reverseGeocodeAsync({ latitude: n.lat, longitude: n.lon });
      if (!a) throw new Error('Adresse introuvable ici.');
      majClient({ commune: [a.postalCode, a.city].filter(Boolean).join(' '), adresse: it.client.adresse || [a.streetNumber, a.street].filter(Boolean).join(' ') });
    } catch (e) { Alert.alert('Adresse', `${(e as Error).message}\nSans réseau, l'adresse se tape à la main.`); } finally { setOccupe(''); }
  };
  const meteo = async () => {
    setOccupe('meteo');
    try {
      const m = await chargerMeteo(n.lat, n.lon, { tempMin: P.tempMin, ventMax: P.ventMax });
      const h = new Date(lireDate(date) ?? maintenant()).getHours();
      const x = m.heures.find((y) => y.h === h) ?? m.heures[0];
      if (!x) throw new Error('Pas de prévision.');
      maj({ meteo: `${Math.round(x.temp)} °C, vent ${Math.round(x.vent)} km/h${x.pluie > 0 ? `, pluie ${x.pluie} mm` : ''}` });
    } catch (e) { Alert.alert('Météo', `${(e as Error).message}\nSans réseau, la météo se tape à la main.`); } finally { setOccupe(''); }
  };
  const photo = async (cle: 'photosAvant' | 'photosApres') => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) { Alert.alert('Photo', 'Autorisation refusée.'); return; }
    const r = await ImagePicker.launchCameraAsync({ quality: 0.6 });
    if (r.canceled || !r.assets[0]) return;
    try {
      const dir = new Directory(Paths.document, 'photos');
      if (!dir.exists) dir.create({ intermediates: true });
      const dest = new File(dir, `inter_${it.id}_${maintenant()}.jpg`);
      new File(r.assets[0].uri).copySync(dest);
      setIt((o) => (o ? { ...o, [cle]: [...o[cle], dest.uri] } : o));
    } catch (e) { Alert.alert('Photo', String(e)); }
  };
  const photos = (cle: 'photosAvant' | 'photosApres', titre: string) => (
    <View style={{ marginTop: 6 }}>
      <Text style={s.discret}>{titre}</Text>
      <View style={[s.ligne, { gap: 8, flexWrap: 'wrap', marginVertical: 6 }]}>
        {it[cle].map((p) => (
          <Pressable key={p} onLongPress={() => setIt((o) => (o ? { ...o, [cle]: o[cle].filter((x) => x !== p) } : o))}>
            <Image source={{ uri: p }} style={{ width: 84, height: 84, borderRadius: 8 }} />
          </Pressable>
        ))}
        <Pressable onPress={() => photo(cle)} style={{ width: 84, height: 84, borderRadius: 8, borderWidth: 1, borderColor: C.ligne, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: C.encre, fontSize: 28 }}>+</Text>
        </Pressable>
      </View>
    </View>
  );

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled" scrollEnabled={defile}>
      <EnTete titre={`Nid n° ${numero} · intervention`} />
      <Puces options={TYPES_INTER} valeur={it.type} onChange={(v) => maj({ type: v })} />

      <Carte>
        <View style={[s.ligne, { gap: 10, alignItems: 'flex-end' }]}>
          <View style={{ flex: 1 }}><Champ titre="Date et heure" valeur={date} onChange={setDate} placeholder="14/09/2026 10:30" /></View>
          <Bouton titre="Maintenant" onPress={() => setDate(fmtDate(maintenant()))} />
        </View>
        {it.type !== 'controle' && (
          <>
            <Text style={[s.discret, { marginTop: 6 }]}>Méthode</Text>
            <Puces options={METHODES.map((m) => [m, m] as [string, string])} valeur={METHODES.includes(it.methode) ? it.methode : it.methode ? 'Autre' : null}
              onChange={(v) => maj({ methode: v })} />
            {!!it.methode && !METHODES.slice(0, -1).includes(it.methode) && (
              <Champ titre="Méthode (précisez)" valeur={it.methode === 'Autre' ? '' : it.methode} onChange={(v) => maj({ methode: v || 'Autre' })} />
            )}
          </>
        )}
        <View style={[s.ligne, { gap: 10 }]}>
          <View style={{ flex: 1 }}><Champ titre="Hauteur du nid (m)" valeur={nombres.h} onChange={(v) => setNombres({ ...nombres, h: v })} clavier="decimal-pad" /></View>
          <View style={{ flex: 1 }}><Champ titre="Diamètre (cm)" valeur={nombres.d} onChange={(v) => setNombres({ ...nombres, d: v })} clavier="decimal-pad" /></View>
        </View>
        {!!num(nombres.h) && <Text style={[s.discret, { fontSize: police.mini }]}>Classe : {classeHauteur(num(nombres.h))}</Text>}
      </Carte>

      {traitement && (
        <Carte>
          <Titre>Produit biocide</Titre>
          {produits.length > 0 && (
            <Puces options={produits.map((p) => [p.nom, p.nom] as [string, string])} valeur={it.produit || null}
              onChange={(v) => { const p = produits.find((x) => x.nom === v); maj({ produit: v, substance: p?.substance ?? '', amm: p?.amm ?? '' }); }} />
          )}
          <Pressable onPress={() => maj({ produit: '', substance: '', amm: '' })} style={{ marginTop: 6 }}>
            <Text style={[s.discret, { textDecorationLine: it.produit ? 'underline' : 'none' }]}>{it.produit ? 'Sans produit (mécanique, congélation…)' : 'Aucun produit'}</Text>
          </Pressable>
          {!!it.produit && (
            <>
              <View style={[s.ligne, { gap: 10 }]}>
                <View style={{ flex: 1 }}><Champ titre="Quantité (g)" valeur={nombres.q} onChange={(v) => setNombres({ ...nombres, q: v })} clavier="decimal-pad" /></View>
                <View style={{ flex: 1 }}><Champ titre="N° de lot" valeur={it.lot} onChange={(v) => maj({ lot: v })} /></View>
              </View>
              <Text style={[s.discret, { fontSize: police.mini }]}>{[it.substance, it.amm && `AMM ${it.amm}`].filter(Boolean).join(' · ') || 'Substance et n° AMM : Menu → Produits biocides'}</Text>
            </>
          )}
          <Interrupteur titre="Nid décroché et emporté" detail="obligatoire avec un insecticide de synthèse dans certaines chartes" valeur={it.nidRetire} onChange={(v) => maj({ nidRetire: v })} />
        </Carte>
      )}

      {it.type === 'controle' && (
        <Carte>
          <Titre>Résultat du contrôle</Titre>
          <Puces options={[['mort', 'Nid mort, plus d\'activité'], ['actif', 'Encore actif : à retraiter']]} valeur={it.resultat || null} onChange={(v) => maj({ resultat: v as Intervention['resultat'] })} />
        </Carte>
      )}

      {ficheComplete && (
      <Carte>
        <Titre>Client ou riverain</Titre>
        <Champ titre="Nom" valeur={it.client.nom} onChange={(v) => majClient({ nom: v })} />
        <Champ titre="Adresse" valeur={it.client.adresse} onChange={(v) => majClient({ adresse: v })} />
        <View style={[s.ligne, { gap: 10, alignItems: 'flex-end' }]}>
          <View style={{ flex: 1 }}><Champ titre="Commune" valeur={it.client.commune} onChange={(v) => majClient({ commune: v })} /></View>
          {occupe === 'adresse' ? <ActivityIndicator color={C.encre} /> : <Bouton titre="Trouver" onPress={adresse} />}
        </View>
        <Champ titre="Téléphone" valeur={it.client.tel} onChange={(v) => majClient({ tel: v })} clavier="numeric" />
        <Interrupteur titre="Présent lors de l'intervention" valeur={it.present} onChange={(v) => maj({ present: v })} />
        {it.present && (
          <>
            <Text style={[s.discret, { marginVertical: 6 }]}>Le client certifie que l'intervention a eu lieu</Text>
            <Signature valeur={it.signature} onChange={signer} geste={geste} />
          </>
        )}
      </Carte>
      )}

      <Carte>
        <Titre>Constat</Titre>
        {photos('photosAvant', 'Photos avant')}
        {it.type !== 'controle' && photos('photosApres', 'Photos après')}
        <Text style={[s.discret, { fontSize: police.mini }]}>Appui long sur une photo pour la retirer.</Text>
        {ficheComplete && <View style={[s.ligne, { gap: 10, alignItems: 'flex-end' }]}>
          <View style={{ flex: 1 }}><Champ titre="Météo" valeur={it.meteo} onChange={(v) => maj({ meteo: v })} placeholder="16 °C, vent faible" /></View>
          {occupe === 'meteo' ? <ActivityIndicator color={C.encre} /> : <Bouton titre="Actuelle" onPress={meteo} />}
        </View>}
        <Champ titre="Commentaires" valeur={it.note} onChange={(v) => maj({ note: v })} multiligne />
      </Carte>

      {ficheComplete ? (
      <Carte>
        <Titre>Opérateur</Titre>
        <View style={[s.ligne, { gap: 10 }]}>
          <View style={{ flex: 1 }}><Champ titre="Nom" valeur={it.operateur} onChange={(v) => maj({ operateur: v })} /></View>
          <View style={{ flex: 1 }}><Champ titre="N° Certibiocide" valeur={it.certibiocide} onChange={(v) => maj({ certibiocide: v })} /></View>
        </View>
        {traitement && <Text style={[s.discret, { fontSize: police.mini }]}>Contrôle conseillé le {new Date(dateControle(lireDate(date) ?? it.t, P.controleJours)).toLocaleDateString('fr-FR')} (rappel automatique).</Text>}
      </Carte>
      ) : traitement && <Text style={[s.discret, { fontSize: police.mini }]}>Contrôle conseillé le {new Date(dateControle(lireDate(date) ?? it.t, P.controleJours)).toLocaleDateString('fr-FR')} (rappel automatique).</Text>}

      <View style={[s.ligne, { gap: 10 }]}>
        <Bouton titre="Enregistrer" plein onPress={enregistrer} />
        {ficheComplete && (occupe === 'pdf' ? <ActivityIndicator color={C.encre} /> : <Bouton titre="Compte rendu PDF" onPress={pdf} />)}
      </View>
      {existe && (
        <Pressable onPress={() => Alert.alert('Supprimer', 'Supprimer cette intervention ?', [{ text: 'Annuler', style: 'cancel' }, { text: 'Supprimer', style: 'destructive', onPress: () => { supprimerIntervention(n.id, it.id); router.back(); } }])}
          style={{ alignSelf: 'center', marginTop: 4 }}>
          <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Supprimer l'intervention</Text>
        </Pressable>
      )}
    </ScrollView>
  );
}
