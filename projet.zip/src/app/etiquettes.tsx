/** Étiquettes QR des tags : planche A4 à imprimer (ou PDF), à coller dans la boîte de rangement, une case par tag (le tag, 16 × 8 mm, est trop petit pour la porter). Un scan (onglet Mes tags →
 *  Scanner, ou l'appareil photo du téléphone) ouvre le tag dans l'appli : pose, suivi, fiche. */
import React, { useState } from 'react';
import { ScrollView, Text, TextInput, View } from 'react-native';
import * as Print from 'expo-print';
import { Bouton, Carte, EnTete, Puces, Titre, s } from '@/ui/composants';
import { C, idTag, police } from '@/ui/theme';
import { useEtat } from '@/store/store';
import { QrCode } from '@/ui/QrCode';
import { lienTag, listeNumeros, planchePdf } from '@/calc/qr';
import * as Sharing from 'expo-sharing';

export default function Etiquettes() {
  const fiches = useEtat((x) => x.fichesTags);
  const connus = Object.keys(fiches).map(Number).sort((a, b) => a - b);
  const [texte, setTexte] = useState(connus.length ? connus.join(', ') : '1-20');
  const [taille, setTaille] = useState('boite');
  const ids = listeNumeros(texte);
  const boite = taille === 'boite', mm = boite ? 12 : Number(taille);
  const html = () => planchePdf(ids, mm, idTag, boite);
  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre="Étiquettes QR des tags" />
      <Text style={s.discret}>
        Une étiquette par tag, au fond de sa case dans la boîte de rangement (le tag lui-même est trop petit). Elle apparaît quand on sort le tag : scannez la case vide au moment de la pose,
        le bon tag est choisi sans chercher son numéro. L'appareil photo ordinaire du téléphone ouvre aussi l'appli sur ce tag.
      </Text>
      <Carte>
        <Titre>Tags</Titre>
        <TextInput value={texte} onChangeText={setTexte} placeholder="1-20, 31, 40" placeholderTextColor="#9AA3AC"
          style={{ borderWidth: 1, borderColor: C.ligne, borderRadius: 8, padding: 10, color: C.encre }} />
        <Text style={[s.discret, { marginTop: 4 }]}>{ids.length} étiquette{ids.length > 1 ? 's' : ''} · numéros séparés par des virgules, plages avec un tiret</Text>
        <Titre>Format</Titre>
        <Puces options={[['boite', 'Boîte 20 cases'], ['15', 'QR 15 mm'], ['20', 'QR 20 mm']]} valeur={taille} onChange={setTaille} />
        <Text style={[s.discret, { fontSize: police.mini, marginTop: 4 }]}>{boite ? 'Carrés de 13 mm (QR de 12 mm) pour le fond des cases de la boîte imprimée (boite_20_tags.stl), numéro au-dessus de chaque carré pour ne pas se tromper de case.' : 'Étiquettes avec numéro, pour une autre boîte.'} Imprimer à 100 % (sans « ajuster à la page »), papier mat ; adhésif transparent par-dessus.</Text>
        <View style={[s.ligne, { gap: 10, marginTop: 12 }]}>
          <Bouton titre="Imprimer" plein desactive={!ids.length} onPress={() => { Print.printAsync({ html: html() }).catch(() => {}); }} />
          <Bouton titre="PDF" desactive={!ids.length} onPress={async () => {
            const r = await Print.printToFileAsync({ html: html() }).catch(() => null);
            if (r) Sharing.shareAsync(r.uri, { mimeType: 'application/pdf', dialogTitle: 'Étiquettes QR' }).catch(() => {});
          }} />
        </View>
      </Carte>
      {ids.length > 0 && (
        <Carte>
          <Titre>Aperçu</Titre>
          <View style={[s.ligne, { gap: 14, flexWrap: 'wrap' }]}>
            {ids.slice(0, 6).map((id) => (
              <View key={id} style={{ alignItems: 'center' }}>
                <QrCode texte={lienTag(id)} taille={86} />
                <Text style={{ color: C.encre, fontWeight: '800', marginTop: 2 }}>TAG {idTag(id)}</Text>
              </View>
            ))}
          </View>
        </Carte>
      )}
    </ScrollView>
  );
}
