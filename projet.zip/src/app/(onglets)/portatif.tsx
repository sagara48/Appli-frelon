/** Écran Portatif (É7) : recherche à pied avec le récepteur portatif. */
import { useModeExpert } from '@/services/expert';
import { useKeepAwake } from 'expo-keep-awake';
import React from 'react';
import { Alert, Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import Svg, { Circle, G, Line, Path, Polyline, Text as T } from 'react-native-svg';
import { Bouton, Carte, Titre, Vide, s, useMaintenant } from '@/ui/composants';
import { C, fmtAge, fmtDist, idTag, police } from '@/ui/theme';
import { agePortatif, store, useEtat } from '@/store/store';
import { capDeg, distM, niveauPct, pointCardinal } from '@/calc/geo';
import { VOIES_RF, cmdPortatif, type ModeLna } from '@/proto/portatif';
import { connecterPortatif, deconnecterPortatif, envoyerPortatif, simulerPortatif } from '@/sources/portatif';
import { suivreAuSon } from '@/services/sons';
import { useFocusEffect, useRouter } from 'expo-router';
import { distanceRssi, texteDistance } from '@/calc/distance';
import { modeleDistance, useParametres } from '@/services/parametres';

const envoyer = (cmd: string) => envoyerPortatif(cmd).catch((e) => Alert.alert('Portatif', (e as Error).message));

export default function Portatif() {
  const P = useParametres();
  const router = useRouter();
  useKeepAwake();
  const p = useEtat((e) => e.portatif);
  const tags = useEtat((e) => e.tags);
  const [lna, setLna] = React.useState<ModeLna>('auto');
  const [gps, setGps] = React.useState<'int' | 'ext'>('int');
  const [son, setSon] = React.useState(true);
  const expert = useModeExpert();
  const connecte = p.connexion === 'connecte';
  // bips qui suivent le signal, seulement quand l'écran est affiché
  useFocusEffect(React.useCallback(() => suivreAuSon(), []));

  if (!connecte || !p.st) {
    return (
      <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
        <Bandeau />
        <Carte>
          <Vide titre="Portatif non connecté" texte="Allumez le récepteur portatif « RX-Frelons » et gardez-le près du téléphone. Il se signale quelques secondes toutes les 8 s : la recherche peut prendre un moment." />
          <View style={{ gap: 10 }}>
            <Bouton titre={p.connexion === 'recherche' ? 'Recherche…' : 'Connecter le portatif'} plein desactive={p.connexion === 'recherche'} onPress={() => connecterPortatif()} />
            <Bouton titre="Essayer avec le portatif simulé" onPress={simulerPortatif} />
          </View>
          {!!p.message && <Text style={[s.discret, { marginTop: 10, textAlign: 'center' }]}>{p.message}</Text>}
        </Carte>
      </ScrollView>
    );
  }

  const st = p.st;
  const ageReel = agePortatif(store.get());
  const entendu = st.tag >= 0 && ageReel < 10;
  const pct = entendu ? niveauPct(st.rssi) : null;
  const dist = entendu ? distanceRssi(st.rssi, modeleDistance('portatif', P)) : null;
  const td = dist ? texteDistance(dist) : null;
  const sens = !entendu ? 'Pas de signal' : st.trend > 0.4 ? 'Ça se rapproche' : st.trend < -0.4 ? 'Ça s\'éloigne' : 'Stable';
  const couleurSens = st.trend > 0.4 ? C.ok : st.trend < -0.4 ? C.alerte : C.discret;
  const autres = Object.values(p.autres).filter((t) => t.id !== st.tag).sort((a, b) => a.id - b.id);
  const ids = [...new Set([...(st.tag >= 0 ? [st.tag] : []), ...autres.map((t) => t.id), ...Object.keys(tags).map(Number)])].sort((a, b) => a - b);

  // nid connu pour ce tag (toutes sources réunies) : distance et direction depuis la personne
  const f = st.tag >= 0 ? tags[st.tag]?.fusion : null;
  const versNid = f?.ok && st.fix ? { d: distM(st.lat, st.lon, f.lat, f.lon), cap: capDeg(st.lat, st.lon, f.lat, f.lon), err: f.errM } : null;
  const sw = p.sw;

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <Bandeau />

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
        <Text style={[s.discret, { alignSelf: 'center' }]}>TAG</Text>
        {ids.map((id) => (
          <Pressable key={id} onPress={() => { envoyer(cmdPortatif.tag(id)); store.choisirTag(id); }} style={[s.puce, id === st.tag && s.puceActive]}>
            <Text style={[s.puceTxt, id === st.tag && { fontWeight: '700' }]}>{idTag(id)}</Text>
          </Pressable>
        ))}
      </ScrollView>

      <Carte style={{ alignItems: 'center' }}>
        <Text style={s.discret}>{st.tag >= 0 ? `TAG ${idTag(st.tag)} · ${entendu ? `reçu il y a ${ageReel.toFixed(1).replace('.', ',')} s` : 'pas reçu'}` : 'Aucun tag choisi'}</Text>
        <View style={[s.ligne, { alignItems: 'flex-end', marginTop: 4 }]}>
          <Text style={{ fontSize: 72, fontWeight: '800', color: entendu ? C.encre : C.discret, fontVariant: ['tabular-nums'], lineHeight: 80 }}>{pct ?? '—'}</Text>
          {pct !== null && <Text style={{ fontSize: 26, fontWeight: '700', color: C.discret, marginBottom: 10, marginLeft: 4 }}>%</Text>}
        </View>
        {td && (
          <Pressable onPress={() => router.push('/distance-etalonnage')} style={{ alignItems: 'center', marginBottom: 4 }}>
            <Text style={{ fontSize: 30, fontWeight: '800', color: C.encre }}>{td.court}</Text>
            <Text style={[s.discret, { fontSize: police.mini }]}>entre {td.fourchette} · d'après le signal</Text>
          </Pressable>
        )}
        <Text style={{ fontSize: police.normal + 2, fontWeight: '700', color: couleurSens }}>
          {st.trend > 0.4 ? '▲ ' : st.trend < -0.4 ? '▼ ' : ''}{sens}
        </Text>
        <Historique valeurs={p.historique} />
      </Carte>

      {versNid && (
        <Carte style={{ borderColor: C.accent, borderWidth: 2 }}>
          <Titre>Vers le nid estimé · ± {Math.round(versNid.err)} m</Titre>
          <View style={[s.ligne, { gap: 14 }]}>
            <FlecheRelative cap={versNid.cap} hdg={st.hdg} />
            <View style={{ flex: 1, gap: 4 }}>
              <Text style={{ fontSize: 28, fontWeight: '800', color: C.encre }}>{fmtDist(versNid.d)}</Text>
              <Text style={{ color: C.encre, fontSize: police.normal }}>{Math.round(versNid.cap)}° {pointCardinal(versNid.cap)}</Text>
              <Text style={s.discret}>{consigne(versNid.cap - st.hdg)}</Text>
            </View>
          </View>
        </Carte>
      )}

      <Carte>
        <View style={[s.ligne, { justifyContent: 'space-between' }]}>
          <Titre>Relèvement à pied</Titre>
          <Text style={[s.discret, { marginBottom: 8 }]}>{sw?.nfix ?? 0} point{(sw?.nfix ?? 0) > 1 ? 's' : ''}</Text>
        </View>
        <Text style={[s.discret, { lineHeight: 19 }]}>
          Tournez lentement sur vous-même, antenne à l'horizontale, puis ajoutez le point. Recommencez 20 à 50 m plus loin, sur le côté.
        </Text>
        {sw?.act ? (
          <View style={{ marginTop: 12 }}>
            <Text style={{ color: C.encre, fontWeight: '700' }}>Tour en cours… {sw.pct} %</Text>
            <View style={{ height: 8, borderRadius: 4, backgroundColor: C.fond, overflow: 'hidden', marginTop: 6 }}>
              <View style={{ width: `${Math.min(100, Math.round(sw.pct / 0.94))}%`, height: '100%', backgroundColor: C.accent }} />
            </View>
          </View>
        ) : sw?.ok ? (
          <Text style={{ marginTop: 12, fontSize: police.normal + 2, color: C.encre }}>
            Meilleure direction <Text style={{ fontWeight: '800' }}>{Math.round(sw.brg)}° {pointCardinal(sw.brg)}</Text>
          </Text>
        ) : null}
        <View style={[s.ligne, { gap: 10, marginTop: 12 }]}>
          <Bouton titre={sw?.ok ? 'Nouveau tour' : 'Faire un tour'} onPress={() => envoyer(cmdPortatif.sweep())} />
          <Bouton titre="Ajouter le point" plein desactive={!sw?.ok || !st.fix} onPress={() => envoyer(cmdPortatif.fix())} />
        </View>
        {(sw?.nfix ?? 0) > 0 && (
          <Pressable onPress={() => Alert.alert('Effacer les relevés', 'Effacer tous les points du portatif ?', [
            { text: 'Annuler', style: 'cancel' }, { text: 'Effacer', style: 'destructive', onPress: () => envoyer(cmdPortatif.clr()) },
          ])} style={{ marginTop: 10, alignSelf: 'center' }}>
            <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Effacer les points</Text>
          </Pressable>
        )}
        {!st.fix && <Text style={[s.discret, { marginTop: 8, color: C.alerte }]}>Pas de position GPS : les points ne peuvent pas être ajoutés.</Text>}
        {st.tag >= 0 && tags[st.tag]?.portatif[0] && (
          <Text style={[s.discret, { marginTop: 10 }]}>Nid calculé par le portatif ± {Math.round(tags[st.tag].portatif[0].errM)} m, ajouté à la carte.</Text>
        )}
      </Carte>

      <Carte>
        {expert && (
          <>
        <Titre>Ampli de réception</Titre>
        <Choix options={[['auto', 'Auto'], ['on', 'Marche'], ['off', 'Arrêt'], ['att', 'Atténué']]} valeur={lna}
          onChange={(v) => { setLna(v as ModeLna); envoyer(cmdPortatif.lna(v as ModeLna)); }} />
        <Text style={[s.discret, { marginTop: 6, fontSize: police.mini }]}>« Atténué » quand on est tout près du nid et que le signal sature.</Text>
        <View style={{ height: 14 }} />
        <Titre>Antenne GPS</Titre>
        <Choix options={[['int', 'Interne'], ['ext', 'Externe']]} valeur={gps} onChange={(v) => { setGps(v as 'int' | 'ext'); envoyer(cmdPortatif.gps(v as 'int' | 'ext')); }} />
          </>
        )}
        <View style={[s.ligne, { gap: 10, marginTop: expert ? 14 : 0 }]}>
          <Bouton titre={son ? 'Son : activé' : 'Son : coupé'} onPress={() => { setSon(!son); envoyer(cmdPortatif.son(!son)); }} />
          <Bouton titre="Déconnecter" onPress={deconnecterPortatif} />
        </View>
      </Carte>
    </ScrollView>
  );
}

function consigne(ecart: number) {
  const e = ((ecart % 360) + 540) % 360 - 180; // −180..180
  if (Math.abs(e) <= 15) return 'Droit devant';
  if (Math.abs(e) >= 165) return 'Derrière vous : faites demi-tour';
  return `Tournez de ${Math.round(Math.abs(e))}° vers la ${e > 0 ? 'droite' : 'gauche'}`;
}

function Bandeau() {
  const p = useEtat((e) => e.portatif);
  const expert = useModeExpert();
  const now = useMaintenant();
  const st = p.st;
  const ok = p.connexion === 'connecte';
  const age = ok && p.recuMs ? (now - p.recuMs) / 1000 : 0;
  return (
    <View style={s.bandeau}>
      <View style={s.ligne}>
        <View style={[s.pastille, { backgroundColor: ok ? (age > 5 ? C.accent : C.ok) : p.connexion === 'recherche' ? C.accent : C.alerte }]} />
        <Text style={s.bandeauTitre}>{ok ? (p.source === 'simulation' ? 'Portatif simulé' : 'Portatif connecté') : p.connexion === 'recherche' ? 'Recherche du portatif…' : 'Portatif non connecté'}</Text>
      </View>
      {st && ok && (
        <View style={[s.ligne, { marginTop: 6, flexWrap: 'wrap', gap: 14 }]}>
          <Info k="Batterie" v={`${st.bat} %`} />
          <Info k="GPS" v={st.fix ? `${st.sats} sat.` : 'pas de position'} />
          {expert && <Info k="Cap" v={`${Math.round(st.hdg)}°`} />}
          {expert && <Info k="Réception" v={VOIES_RF[st.lna] ?? '—'} />}
          {age > 5 && <Info k="Dernière donnée" v={`il y a ${fmtAge(age)}`} />}
        </View>
      )}
    </View>
  );
}

function Info({ k, v }: { k: string; v: string }) {
  return <Text style={s.info}><Text style={{ color: '#A9B4BF' }}>{k} </Text>{v}</Text>;
}

function Choix({ options, valeur, onChange }: { options: [string, string][]; valeur: string; onChange: (v: string) => void }) {
  return (
    <View style={[s.ligne, { gap: 8, flexWrap: 'wrap' }]}>
      {options.map(([v, txt]) => (
        <Pressable key={v} onPress={() => onChange(v)} style={[s.puce, v === valeur && s.puceActive]}>
          <Text style={[s.puceTxt, { fontSize: police.petit }, v === valeur && { fontWeight: '700' }]}>{txt}</Text>
        </Pressable>
      ))}
    </View>
  );
}

/** Courbe du niveau sur les 2 dernières minutes. */
function Historique({ valeurs }: { valeurs: number[] }) {
  const { width } = useWindowDimensions();
  const W = width - 64, H = 56;
  const pts: string[] = [];
  valeurs.forEach((v, i) => {
    const pc = niveauPct(v);
    if (pc === null || Number.isNaN(v)) return;
    pts.push(`${(W * (i + 120 - valeurs.length)) / 119},${H - 4 - ((H - 8) * pc) / 100}`);
  });
  return (
    <View style={{ marginTop: 10 }}>
      <Svg width={W} height={H}>
        <Line x1={0} y1={H - 4} x2={W} y2={H - 4} stroke={C.ligne} />
        <Line x1={0} y1={H / 2} x2={W} y2={H / 2} stroke={C.ligne} strokeDasharray="3 4" />
        {pts.length > 1 && <Polyline points={pts.join(' ')} fill="none" stroke={C.accent} strokeWidth={2.5} strokeLinejoin="round" />}
      </Svg>
      <Text style={[s.discret, { fontSize: police.mini, textAlign: 'right' }]}>2 dernières minutes</Text>
    </View>
  );
}

/** Flèche vers le nid par rapport à la direction où pointe l'antenne (haut = devant soi). */
function FlecheRelative({ cap, hdg }: { cap: number; hdg: number }) {
  const t = 92, c = t / 2, rel = cap - hdg;
  return (
    <Svg width={t} height={t}>
      <Circle cx={c} cy={c} r={c - 3} fill={C.fond} stroke={C.ligne} strokeWidth={2} />
      <T x={c} y={14} fontSize={10} fill={C.discret} textAnchor="middle">devant</T>
      <G transform={`rotate(${rel} ${c} ${c})`}>
        <Path d={`M${c},${c - 32} L${c + 13},${c + 6} L${c},${c} L${c - 13},${c + 6} Z`} fill={C.accent} />
        <Line x1={c} y1={c} x2={c} y2={c + 26} stroke={C.accent} strokeWidth={5} strokeLinecap="round" />
      </G>
    </Svg>
  );
}
