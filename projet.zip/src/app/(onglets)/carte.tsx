/** Écran Carte (É2) : trajet, relèvements, directions à l'œil, nid estimé et son cercle d'incertitude. */
import { router as routeur, useFocusEffect, useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, Animated, PanResponder, Pressable, ScrollView, Text, View, useWindowDimensions, type GestureResponderEvent } from 'react-native';
import Svg, { Circle, G, Image as SvgImage, Line, Path, Polyline, Rect, Text as T } from 'react-native-svg';
import { BandeauToit, Bouton, Carte as Bloc, ChoixTag, Titre, Vide, s, useMaintenant } from '@/ui/composants';
import { allerParLaRoute, routePourCroiserEnLigne } from '@/services/route';
import { ouCroiser } from '@/calc/croiser';
import { retourVoiture, useVoiture } from '@/services/voiture';
import { useEquipiers } from '@/services/equipe';
import { envoyerCible } from '@/services/cible';
import { C, fmtCoord, fmtDist, idTag, police } from '@/ui/theme';
import { store, useEtat } from '@/store/store';
import { KY, capDeg, distM, kxOf, pointCardinal } from '@/calc/geo';
import { cmdToit } from '@/proto/toit';
import { envoyerToit } from '@/sources/commandesToit';
import { nouveauNid, numeroNid, sourcesTexte } from '@/services/carnet';
import { fondCarte, type Fond } from '@/services/fond';
import { sourceTuile, tuilesDe, xVersLon, yVersLat, zoomPour } from '@/services/tuiles';
import { resume } from '@/calc/appat';
import { capturesPiege, grilleDensite, piegeActif } from '@/calc/saison';
import { useParametres } from '@/services/parametres';
import { couleurSignal, pointFort } from '@/calc/traceAPied';
import { nid3DDe, useVols, volPourTag } from '@/services/vols';
import { mesuresTag } from '@/calc/vol';

type Calques = { vol: boolean; pied: boolean; voiture: boolean; ecartes: boolean; oeil: boolean; portatif: boolean; appat: boolean; trajet: boolean; pieges: boolean; densite: boolean };

/** Appui long sur la carte : nid trouvé à cet endroit (fiche ouverte aussitôt) ou rucher à cet endroit. */
function appuiLong(x: number, y: number, v: { cLat: number; cLon: number; kx: number; m: number; W: number; H: number }) {
  const lat = v.cLat - ((y - v.H / 2) * v.m) / KY, lon = v.cLon + ((x - v.W / 2) * v.m) / v.kx;
  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
  const ici = `${lat.toFixed(5).replace('.', ',')} N · ${lon.toFixed(5).replace('.', ',')} E`;
  const prm = { lat: lat.toFixed(7), lon: lon.toFixed(7) };
  // Android n'affiche que 3 boutons par fenêtre : rucher et piège sont dans une seconde fenêtre
  Alert.alert('À cet endroit', ici, [
    { text: 'Nid trouvé ici', onPress: () => {
      const id = nouveauNid(-1, lat, lon, 10, 'pointé sur la carte');
      if (id) routeur.push({ pathname: '/nid/[id]', params: { id: String(id) } });
    } },
    { text: 'Rucher ou piège…', onPress: () => Alert.alert('À cet endroit', ici, [
      { text: 'Rucher ici', onPress: () => routeur.push({ pathname: '/ruchers', params: prm }) },
      { text: 'Piège ici', onPress: () => routeur.push({ pathname: '/pieges', params: prm }) },
      { text: 'Annuler', style: 'cancel' },
    ]) },
    { text: 'Annuler', style: 'cancel' },
  ]);
}

export default function CarteEcran() {
  const { width } = useWindowDimensions();
  const P = useParametres();
  const e = useEtat((x) => ({ portatif: x.portatif, pas: x.pas, tags: x.tags, tagChoisi: x.tagChoisi, trajet: x.trajet, toit: x.toit, source: x.source, chrono: x.chrono, nids: x.nids, ruchers: x.ruchers, pieges: x.pieges }));
  const router = useRouter();
  const [fond, setFond] = useState<Fond>(fondCarte());
  useFocusEffect(useCallback(() => { setFond(fondCarte()); }, []));
  const tTag = e.tagChoisi !== null ? e.tags[e.tagChoisi] : undefined;
  // sans tag suivi, la carte montre quand même les nids du carnet, les ruchers et le trajet
  const t = tTag ?? { id: e.tagChoisi ?? -1, lignes: [], oeil: [], portatif: [], fusion: null };
  const tel = useEtat((x) => x.telephone);
  const V = useVols();
  const vol = t.id >= 0 ? volPourTag(V, t.id) : null;
  const mVol = vol ? mesuresTag(vol, t.id) : [];
  const [zoom, setZoom] = useState(1);
  // centre choisi au doigt (null = cadrage automatique sur le nid et les relèvements)
  const [centre, setCentre] = useState<{ lat: number; lon: number } | null>(null);
  const [geste, setGeste] = useState(false); // la page ne défile pas pendant qu'on déplace la carte
  const [calques, setCalques] = useState<Calques>({ vol: true, pied: true, voiture: true, ecartes: true, oeil: true, portatif: true, appat: true, trajet: true, pieges: true, densite: false });
  const W = width - 32, H = Math.round(W * 1.1);
  const appats = t.id >= 0 ? e.chrono.appats.filter((a) => a.tag === t.id).map((a) => ({ a, r: resume(e.chrono, a) })) : [];
  const f = t.fusion?.ok ? t.fusion : null;
  const pos = e.toit && e.toit.lat ? e.toit : null;
  const voiture = useVoiture();
  const equipiers = useEquipiers();
  const maintenantMs = useMaintenant(30000);
  // où rouler pour croiser : plus grand trou entre les directions des relevés vues depuis le nid
  const cr = f ? ouCroiser(f, [...t.lignes.filter((l) => !l.ecartee), ...t.oeil]) : null;

  // emprise : nid + origines des relèvements + position actuelle ; repère local centré
  const vue = (() => {
    const pts: [number, number][] = [];
    if (f) pts.push([f.lat, f.lon]);
    t.lignes.forEach((l) => pts.push([l.lat, l.lon]));
    t.oeil.forEach((o) => pts.push([o.lat, o.lon]));
    t.portatif.forEach((p) => pts.push([p.lat, p.lon]));
    (e.pas[t.id] ?? []).forEach((p) => pts.push([p.lat, p.lon]));
    mVol.forEach((p) => pts.push([p.lat, p.lon]));
    appats.forEach(({ a }) => pts.push([a.lat, a.lon]));
    if (pos) pts.push([pos.lat, pos.lon]);
    if (!pts.length) e.trajet.slice(-200).forEach((p) => pts.push([p.lat, p.lon]));
    if (!pts.length) { e.ruchers.forEach((r) => pts.push([r.lat, r.lon])); e.nids.forEach((n) => pts.push([n.lat, n.lon])); }
    if (!pts.length && tel) pts.push([tel.lat, tel.lon]);
    if (!pts.length) return null;
    const lat0 = pts.reduce((a, p) => a + p[0], 0) / pts.length;
    const kx = kxOf(lat0);
    let la1 = 1e9, la2 = -1e9, lo1 = 1e9, lo2 = -1e9;
    for (const [la, lo] of pts) { la1 = Math.min(la1, la); la2 = Math.max(la2, la); lo1 = Math.min(lo1, lo); lo2 = Math.max(lo2, lo); }
    const cLat = f ? f.lat : (la1 + la2) / 2, cLon = f ? f.lon : (lo1 + lo2) / 2;
    // demi-étendue en mètres autour du centre, avec 15 % de marge
    const ext = Math.max(
      Math.abs(la2 - cLat) * KY, Math.abs(cLat - la1) * KY, Math.abs(lo2 - cLon) * kx * (H / W), Math.abs(cLon - lo1) * kx * (H / W), 150,
    ) * 1.15;
    return { cLat, cLon, kx, mParPx: (2 * ext) / H };
  })();

  // déplacement à un doigt, zoom à deux doigts : la carte suit le doigt (transformation), puis se redessine au lâcher
  const geo = useRef({ cLat: 0, cLon: 0, kx: 1, m: 1, W, H, zoom });
  const [anim] = useState(() => ({ tx: new Animated.Value(0), ty: new Animated.Value(0), sc: new Animated.Value(1) }));
  const g = useRef({ ox: 0, oy: 0, f0x: 0, f0y: 0, d0: 0, s: 1, f1x: 0, f1y: 0, n: 0 });
  // appui long (0,6 s sans bouger) : ajouter un nid ou un rucher à cet endroit
  const appui = useRef<ReturnType<typeof setTimeout> | null>(null);
  const finAppui = () => { if (appui.current) { clearTimeout(appui.current); appui.current = null; } };
  // les refs ne sont lues que dans les gestionnaires du geste, jamais pendant l'affichage
  // eslint-disable-next-line react-hooks/refs
  const [pan] = useState(() => {
    const points = (ev: GestureResponderEvent) => {
      const t = ev.nativeEvent.touches.length ? ev.nativeEvent.touches : [ev.nativeEvent];
      const a = t[0], b = t[1];
      const x1 = a.pageX - g.current.ox, y1 = a.pageY - g.current.oy;
      if (!b) return { fx: x1, fy: y1, d: 0, n: 1 };
      const x2 = b.pageX - g.current.ox, y2 = b.pageY - g.current.oy;
      return { fx: (x1 + x2) / 2, fy: (y1 + y2) / 2, d: Math.hypot(x2 - x1, y2 - y1), n: 2 };
    };
    // nouveau départ du geste (premier doigt, ou passage de 1 à 2 doigts) : la transformation en cours est conservée
    const repartir = (p: { fx: number; fy: number; d: number; n: number }) => {
      const c = g.current;
      // point de la carte d'origine sous le nouveau foyer
      const px = c.f0x + (p.fx - c.f1x) / c.s, py = c.f0y + (p.fy - c.f1y) / c.s;
      c.f0x = px; c.f0y = py; c.f1x = p.fx; c.f1y = p.fy; c.d0 = p.d / c.s; c.n = p.n;
    };
    const appliquer = () => {
      const c = g.current, { W: w, H: h } = geo.current;
      anim.sc.setValue(c.s);
      anim.tx.setValue(c.f1x - c.s * c.f0x + (c.s - 1) * (w / 2));
      anim.ty.setValue(c.f1y - c.s * c.f0y + (c.s - 1) * (h / 2));
    };
    return PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderTerminationRequest: () => false,
      onPanResponderGrant: (ev) => {
        const t = ev.nativeEvent;
        g.current = { ox: t.pageX - t.locationX, oy: t.pageY - t.locationY, f0x: t.locationX, f0y: t.locationY, d0: 0, s: 1, f1x: t.locationX, f1y: t.locationY, n: 1 };
        setGeste(true);
        finAppui();
        const x = t.locationX, y = t.locationY;
        appui.current = setTimeout(() => { appui.current = null; appuiLong(x, y, geo.current); }, 600);
      },
      onPanResponderMove: (ev) => {
        const p = points(ev), c = g.current;
        if (appui.current && (p.n > 1 || Math.hypot(p.fx - c.f0x, p.fy - c.f0y) > 8)) finAppui();
        if (p.n !== c.n) { repartir(p); return; }
        c.f1x = p.fx; c.f1y = p.fy;
        if (p.n === 2 && c.d0 > 0) {
          const z = geo.current.zoom;
          c.s = Math.min(40 / z, Math.max(0.3 / z, p.d / c.d0));
        }
        appliquer();
      },
      onPanResponderRelease: () => {
        finAppui();
        const c = g.current, v = geo.current;
        const bouge = Math.abs(c.f1x - c.f0x) > 3 || Math.abs(c.f1y - c.f0y) > 3 || Math.abs(c.s - 1) > 0.01;
        if (bouge) {
          // point de l'ancienne carte qui arrive au centre de l'écran → nouveau centre ; nouvelle échelle
          const px = c.f0x + (v.W / 2 - c.f1x) / c.s, py = c.f0y + (v.H / 2 - c.f1y) / c.s;
          setCentre({ lat: v.cLat - ((py - v.H / 2) * v.m) / KY, lon: v.cLon + ((px - v.W / 2) * v.m) / v.kx });
          setZoom(v.zoom * c.s);
        }
        anim.tx.setValue(0); anim.ty.setValue(0); anim.sc.setValue(1);
        setGeste(false);
      },
      onPanResponderTerminate: () => { finAppui(); anim.tx.setValue(0); anim.ty.setValue(0); anim.sc.setValue(1); setGeste(false); },
    });
  });

  // valeurs lues par le geste au moment du lâcher
  const mGeo = vue ? vue.mParPx / zoom : 1;
  const geoLat = centre?.lat ?? vue?.cLat ?? 0, geoLon = centre?.lon ?? vue?.cLon ?? 0, geoKx = vue?.kx ?? 1;
  useEffect(() => { geo.current = { cLat: geoLat, cLon: geoLon, kx: geoKx, m: mGeo, W, H, zoom }; }, [geoLat, geoLon, geoKx, mGeo, W, H, zoom]);

  if (!vue) {
    return (
      <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
        <BandeauToit />
        <Bloc><Vide titre="Rien à afficher" texte="La carte se remplit dès que le toit relève un tag, ou avec les nids du carnet et vos ruchers. Activez la localisation pour voir votre position." /></Bloc>
      </ScrollView>
    );
  }

  const m = vue.mParPx / zoom;
  const cLat = centre?.lat ?? vue.cLat, cLon = centre?.lon ?? vue.cLon;
  const X = (lon: number) => W / 2 + ((lon - cLon) * vue.kx) / m;
  const Y = (lat: number) => H / 2 - ((lat - cLat) * KY) / m;
  const longRayon = Math.hypot(W, H) * m; // les relèvements sont tracés jusqu'au bord
  const rayon = (lat: number, lon: number, deg: number) => {
    const a = (deg * Math.PI) / 180;
    return { x1: X(lon), y1: Y(lat), x2: X(lon) + (Math.sin(a) * longRayon) / m, y2: Y(lat) - (Math.cos(a) * longRayon) / m };
  };
  const echelle = choisirEchelle(m * W * 0.3);
  const trajetPts = e.trajet.map((p) => `${X(p.lon).toFixed(1)},${Y(p.lat).toFixed(1)}`).join(' ');
  const nUtiles = t.lignes.filter((l) => !l.ecartee).length, nEcartes = t.lignes.length - nUtiles;
  const capNid = f && pos ? capDeg(pos.lat, pos.lon, f.lat, f.lon) : null;
  const distNid = f && pos ? distM(pos.lat, pos.lon, f.lat, f.lon) : null;
  const nSources = f ? [f.nVoiture > 0, f.nOeil > 0, f.nPortatif > 0, f.nAnneaux + f.nCapsAppat > 0, f.nMarche > 0, f.nDrone > 0].filter(Boolean).length : 0;

  const bascule = (k: keyof Calques) => setCalques((c) => ({ ...c, [k]: !c[k] }));
  // densité : tous les nids du carnet, toutes saisons (où les nids reviennent d'une année sur l'autre)
  const PAS = 18;
  const densite = calques.densite ? grilleDensite(e.nids, (n) => ({ x: X(n.lon), y: Y(n.lat) }), W, H, m, PAS, P.densiteM) : [];
  const anCourant = e.nids.length ? Math.max(...e.nids.map((n) => new Date(n.t).getFullYear())) : 0;

  const envoyer = async () => {
    if (!f) return;
    try { await envoyerToit(cmdToit.nid(f.lat, f.lon, f.errM, t.id)); store.evenement(`Nid du tag ${idTag(t.id)} envoyé au portatif`); }
    catch (err) { Alert.alert('Envoi impossible', (err as Error).message); }
  };
  const noter = () => {
    if (!f) return;
    const deja = e.nids.find((n) => distM(n.lat, n.lon, f.lat, f.lon) < Math.max(30, f.errM));
    const creer = () => { const id = nouveauNid(t.id, f.lat, f.lon, f.errM, sourcesTexte(f)); if (id) router.push({ pathname: '/nid/[id]', params: { id: String(id) } }); };
    if (deja) Alert.alert('Carnet', `Le nid n° ${numeroNid(e.nids, deja.id)} est déjà noté à ${Math.round(distM(deja.lat, deja.lon, f.lat, f.lon))} m. Ajouter quand même un nouveau nid ?`, [
      { text: 'Ouvrir le nid existant', onPress: () => router.push({ pathname: '/nid/[id]', params: { id: String(deja.id) } }) },
      { text: 'Nouveau nid', onPress: creer }, { text: 'Annuler', style: 'cancel' }]);
    else creer();
  };

  // fond IGN : tuiles du niveau adapté à l'échelle, placées dans le repère local (approximation plane, bonne à quelques km)
  const tuiles: { uri: string; x: number; y: number; w: number; h: number; k: string }[] = [];
  if (fond !== 'aucun') {
    const la1 = cLat + (H / 2) * m / KY, la2 = cLat - (H / 2) * m / KY, lo1 = cLon - (W / 2) * m / vue.kx, lo2 = cLon + (W / 2) * m / vue.kx;
    const z = zoomPour(cLat, m);
    for (const tt of tuilesDe(la1, lo1, la2, lo2, z).slice(0, 80)) {
      const x0 = X(xVersLon(tt.x, z)), x1 = X(xVersLon(tt.x + 1, z)), y0 = Y(yVersLat(tt.y, z)), y1 = Y(yVersLat(tt.y + 1, z));
      tuiles.push({ uri: sourceTuile(fond, z, tt.x, tt.y), x: x0, y: y0, w: x1 - x0 + 0.5, h: y1 - y0 + 0.5, k: `${z}/${tt.x}/${tt.y}` });
    }
  }

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} scrollEnabled={!geste}>
      <ChoixTag />
      <View style={[s.ligne, { justifyContent: 'space-between' }]}>
        <Text style={{ fontSize: police.titre, fontWeight: '800', color: C.encre }}>{t.id >= 0 ? `Tag ${idTag(t.id)}` : 'Carte'}</Text>
        <Text style={s.discret}>{nUtiles} relèvements{nEcartes ? ` · ${nEcartes} écartés` : ''}</Text>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
        <Filtre actif={calques.voiture} couleur={C.accent} txt={`Voiture (${nUtiles})`} onPress={() => bascule('voiture')} />
        <Filtre actif={calques.ecartes} couleur={C.ecarte} txt={`Écartés (${nEcartes})`} onPress={() => bascule('ecartes')} />
        <Filtre actif={calques.oeil} couleur={C.oeil} txt={`${t.oeil.some((o) => o.src === 'tour') ? 'Œil / tours' : 'À l\'œil'} (${t.oeil.length})`} onPress={() => bascule('oeil')} />
        <Filtre actif={calques.portatif} couleur={C.portatif} txt={`Portatif (${t.portatif.length})`} onPress={() => bascule('portatif')} />
        {vol && <Filtre actif={calques.vol} couleur={couleurSignal(-70)} txt={`Vol drone (${mVol.length})`} onPress={() => bascule('vol')} />}
        {(e.pas[t.id]?.length ?? 0) > 0 && <Filtre actif={calques.pied} couleur={couleurSignal(-60)} txt={`Signal à pied (${e.pas[t.id].length})`} onPress={() => bascule('pied')} />}
        <Filtre actif={calques.appat} couleur={C.ok} txt={`Appâts (${appats.length})`} onPress={() => bascule('appat')} />
        <Filtre actif={calques.trajet} couleur={C.discret} txt="Trajet" onPress={() => bascule('trajet')} />
        <Filtre actif={calques.densite} couleur={C.alerte} txt={`Densité des nids (${e.nids.length})`} onPress={() => bascule('densite')} />
        {e.pieges.length > 0 && <Filtre actif={calques.pieges} couleur="#7A4FB5" txt={`Pièges (${e.pieges.filter(piegeActif).length})`} onPress={() => bascule('pieges')} />}
      </ScrollView>

      <View style={{ borderRadius: 14, overflow: 'hidden', borderWidth: 1, borderColor: C.ligne }}>
        <Animated.View {...pan.panHandlers} style={{ width: W, height: H, transform: [{ translateX: anim.tx }, { translateY: anim.ty }, { scale: anim.sc }] }}>
        <Svg width={W} height={H}>
          <Rect x={-W} y={-H} width={3 * W} height={3 * H} fill="#EEF0E8" />
          {tuiles.map((u) => <SvgImage key={u.k} href={{ uri: u.uri }} x={u.x} y={u.y} width={u.w} height={u.h} preserveAspectRatio="none" opacity={fond === 'photo' ? 0.85 : 0.7} />)}
          {densite.map((c) => <Rect key={`d${c.x}_${c.y}`} x={c.x - PAS / 2} y={c.y - PAS / 2} width={PAS} height={PAS} fill={c.v > 0.66 ? '#B3261E' : c.v > 0.33 ? '#E0603A' : '#F2B33D'} opacity={0.18 + 0.42 * c.v} />)}
          {calques.pieges && e.pieges.filter(piegeActif).map((p) => (
            <G key={`pg${p.id}`}>
              <Path d={`M${X(p.lon)},${Y(p.lat) - 8} L${X(p.lon) + 7},${Y(p.lat) + 6} L${X(p.lon) - 7},${Y(p.lat) + 6} Z`} fill="#7A4FB5" stroke="#fff" strokeWidth={1.5} />
              <T x={X(p.lon) + 9} y={Y(p.lat) + 5} fontSize={10} fontWeight="700" fill="#7A4FB5">{capturesPiege(p, anCourant || undefined)}</T>
            </G>
          ))}
          {e.ruchers.map((r) => (
            <G key={`r${r.id}`}>
              <Rect x={X(r.lon) - 7} y={Y(r.lat) - 7} width={14} height={14} rx={3} fill={C.encre} />
              <T x={X(r.lon) + 10} y={Y(r.lat) + 4} fontSize={11} fontWeight="700" fill={C.encre}>{r.nom}</T>
            </G>
          ))}
          {tel && !pos && <Circle cx={X(tel.lon)} cy={Y(tel.lat)} r={7} fill={C.oeil} stroke="#fff" strokeWidth={3} />}
          {e.nids.map((n) => (
            <G key={`n${n.id}`}>
              <Circle cx={X(n.lon)} cy={Y(n.lat)} r={6} fill={n.etat === 'mort' ? C.ok : n.etat === 'traite' ? C.accent : C.alerte} stroke="#fff" strokeWidth={2} />
              <T x={X(n.lon) + 9} y={Y(n.lat) - 6} fontSize={11} fontWeight="700" fill={C.encre}>n° {numeroNid(e.nids, n.id)}</T>
            </G>
          ))}
          {calques.trajet && e.trajet.length > 1 && <Polyline points={trajetPts} fill="none" stroke={C.discret} strokeWidth={2} opacity={0.45} />}
          {t.lignes.map((l, i) => {
            if (l.ecartee ? !calques.ecartes : !calques.voiture) return null;
            const r = rayon(l.lat, l.lon, l.absDeg);
            return (
              <G key={`l${i}`}>
                <Line {...r} stroke={l.ecartee ? C.ecarte : C.accent} strokeWidth={l.ecartee ? 1 : 1.5} strokeDasharray={l.ecartee ? '4 4' : undefined} opacity={l.ecartee ? 0.8 : 0.35 + (0.5 * l.q) / 100} />
                <Circle cx={r.x1} cy={r.y1} r={2.5} fill={l.ecartee ? C.ecarte : C.accent} />
              </G>
            );
          })}
          {calques.oeil && t.oeil.map((o, i) => {
            const r = rayon(o.lat, o.lon, o.deg);
            return (
              <G key={`o${i}`}>
                <Line {...r} stroke={C.oeil} strokeWidth={2} strokeDasharray="8 4" />
                <Circle cx={r.x1} cy={r.y1} r={4} fill={C.oeil} />
              </G>
            );
          })}
          {calques.vol && vol && <Polyline points={vol.points.map((p) => `${X(p.lon).toFixed(1)},${Y(p.lat).toFixed(1)}`).join(' ')} fill="none" stroke="#555" strokeWidth={1} opacity={0.4} />}
          {calques.vol && mVol.map((p, i) => <Rect key={`v${i}`} x={X(p.lon) - 3} y={Y(p.lat) - 3} width={6} height={6} fill={couleurSignal(p.rssi)} opacity={0.85} />)}
          {calques.vol && (() => { const b = mVol.reduce<(typeof mVol)[number] | null>((m, p) => (!m || p.rssi > m.rssi ? p : m), null); return b ? <Rect x={X(b.lon) - 9} y={Y(b.lat) - 9} width={18} height={18} fill="none" stroke={couleurSignal(b.rssi)} strokeWidth={3} /> : null; })()}
          {calques.vol && vol && (() => { const e3 = nid3DDe(vol, t.id); return e3 ? (
            <>
              <Circle cx={X(e3.lon)} cy={Y(e3.lat)} r={Math.max(6, e3.errM / m)} fill="none" stroke={C.alerte} strokeDasharray="5 3" strokeWidth={2} />
              <Circle cx={X(e3.lon)} cy={Y(e3.lat)} r={4} fill={C.alerte} />
            </>
          ) : null; })()}
          {calques.pied && e.portatif.est && e.portatif.est.tag === t.id && e.portatif.est.ok > 0 && (
            <>
              <Circle cx={X(e.portatif.est.lon)} cy={Y(e.portatif.est.lat)} r={Math.max(6, e.portatif.est.err / m)} fill={C.portatif} opacity={0.15} stroke={C.portatif} strokeDasharray="4 3" />
              <Circle cx={X(e.portatif.est.lon)} cy={Y(e.portatif.est.lat)} r={5} fill={C.portatif} />
            </>
          )}
          {calques.pied && (e.pas[t.id] ?? []).map((p, i) => <Circle key={`s${i}`} cx={X(p.lon)} cy={Y(p.lat)} r={3.5} fill={couleurSignal(p.rssi)} opacity={0.85} />)}
          {calques.pied && (() => { const pf = pointFort(e.pas[t.id]); return pf ? <Circle cx={X(pf.lon)} cy={Y(pf.lat)} r={10} fill="none" stroke={couleurSignal(pf.rssi)} strokeWidth={3} /> : null; })()}
          {calques.portatif && t.portatif.map((p, i) => (
            <G key={`p${i}`}>
              <Circle cx={X(p.lon)} cy={Y(p.lat)} r={Math.max(p.errM / m, 4)} fill={C.portatif} opacity={0.15} />
              <Circle cx={X(p.lon)} cy={Y(p.lat)} r={4} fill={C.portatif} />
            </G>
          ))}
          {calques.appat && appats.map(({ a, r }) => {
            const cx = X(a.lon), cy = Y(a.lat);
            const ligne = r.cap !== null ? rayon(a.lat, a.lon, r.cap) : null;
            return (
              <G key={`a${a.id}`}>
                {r.rt.ok && <Circle cx={cx} cy={cy} r={r.rt.r / m} fill="none" stroke={C.ok} strokeWidth={Math.max((2 * r.rt.sig) / m, 2)} opacity={0.18} />}
                {r.rt.ok && <Circle cx={cx} cy={cy} r={r.rt.r / m} fill="none" stroke={C.ok} strokeWidth={1.5} strokeDasharray="6 4" />}
                {ligne && <Line {...ligne} stroke={C.ok} strokeWidth={2} />}
                <Rect x={cx - 6} y={cy - 6} width={12} height={12} fill={C.ok} stroke="#fff" strokeWidth={2} />
                <T x={cx + 9} y={cy + 16} fontSize={12} fontWeight="700" fill={C.ok}>Appât {a.id}</T>
              </G>
            );
          })}
          {f && (
            <G>
              <Circle cx={X(f.lon)} cy={Y(f.lat)} r={Math.max(f.errM / m, 6)} fill={C.accent} opacity={0.18} stroke={C.accent} strokeWidth={2} />
              <Circle cx={X(f.lon)} cy={Y(f.lat)} r={7} fill={C.encre} stroke="#fff" strokeWidth={2.5} />
              <T x={X(f.lon) + 12} y={Y(f.lat) - 10} fontSize={13} fontWeight="700" fill={C.encre}>Nid ± {Math.round(f.errM)} m</T>
            </G>
          )}
          {cr?.besoin && (
            <G>
              <Line x1={X(f!.lon)} y1={Y(f!.lat)} x2={X(cr.lon)} y2={Y(cr.lat)} stroke={C.oeil} strokeWidth={1.5} strokeDasharray="3 5" opacity={0.7} />
              <Circle cx={X(cr.lon)} cy={Y(cr.lat)} r={Math.max(60 / m, 10)} fill={C.oeil} opacity={0.12} stroke={C.oeil} strokeWidth={2} strokeDasharray="6 4" />
              <T x={X(cr.lon)} y={Y(cr.lat) + 4} fontSize={11} fontWeight="700" fill={C.oeil} textAnchor="middle">croiser ici</T>
            </G>
          )}
          {equipiers.map((q) => (
            <G key={`eq${q.utilisateur}`}>
              {q.nid && q.tag === t.id && <Circle cx={X(q.nid.lon)} cy={Y(q.nid.lat)} r={Math.max(q.nid.err / m, 6)} fill="none" stroke="#1F5FAD" strokeWidth={2} strokeDasharray="5 4" />}
              <Circle cx={X(q.lon)} cy={Y(q.lat)} r={7} fill="#1F5FAD" stroke="#fff" strokeWidth={2.5} />
              <T x={X(q.lon) + 10} y={Y(q.lat) + 4} fontSize={12} fontWeight="700" fill="#1F5FAD">{q.nom}</T>
            </G>
          ))}
          {voiture && (
            <G>
              <Rect x={X(voiture.lon) - 9} y={Y(voiture.lat) - 9} width={18} height={18} rx={4} fill="#1F5FAD" stroke="#fff" strokeWidth={2} />
              <T x={X(voiture.lon)} y={Y(voiture.lat) + 5} fontSize={13} fontWeight="800" fill="#fff" textAnchor="middle">P</T>
            </G>
          )}
          {pos && (
            <G transform={`rotate(${pos.cap} ${X(pos.lon)} ${Y(pos.lat)})`}>
              <Path d={`M${X(pos.lon)},${Y(pos.lat) - 11} L${X(pos.lon) + 7},${Y(pos.lat) + 8} L${X(pos.lon)},${Y(pos.lat) + 4} L${X(pos.lon) - 7},${Y(pos.lat) + 8} Z`} fill={C.encre} stroke="#fff" strokeWidth={1.5} />
            </G>
          )}
        </Svg>
        </Animated.View>
        <Svg width={W} height={H} style={{ position: 'absolute', left: 0, top: 0 }} pointerEvents="none">
          {/* nord et échelle */}
          <G>
            <Path d={`M${W - 24},14 L${W - 18},30 L${W - 24},26 L${W - 30},30 Z`} fill={C.encre} />
            <T x={W - 24} y={44} fontSize={12} fontWeight="700" fill={C.encre} textAnchor="middle">N</T>
          </G>
          <G>
            <Line x1={14} y1={H - 16} x2={14 + echelle / m} y2={H - 16} stroke={C.encre} strokeWidth={3} />
            <Line x1={14} y1={H - 22} x2={14} y2={H - 10} stroke={C.encre} strokeWidth={2} />
            <Line x1={14 + echelle / m} y1={H - 22} x2={14 + echelle / m} y2={H - 10} stroke={C.encre} strokeWidth={2} />
            <T x={14 + echelle / m / 2} y={H - 26} fontSize={12} fill={C.encre} textAnchor="middle">{fmtDist(echelle)}</T>
          </G>
        </Svg>
        <View style={{ position: 'absolute', right: 10, bottom: 10, gap: 8 }}>
          <Rond txt="+" onPress={() => setZoom((z) => Math.min(z * 1.6, 40))} />
          <Rond txt="−" onPress={() => setZoom((z) => Math.max(z / 1.6, 0.3))} />
          <Rond txt="⤢" onPress={() => { setZoom(1); setCentre(null); }} />
        </View>
      </View>

      {f ? (
        <Bloc>
          <Titre>Nid estimé · {nSources > 1 ? `${nSources} sources concordantes` : 'relèvements de la voiture'}</Titre>
          <View style={[s.ligne, { justifyContent: 'space-between' }]}>
            <Chiffre k="Distance" v={distNid !== null ? fmtDist(distNid) : '—'} />
            <Chiffre k="Cap" v={capNid !== null ? `${Math.round(capNid)}° ${pointCardinal(capNid)}` : '—'} />
            <Chiffre k="Précision" v={`± ${Math.round(f.errM)} m`} />
          </View>
          <Text style={[s.discret, { marginTop: 8 }]}>{fmtCoord(f.lat, f.lon)}</Text>
          <View style={[s.ligne, { gap: 10, marginTop: 12 }]}>
            <Bouton titre="Envoyer au portatif" plein onPress={envoyer} />
            <Bouton titre="Ajouter au carnet" onPress={noter} />
          </View>
          <View style={{ marginTop: 10 }}><Bouton titre="Y aller par la route" onPress={() => { allerParLaRoute(f.lat, f.lon).catch(() => {}); }} /></View>
        </Bloc>
      ) : t.id < 0 ? null : (
        <Bloc>
          <Vide titre="Pas encore de nid" texte="Il faut au moins deux relèvements qui se croisent nettement (plus de 15°). Faites le tour de la zone." />
        </Bloc>
      )}
      {f && cr?.besoin && (
        <Bloc style={{ borderColor: C.oeil }}>
          <Titre>Pour croiser les relèvements</Titre>
          <Text style={{ color: C.encre }}>
            Ils partent tous du même côté du nid (trou de {cr.trouDeg}°) : un relevé au <Text style={{ fontWeight: '800' }}>{pointCardinal(cr.dirDeg)}</Text> du nid,
            à ~{fmtDist(cr.distM)}, resserrerait nettement l'estimation.
            {pos ? ` Ce point est à ${fmtDist(distM(pos.lat, pos.lon, cr.lat, cr.lon))} de vous, cap ${Math.round(capDeg(pos.lat, pos.lon, cr.lat, cr.lon))}°.` : ''}
          </Text>
          <View style={{ marginTop: 10 }}><Bouton titre="Trouver la route la plus proche" onPress={() => { routePourCroiserEnLigne(f, cr).catch(() => {}); }} /></View>
        </Bloc>
      )}
      {voiture && (!pos || e.portatif.connexion === 'connecte') && (
        <Bloc>
          <View style={[s.ligne, { justifyContent: 'space-between' }]}>
            <Titre>Voiture garée</Titre>
            <Text style={s.discret}>{(() => { const ici = e.portatif.st?.fix ? e.portatif.st : tel; return ici ? `à ${fmtDist(distM(ici.lat, ici.lon, voiture.lat, voiture.lon))}` : ''; })()}</Text>
          </View>
          <Text style={s.discret}>Notée {voiture.src === 'toit' ? 'à l\'arrêt du toit' : voiture.src === 'portatif' ? 'par le portatif près du toit' : 'à la main'} à {new Date(voiture.t).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}. Le portatif la connaît aussi (menu → Retour à la voiture).</Text>
          <View style={[s.ligne, { gap: 10, marginTop: 10 }]}>
            <Bouton titre="Flèche du portatif" desactive={e.portatif.connexion !== 'connecte'} onPress={() => { retourVoiture().catch(() => {}); }} />
            <Bouton titre="Guidage à pied" onPress={() => { retourVoiture(true).catch(() => {}); }} />
          </View>
        </Bloc>
      )}
      {equipiers.length > 0 && (
        <Bloc>
          <Titre>Équipe en direct</Titre>
          {equipiers.map((q) => {
            const ici = e.portatif.st?.fix ? e.portatif.st : pos ?? tel;
            const age = Math.max(0, Math.round((maintenantMs - q.majMs) / 60000));
            return (
              <View key={q.utilisateur} style={[s.ligne, { justifyContent: 'space-between', paddingVertical: 6 }]}>
                <View style={{ flex: 1 }}>
                  <Text style={{ color: C.encre, fontWeight: '700' }}>{q.nom}{q.tag !== null ? ` · tag ${idTag(q.tag)}` : ''}</Text>
                  <Text style={s.discret}>{ici ? `à ${fmtDist(distM(ici.lat, ici.lon, q.lat, q.lon))} ${pointCardinal(capDeg(ici.lat, ici.lon, q.lat, q.lon))} · ` : ''}{age < 1 ? 'à l\'instant' : `il y a ${age} min`}{q.nid ? ` · son nid ± ${Math.round(q.nid.err)} m` : ''}</Text>
                </View>
                <Pressable onPress={() => { envoyerCible(q.lat, q.lon, q.nom.slice(0, 18).toUpperCase()).catch(() => {}); }} style={s.puce}><Text style={s.puceTxt}>Flèche</Text></Pressable>
              </View>
            );
          })}
        </Bloc>
      )}
      <BandeauToit />
    </ScrollView>
  );
}

function choisirEchelle(m: number) {
  const pas = [10, 20, 50, 100, 200, 250, 500, 1000, 2000, 5000];
  return pas.reduce((b, p) => (p <= m ? p : b), 10);
}

function Filtre({ actif, couleur, txt, onPress }: { actif: boolean; couleur: string; txt: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={[s.puce, s.ligne, { gap: 6, opacity: actif ? 1 : 0.45 }]}>
      <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: couleur }} />
      <Text style={{ color: C.encre, fontSize: police.petit }}>{txt}</Text>
    </Pressable>
  );
}

function Rond({ txt, onPress }: { txt: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: C.carte, borderWidth: 1, borderColor: C.ligne, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: 20, color: C.encre, fontWeight: '700' }}>{txt}</Text>
    </Pressable>
  );
}

function Chiffre({ k, v }: { k: string; v: string }) {
  return (
    <View>
      <Text style={s.discret}>{k}</Text>
      <Text style={{ fontSize: police.normal + 1, fontWeight: '700', color: C.encre, fontVariant: ['tabular-nums'] }}>{v}</Text>
    </View>
  );
}
