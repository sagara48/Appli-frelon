/** Écran Chrono (É4) : temps d'aller-retour du frelon tagué à l'appât → distance du nid ; caps → direction. */
import { useRouter } from 'expo-router';
import { useKeepAwake } from 'expo-keep-awake';
import React, { useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, Titre, Vide, s } from '@/ui/composants';
import { C, fmtDist, idTag, police } from '@/ui/theme';
import { chronoLacher, chronoManuel, chronoReglages, chronoSupprimer, maintenant, store, useEtat } from '@/store/store';
import { appatActif, appatSuivant, resume } from '@/calc/appat';
import { pointCardinal } from '@/calc/geo';

const mmss = (s: number) => `${Math.floor(s / 60)} min ${String(Math.round(s % 60)).padStart(2, '0')} s`;
const horloge = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

export default function Chrono() {
  useKeepAwake();
  const router = useRouter();
  const e = useEtat((x) => ({ chrono: x.chrono, tags: x.tags, tagChoisi: x.tagChoisi, toit: x.toit, portatif: x.portatif, horlogeMs: x.horlogeMs, source: x.source }));
  const [, setTic] = useState(0);
  const [capPortatif, setCapPortatif] = useState(true);
  useEffect(() => { const i = setInterval(() => setTic((n) => n + 1), 1000); return () => clearInterval(i); }, []);

  const ids = [...new Set([...Object.keys(e.tags).map(Number), ...e.chrono.appats.map((a) => a.tag), ...(e.portatif.st && e.portatif.st.tag >= 0 ? [e.portatif.st.tag] : [])])].sort((a, b) => a - b);
  const tag = e.tagChoisi ?? ids[0] ?? null;
  const a = tag !== null ? appatActif(e.chrono, tag) : null;

  // position pour « Lâcher ici » : voiture si le toit a une position, sinon portatif
  const pst = e.portatif.connexion === 'connecte' ? e.portatif.st : null;
  const pos = e.toit && e.toit.lat ? { lat: e.toit.lat, lon: e.toit.lon, src: 'voiture' as const }
    : pst && pst.fix ? { lat: pst.lat, lon: pst.lon, src: 'main' as const } : null;
  const capDispo = !!pst; // cap pointé avec le portatif au moment d'appuyer
  const cap = () => (capDispo && capPortatif ? Math.round(pst!.hdg) : null);

  const lacherIci = () => {
    if (tag === null) { Alert.alert('Chrono', 'Choisissez d\'abord le tag.'); return; }
    if (!pos) { Alert.alert('Chrono', 'Pas de position : connectez le toit (voiture garée à l\'appât) ou le portatif avec le GPS.'); return; }
    chronoLacher(tag, pos.lat, pos.lon, pos.src);
  };

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
        <Text style={[s.discret, { alignSelf: 'center' }]}>TAG</Text>
        {ids.map((id) => (
          <Pressable key={id} onPress={() => store.choisirTag(id)} style={[s.puce, id === tag && s.puceActive]}>
            <Text style={[s.puceTxt, id === tag && { fontWeight: '700' }]}>{idTag(id)}</Text>
          </Pressable>
        ))}
        {!ids.length && <Text style={s.discret}>aucun tag entendu</Text>}
      </ScrollView>

      {!a ? (
        <Carte>
          <Vide titre="Pas d'appât pour ce tag" texte={'Garez la voiture à moins de 20 m de l\'appât, nez vers lui, puis « Lâcher ici » au moment où vous lâchez le frelon tagué. Le toit chronomètre seul ses allers-retours.\n\nSans la voiture : « Lâcher ici » prend la position du portatif, et vous notez les départs et retours à la main.'} />
          <Bouton titre="Lâcher ici" plein onPress={lacherIci} desactive={tag === null} />
          <Text style={[s.discret, { textAlign: 'center', marginTop: 8 }]}>
            {pos ? `Position : ${pos.src === 'voiture' ? 'voiture (toit)' : 'portatif'}` : 'Aucune position disponible'}
          </Text>
        </Carte>
      ) : (
        EcranAppat({ a, tag: tag! })
      )}
    </ScrollView>
  );

  function EcranAppat({ a, tag }: { a: NonNullable<ReturnType<typeof appatActif>>; tag: number }) {
    const r = resume(e.chrono, a);
    const durees = a.trajets.map((t) => t.dureeS).sort((x, y) => x - y);
    const habituel = durees.length ? durees[Math.floor(durees.length / 2)] : null;
    const ecoule = a.etat === 2 ? Math.max(0, (maintenant() - a.depart) / 1000) : 0;
    const f = e.tags[tag]?.fusion;
    const suivant = appatSuivant(e.chrono, tag, f?.ok && f.nVoiture + f.nOeil + f.nPortatif > 0 ? f : null);
    const nAppats = e.chrono.appats.filter((x) => x.tag === tag).length;
    const etat = a.etat === 2 ? 'PARTI' : a.source === 'voiture' ? (a.maxr > -128 ? 'À L\'APPÂT' : 'EN ATTENTE DU TAG') : 'À L\'APPÂT';
    return (
      <>
        <View style={[s.ligne, { justifyContent: 'space-between' }]}>
          <View>
            <Text style={{ fontSize: police.titre, fontWeight: '800', color: C.encre }}>Appât {a.id}</Text>
            <Text style={s.discret}>{a.source === 'voiture' ? 'écoute par la voiture (automatique)' : 'chronométré à la main'}{nAppats > 1 ? ` · ${nAppats} appâts pour ce tag` : ''}</Text>
          </View>
          <Pressable onPress={() => Alert.alert('Nouvel appât', 'Ouvrir un appât à la position actuelle ? (à plus de 30 m, sinon on reprend celui-ci)', [
            { text: 'Annuler', style: 'cancel' }, { text: 'Lâcher ici', onPress: lacherIci }])} style={[s.puce, { borderColor: C.encre }]}>
            <Text style={[s.puceTxt, { fontSize: police.petit, fontWeight: '700' }]}>Lâcher ici</Text>
          </Pressable>
        </View>

        <Carte style={{ alignItems: 'center', backgroundColor: a.etat === 2 ? C.encre : C.carte }}>
          <Text style={{ fontSize: police.petit, fontWeight: '700', letterSpacing: 1.5, color: a.etat === 2 ? C.accent : C.discret }}>{etat}</Text>
          <Text style={{ fontSize: 64, fontWeight: '800', color: a.etat === 2 ? '#fff' : C.encre, fontVariant: ['tabular-nums'] }}>
            {a.etat === 2 ? horloge(ecoule) : '—'}
          </Text>
          <Text style={{ color: a.etat === 2 ? '#A9B4BF' : C.discret }}>
            {habituel ? `Retour habituel vers ${mmss(habituel)}` : a.etat === 2 ? 'Premier aller-retour en cours' : 'Le chrono part quand le frelon s\'en va'}
          </Text>
          {a.etat === 2 && habituel !== null && ecoule > habituel * 1.6 && (
            <Text style={{ color: C.accent, marginTop: 6 }}>Plus long que d'habitude : il chasse peut-être en route</Text>
          )}
        </Carte>

        <View style={[s.ligne, { gap: 10 }]}>
          <Bouton titre="Parti (à la main)" onPress={() => chronoManuel(tag, 'parti', cap())} />
          <Bouton titre="Revenu (à la main)" desactive={a.etat !== 2} onPress={() => chronoManuel(tag, 'revenu', cap())} />
        </View>
        {capDispo && (
          <Pressable onPress={() => setCapPortatif(!capPortatif)} style={[s.ligne, { gap: 8 }]}>
            <View style={{ width: 20, height: 20, borderRadius: 4, borderWidth: 2, borderColor: C.encre, backgroundColor: capPortatif ? C.accent : 'transparent' }} />
            <Text style={{ color: C.encre, flex: 1 }}>Noter aussi le cap pointé avec le portatif ({Math.round(pst!.hdg)}° {pointCardinal(pst!.hdg)}) : visez la direction du vol en appuyant</Text>
          </Pressable>
        )}

        <Carte>
          <View style={[s.ligne, { justifyContent: 'space-between' }]}>
            <Titre>Allers-retours</Titre>
            <Text style={[s.discret, { marginBottom: 8 }]}>cap départ / retour</Text>
          </View>
          {!a.trajets.length && <Text style={s.discret}>Aucun pour l'instant.</Text>}
          {a.trajets.map((t, i) => (
            <View key={i} style={[s.ligne, { paddingVertical: 6, borderTopWidth: i ? 1 : 0, borderTopColor: C.ligne }]}>
              <Text style={{ width: 26, color: C.discret, fontVariant: ['tabular-nums'] }}>{i + 1}</Text>
              <Text style={{ flex: 1, color: C.encre, fontWeight: t.dureeS === r.rt.tMin ? '800' : '400', fontVariant: ['tabular-nums'] }}>{mmss(t.dureeS)}</Text>
              <Text style={{ color: C.encre, fontVariant: ['tabular-nums'] }}>
                {t.capDep !== null ? `${Math.round(t.capDep)}°` : '—'} / {t.capRet !== null ? `${Math.round(t.capRet)}°` : '—'}
              </Text>
            </View>
          ))}
        </Carte>

        {r.rt.ok && (
          <Carte style={{ borderColor: C.accent, borderWidth: 2 }}>
            <Text style={{ fontSize: 28, fontWeight: '800', color: C.encre }}>Nid à {fmtDist(r.rt.r)}</Text>
            <View style={[s.ligne, { gap: 18, marginTop: 4 }]}>
              <Text style={{ color: C.encre }}>Précision ± {Math.round(r.rt.sig)} m</Text>
              <Text style={{ color: C.encre }}>{r.cap !== null ? `Direction ${Math.round(r.cap)}° ${pointCardinal(r.cap)}` : 'Direction inconnue'}</Text>
            </View>
            <Text style={[s.discret, { marginTop: 8, lineHeight: 19 }]}>
              Vitesse frelon {e.chrono.reglages.vitesse.toFixed(1).replace('.', ',')} m/s · {e.chrono.reglages.auNid} s au nid · calcul sur le trajet le plus rapide confirmé ({mmss(r.rt.tMin)})
              {r.nCaps ? ` · cap moyen de ${a.nDep} départ${a.nDep > 1 ? 's' : ''} et ${a.nRet} retour${a.nRet > 1 ? 's' : ''}` : ''}
            </Text>
            {r.rt.tMin < 90 && <Text style={{ color: C.alerte, fontWeight: '700', marginTop: 8 }}>Nid tout proche : finir au portatif.</Text>}
            <View style={{ height: 1, backgroundColor: C.ligne, marginVertical: 12 }} />
            <Text style={{ color: C.encre, fontWeight: '700' }}>
              {suivant.ok ? `Appât suivant : ${fmtDist(suivant.dist)} au cap ${Math.round(suivant.cap)}° ${pointCardinal(suivant.cap)}` : suivant.message}
            </Text>
            {suivant.ok && <Text style={[s.discret, { marginTop: 4 }]}>Un peu sur le côté, pour que les deux anneaux se croisent nettement (reste ~{fmtDist(suivant.reste)}).</Text>}
            <View style={{ marginTop: 12 }}><Bouton titre="Voir sur la carte" onPress={() => router.navigate('/carte')} /></View>
          </Carte>
        )}

        <Carte>
          <Titre>Réglages du calcul</Titre>
          <Pas k="Vitesse du frelon" v={`${e.chrono.reglages.vitesse.toFixed(1).replace('.', ',')} m/s`}
            moins={() => chronoReglages({ vitesse: Math.max(1.5, +(e.chrono.reglages.vitesse - 0.1).toFixed(1)) })}
            plus={() => chronoReglages({ vitesse: Math.min(7, +(e.chrono.reglages.vitesse + 0.1).toFixed(1)) })} />
          <Pas k="Temps passé au nid" v={`${e.chrono.reglages.auNid} s`}
            moins={() => chronoReglages({ auNid: Math.max(10, e.chrono.reglages.auNid - 5) })}
            plus={() => chronoReglages({ auNid: Math.min(300, e.chrono.reglages.auNid + 5) })} />
          <Text style={[s.discret, { marginTop: 6, fontSize: police.mini }]}>Valeurs habituelles : 3,4 m/s et 55 s. Elles se règlent mieux une fois un premier nid trouvé.</Text>
          <Pressable onPress={() => Alert.alert('Supprimer l\'appât', `Supprimer l'appât ${a.id} et ses ${a.trajets.length} allers-retours ?`, [
            { text: 'Annuler', style: 'cancel' }, { text: 'Supprimer', style: 'destructive', onPress: () => chronoSupprimer(a.id) }])}
            style={{ marginTop: 14, alignSelf: 'center' }}>
            <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Supprimer cet appât</Text>
          </Pressable>
        </Carte>
      </>
    );
  }
}

function Pas({ k, v, moins, plus }: { k: string; v: string; moins: () => void; plus: () => void }) {
  const b = { width: 40, height: 36, borderRadius: 8, borderWidth: 1, borderColor: C.ligne, alignItems: 'center' as const, justifyContent: 'center' as const };
  return (
    <View style={[s.ligne, { justifyContent: 'space-between', marginVertical: 4 }]}>
      <Text style={{ color: C.encre, flex: 1 }}>{k}</Text>
      <Pressable onPress={moins} style={b}><Text style={{ fontSize: 20, color: C.encre }}>−</Text></Pressable>
      <Text style={{ width: 80, textAlign: 'center', color: C.encre, fontWeight: '700', fontVariant: ['tabular-nums'] }}>{v}</Text>
      <Pressable onPress={plus} style={b}><Text style={{ fontSize: 20, color: C.encre }}>+</Text></Pressable>
    </View>
  );
}
