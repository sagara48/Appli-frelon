/** Écran Suivi (É1) : où est le tag suivi, en ce moment. */
import { useRouter } from 'expo-router';
import { useKeepAwake } from 'expo-keep-awake';
import React from 'react';
import { Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { Boussole } from '@/ui/Boussole';
import { BandeauToit, Bouton, Carte, ChoixTag, Titre, Vide, s } from '@/ui/composants';
import { C, VOIES, fmtAge, fmtDist, idTag, libelleQualite, libelleRelatif, police } from '@/ui/theme';
import { ageS, maintenant, useEtat } from '@/store/store';
import { bilanActivite, texteActivite } from '@/calc/activite';
import { envoyerCible } from '@/services/cible';
import { capDeg, distM, niveauPct, pointCardinal } from '@/calc/geo';
import { distanceRssi, texteDistance } from '@/calc/distance';
import { modeleDistance, useParametres } from '@/services/parametres';
import { useModeExpert } from '@/services/expert';
import { connecterToit } from '@/sources/ble';
import { demarrerSimulation } from '@/sources/simulation';

export default function Direct() {
  const P = useParametres();
  const expert = useModeExpert();
  useKeepAwake(); // l'écran reste allumé pendant la conduite
  const router = useRouter();
  const { width } = useWindowDimensions();
  const e = useEtat((x) => x);
  const [, tic] = React.useState(0);
  React.useEffect(() => { const i = setInterval(() => tic((n) => n + 1), 1000); return () => clearInterval(i); }, []); // âge du dernier signal
  const t = e.tagChoisi !== null ? e.tags[e.tagChoisi] : undefined;

  if (e.source === 'aucune') {
    const recherche = e.connexion === 'recherche';
    return (
      <ScrollView style={s.ecran} contentContainerStyle={[s.contenu, { paddingTop: 28 }]}>
        <Text style={{ color: C.encre, fontSize: 26, fontWeight: '800' }}>Prêt à partir ?</Text>
        <Text style={[s.discret, { marginBottom: 8 }]}>Allumez le récepteur de toit, puis touchez « Connecter ». La direction du tag s'affichera ici.</Text>
        <Bouton titre={recherche ? 'Recherche du toit…' : 'Connecter le toit'} plein desactive={recherche} onPress={() => { connecterToit().catch(() => {}); }} />
        <Bouton titre="Chercher à pied (portatif)" onPress={() => router.navigate('/portatif')} />
        <Bouton titre="Poser un tag" onPress={() => router.push('/pose-tag')} />
        {!!e.message && <Text style={[s.discret, { textAlign: 'center' }]}>{e.message}</Text>}
        <Pressable onPress={() => { demarrerSimulation(); }} style={{ alignSelf: 'center', padding: 14, marginTop: 8 }}>
          <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Essayer sans matériel (sortie simulée)</Text>
        </Pressable>
      </ScrollView>
    );
  }

  const age = t ? ageS(e, t) : 0;
  const dTag = t && age < 30 ? distanceRssi(Math.max(...t.r), modeleDistance('toit', P)) : null;
  const tdTag = dTag ? texteDistance(dTag) : null;
  const ancien = age > 10;
  const abs = t && t.abs >= 0 ? t.abs : null;
  const f = t?.fusion?.ok ? t.fusion : null;
  const pos = e.toit && e.toit.lat ? e.toit : null;
  const capNid = f && pos ? capDeg(pos.lat, pos.lon, f.lat, f.lon) : null;
  const distNid = f && pos ? distM(pos.lat, pos.lon, f.lat, f.lon) : null;

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <BandeauToit />
      <ChoixTag />
      {!t ? (
        <Carte><Vide titre="En écoute…" texte="Aucun tag entendu pour l'instant. Roulez dans la zone du lâcher." /></Carte>
      ) : (
        <>
          <Carte style={{ alignItems: 'center' }}>
            <Boussole taille={Math.min(width - 60, 340)} abs={abs} cap={pos ? pos.cap : null} capNid={capNid} ancien={ancien} />
            <View style={[s.ligne, { gap: 10, marginTop: 4 }]}>
              <Text style={{ fontSize: 44, fontWeight: '800', color: ancien ? C.discret : C.encre, fontVariant: ['tabular-nums'] }}>
                {abs !== null ? `${Math.round(abs)}°` : '—'}
              </Text>
              {abs !== null && <Text style={{ fontSize: 26, fontWeight: '700', color: C.accent }}>{pointCardinal(abs)}</Text>}
            </View>
            <Text style={[s.discret, { textAlign: 'center' }]}>
              {ancien ? `Dernier signal il y a ${fmtAge(age)}` : t.rel >= 0 ? `${libelleRelatif(t.rel)} · qualité ${libelleQualite(t.q)}` : 'Direction inconnue'}
            </Text>
          </Carte>

          {expert && <Carte>
            <Titre>Niveaux reçus · % du signal</Titre>
            {VOIES.map((v, k) => {
              const p = niveauPct(t.r[k]);
              const max = Math.max(...t.r.slice(0, 4));
              return (
                <View key={v} style={[s.ligne, { marginVertical: 4 }]}>
                  <Text style={{ width: 70, color: C.encre, fontSize: police.petit }}>{v}</Text>
                  <View style={{ flex: 1, height: 10, borderRadius: 5, backgroundColor: C.fond, overflow: 'hidden' }}>
                    <View style={{ width: `${p ?? 0}%`, height: '100%', backgroundColor: k < 4 && t.r[k] === max && !ancien ? C.accent : C.encre, opacity: ancien ? 0.35 : 1 }} />
                  </View>
                  <Text style={{ width: 44, textAlign: 'right', color: C.encre, fontVariant: ['tabular-nums'] }}>{p === null ? '—' : p}</Text>
                </View>
              );
            })}
          </Carte>}

          <Carte>
            <View style={[s.ligne, { justifyContent: 'space-between' }]}>
              <Chiffre k="Relèvements" v={`${t.nReleves}`} />
              <Chiffre k="Dernier signal" v={`il y a ${fmtAge(age)}`} />
              <Chiffre k="Distance du tag" v={tdTag ? tdTag.court : '—'} />
              <Chiffre k="Pile du tag" v={t.pile >= 0 ? `${t.pile} %` : '—'} />
            </View>
            {(() => {
              const a = e.activites[t.id], tx = texteActivite(a, maintenant()), b = bilanActivite(a, maintenant());
              if (!tx || !b) return null;
              return (
                <Text style={{ marginTop: 8, color: a!.nid ? C.encre : C.ok, fontWeight: '700' }}>
                  {tx}{b.sortiesJour ? ` · ${b.sortiesJour} sortie${b.sortiesJour > 1 ? 's' : ''} aujourd'hui` : ''}{b.dureeMedianeMin !== null ? ` · ${b.dureeMedianeMin} min par sortie` : ''}
                </Text>
              );
            })()}
          </Carte>

          {f && (
            <Carte style={{ borderColor: C.accent, borderWidth: 2 }}>
              <Titre>Nid estimé · tag {idTag(t.id)}</Titre>
              <View style={[s.ligne, { justifyContent: 'space-between' }]}>
                <Chiffre k="Distance" v={distNid !== null ? fmtDist(distNid) : '—'} />
                <Chiffre k="Cap" v={capNid !== null ? `${Math.round(capNid)}° ${pointCardinal(capNid)}` : '—'} />
                <Chiffre k="Précision" v={`± ${Math.round(f.errM)} m`} />
              </View>
              <View style={[s.ligne, { marginTop: 12, gap: 10 }]}>
                <Bouton titre="Voir sur la carte" onPress={() => router.navigate('/carte')} />
                {e.portatif.connexion === 'connecte' && <Bouton titre="Envoyer au portatif" onPress={() => envoyerCible(f.lat, f.lon, `Nid tag ${idTag(t.id)}`)} />}
              </View>
            </Carte>
          )}
        </>
      )}
      {t && (
        <View style={[s.ligne, { gap: 10 }]}>
          <Bouton titre="Mode conduite" onPress={() => router.push('/conduite')} />
          <Bouton titre="Direction à l'œil" onPress={() => router.push('/cap-oeil')} />
        </View>
      )}
      {e.evenements.length > 0 && <Text style={[s.discret, { textAlign: 'center' }]}>{e.evenements[0]}</Text>}
    </ScrollView>
  );
}

function Chiffre({ k, v }: { k: string; v: string }) {
  return (
    <View>
      <Text style={s.discret}>{k}</Text>
      <Text style={{ fontSize: police.normal + 1, fontWeight: '700', color: C.encre, fontVariant: ['tabular-nums'] }}>{v}</Text>
    </View>
  );
}
