/** Menu (É5) : appareils, tous les écrans regroupés par usage, essai sans matériel ; réglages techniques en mode expert. */
import { useRouter } from 'expo-router';
import React, { useEffect, useState, useSyncExternalStore } from 'react';
import { Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { BandeauToit, Bouton, Carte, Interrupteur, LigneLien, Titre, s, useMaintenant } from '@/ui/composants';
import { C, VOIES, nbVoies, police } from '@/ui/theme';
import { Pas, signe } from '@/ui/Pas';
import { definirArretAuto, store, terminerSortie, useEtat } from '@/store/store';
import { abonnerArrierePlan, activerArrierePlan, arrierePlanActive, etatArrierePlan } from '@/services/arrierePlan';
import { abonnerPartage, etatPartage, lireConfig } from '@/services/partage';
import { useSession } from '@/services/auth';
import { BUILD } from '@/services/majAppli';
import { changerModeExpert, useModeExpert } from '@/services/expert';
import { aControler } from '@/calc/intervention';
import { lireValeur } from '@/db';
import { etapesDatees } from '@/calc/calendrier';
import { lireCalendrier } from '@/services/calendrier';
import { arreterSimulation, avancementSimulation, demarrerSimulation, dureeSimulationMs, simulationActive } from '@/sources/simulation';
import { connecterToit, toit } from '@/sources/ble';
import { envoyerToit } from '@/sources/commandesToit';
import { cmdToit } from '@/proto/toit';
import { param } from '@/services/parametres';
import { verdict, type Verdict } from '@/calc/versions';

const VITESSES = [1, 10, 30];
const envoyer = (cmd: string) => envoyerToit(cmd).catch((e) => Alert.alert('Toit', (e as Error).message));
const dateCourte = (t: number) => new Date(t).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });

export default function Reglages() {
  const router = useRouter();
  const expert = useModeExpert();
  const e = useEtat((x) => ({
    source: x.source, connexion: x.connexion, vitesseSim: x.vitesseSim, message: x.message, config: x.config, toit: x.toit,
    etalonnage: x.etalonnage, arretAutoMin: x.arretAutoMin, portatif: x.portatif, nids: x.nids, fiches: x.fichesTags, ruchers: x.ruchers, pieges: x.pieges, alertes: x.alertes, station: x.station,
    versionToit: x.versionToit, nTags: Object.keys(x.tags).length, nPoints: x.trajet.length, reprise: x.reprise,
  }));
  const ap = useSyncExternalStore(abonnerArrierePlan, etatArrierePlan);
  const [apActif, setApActif] = useState(arrierePlanActive);
  const partage = useSyncExternalStore(abonnerPartage, etatPartage);
  const cfgPartage = lireConfig();
  const session = useSession();
  const derniereSauv = lireValeur<number>('derniereSauvegarde');
  const avanceCal = useMaintenant(3600000);
  const enCoursCal = etapesDatees(avanceCal, lireCalendrier().decalage, lireCalendrier().dates).filter((x) => x.etat === 'en-cours');
  const aTraiter = e.nids.filter((n) => n.etat === 'trouve' || n.etat === 'estime').length;
  const aControlerN = e.nids.filter((n) => aControler(n, avanceCal, param().controleJours)).length;
  const poses = Object.values(e.fiches).filter((f) => f.etat === 'pose').length;
  const nAlertes = (['nouveauTag', 'tagPerdu', 'pileFaible', 'retourAppat', 'nidLocalise', 'approcheNid', 'batterie'] as const).filter((k) => e.alertes[k]).length;
  const [avance, setAvance] = useState(0);
  useEffect(() => { const i = setInterval(() => setAvance(avancementSimulation()), 500); return () => clearInterval(i); }, []);
  const simEnCours = e.source === 'simulation' && e.connexion === 'connecte';
  const toitConnecte = e.source === 'toit' && e.connexion === 'connecte';
  const actif = toitConnecte || simEnCours;
  // si le toit vient de se connecter sans avoir envoyé ses réglages, on les demande
  const aConfig = !!e.config;
  useEffect(() => { if (actif && !aConfig) envoyer(cmdToit.cfg()); }, [actif, aConfig]);
  const cfg = actif ? e.config : null;
  const r = e.etalonnage.resultat;

  const confirmer = (titre: string, texte: string, cmd: string, bouton: string) =>
    Alert.alert(titre, texte, [{ text: 'Annuler', style: 'cancel' }, { text: bouton, style: 'destructive', onPress: () => envoyer(cmd) }]);

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <BandeauToit />

      <Carte>
        <Titre>Appareils</Titre>
        <View style={[s.ligne, { justifyContent: 'space-between', marginBottom: 8 }]}>
          <View style={{ flex: 1 }}>
            <Text style={{ color: C.encre, fontWeight: '700' }}>Récepteur de toit</Text>
            <Text style={s.discret}>{toitConnecte ? `${param().nomToit} · voies ${nbVoies(e.toit?.voiesOk ?? 0)} / 4` : e.source === 'toit' && e.message ? e.message : 'non connecté'}</Text>
            {toitConnecte && <LigneVersion v={verdict('toit', e.versionToit)} />}
          </View>
          {toitConnecte
            ? <Pressable onPress={() => toit.deconnecter()} style={s.puce}><Text style={s.puceTxt}>Déconnecter</Text></Pressable>
            : <Pressable disabled={e.connexion === 'recherche'} onPress={() => { arreterSimulation(); connecterToit(); }} style={[s.puce, s.puceActive]}>
                <Text style={[s.puceTxt, { fontWeight: '700' }]}>{e.connexion === 'recherche' && e.source === 'toit' ? 'Recherche…' : 'Connecter'}</Text>
              </Pressable>}
        </View>
        <View style={[s.ligne, { justifyContent: 'space-between', paddingTop: 8, borderTopWidth: 1, borderTopColor: C.ligne }]}>
          <View style={{ flex: 1 }}>
            <Text style={{ color: C.encre, fontWeight: '700' }}>Récepteur portatif</Text>
            <Text style={s.discret}>{e.portatif.connexion === 'connecte' ? (e.portatif.source === 'simulation' ? 'portatif simulé' : `${param().nomPortatif} connecté`) : 'non connecté'}</Text>
            {e.portatif.connexion === 'connecte' && e.portatif.source === 'ble' && <LigneVersion v={verdict('portatif', e.portatif.version)} />}
          </View>
          <Pressable onPress={() => router.navigate('/portatif')} style={s.puce}><Text style={s.puceTxt}>Ouvrir</Text></Pressable>
        </View>
        <Text style={[s.discret, { marginTop: 10, fontSize: police.mini }]}>Le téléphone peut suivre les deux à la fois. Allumez l'appareil et restez à moins de 10 m.</Text>
        <Interrupteur titre="Continuer écran verrouillé" detail={ap === 'actif' ? 'actif : notification « sortie en cours »' : ap === 'refuse' ? 'position « Toujours » refusée dans Android' : 'pendant une sortie avec le toit ou le portatif'}
          valeur={apActif} onChange={(v) => { setApActif(v); activerArrierePlan(v); }} />
        {e.source !== 'simulation' && e.nTags > 0 && (
          <View style={[s.ligne, { justifyContent: 'space-between', paddingTop: 8, borderTopWidth: 1, borderTopColor: C.ligne }]}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: C.encre, fontWeight: '700' }}>Sortie en cours</Text>
              <Text style={s.discret}>{e.nTags} tag{e.nTags > 1 ? 's' : ''} · {e.nPoints} points de trajet{e.reprise ? ` · reprise de ${new Date(e.reprise.t).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}` : ''}</Text>
            </View>
            <Pressable onPress={() => Alert.alert('Terminer la sortie', 'Effacer les relevés, directions et le trajet de cette sortie ? Les nids du carnet et les appâts du chrono restent.', [{ text: 'Annuler', style: 'cancel' }, { text: 'Terminer', style: 'destructive', onPress: terminerSortie }])} style={s.puce}>
              <Text style={s.puceTxt}>Terminer</Text>
            </Pressable>
          </View>
        )}
      </Carte>

      <Carte>
        <Titre>Sur le terrain</Titre>
        <LigneLien titre="Avant de partir" detail="liste à cocher" onPress={() => router.push('/avant-depart')} />
        <LigneLien titre="Poser un tag" detail="pas à pas" onPress={() => router.push('/pose-tag')} />
        <LigneLien titre="Mes tags" detail={`${poses} posé${poses > 1 ? 's' : ''}`} onPress={() => router.push('/tags')} />
        <LigneLien titre="Pièges de printemps" detail={`${e.pieges.filter((p) => !p.retire_ms).length} en place`} onPress={() => router.push('/pieges')} />
        <LigneLien titre="Météo du jour" detail="meilleur moment pour sortir" onPress={() => router.push('/meteo')} />
      </Carte>

      <Carte>
        <Titre>Carnet</Titre>
        <LigneLien titre="Nids" detail={aTraiter ? `${aTraiter} à traiter` : `${e.nids.length} nid${e.nids.length > 1 ? 's' : ''}`} alerte={aTraiter > 0} onPress={() => router.push('/nids')} />
        <LigneLien titre="Ruchers" detail={e.station ? `station en cours au ${e.station.nom}` : `${e.ruchers.length} rucher${e.ruchers.length > 1 ? 's' : ''}`} onPress={() => router.push('/ruchers')} />
        <LigneLien titre="Bilan de saison" detail="chiffres, export GDSA" onPress={() => router.push('/bilan')} />
        <LigneLien titre="Registre des traitements" detail={aControlerN ? `${aControlerN} contrôle${aControlerN > 1 ? 's' : ''} à faire` : 'biocides, export PDF et Excel'} alerte={aControlerN > 0} onPress={() => router.push('/registre')} />
        <LigneLien titre="Produits biocides" detail="nom, substance, n° AMM" onPress={() => router.push('/produits')} />
        <LigneLien titre="Calendrier de saison" detail={enCoursCal.length ? enCoursCal.map((x) => x.titre).join(' · ') : 'étapes de l\'année'} onPress={() => router.push('/calendrier')} />
      </Carte>

      <Carte>
        <Titre>Compte et réglages</Titre>
        <LigneLien titre="Partage entre téléphones" detail={!session ? 'pas connecté' : !cfgPartage.equipe ? 'sans équipe' : `${cfgPartage.equipe.nom}${partage.erreur ? ' · erreur' : cfgPartage.actif ? '' : ' · en pause'}`} alerte={!!session && cfgPartage.actif && !!partage.erreur} onPress={() => router.push('/partage')} />
        <LigneLien titre="Sauvegarde" detail={derniereSauv ? `dernière le ${dateCourte(derniereSauv)}` : 'jamais faite'} alerte={!derniereSauv} onPress={() => router.push('/sauvegarde')} />
        <LigneLien titre="Sons et alertes" detail={`${nAlertes} actives`} onPress={() => router.push('/alertes')} />
        <LigneLien titre="Cartes hors ligne" detail="pour les zones sans réseau" onPress={() => router.push('/cartes-hors-ligne')} />
        <LigneLien titre="Mises à jour" detail={`appli${BUILD ? ` n° ${BUILD}` : ''} et appareils`} onPress={() => router.push('/mises-a-jour')} />
        <LigneLien titre="Paramètres" detail="votre nom, rappels, seuils…" onPress={() => router.push('/parametres')} />
        <Interrupteur titre="Mode expert" detail="réglages du toit, étalonnage, banc d'essai, journal" valeur={expert} onChange={changerModeExpert} />
      </Carte>

      <Carte>
        <Titre>Essayer sans matériel</Titre>
        <Text style={[s.discret, { marginBottom: 12 }]}>
          Rejoue une vraie sortie enregistrée ({Math.round(dureeSimulationMs() / 60000)} min) pour découvrir l'appli sans le toit.
        </Text>
        {expert && <View style={[s.ligne, { gap: 8, marginBottom: 12 }]}>
          <Text style={[s.discret, { marginRight: 4 }]}>Vitesse</Text>
          {VITESSES.map((v) => (
            <Pressable key={v} onPress={() => store.set({ vitesseSim: v })} style={[s.puce, v === e.vitesseSim && s.puceActive]}>
              <Text style={[s.puceTxt, v === e.vitesseSim && { fontWeight: '700' }]}>×{v}</Text>
            </Pressable>
          ))}
        </View>}
        {simEnCours || simulationActive()
          ? <Bouton titre="Arrêter la simulation" onPress={arreterSimulation} />
          : <Bouton titre="Lancer la sortie simulée" plein onPress={() => { toit.deconnecter(); demarrerSimulation(); }} />}
        {e.source === 'simulation' && (
          <View style={{ marginTop: 12 }}>
            <View style={{ height: 6, borderRadius: 3, backgroundColor: C.fond, overflow: 'hidden' }}>
              <View style={{ width: `${Math.round(avance * 100)}%`, height: '100%', backgroundColor: C.accent }} />
            </View>
            <Text style={[s.discret, { marginTop: 6, fontSize: police.mini }]}>{Math.round(avance * 100)} % de la sortie · {e.message}</Text>
          </View>
        )}
      </Carte>

      {expert && (
        <>
      <Carte>
        <Titre>Outils techniques</Titre>
        <LigneLien titre="Étalonner la distance" detail="distance du tag d'après le signal" onPress={() => router.push('/distance-etalonnage')} />
        <LigneLien titre="Banc d'essai" detail="première mise sous tension, carte par carte" onPress={() => router.push('/banc-essai')} />
        <LigneLien titre="Journal de mise au point" detail="échanges Bluetooth, export" onPress={() => router.push('/journal')} />
      </Carte>
      <Carte>
        <View style={[s.ligne, { justifyContent: 'space-between' }]}>
          <Titre>Mesure du toit</Titre>
          <Pressable onPress={() => router.push('/aide-reglages')}><Text style={[s.discret, { textDecorationLine: 'underline', marginBottom: 8 }]}>Aide</Text></Pressable>
        </View>
        {!cfg && <Text style={[s.discret, { marginBottom: 8 }]}>Connectez le toit pour lire et changer ses réglages (ils sont gardés dans le boîtier).</Text>}
        <Pas titre="Orientation du boîtier" aide="Décalage de l'avant" valeur={cfg ? (cfg.fwd > 180 ? cfg.fwd - 360 : cfg.fwd) : null} pas={1} min={-180} max={180}
          format={(v) => `${signe(v)}°`} envoyer={(v) => envoyer(cmdToit.fwd((v + 360) % 360))}
          alerte={(v) => (Math.abs(v) > 15 ? 'Plus de 15° : le boîtier est sans doute tourné sur le toit' : null)} />
        <Pas titre="Largeur du lobe" aide="Mesurée à l'étalonnage" valeur={cfg?.beam ?? null} pas={5} min={50} max={100} format={(v) => `${v}°`} envoyer={(v) => envoyer(cmdToit.beam(v))} />
        <Pas titre="Vitesse minimale" aide="En dessous, cap GPS pas fiable" valeur={cfg?.vmin ?? null} pas={1} min={0} max={20} format={(v) => `${v} km/h`} envoyer={(v) => envoyer(cmdToit.vmin(v))} />
        <Pas titre="Arrêt automatique" aide="Sans USB ni appareil connecté" valeur={cfg ? e.arretAutoMin : null} pas={5} min={0} max={120}
          format={(v) => (v ? `${v} min` : 'jamais')} envoyer={(v) => { definirArretAuto(v); envoyer(cmdToit.auto(v)); }} />
      </Carte>

      <Carte>
        <Titre>Correction de gain (dB)</Titre>
        {VOIES.slice(0, 4).map((nom, k) => (
          <Pas key={nom} titre={nom} valeur={cfg?.gains[k] ?? null} pas={0.5} min={-12} max={12} format={(v) => signe(v, 1)}
            envoyer={(v) => envoyer(cmdToit.gain(k, v))}
            alerte={(v) => (Math.abs(v) > 6 ? 'Plus de 6 dB : antenne mal vissée, câble abîmé ou voie défaillante ?' : null)} />
        ))}
      </Carte>

      <Carte>
        <Titre>Maintenance</Titre>
        <Ligne titre="Étalonner le toit" detail={r ? `erreur ${Math.round(r.errDeg)}° · ${dateCourte(r.date)}` : 'jamais fait'} onPress={() => router.push('/etalonnage')} />
        <Ligne titre="Mettre à jour les 4 voies" detail="par le câble, toit branché" desactive={!actif}
          onPress={() => confirmer('Mise à jour des voies', 'Envoyer le programme aux 4 cartes voies ? Laisser le toit branché pendant la mise à jour.', cmdToit.maj(), 'Mettre à jour')} />
        <Ligne titre="Redémarrer les voies" detail="si une voie n'affiche plus de niveau" desactive={!actif} onPress={() => envoyer(cmdToit.reset())} />
        <Ligne titre="Éteindre le toit" detail="se rallume en le rebranchant" desactive={!actif}
          onPress={() => confirmer('Éteindre le toit', 'Éteindre le récepteur de toit maintenant ?', cmdToit.off(), 'Éteindre')} />
        {e.etalonnage.dernierK?.type === 'MAJ' && <Text style={[s.discret, { marginTop: 8 }]}>Mise à jour lancée sur {e.etalonnage.dernierK.n} voie(s).</Text>}
      </Carte>
        </>
      )}
    </ScrollView>
  );
}

function Ligne({ titre, detail, onPress, desactive }: { titre: string; detail: string; onPress: () => void; desactive?: boolean }) {
  return (
    <Pressable onPress={onPress} disabled={desactive} style={[s.ligne, { paddingVertical: 11, borderTopWidth: 1, borderTopColor: C.ligne, opacity: desactive ? 0.45 : 1 }]}>
      <View style={{ flex: 1 }}>
        <Text style={{ color: C.encre, fontSize: police.normal }}>{titre}</Text>
        <Text style={[s.discret, { fontSize: police.mini }]}>{detail}</Text>
      </View>
      <Text style={{ color: C.discret, fontSize: 20 }}>›</Text>
    </Pressable>
  );
}

/** Version du firmware d'un appareil connecté et compatibilité avec l'appli. */
function LigneVersion({ v }: { v: Verdict | null }) {
  if (!v) return <Text style={[s.discret, { fontSize: police.mini }]}>version : en attente…</Text>;
  const c = v.etat === 'ok' ? C.ok : v.etat === 'maj' ? C.accent : C.alerte;
  return <Text style={{ fontSize: police.mini, color: c, fontWeight: '700', marginTop: 2 }}>{v.texte}</Text>;
}
