import { Stack, router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { brancherPersistance, chronoTic, store } from '@/store/store';
import { ecrireValeur, lireValeur } from '@/db';
import { chargerCarnet } from '@/services/carnet';
import { demarrerAlertes } from '@/services/alertes';
import '@/services/etalonnage'; // renvoie les étalonnages des tags au portatif à chaque connexion
import '@/services/terrain'; // apprend le terrain et l'orientation du toit sur les nids trouvés
import { suivrePosition } from '@/services/position';
import { BandeauAlerte, Bouton, s as st } from '@/ui/composants';
import { noterErreur, surveillerErreurs } from '@/services/erreurs';
import { surveillerArrierePlan } from '@/services/arrierePlan';
import { demarrerPartage } from '@/services/partage';
import { verifierAuDemarrage } from '@/services/majAppli';
import { rappelRecharge, suivreTags } from '@/services/suiviTags';
import { rappelCalendrier } from '@/services/calendrier';
import { surveillerVersions } from '@/services/versions';
import { connecterToit } from '@/sources/ble';
import { connecterPortatif } from '@/sources/portatif';
import { C } from '@/ui/theme';
import { sessionActuelle } from '@/services/auth';
import { aControler } from '@/calc/intervention';
import { param } from '@/services/parametres';
import { demarrerWidget } from '@/widget/majWidget';
import { demarrerSauvegardeAuto } from '@/services/sauvegardeAuto';

// aperçu de développement : l'état est accessible depuis la console du navigateur (jamais dans l'APK)
if (__DEV__) (globalThis as unknown as { __store?: typeof store }).__store = store;

export default function Racine() {
  useEffect(() => {
    surveillerErreurs();                                                               // erreurs de l'appli → journal (et celles d'avant un plantage)
    try { brancherPersistance({ lire: lireValeur, ecrire: ecrireValeur }); } catch (e) { noterErreur(e, 'Démarrage'); } // réglages, appâts, sortie interrompue
    try { chargerCarnet(); } catch (e) { noterErreur(e, 'Carnet'); }                 // nids, tags, ruchers
    try { demarrerSauvegardeAuto(); } catch (e) { noterErreur(e, 'Sauvegarde auto'); }   // sauvegarde automatique sur le serveur
    try { demarrerWidget(); } catch (e) { noterErreur(e, 'Widget'); }                // widget d'écran d'accueil (Android)
    // sortie interrompue (plantage, téléphone redémarré) : on se reconnecte aux appareils qui l'étaient
    const rep = store.get().reprise;
    if (rep) {
      store.set({ bandeau: { texte: `Sortie reprise : ${rep.nTags} tag${rep.nTags > 1 ? 's' : ''}, relevés conservés${rep.toit || rep.portatif ? ', reconnexion…' : ''}`, grave: false, ms: Date.now() } });
      if (rep.toit) connecterToit().catch((e) => noterErreur(e, 'Reconnexion au toit'));
      if (rep.portatif) connecterPortatif().catch((e) => noterErreur(e, 'Reconnexion au portatif'));
    }
    else if (lireValeur<boolean>('connexionProposee') || sessionActuelle()) rappelRecharge((n) => store.set({ bandeau: { texte: `${n} tag${n > 1 ? 's' : ''} à recharger avant la prochaine sortie (Menu → Mes tags)`, grave: false, ms: Date.now() } }));
    // étape du calendrier qui commence (rappelée une seule fois) ; ne remplace pas un bandeau plus urgent
    const premierLancement = !lireValeur<boolean>('connexionProposee') && !sessionActuelle();
    if (!premierLancement) rappelCalendrier((et) => { if (!store.get().bandeau) store.set({ bandeau: { texte: `Calendrier : « ${et.titre} » commence (Menu → Calendrier de saison)`, grave: false, ms: Date.now() } }); });
    // premier lancement : proposer la connexion (facultative) une seule fois
    // nids traités à contrôler (une fois par jour au plus) ; prioritaire sur le calendrier
    if (!premierLancement) {
      const jour = new Date().toDateString();
      const n = store.get().nids.filter((x) => aControler(x, Date.now(), param().controleJours)).length;
      if (n && lireValeur<string>('rappelControle') !== jour) {
        ecrireValeur('rappelControle', jour);
        store.set({ bandeau: { texte: `${n} nid${n > 1 ? 's' : ''} traité${n > 1 ? 's' : ''} à contrôler (Menu → Registre des traitements)`, grave: false, ms: Date.now() } });
      }
    }
    if (premierLancement) setTimeout(() => router.push('/connexion'), 300);
    const stopVersions = surveillerVersions();                                         // firmware et protocole du toit et du portatif
    const stopTags = suivreTags();                                                     // pile des tags entendue → rappel de recharge
    const stopAp = surveillerArrierePlan();                                           // service écran verrouillé pendant une sortie
    const stopPartage = demarrerPartage();                                             // partage entre téléphones (si réglé)
    verifierAuDemarrage((v) => store.set({ bandeau: { texte: `Nouvelle version de l'appli (n° ${v.build}) : Menu → Mises à jour`, grave: false, ms: Date.now() } }));
    suivrePosition();                                                                  // position du téléphone (secours, zone de sécurité)
    const i = setInterval(chronoTic, 1000);                                            // chrono à l'appât : détection « parti »
    const stop = demarrerAlertes((id, dist) => router.push({ pathname: '/zone-securite', params: { id: String(id), dist: String(Math.round(dist)) } }));
    return () => { clearInterval(i); stop(); stopAp(); stopPartage(); stopTags(); stopVersions(); };
  }, []);
  return (
    <View style={{ flex: 1, backgroundColor: C.fond }}>
      <StatusBar style="dark" />
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: C.fond } }} />
      <BandeauAlerte />
    </View>
  );
}

/** Écran de secours si un écran plante : l'erreur va dans le journal, on peut réessayer sans relancer l'appli. */
export function ErrorBoundary({ error, retry }: { error: Error; retry: () => Promise<void> }) {
  useEffect(() => { noterErreur(error, 'Écran'); }, [error]);
  return (
    <ScrollView style={st.ecran} contentContainerStyle={[st.contenu, { paddingTop: 60 }]}>
      <Text style={{ color: C.encre, fontSize: 22, fontWeight: '800' }}>Cet écran a rencontré une erreur</Text>
      <Text style={[st.discret, { marginVertical: 10 }]}>Elle est notée dans le journal de mise au point (Menu → Journal, filtre Problèmes). Les données de la sortie sont conservées.</Text>
      <Text selectable style={{ color: C.alerte, fontFamily: 'monospace', fontSize: 12, marginBottom: 16 }}>{error.message}</Text>
      <Bouton titre="Réessayer" plein onPress={() => { retry(); }} />
      <View style={{ height: 10 }} />
      <Bouton titre="Retour à l'accueil" onPress={() => { router.replace('/'); retry(); }} />
    </ScrollView>
  );
}
