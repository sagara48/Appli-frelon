import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect } from 'react';
import { brancherPersistance, chronoTic } from '@/store/store';
import { ecrireValeur, lireValeur } from '@/db';
import { C } from '@/ui/theme';

export default function Racine() {
  useEffect(() => { try { brancherPersistance({ lire: lireValeur, ecrire: ecrireValeur }); } catch {} }, []); // appâts de la dernière session
  useEffect(() => { const i = setInterval(chronoTic, 1000); return () => clearInterval(i); }, []); // chrono à l'appât : détection « parti »
  return (
    <>
      <StatusBar style="dark" />
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: C.fond } }} />
    </>
  );
}
