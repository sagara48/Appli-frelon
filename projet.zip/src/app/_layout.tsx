import { Stack, router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect } from 'react';
import { View } from 'react-native';
import { brancherPersistance, chronoTic } from '@/store/store';
import { ecrireValeur, lireValeur } from '@/db';
import { chargerCarnet } from '@/services/carnet';
import { demarrerAlertes } from '@/services/alertes';
import { suivrePosition } from '@/services/position';
import { BandeauAlerte } from '@/ui/composants';
import { C } from '@/ui/theme';

export default function Racine() {
  useEffect(() => {
    try { brancherPersistance({ lire: lireValeur, ecrire: ecrireValeur }); } catch {} // réglages, appâts de la dernière session
    try { chargerCarnet(); } catch {}                                                 // nids, tags, ruchers
    suivrePosition();                                                                  // position du téléphone (secours, zone de sécurité)
    const i = setInterval(chronoTic, 1000);                                            // chrono à l'appât : détection « parti »
    const stop = demarrerAlertes((id, dist) => router.push({ pathname: '/zone-securite', params: { id: String(id), dist: String(Math.round(dist)) } }));
    return () => { clearInterval(i); stop(); };
  }, []);
  return (
    <View style={{ flex: 1, backgroundColor: C.fond }}>
      <StatusBar style="dark" />
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: C.fond } }} />
      <BandeauAlerte />
    </View>
  );
}
