/** Enregistrer un essai : toutes les mesures brutes de la sortie dans un fichier, à m'envoyer pour régler les seuils. */
import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { useKeepAwake } from 'expo-keep-awake';
import { Bouton, Carte, EnTete, Titre, s, useMaintenant } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { arreterEssai, demarrerEssai, listerEssais, partagerEssai, repere, supprimerEssai, useEssai } from '@/services/essais';

const taille = (o: number) => (o > 1e6 ? `${(o / 1e6).toFixed(1).replace('.', ',')} Mo` : `${Math.max(1, Math.round(o / 1000))} ko`);
const SOURCES: Record<string, string> = { T: 'toit', P: 'portatif', D: 'drone', G: 'GPS', R: 'repères', I: 'infos' };
const REPERES = ['Tag posé ici', 'Nid ici', 'Je suis à la voiture', 'Début du tour', 'Fin du tour'];

function Eveil() { useKeepAwake(); return null; }

export default function Essais() {
  const E = useEssai();
  const maint = useMaintenant(1000);
  const [note, setNote] = useState('');
  const fichiers = listerEssais();
  const duree = E.actif ? Math.round((maint - E.debut) / 60000) : 0;
  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre="Enregistrer un essai" />
      {E.actif && <Eveil />}
      <Text style={s.discret}>
        Pendant l'essai, l'appli garde toutes les mesures brutes (chaque trame du toit, du portatif et du drone, le GPS du téléphone).
        Le toit et le portatif passent en mode « brut » le temps de l'essai. Notez des repères sur le terrain : ils servent de vérité pour régler les calculs.
      </Text>
      <Carte style={E.actif ? { borderColor: C.alerte, borderWidth: 2 } : undefined}>
        {E.actif ? (
          <>
            <Text style={{ color: C.alerte, fontWeight: '800', fontSize: police.normal + 2 }}>● {E.auto ? 'Sortie enregistrée automatiquement' : 'Enregistrement en cours'} · {duree} min</Text>
            <Text style={[s.discret, { marginTop: 4 }]}>{E.lignes} mesures · {taille(E.octets)} · {Object.entries(E.parSource).map(([k, n]) => `${SOURCES[k] ?? k} ${n}`).join(', ') || 'rien reçu pour l\'instant'}</Text>
            <Text style={[s.discret, { marginTop: 2, fontSize: police.mini }]}>L'écran reste allumé tant que cette page est ouverte.</Text>
            <View style={{ marginTop: 10 }}>{E.auto
              ? <Bouton titre="Passer en essai complet (mode brut, repères)" plein onPress={() => demarrerEssai()} />
              : <Bouton titre="Arrêter l'essai" plein onPress={arreterEssai} />}</View>
            {E.auto && <Text style={[s.discret, { marginTop: 6, fontSize: police.mini }]}>Les 10 dernières sorties sont gardées. Se coupe dans Paramètres → Automatismes.</Text>}
          </>
        ) : (
          <Bouton titre="Démarrer un essai" plein onPress={() => demarrerEssai()} />
        )}
      </Carte>
      {E.actif && !E.auto && (
        <Carte>
          <Titre>Repères (position du téléphone)</Titre>
          <View style={[s.ligne, { flexWrap: 'wrap', gap: 8 }]}>
            {REPERES.map((r) => <Bouton key={r} titre={r} onPress={() => repere(r)} />)}
          </View>
          <View style={[s.ligne, { gap: 8, marginTop: 10 }]}>
            <TextInput value={note} onChangeText={setNote} placeholder="Note libre (ex. tag à 50 m derrière la haie)" placeholderTextColor={C.discret}
              style={{ flex: 1, borderWidth: 1, borderColor: C.ligne, borderRadius: 8, padding: 10, color: C.encre }} />
            <Bouton titre="Noter" onPress={() => { if (note.trim()) { repere(note.trim()); setNote(''); } }} />
          </View>
          {!!E.dernierRepere && <Text style={[s.discret, { marginTop: 6 }]}>Dernier repère : {E.dernierRepere}</Text>}
        </Carte>
      )}
      <Carte>
        <Titre>Essais enregistrés</Titre>
        {!fichiers.length && <Text style={s.discret}>Aucun pour l'instant.</Text>}
        {fichiers.map((f) => (
          <View key={f.nom} style={[s.ligne, { justifyContent: 'space-between', paddingVertical: 6, borderTopWidth: 1, borderTopColor: C.ligne }]}>
            <Text style={{ color: C.encre, flex: 1 }}>{f.nom.startsWith('sortie_') ? 'Sortie ' : ''}{f.nom.replace('essai_', '').replace('sortie_', '').replace('.txt', '').replace('_', ' à ')} · {taille(f.taille)}</Text>
            <Pressable onPress={() => partagerEssai(f).catch(() => {})} style={{ paddingHorizontal: 8 }}><Text style={{ color: C.encre, textDecorationLine: 'underline' }}>Envoyer</Text></Pressable>
            <Pressable onPress={() => Alert.alert('Supprimer', `Supprimer ${f.nom} ?`, [{ text: 'Annuler', style: 'cancel' }, { text: 'Supprimer', style: 'destructive', onPress: () => supprimerEssai(f) }])}>
              <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Suppr.</Text>
            </Pressable>
          </View>
        ))}
      </Carte>
    </ScrollView>
  );
}
