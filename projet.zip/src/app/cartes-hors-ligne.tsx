/** Cartes hors ligne (É16) : fond IGN (plan, photo aérienne) téléchargé par zone, pour les secteurs sans réseau. */
import React, { useEffect, useRef, useState } from 'react';
import { Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, Champ, EnTete, Puces, Titre, s } from '@/ui/composants';
import { C, fmtCoord, police } from '@/ui/theme';
import { meilleurePosition, useEtat } from '@/store/store';
import { lireValeur, ecrireValeur } from '@/db';
import { compterTuiles, effacerTuiles, tailleEstimee, telechargerZone, type Couche, type Zone } from '@/services/tuiles';
import { suivrePosition } from '@/services/position';
import { definirFond, fondCarte } from '@/services/fond';

const TAILLES: [string, string][] = [['4x4', '4 × 4 km'], ['8x6', '8 × 6 km'], ['10x10', '10 × 10 km'], ['20x15', '20 × 15 km']];
const mo = (o: number) => `${Math.max(1, Math.round(o / 1e6))} Mo`;

export default function CartesHorsLigne() {
  const e = useEtat((x) => ({ ruchers: x.ruchers, telephone: x.telephone }));
  const [zones, setZones] = useState<Zone[]>(() => lireValeur<Zone[]>('zones') ?? []);
  const [taille, setTaille] = useState('8x6');
  const [couches, setCouches] = useState<'plan' | 'photo' | 'les2'>('plan');
  const [nom, setNom] = useState('');
  const [centre, setCentre] = useState<{ lat: number; lon: number; nom: string } | null>(null);
  const [fond, setFond] = useState(fondCarte());
  const [prog, setProg] = useState<{ fait: number; total: number } | null>(null);
  const annule = useRef(false);
  useEffect(() => { suivrePosition(); }, []);
  // centre par défaut : premier rucher, sinon la position du téléphone
  const defaut = e.ruchers[0] ? { lat: e.ruchers[0].lat, lon: e.ruchers[0].lon, nom: `rucher ${e.ruchers[0].nom}` }
    : e.telephone ? { lat: e.telephone.lat, lon: e.telephone.lon, nom: 'ma position' } : null;
  const ctr = centre ?? defaut;

  const [l, h] = taille.split('x').map(Number);
  const cs: Couche[] = couches === 'les2' ? ['plan', 'photo'] : [couches];
  const zone = ctr ? { lat: ctr.lat, lon: ctr.lon, largeurKm: l, hauteurKm: h, couches: cs } : null;

  const telecharger = async () => {
    if (!zone) return;
    annule.current = false;
    setProg({ fait: 0, total: compterTuiles(zone) });
    try {
      const octets = await telechargerZone(zone, (fait, total) => setProg({ fait, total }), () => annule.current);
      if (annule.current) return;
      const fin = new Date().getTime();
      const z: Zone = { ...zone, id: String(fin), nom: nom.trim() || `Zone ${zones.length + 1}`, tuiles: compterTuiles(zone), octets, dateMs: fin };
      const nz = [...zones, z]; setZones(nz); ecrireValeur('zones', nz);
    } catch (err) { Alert.alert('Téléchargement', String(err)); }
    finally { setProg(null); }
  };
  const total = zones.reduce((n, z) => n + z.octets, 0);

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Cartes hors ligne" />
      <Text style={s.discret}>Pour les zones sans réseau mobile. Fond de carte IGN (Géoplateforme).</Text>
      <Carte>
        <Titre>Fond de la carte</Titre>
        <Puces options={[['plan', 'Plan IGN'], ['photo', 'Photo aérienne'], ['aucun', 'Aucun']]} valeur={fond} onChange={(v) => { setFond(v); definirFond(v); }} />
      </Carte>
      <Carte>
        <Titre>Nouvelle zone</Titre>
        <Text style={{ color: C.encre, marginBottom: 6 }}>Centrée sur {ctr ? `${ctr.nom} (${fmtCoord(ctr.lat, ctr.lon)})` : '… (attente de la position)'}</Text>
        <View style={[s.ligne, { gap: 8, flexWrap: 'wrap', marginBottom: 10 }]}>
          {e.ruchers.map((r) => (
            <Pressable key={r.id} onPress={() => setCentre({ lat: r.lat, lon: r.lon, nom: `rucher ${r.nom}` })} style={s.puce}><Text style={s.puceTxt}>{r.nom}</Text></Pressable>
          ))}
          <Pressable onPress={() => { const p = meilleurePosition(); if (p) setCentre({ lat: p.lat, lon: p.lon, nom: 'ma position' }); }} style={s.puce}><Text style={s.puceTxt}>Ma position</Text></Pressable>
        </View>
        <Puces options={TAILLES} valeur={taille} onChange={setTaille} />
        <View style={{ height: 8 }} />
        <Puces options={[['plan', 'Plan IGN'], ['photo', 'Photo aérienne'], ['les2', 'Les deux']]} valeur={couches} onChange={setCouches} />
        <Champ titre="Nom de la zone" valeur={nom} onChange={setNom} placeholder="Secteur rucher" />
        {zone && <Text style={[s.discret, { marginVertical: 6 }]}>{l} × {h} km · {compterTuiles(zone)} tuiles · environ {mo(tailleEstimee(zone))}</Text>}
        {prog ? (
          <View>
            <Text style={{ color: C.encre }}>Téléchargement… {Math.round((prog.fait / Math.max(1, prog.total)) * 100)} %</Text>
            <View style={{ height: 8, borderRadius: 4, backgroundColor: C.fond, overflow: 'hidden', marginVertical: 6 }}>
              <View style={{ width: `${(prog.fait / Math.max(1, prog.total)) * 100}%`, height: '100%', backgroundColor: C.accent }} />
            </View>
            <Bouton titre="Annuler" onPress={() => { annule.current = true; }} />
          </View>
        ) : <Bouton titre="Télécharger cette zone" plein desactive={!zone} onPress={telecharger} />}
      </Carte>
      <Carte>
        <View style={[s.ligne, { justifyContent: 'space-between' }]}>
          <Titre>Zones enregistrées</Titre>
          <Text style={[s.discret, { marginBottom: 8 }]}>{mo(total)} utilisés</Text>
        </View>
        {!zones.length && <Text style={s.discret}>Aucune zone pour l'instant.</Text>}
        {zones.map((z) => (
          <View key={z.id} style={{ paddingVertical: 8, borderTopWidth: 1, borderTopColor: C.ligne }}>
            <Text style={{ color: C.encre, fontWeight: '700' }}>{z.nom}</Text>
            <Text style={s.discret}>{z.largeurKm} × {z.hauteurKm} km · {z.couches.map((c) => (c === 'plan' ? 'plan' : 'photo')).join(' + ')} · {mo(z.octets)} · {new Date(z.dateMs).toLocaleDateString('fr-FR')}</Text>
          </View>
        ))}
        {zones.length > 0 && (
          <Pressable onPress={() => Alert.alert('Effacer', 'Effacer toutes les cartes enregistrées ?', [{ text: 'Annuler', style: 'cancel' }, { text: 'Effacer', style: 'destructive', onPress: () => { effacerTuiles(); setZones([]); ecrireValeur('zones', []); } }])} style={{ marginTop: 8 }}>
            <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Tout effacer</Text>
          </Pressable>
        )}
      </Carte>
      <Text style={[s.discret, { fontSize: police.mini }]}>Téléchargez en Wi-Fi avant de partir. Sans réseau, la carte utilise automatiquement ces zones ; ailleurs, le fond reste vide.</Text>
    </ScrollView>
  );
}
