/** Recette des cartes à la réception : tags, toit, portatif, chargeur. Chaque contrôle se fait avec les appareils
 *  connectés ; le résultat se partage en texte. */
import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, EnTete, Titre, s, useMaintenant } from '@/ui/composants';
import { C, VOIES, idTag, police } from '@/ui/theme';
import { store, useEtat } from '@/store/store';
import { useEtalonnages } from '@/services/etalonnage';
import { mediane, moyennesVoies, rapportRecette, verdictDirection, verifsTag, type Verif } from '@/calc/recette';
import { partager } from '@/services/exports';

function Ligne({ v }: { v: Verif }) {
  const c = v.ok === null ? C.discret : v.ok ? C.ok : C.alerte;
  return (
    <View style={[s.ligne, { alignItems: 'flex-start', marginTop: 4 }]}>
      <Text style={{ color: c, fontWeight: '800', width: 28 }}>{v.ok === null ? '…' : v.ok ? '✓' : '✗'}</Text>
      <Text style={{ color: C.encre, flex: 1 }}><Text style={{ fontWeight: '700' }}>{v.nom}</Text> : {v.detail}</Text>
    </View>
  );
}

const CHARGEUR = [
  "À vide : l'écran s'allume, les 6 places sont vides, aucune LED de place allumée",
  'Un tag dans chaque place l\'une après l\'autre : la LED de la place clignote (en charge) puis reste fixe (pleine)',
  'Les 6 tensions affichées sont proches pour des tags de même charge (écart < 0,2 V)',
  'Aucune place n\'affiche « U » ni « ! » avec des piles neuves',
];

export default function Recette() {
  const e = useEtat((x) => ({ tags: x.tags, portatif: x.portatif, versionToit: x.versionToit, toit: x.toit, activites: x.activites, source: x.source, connexion: x.connexion, tagChoisi: x.tagChoisi }));
  const etals = useEtalonnages();
  const maint = useMaintenant(1000);
  // capteur de lumière : noir et lumière vus pendant la recette
  const [vus, setVus] = useState<Record<number, { noir: boolean; lumiere: boolean }>>({});
  useEffect(() => { const fin = store.abonner(() => {
    const a = store.get().activites;
    setVus((v) => {
      let n = v;
      for (const [k, x] of Object.entries(a)) {
        const id = Number(k), o = v[id] ?? { noir: false, lumiere: false };
        if (maint0 > x.vuMs) continue;
        const p = { noir: o.noir || x.nid, lumiere: o.lumiere || !x.nid };
        if (p.noir !== o.noir || p.lumiere !== o.lumiere) n = { ...n, [id]: p };
      }
      return n;
    });
  }); return () => { fin(); }; }, []);
  // test des 4 directions du toit
  const [dir, setDir] = useState<Record<number, Verif>>({});
  const [mesure, setMesure] = useState<{ voie: number; fin: number } | null>(null);
  const tag = e.tagChoisi;
  const t = tag !== null ? e.tags[tag] : null;
  const mesurer = (voie: number) => { if (tag !== null) lancerMesure(tag, voie, setMesure, (v) => setDir((d) => ({ ...d, [voie]: v }))); };

  // ---- tags ----
  const stp = e.portatif.st;
  const ids = [...new Set([...Object.keys(e.tags), ...Object.keys(e.portatif.autres ?? {}), ...(stp && stp.tag >= 0 ? [String(stp.tag)] : [])].map(Number))].sort((a, b) => a - b);
  const med = mediane(Object.values(etals).map((x) => x.p1m));
  const tagsV = ids.map((id) => {
    const tt = e.tags[id], pa = e.portatif.autres?.[id];
    const duSt = stp && stp.tag === id && stp.age < 60 ? stp : null;
    const entendu = (!!tt && maint - tt.dernierMs < 60000) || (!!pa && pa.age < 60) || !!duSt;
    const etat = duSt?.etat ?? pa?.etat ?? (e.activites[id] ? (e.activites[id].nid ? 0x80 : 0) | ((e.activites[id].tempC ?? -40) + 40) : null);
    return { id, v: verifsTag({ id, entendu, pile: tt && tt.pile >= 0 ? tt.pile : null, etat: etat || null, noirVu: !!vus[id]?.noir, lumiereVu: !!vus[id]?.lumiere, p1m: etals[id]?.p1m ?? null }, med) };
  });
  // ---- toit ----
  const vt = e.versionToit;
  const toitV: Verif[] = [
    { nom: 'Connexion', ok: e.source === 'toit' ? e.connexion === 'connecte' : null, detail: e.source === 'toit' ? e.connexion : 'connecter le toit (onglet Menu)' },
    ...[0, 1, 2, 3].map((k): Verif => ({ nom: `Voie ${VOIES[k].toLowerCase()}`, ok: vt ? ((vt.voies ?? [])[k] ?? 0) > 0 : null,
      detail: !vt ? 'version pas encore reçue' : ((vt.voies ?? [])[k] ?? 0) > 0 ? `répond (firmware ${(vt.voies ?? [])[k]})` : 'ne répond pas : nappe, alimentation ou flashage' })),
    { nom: 'GPS du toit', ok: e.toit ? e.toit.sats >= 5 : null, detail: e.toit ? `${e.toit.sats} satellites` : 'en attente' },
    ...[0, 1, 2, 3].map((k) => dir[k] ?? { nom: `Tag ${VOIES[k].toLowerCase()}`, ok: null, detail: 'pas encore mesuré' }),
  ];
  // ---- portatif ----
  const st = e.portatif.st;
  const portV: Verif[] = [
    { nom: 'Connexion', ok: e.portatif.connexion === 'connecte' ? true : null, detail: e.portatif.connexion === 'connecte' ? `firmware ${e.portatif.version?.fw ?? '?'}` : 'connecter le portatif' },
    { nom: 'GPS', ok: st ? st.fix > 0 : null, detail: st ? `${st.sats} satellites${st.fix ? '' : ', pas encore de position (dehors)'}` : '—' },
    { nom: 'Boussole', ok: st?.cmp === undefined ? null : st.cmp === 0, detail: st?.cmp === undefined ? '—' : ['bonne', 'perturbée (métal proche ?)', 'pas calibrée : menu du portatif → Calibrer'][st.cmp] },
    { nom: 'Batterie', ok: st ? st.bat >= 20 : null, detail: st ? `${st.bat} %` : '—' },
    { nom: 'Réception', ok: st && st.tag >= 0 && st.age < 5 ? st.rssi > -90 : null, detail: st && st.tag >= 0 ? `tag ${idTag(st.tag)} à ${Math.round(st.rssi)} dBm (le poser à 1-2 m : plus fort que −70 dBm)` : 'choisir un tag sur le portatif' },
  ];
  const [charg, setCharg] = useState<boolean[]>(CHARGEUR.map(() => false));
  const chargV: Verif[] = CHARGEUR.map((c, i) => ({ nom: `Chargeur ${i + 1}`, ok: charg[i] ? true : null, detail: c }));

  const exporter = () => partagerRapport([
    ...tagsV.map((x) => ({ titre: `Tag ${idTag(x.id)}`, verifs: x.v })), { titre: 'Toit', verifs: toitV }, { titre: 'Portatif', verifs: portV }, { titre: 'Chargeur', verifs: chargV },
  ]);

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Recette des cartes" />
      <Text style={s.discret}>À faire à la réception de chaque carte, avant les essais : les contrôles se remplissent avec les appareils connectés.</Text>

      <Carte>
        <Titre>Tags</Titre>
        <Text style={s.discret}>Allumez les tags (posés sur le chargeur puis retirés), toit ou portatif connecté. Pour chaque tag : le cacher dans la main quelques secondes puis le découvrir, et l'étalonner à 1 m (Mes tags).</Text>
        {!tagsV.length && <Text style={[s.discret, { marginTop: 8 }]}>Aucun tag entendu pour l'instant.</Text>}
        {tagsV.map((x) => (
          <View key={x.id} style={{ marginTop: 10, borderTopWidth: 1, borderTopColor: C.ligne, paddingTop: 6 }}>
            <Text style={{ color: C.encre, fontWeight: '800' }}>Tag {idTag(x.id)} {x.v.every((v) => v.ok) ? '✓' : x.v.some((v) => v.ok === false) ? '✗' : ''}</Text>
            {x.v.map((v) => <Ligne key={v.nom} v={v} />)}
          </View>
        ))}
      </Carte>

      <Carte>
        <Titre>Toit</Titre>
        {toitV.slice(0, 6).map((v) => <Ligne key={v.nom} v={v} />)}
        <Text style={[s.discret, { marginTop: 10 }]}>
          Directions : un tag allumé sur un piquet à 5-10 m, successivement devant, à droite, derrière et à gauche de la voiture.
          {tag !== null ? ` Tag suivi : ${idTag(tag)}.` : ' Choisissez d\'abord le tag dans Suivi.'}
        </Text>
        {[0, 1, 2, 3].map((k) => (
          <View key={k} style={[s.ligne, { justifyContent: 'space-between', marginTop: 6 }]}>
            <View style={{ flex: 1 }}><Ligne v={toitV[6 + k]} /></View>
            <Bouton titre={mesure?.voie === k ? `${Math.max(0, Math.ceil((mesure.fin - maint) / 1000))} s` : 'Mesurer'} desactive={!t || !!mesure}
              onPress={() => mesurer(k)} />
          </View>
        ))}
      </Carte>

      <Carte>
        <Titre>Portatif</Titre>
        {portV.map((v) => <Ligne key={v.nom} v={v} />)}
      </Carte>

      <Carte>
        <Titre>Chargeur (à cocher)</Titre>
        {chargV.map((v, i) => (
          <Pressable key={i} onPress={() => setCharg(charg.map((x, j) => (j === i ? !x : x)))}><Ligne v={v} /></Pressable>
        ))}
        <Text style={[s.discret, { marginTop: 6, fontSize: police.mini }]}>Touchez une ligne pour la cocher.</Text>
      </Carte>

      <Bouton titre="Partager le rapport de recette" plein onPress={exporter} />
    </ScrollView>
  );
}
const maint0 = Date.now();
/** 10 s de trames du tag suivi, puis verdict : la voie attendue doit être la plus forte. */
function lancerMesure(tag: number, voie: number, setMesure: (m: { voie: number; fin: number } | null) => void, verdict: (v: Verif) => void) {
  const trames: number[][] = [];
  let der = store.get().tags[tag]?.dernierMs ?? 0;
  const fin = store.abonner(() => { const tt = store.get().tags[tag]; if (tt && tt.dernierMs !== der) { der = tt.dernierMs; trames.push(tt.r); } });
  setMesure({ voie, fin: Date.now() + 10000 });
  setTimeout(() => { fin(); verdict(verdictDirection(voie, moyennesVoies(trames), VOIES)); setMesure(null); }, 10000);
}
function partagerRapport(sections: { titre: string; verifs: Verif[] }[]) {
  partager(`recette_${new Date().toISOString().slice(0, 10)}.txt`, rapportRecette(sections, Date.now()), 'text/plain').catch(() => {});
}
