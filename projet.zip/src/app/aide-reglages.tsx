import React from 'react';
import { Bloc, G, P, PageAide } from '@/ui/Aide';

export default function AideReglages() {
  return (
    <PageAide titre="Comprendre les réglages" sousTitre="Gardés dans le boîtier, même éteint">
      <Bloc titre="En temps normal">
        <P>Ne touchez à rien : l'étalonnage règle l'orientation, le lobe et les gains tout seul. Ces réglages servent à corriger à la main ou à dépanner.</P>
      </Bloc>
      <Bloc titre="Mesure">
        <P><G>Orientation du boîtier</G> : angle entre la face « avant » du boîtier et l'axe de la voiture. Si le boîtier est posé de travers de 10° vers la droite, la valeur est +10°. Réglée par l'étalonnage.</P>
        <P><G>Largeur du lobe</G> : angle couvert par chaque antenne (70° par défaut). Le toit s'en sert pour transformer les 4 niveaux reçus en une direction. Réglée par l'étalonnage.</P>
        <P><G>Vitesse minimale</G> : en dessous (4 km/h par défaut), le GPS ne donne pas de cap fiable : la direction reste affichée par rapport à la voiture, mais pas sur la carte. Augmentez-la si la flèche « saute » dans les bouchons.</P>
        <P><G>Arrêt automatique</G> : le toit s'éteint après ce délai sans alimentation USB et sans téléphone ni écran connecté (10 min par défaut). « Jamais » pour une station fixe.</P>
      </Bloc>
      <Bloc titre="Correction de gain">
        <P>Compense les petites différences entre les 4 voies (câble, antenne, ampli). Une voie à +2 dB est relevée de 2 dB avant le calcul.</P>
        <P>Si une voie demande plus de 6 dB, elle a sans doute un problème : antenne mal vissée, câble abîmé ou voie défaillante.</P>
      </Bloc>
      <Bloc titre="Maintenance">
        <P><G>Mettre à jour les 4 voies</G> : envoie le nouveau programme aux cartes voies par le câble. Laisser le toit branché pendant la mise à jour.</P>
        <P><G>Redémarrer les voies</G> : à essayer si une voie n'affiche plus de niveau (« Voies 3 / 4 »).</P>
        <P><G>Éteindre le toit</G> : arrêt propre. Il se rallume en le rebranchant ou avec son bouton.</P>
      </Bloc>
    </PageAide>
  );
}
