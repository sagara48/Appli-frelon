/** Journal de mise au point : lignes Bluetooth reçues et envoyées, connexions, erreurs, mises à jour ; export en fichier texte. */
import Constants from 'expo-constants';
import React, { useCallback, useState, useSyncExternalStore } from 'react';
import { Alert, FlatList, Platform, Pressable, Text, View } from 'react-native';
import { Bouton, Carte, Champ, EnTete, Interrupteur, Puces, s } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { abonnerJournal, activerJournal, journalActif, ligneJournal, lireJournal, texteJournal, versionJournal, viderJournal, type Entree } from '@/services/journal';
import { partager } from '@/services/exports';
import { envoyerToit } from '@/sources/commandesToit';
import { envoyerPortatif } from '@/sources/portatif';
import { store, useEtat } from '@/store/store';
import { PROTO_PORTATIF, PROTO_TOIT } from '@/calc/versions';
import { BUILD } from '@/services/majAppli';

type Filtre = 'tout' | 'toit' | 'portatif' | 'maj' | 'appli' | 'partage' | 'pb';
const FILTRES: [Filtre, string][] = [['tout', 'Tout'], ['toit', 'Toit'], ['portatif', 'Portatif'], ['maj', 'Mises à jour'], ['appli', 'Appli'], ['partage', 'Partage'], ['pb', 'Problèmes']];
const garder = (f: Filtre) => (e: Entree) => (f === 'tout' ? true : f === 'pb' ? e.sens === 'erreur' || !!e.incomprise : e.app === f);
const COULEUR: Record<Entree['sens'], string> = { recu: C.encre, envoye: C.oeil, etat: C.discret, erreur: C.alerte };

// instantané immuable pour useSyncExternalStore, recopié seulement quand le journal a changé
let instantane = { v: -1, liste: [] as Entree[], actif: true };
const lire = () => {
  const v = versionJournal();
  if (instantane.v !== v) instantane = { v, liste: lireJournal().slice(), actif: journalActif() };
  return instantane;
};

export default function Journal() {
  const j = useSyncExternalStore(abonnerJournal, lire);
  const e = useEtat((x) => ({ source: x.source, toitOk: x.connexion === 'connecte', portatifOk: x.portatif.connexion === 'connecte' }));
  const [filtre, setFiltre] = useState<Filtre>('tout');
  const [gele, setGele] = useState<Entree[] | null>(null);
  const [cmd, setCmd] = useState('');
  const liste = (gele ?? j.liste).filter(garder(filtre));
  const affichees = liste.slice(-400).reverse();
  // fonction stable : une nouvelle fonction à chaque affichage relancerait l'en-tête en boucle
  const boutonEffacer = useCallback(() => (
    <Pressable onPress={() => Alert.alert('Journal', 'Effacer le journal ?', [{ text: 'Annuler', style: 'cancel' }, { text: 'Effacer', style: 'destructive', onPress: () => { viderJournal(); setGele(null); } }])}>
      <Text style={{ color: C.encre, textDecorationLine: 'underline' }}>Effacer</Text>
    </Pressable>
  ), []);
  const pb = j.liste.filter(garder('pb')).length;

  const exporter = async () => {
    const d = new Date();
    const vt = store.get().versionToit, vp = store.get().portatif.version;
    const entete = [
      'Journal de mise au point – Appli Frelons',
      `Exporté le ${d.toLocaleString('fr-FR')}`,
      `Appli ${Constants.expoConfig?.version ?? '?'}${BUILD ? ` (n° ${BUILD})` : ''} · ${Platform.OS} ${Platform.Version}`,
      `Toit : ${vt ? (vt.absente ? 'firmware d\'avant 1.1.0' : `firmware ${vt.fw}, protocole ${vt.proto}, voies ${vt.voies?.join('/')}`) : 'version inconnue'} · Portatif : ${vp ? (vp.absente ? 'firmware d\'avant 1.1.0' : `firmware ${vp.fw}, protocole ${vp.proto}`) : 'version inconnue'}`,
      `L'appli comprend : protocole toit ${PROTO_TOIT}, protocole portatif ${PROTO_PORTATIF}`,
      `Filtre : ${FILTRES.find(([f]) => f === filtre)?.[1]}`,
    ];
    const nom = `journal_frelons_${d.toISOString().slice(0, 16).replace(/[-:T]/g, '')}.txt`;
    try { await partager(nom, texteJournal(liste, entete), 'text/plain'); } catch (err) { Alert.alert('Export', String(err)); }
  };
  const envoyer = (vers: 'toit' | 'portatif') => {
    const c = cmd.trim();
    if (!c) return;
    (vers === 'toit' ? envoyerToit(c) : envoyerPortatif(c)).then(() => setCmd('')).catch((err) => Alert.alert('Envoi', String((err as Error).message ?? err)));
  };

  const entete = (
    <View>
      <Text style={s.discret}>Échanges Bluetooth avec le toit et le portatif, mises à jour, partage et erreurs de l'appli (celles de la session précédente sont reprises au démarrage). Les 5 000 dernières lignes sont gardées tant que l'appli reste ouverte.</Text>
      <Carte>
        <Interrupteur titre="Enregistrer" detail={`${j.liste.length} lignes${pb ? ` · ${pb} problème${pb > 1 ? 's' : ''}` : ''}`} valeur={j.actif} onChange={activerJournal} />
        <Puces options={FILTRES} valeur={filtre} onChange={setFiltre} />
        <View style={[s.ligne, { gap: 10, marginTop: 10, flexWrap: 'wrap' }]}>
          <Bouton titre={gele ? 'Reprendre' : 'Figer l\'affichage'} onPress={() => setGele(gele ? null : j.liste.slice())} />
          <Bouton titre="Exporter" plein desactive={!liste.length} onPress={exporter} />
        </View>
      </Carte>
      <Carte>
        <Champ titre="Envoyer une commande" valeur={cmd} onChange={setCmd} placeholder="cfg, clr…" />
        <View style={[s.ligne, { gap: 10 }]}>
          <Bouton titre="Au toit" desactive={!cmd.trim() || (!e.toitOk && e.source !== 'simulation')} onPress={() => envoyer('toit')} />
          <Bouton titre="Au portatif" desactive={!cmd.trim() || !e.portatifOk} onPress={() => envoyer('portatif')} />
        </View>
      </Carte>
      <View style={[s.ligne, { justifyContent: 'space-between', marginBottom: 4 }]}>
        <Text style={[s.discret, { fontSize: police.mini }]}>{'<'} reçu · {'>'} envoyé · * connexion · ! erreur</Text>
        {liste.length > 400 && <Text style={[s.discret, { fontSize: police.mini }]}>400 dernières sur {liste.length}</Text>}
      </View>
      {!affichees.length && <Text style={s.discret}>Rien pour l'instant. Connectez le toit ou le portatif depuis Réglages.</Text>}
    </View>
  );

  return (
    <View style={s.ecran}>
      <EnTete titre="Journal de mise au point" droite={boutonEffacer} />
      <FlatList
        data={affichees}
        keyExtractor={(x) => String(x.n)}
        contentContainerStyle={s.contenu}
        ListHeaderComponent={entete}
        initialNumToRender={40}
        renderItem={({ item }) => (
          <Text selectable style={{ fontFamily: Platform.OS === 'android' ? 'monospace' : 'Menlo', fontSize: police.mini, color: item.incomprise ? C.alerte : COULEUR[item.sens], paddingVertical: 1 }}>
            {ligneJournal(item)}
          </Text>
        )}
      />
    </View>
  );
}
