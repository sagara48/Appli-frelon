/** Avant de partir (É19) : ce que l'appli vérifie seule, et une liste à cocher modifiable. */
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { Bouton, Carte, EnTete, Titre, s, useMaintenant } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { useEtat } from '@/store/store';
import { ecrireValeur, lireValeur } from '@/db';
import { pointsAvantDepart } from '@/services/avantDepart';
import { useResteEtalonnage } from '@/services/etalonnages';

const LISTE_DEFAUT = ['Batteries du drone chargées', 'Appâts et filet de capture', 'Matériel de pose (tube, fil, colle)', 'Équipement de protection', 'Poudre et lance'];
const AUTO_VERIFIE = ['Tags chargés (sur le chargeur)']; // vérifié par l'appli maintenant : retiré des anciennes listes

export default function AvantDepart() {
  const router = useRouter();
  const [liste, setListe] = useState<string[]>(() => (lireValeur<string[]>('avantDepart') ?? LISTE_DEFAUT).filter((l) => !AUTO_VERIFIE.includes(l)));
  // cases cochées gardées pour la journée
  const [coche, setCocheEtat] = useState<Record<string, boolean>>(() => { const c = lireValeur<{ jour: string; c: Record<string, boolean> }>('avantDepartCoche'); return c && c.jour === new Date().toDateString() ? c.c : {}; });
  const setCoche = (c: Record<string, boolean>) => { setCocheEtat(c); ecrireValeur('avantDepartCoche', { jour: new Date().toDateString(), c }); };
  const [edition, setEdition] = useState(false);
  const [nouveau, setNouveau] = useState('');
  const maint = useMaintenant(60000);
  const resteEtal = useResteEtalonnage();
  // sélection étroite : l'écran ne suit que ce qu'il affiche (pas chaque trame des tags)
  const e = useEtat((x) => ({ source: x.source, connexion: x.connexion, toit: x.toit, portatif: x.portatif, versionToit: x.versionToit, fichesTags: x.fichesTags }));
  const auto = pointsAvantDepart(e, maint, resteEtal);
  const prets = auto.filter((a) => a.ok).length + liste.filter((l) => coche[l]).length;
  const total = auto.length + liste.length;
  const enregistrer = (l: string[]) => { setListe(l); ecrireValeur('avantDepart', l); };

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Avant de partir" />
      <Text style={{ color: C.encre, fontSize: police.titre, fontWeight: '800' }}>{prets} sur {total} prêts</Text>
      <Carte>
        <Titre>Vérifié par l'appli</Titre>
        {auto.map((a) => (
          <Pressable key={a.titre} disabled={!a.url || a.ok !== false} onPress={() => a.url && router.push(a.url as never)} style={[s.ligne, { paddingVertical: 8, borderTopWidth: 1, borderTopColor: C.ligne, gap: 10 }]}>
            <Rond ok={a.ok} />
            <View style={{ flex: 1 }}>
              <Text style={{ color: C.encre }}>{a.titre}</Text>
              <Text style={[s.discret, { fontSize: police.mini, color: a.ok === false ? C.alerte : C.discret }]}>{a.detail}</Text>
            </View>
            {!!a.valeur && <Text style={{ color: C.encre, fontWeight: '700' }}>{a.valeur}</Text>}
            {!!a.url && a.ok === false && <Text style={{ color: C.discret, fontSize: 20 }}>›</Text>}
          </Pressable>
        ))}
      </Carte>
      <Carte>
        <View style={[s.ligne, { justifyContent: 'space-between' }]}>
          <Titre>À cocher</Titre>
          <Pressable onPress={() => setEdition(!edition)}><Text style={[s.discret, { textDecorationLine: 'underline', marginBottom: 8 }]}>{edition ? 'Terminé' : 'Modifier la liste'}</Text></Pressable>
        </View>
        {liste.map((l) => (
          <Pressable key={l} onPress={() => (edition ? enregistrer(liste.filter((x) => x !== l)) : setCoche({ ...coche, [l]: !coche[l] }))}
            style={[s.ligne, { paddingVertical: 10, borderTopWidth: 1, borderTopColor: C.ligne, gap: 10 }]}>
            {edition ? <Text style={{ color: C.alerte, fontSize: 18, width: 22 }}>✕</Text> : <Rond ok={coche[l] ? true : null} carre />}
            <Text style={{ color: C.encre, flex: 1 }}>{l}</Text>
          </Pressable>
        ))}
        {edition && (
          <View style={[s.ligne, { gap: 8, marginTop: 8 }]}>
            <TextInput value={nouveau} onChangeText={setNouveau} placeholder="Ajouter une ligne" placeholderTextColor="#9AA3AC"
              style={{ flex: 1, borderWidth: 1, borderColor: C.ligne, borderRadius: 8, padding: 8, color: C.encre }} />
            <View style={{ width: 90 }}><Bouton titre="Ajouter" onPress={() => { if (nouveau.trim()) { enregistrer([...liste, nouveau.trim()]); setNouveau(''); } }} /></View>
          </View>
        )}
      </Carte>
      <View style={[s.ligne, { gap: 10 }]}>
        <Bouton titre="Menu" onPress={() => router.navigate('/reglages')} />
        <Bouton titre="Partir" plein onPress={() => router.navigate('/')} />
      </View>
    </ScrollView>
  );
}

function Rond({ ok, carre }: { ok: boolean | null; carre?: boolean }) {
  const fond = ok === true ? C.ok : ok === false ? C.alerte : 'transparent';
  return (
    <View style={{ width: 22, height: 22, borderRadius: carre ? 5 : 11, borderWidth: 2, borderColor: ok === null ? C.discret : fond, backgroundColor: fond, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>{ok === true ? '✓' : ok === false ? '!' : ''}</Text>
    </View>
  );
}
