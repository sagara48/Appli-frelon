/** Avant de partir (É19) : ce que l'appli vérifie seule, et une liste à cocher modifiable. */
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { Bouton, Carte, EnTete, Titre, s, useMaintenant } from '@/ui/composants';
import { C, idTag, police } from '@/ui/theme';
import { useEtat } from '@/store/store';
import { ecrireValeur, lireValeur } from '@/db';
import type { Zone } from '@/services/tuiles';
import { raisonRecharge } from '@/calc/saison';
import { reglagesRecharge } from '@/services/suiviTags';

type Point = { titre: string; detail: string; ok: boolean | null; valeur?: string }; // null = inconnu
const LISTE_DEFAUT = ['Batteries du drone chargées', 'Appâts et filet de capture', 'Matériel de pose (tube, fil, colle)', 'Tags chargés (sur le chargeur)', 'Équipement de protection'];

export default function AvantDepart() {
  const router = useRouter();
  const e = useEtat((x) => ({ toit: x.toit, connexion: x.connexion, source: x.source, portatif: x.portatif, etalonnage: x.etalonnage, fiches: x.fichesTags, tags: x.tags }));
  const [liste, setListe] = useState<string[]>(() => lireValeur<string[]>('avantDepart') ?? LISTE_DEFAUT);
  const [coche, setCoche] = useState<Record<string, boolean>>({});
  const [edition, setEdition] = useState(false);
  const [nouveau, setNouveau] = useState('');
  const zones = lireValeur<Zone[]>('zones') ?? [];
  const toitOk = e.source === 'toit' && e.connexion === 'connecte' && e.toit;
  const p = e.portatif.connexion === 'connecte' && e.portatif.source === 'ble' ? e.portatif.st : null;
  const r = e.etalonnage.resultat;
  const dispo = Object.values(e.fiches).filter((f) => f.etat === 'dispo').length;
  const maint = useMaintenant(60000);
  const rr = reglagesRecharge();
  const recharger = Object.values(e.fiches).filter((f) => f.etat !== 'pose' && f.etat !== 'perdu' && raisonRecharge(f, maint, rr.seuil, rr.jours) !== null);

  const auto: Point[] = [
    { titre: 'Toit chargé', detail: toitOk ? (e.toit!.charge ? 'en charge' : 'batterie') : 'connectez le toit pour vérifier', ok: toitOk ? e.toit!.battPct >= 50 : null, valeur: toitOk ? `${e.toit!.battPct} %` : undefined },
    { titre: 'GPS du toit', detail: toitOk ? `${e.toit!.sats} satellites` : 'connectez le toit pour vérifier', ok: toitOk ? e.toit!.sats >= 6 : null },
    { titre: 'Portatif', detail: p ? (p.bat < 50 ? 'à recharger : moins de 3 h d\'autonomie' : 'chargé') : 'connectez le portatif pour vérifier', ok: p ? p.bat >= 50 : null, valeur: p ? `${p.bat} %` : undefined },
    { titre: 'Tags prêts', detail: 'tags marqués disponibles dans « Mes tags »', ok: dispo > 0, valeur: String(dispo) },
    { titre: 'Tags rechargés', detail: recharger.length ? `à recharger : ${recharger.slice(0, 8).map((f) => idTag(f.id)).join(', ')}${recharger.length > 8 ? '…' : ''}` : 'tous rechargés récemment', ok: recharger.length === 0, valeur: recharger.length ? String(recharger.length) : undefined },
    { titre: 'Carte de la zone hors ligne', detail: zones.length ? zones.map((z) => z.nom).join(', ') : 'aucune zone téléchargée', ok: zones.length > 0 },
    { titre: 'Toit étalonné', detail: r ? `erreur ${Math.round(r.errDeg)}° le ${new Date(r.date).toLocaleDateString('fr-FR')}` : 'jamais étalonné', ok: r ? r.errDeg <= 20 : false },
  ];
  const prets = auto.filter((a) => a.ok).length + liste.filter((l) => coche[l]).length;
  const total = auto.length + liste.length;
  const enregistrer = (l: string[]) => { setListe(l); ecrireValeur('avantDepart', l); };

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Avant de partir" />
      <Text style={{ color: C.encre, fontSize: police.titre, fontWeight: '800' }}>{prets} sur {total} prêts</Text>
      <Carte>
        <Titre>Vérifié par l'appli</Titre>
        {auto.map((a) => (
          <View key={a.titre} style={[s.ligne, { paddingVertical: 8, borderTopWidth: 1, borderTopColor: C.ligne, gap: 10 }]}>
            <Rond ok={a.ok} />
            <View style={{ flex: 1 }}>
              <Text style={{ color: C.encre }}>{a.titre}</Text>
              <Text style={[s.discret, { fontSize: police.mini, color: a.ok === false ? C.alerte : C.discret }]}>{a.detail}</Text>
            </View>
            {!!a.valeur && <Text style={{ color: C.encre, fontWeight: '700' }}>{a.valeur}</Text>}
          </View>
        ))}
      </Carte>
      <Carte>
        <View style={[s.ligne, { justifyContent: 'space-between' }]}>
          <Titre>À cocher</Titre>
          <Pressable onPress={() => setEdition(!edition)}><Text style={[s.discret, { textDecorationLine: 'underline', marginBottom: 8 }]}>{edition ? 'Terminé' : 'Modifier la liste'}</Text></Pressable>
        </View>
        {liste.map((l) => (
          <Pressable key={l} onPress={() => (edition ? enregistrer(liste.filter((x) => x !== l)) : setCoche({ ...coche, [l]: !coche[l] }))}
            style={[s.ligne, { paddingVertical: 10, borderTopWidth: 1, borderTopColor: C.ligne, gap: 10 }]}>
            {edition ? <Text style={{ color: C.alerte, fontSize: 18, width: 22 }}>✕</Text> : <Rond ok={coche[l] ? true : null} carre />}
            <Text style={{ color: C.encre, flex: 1 }}>{l}</Text>
          </Pressable>
        ))}
        {edition && (
          <View style={[s.ligne, { gap: 8, marginTop: 8 }]}>
            <TextInput value={nouveau} onChangeText={setNouveau} placeholder="Ajouter une ligne" placeholderTextColor="#9AA3AC"
              style={{ flex: 1, borderWidth: 1, borderColor: C.ligne, borderRadius: 8, padding: 8, color: C.encre }} />
            <View style={{ width: 90 }}><Bouton titre="Ajouter" onPress={() => { if (nouveau.trim()) { enregistrer([...liste, nouveau.trim()]); setNouveau(''); } }} /></View>
          </View>
        )}
      </Carte>
      <View style={[s.ligne, { gap: 10 }]}>
        <Bouton titre="Réglages" onPress={() => router.navigate('/reglages')} />
        <Bouton titre="Partir" plein onPress={() => router.navigate('/')} />
      </View>
    </ScrollView>
  );
}

function Rond({ ok, carre }: { ok: boolean | null; carre?: boolean }) {
  const fond = ok === true ? C.ok : ok === false ? C.alerte : 'transparent';
  return (
    <View style={{ width: 22, height: 22, borderRadius: carre ? 5 : 11, borderWidth: 2, borderColor: ok === null ? C.discret : fond, backgroundColor: fond, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>{ok === true ? '✓' : ok === false ? '!' : ''}</Text>
    </View>
  );
}
