/** « Nid trouvé ici » (raccourci Android) : attend une position correcte, puis crée la fiche du nid à cet endroit. */
import { useRouter } from 'expo-router';
import React, { useEffect } from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { Bouton, Carte, EnTete, s } from '@/ui/composants';
import { C, fmtCoord, police } from '@/ui/theme';
import { meilleurePosition, useEtat } from '@/store/store';
import { nouveauNid } from '@/services/carnet';
import { suivrePosition } from '@/services/position';
import { useParametres } from '@/services/parametres';

export default function NidIci() {
  const router = useRouter();
  const tel = useEtat((x) => x.telephone);
  const P = useParametres();
  useEtat((x) => x.toit); // suit aussi la position du toit ou du portatif
  useEffect(() => { suivrePosition(); }, []);
  const p = meilleurePosition();
  const precision = p?.source === 'telephone' && tel ? Math.round(tel.precision) : null;
  const bonne = !!p && (precision === null || precision <= P.positionBonneM);
  const noter = () => {
    if (!p) return;
    const id = nouveauNid(-1, p.lat, p.lon, Math.max(5, precision ?? 10), 'noté sur place');
    if (id) router.replace({ pathname: '/nid/[id]', params: { id: String(id) } });
  };
  return (
    <View style={[s.ecran, s.contenu]}>
      <EnTete titre="Nid trouvé ici" />
      <Carte>
        {!p ? (
          <View style={{ alignItems: 'center', paddingVertical: 20, gap: 10 }}>
            <ActivityIndicator color={C.encre} />
            <Text style={s.discret}>Recherche de la position… (localisation activée, dehors de préférence)</Text>
          </View>
        ) : (
          <>
            <Text style={{ color: C.encre, fontSize: police.normal + 2, fontWeight: '800' }}>{fmtCoord(p.lat, p.lon)}</Text>
            <Text style={[s.discret, { marginVertical: 6 }]}>
              {p.source === 'telephone' ? `GPS du téléphone, précision ± ${precision ?? '?'} m${bonne ? '' : ' : attendez quelques secondes, elle s\'améliore'}` : `position du ${p.source}`}
            </Text>
            <Bouton titre="Noter le nid ici" plein onPress={noter} />
          </>
        )}
      </Carte>
      <Text style={[s.discret, { fontSize: police.mini }]}>Placez-vous au plus près du nid (sous l'arbre). La fiche s'ouvre ensuite pour la description et les photos.</Text>
    </View>
  );
}
