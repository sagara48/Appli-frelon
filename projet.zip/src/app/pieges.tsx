/** Pièges de printemps : carnet des pièges à fondatrices, relevés, captures par semaine. */
import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import Svg, { Rect, Text as T } from 'react-native-svg';
import { Bouton, Carte, Champ, EnTete, Puces, Titre, Vide, s, useMaintenant } from '@/ui/composants';
import { C, fmtDist, police } from '@/ui/theme';
import { meilleurePosition, useEtat } from '@/store/store';
import { distM } from '@/calc/geo';
import { aRelever as aReleverPiege, capturesParSemaine, capturesPiege, dernierReleve, piegeActif } from '@/calc/saison';
import { nouveauPiege } from '@/services/carnet';
import { param, useParametres } from '@/services/parametres';
import { listeAppats } from '@/calc/parametres';
import type { Piege } from '@/db';

const jours = (ms: number, t: number) => Math.floor((t - ms) / 86400000);

export default function Pieges() {
  const router = useRouter();
  const { width } = useWindowDimensions();
  const maint = useMaintenant(60000);
  const e = useEtat((x) => ({ pieges: x.pieges, ruchers: x.ruchers }));
  const P = useParametres();
  const APPATS = listeAppats(P);
  const aRelever = (p: Piege, t: number) => aReleverPiege(p, t, P.releverJours);
  const prm = useLocalSearchParams<{ lat?: string; lon?: string }>();
  const pointe = prm.lat && prm.lon ? { lat: Number(prm.lat), lon: Number(prm.lon) } : null;
  const [ajout, setAjout] = useState(!!pointe);
  const [nom, setNom] = useState('');
  const [appat, setAppat] = useState(() => listeAppats(param())[0] ?? '');
  const [vue, setVue] = useState<'actifs' | 'tous'>('actifs');
  const an = new Date(maint).getFullYear();

  const ajouter = () => {
    const p = pointe ?? meilleurePosition();
    if (!p) { Alert.alert('Piège', 'Pas de position : activez la localisation ou faites un appui long sur la carte.'); return; }
    const id = nouveauPiege(nom.trim() || `Piège ${e.pieges.length + 1}`, p.lat, p.lon, appat);
    setAjout(false); setNom('');
    if (id) router.push({ pathname: '/piege/[id]', params: { id: String(id) } });
  };

  const liste = e.pieges.filter((p) => vue === 'tous' || piegeActif(p))
    .sort((a, b) => Number(aRelever(b, maint)) - Number(aRelever(a, maint)) || capturesPiege(b, an) - capturesPiege(a, an));
  const actifs = e.pieges.filter(piegeActif);
  const total = e.pieges.reduce((a, p) => a + capturesPiege(p, an), 0);
  const nRelever = actifs.filter((p) => aRelever(p, maint)).length;
  const sem = capturesParSemaine(e.pieges, an).slice(-10);
  const W = width - 64, bw = sem.length ? W / sem.length : 0, max = Math.max(1, ...sem.map((x) => x.n));
  const rucherProche = (lat: number, lon: number) => {
    let b: { nom: string; d: number } | null = null;
    for (const r of e.ruchers) { const d = distM(lat, lon, r.lat, r.lon); if (!b || d < b.d) b = { nom: r.nom, d }; }
    return b;
  };

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre="Pièges de printemps" />
      <Text style={s.discret}>Pièges à fondatrices (février à mai), autour des ruchers et des nids de l'an passé. Une fondatrice piégée, c'est un nid de moins à l'été.</Text>
      <View style={[s.ligne, { gap: 10 }]}>
        <Gros k="Pièges actifs" v={String(actifs.length)} />
        <Gros k={`Frelons ${an}`} v={String(total)} />
        <Gros k="À relever" v={String(nRelever)} alerte={nRelever > 0} />
      </View>

      {sem.length > 0 && (
        <Carte>
          <Titre>Captures par semaine</Titre>
          <Svg width={W} height={110}>
            {sem.map((x, i) => (
              <React.Fragment key={x.lundi}>
                <Rect x={i * bw + bw * 0.15} y={80 - (x.n / max) * 64} width={bw * 0.7} height={(x.n / max) * 64 + 1} rx={3} fill={C.accent} />
                <T x={i * bw + bw / 2} y={76 - (x.n / max) * 64} fontSize={11} fontWeight="700" fill={C.encre} textAnchor="middle">{x.n}</T>
                <T x={i * bw + bw / 2} y={98} fontSize={9} fill={C.discret} textAnchor="middle">{new Date(x.lundi).toLocaleDateString('fr-FR', { day: 'numeric', month: 'numeric' })}</T>
              </React.Fragment>
            ))}
          </Svg>
        </Carte>
      )}

      {ajout ? (
        <Carte>
          <Titre>Nouveau piège {pointe ? '(au point choisi sur la carte)' : '(à votre position)'}</Titre>
          <Champ titre="Nom" valeur={nom} onChange={setNom} placeholder={`Piège ${e.pieges.length + 1}, haie du rucher…`} />
          <Text style={[s.discret, { fontSize: police.mini, marginBottom: 4 }]}>Appât</Text>
          <Puces options={APPATS.map((a) => [a, a] as [string, string])} valeur={appat} onChange={setAppat} />
          <View style={[s.ligne, { gap: 10, marginTop: 10 }]}><Bouton titre="Annuler" onPress={() => setAjout(false)} /><Bouton titre="Ajouter" plein onPress={ajouter} /></View>
        </Carte>
      ) : <Bouton titre="Poser un piège ici" plein onPress={() => setAjout(true)} />}

      <Puces options={[['actifs', `En place (${actifs.length})`], ['tous', `Tous (${e.pieges.length})`]]} valeur={vue} onChange={setVue} />
      {!liste.length && <Carte><Vide titre="Aucun piège" texte="Posez un piège à votre position, ou faites un appui long sur la carte à l'endroit voulu." /></Carte>}
      {liste.map((p) => {
        const der = dernierReleve(p), rel = aRelever(p, maint), rp = rucherProche(p.lat, p.lon);
        return (
          <Pressable key={p.id} onPress={() => router.push({ pathname: '/piege/[id]', params: { id: String(p.id) } })}>
            <Carte style={rel ? { borderColor: C.alerte, borderWidth: 1.5 } : undefined}>
              <View style={[s.ligne, { justifyContent: 'space-between' }]}>
                <Text style={{ color: C.encre, fontWeight: '800', fontSize: police.normal + 1, flex: 1 }}>{p.nom}</Text>
                <Text style={{ color: C.encre, fontWeight: '800', fontSize: 20 }}>{capturesPiege(p, an)}</Text>
              </View>
              <Text style={s.discret}>{p.appat || 'appât ?'}{rp ? ` · ${fmtDist(rp.d)} du rucher ${rp.nom}` : ''}{p.auteur ? ` · ${p.auteur}` : ''}</Text>
              <Text style={{ color: !piegeActif(p) ? C.discret : rel ? C.alerte : C.ok, fontWeight: '700', marginTop: 4 }}>
                {!piegeActif(p) ? `Retiré le ${new Date(p.retire_ms!).toLocaleDateString('fr-FR')}` : der ? `Relevé il y a ${jours(der, maint)} j${rel ? (jours(der, maint) > 30 ? ' : à relever ou à retirer' : ' : à relever') : ''}` : 'Jamais relevé'}
              </Text>
            </Carte>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

const Gros = ({ k, v, alerte }: { k: string; v: string; alerte?: boolean }) => (
  <View style={[s.carte, { flex: 1, alignItems: 'center' }]}><Text style={{ fontSize: 24, fontWeight: '800', color: alerte ? C.alerte : C.encre }}>{v}</Text><Text style={[s.discret, { fontSize: police.mini }]}>{k}</Text></View>
);
