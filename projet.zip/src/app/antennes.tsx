/** Santé des antennes du toit (calc/santeAntennes.ts) : niveau de chaque voie par rapport aux autres, sortie après sortie. */
import React from 'react';
import { Alert, ScrollView, Text, View } from 'react-native';
import Svg, { Line, Rect } from 'react-native-svg';
import { Bouton, Carte, EnTete, Titre, Vide, s } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { diagnosticAntennes } from '@/calc/santeAntennes';
import { effacerHistoriqueAntennes, useSanteAntennes } from '@/services/santeAntennes';

const COUL = { ok: C.ok, faible: C.alerte, coupe: C.alerte, apprentissage: C.discret } as const;

export default function Antennes() {
  const h = useSanteAntennes();
  const d = diagnosticAntennes(h);
  const l = h.slice(-20);
  const pb = d.filter((x) => x.etat === 'faible' || x.etat === 'coupe');
  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Santé des antennes du toit" />
      <Text style={s.discret}>
        À chaque sortie, chaque voie est comparée aux autres sur toutes les trames reçues. Son niveau relatif reste à peu près le même
        d'une sortie à l'autre : s'il baisse de 4 dB ou plus pendant 3 sorties de suite, ou si la voie se tait souvent, l'appli prévient.
        Les relèvements se faussent bien avant qu'on s'en aperçoive autrement.
      </Text>
      {!h.length ? (
        <Carte><Vide titre="Pas encore de sortie" texte="Le bilan se fait à la fin de chaque sortie avec le toit (150 trames au moins)." /></Carte>
      ) : (
        <>
          <Carte style={{ borderColor: pb.length ? C.alerte : C.ok, borderWidth: 2 }}>
            <Text style={{ color: C.encre, fontWeight: '800', fontSize: police.normal + 1 }}>{pb.length ? `${pb.length} voie${pb.length > 1 ? 's' : ''} à vérifier` : 'Rien d\'anormal'}</Text>
            <Text style={s.discret}>{h.length} sortie{h.length > 1 ? 's' : ''} analysée{h.length > 1 ? 's' : ''} · dernière le {new Date(h[h.length - 1].t).toLocaleDateString('fr-FR')}</Text>
            {pb.length > 0 && <Text style={[s.discret, { marginTop: 6 }]}>À vérifier : connecteurs SMA serrés et propres, câble non pincé (portière, passage de toit), antenne non fêlée. Après réparation, refaites l'étalonnage du toit.</Text>}
          </Carte>
          {d.map((x, k) => (
            <Carte key={x.voie}>
              <View style={[s.ligne, { justifyContent: 'space-between' }]}>
                <Titre>{`Voie ${x.voie}`}</Titre>
                <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: COUL[x.etat] }} />
              </View>
              <Text style={{ color: x.etat === 'faible' || x.etat === 'coupe' ? C.alerte : C.encre }}>{x.texte}</Text>
              {l.some((b) => b.ecart[k] !== null) && (
                <Svg width="100%" height={46} viewBox={`0 0 ${l.length * 14} 46`} preserveAspectRatio="none" style={{ marginTop: 8 }}>
                  <Line x1={0} y1={23} x2={l.length * 14} y2={23} stroke={C.ligne} strokeWidth={1} />
                  {l.map((b, i) => {
                    const v = b.ecart[k];
                    if (v === null) return null;
                    const ref = x.ref ?? 0, dv = Math.max(-11, Math.min(11, v - ref)) * 2;
                    return <Rect key={i} x={i * 14 + 2} y={dv >= 0 ? 23 - dv : 23} width={10} height={Math.max(1, Math.abs(dv))} fill={v - ref <= -4 ? C.alerte : C.accent} />;
                  })}
                </Svg>
              )}
            </Carte>
          ))}
          <Text style={[s.discret, { fontSize: police.mini }]}>Barres : écart de chaque sortie au niveau habituel de la voie (vers le bas = plus faible), les 20 dernières sorties.</Text>
          <Bouton titre="Repartir de zéro (après un changement d'antenne)" onPress={() => Alert.alert('Antennes', 'Effacer l\'historique des sorties ?', [{ text: 'Annuler', style: 'cancel' }, { text: 'Effacer', style: 'destructive', onPress: effacerHistoriqueAntennes }])} />
        </>
      )}
    </ScrollView>
  );
}
