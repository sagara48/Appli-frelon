/** Registre des traitements biocides : toutes les interventions de l'année (date, lieu, produit, quantité, opérateur),
 *  totaux par produit, export PDF et Excel. Les contrôles n'y figurent pas (pas de produit). */
import { useRouter } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, EnTete, Puces, Titre, s, useMaintenant } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { useEtat } from '@/store/store';
import { numeroNid } from '@/services/carnet';
import { registrePdf, registreXlsx } from '@/services/exports';
import { aControler, interventionsDe, libelleType, lignesRegistre, totauxProduits } from '@/calc/intervention';
import { useParametres } from '@/services/parametres';

export default function Registre() {
  const router = useRouter();
  const nids = useEtat((e) => e.nids);
  const P = useParametres();
  const maint = useMaintenant(60000);
  const avecInter = useMemo(() => nids.map((n) => ({ id: n.id, lat: n.lat, lon: n.lon, l: interventionsDe(n) })), [nids]);
  const annees = useMemo(() => {
    const a = new Set(avecInter.flatMap((n) => n.l.map((i) => new Date(i.t).getFullYear())));
    a.add(new Date(maint).getFullYear());
    return [...a].sort((x, y) => y - x);
  }, [avecInter, maint]);
  const [an, setAn] = useState(annees[0]);
  const operateurs = useMemo(() => [...new Set(avecInter.flatMap((n) => n.l.map((i) => i.operateur)).filter(Boolean))], [avecInter]);
  const [op, setOp] = useState('');
  const lignes = lignesRegistre(avecInter, (id) => numeroNid(nids, id), an, op);
  const tot = totauxProduits(lignes);
  const aCtrl = nids.filter((n) => aControler(n, maint, P.controleJours));
  const [occupe, setOccupe] = useState('');
  const exporter = async (q: 'pdf' | 'xlsx') => {
    setOccupe(q);
    try { await (q === 'pdf' ? registrePdf(lignes, an) : registreXlsx(lignes, an)); } catch (e) { Alert.alert('Export', String(e)); } finally { setOccupe(''); }
  };

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Registre des traitements" />
      <Puces options={annees.map((a) => [a, String(a)] as [number, string])} valeur={an} onChange={setAn} />
      {operateurs.length > 1 && <View style={{ marginTop: 8 }}><Puces options={[['', 'Tous'], ...operateurs.map((o) => [o, o] as [string, string])]} valeur={op} onChange={setOp} /></View>}

      {aCtrl.length > 0 && (
        <Carte>
          <Titre>Contrôles à faire</Titre>
          {aCtrl.map((n) => (
            <Pressable key={n.id} onPress={() => router.push({ pathname: '/intervention', params: { nid: String(n.id), type: 'controle' } })} style={{ paddingVertical: 6 }}>
              <Text style={{ color: C.alerte, fontWeight: '700' }}>Nid n° {numeroNid(nids, n.id)} · traité le {new Date(n.traite_ms ?? 0).toLocaleDateString('fr-FR')}</Text>
            </Pressable>
          ))}
        </Carte>
      )}

      <Carte>
        <Titre>{lignes.length} intervention{lignes.length > 1 ? 's' : ''} en {an}</Titre>
        {tot.map((t) => (
          <Text key={t.produit} style={{ color: C.encre }}>{t.produit} : {t.n} traitement{t.n > 1 ? 's' : ''}, {String(Math.round(t.g * 10) / 10).replace('.', ',')} g</Text>
        ))}
        <View style={[s.ligne, { gap: 10, marginTop: 10 }]}>
          {occupe ? <ActivityIndicator color={C.encre} /> : (
            <>
              <Bouton titre="Registre PDF" plein desactive={!lignes.length} onPress={() => exporter('pdf')} />
              <Bouton titre="Excel" desactive={!lignes.length} onPress={() => exporter('xlsx')} />
            </>
          )}
        </View>
      </Carte>

      {[...lignes].reverse().map(({ nid, inter: i }) => {
        const n = nids.find((x) => numeroNid(nids, x.id) === nid);
        return (
          <Pressable key={i.id} onPress={() => n && router.push({ pathname: '/intervention', params: { nid: String(n.id), i: i.id } })}
            style={{ paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: C.ligne }}>
            <Text style={{ color: C.encre, fontWeight: '700' }}>{new Date(i.t).toLocaleDateString('fr-FR')} · nid n° {nid} · {libelleType(i.type)}</Text>
            <Text style={s.discret}>{[i.client.commune, i.methode, i.produit && `${i.produit}${i.quantiteG !== null ? ` ${String(i.quantiteG).replace('.', ',')} g` : ''}`, i.operateur].filter(Boolean).join(' · ')}</Text>
          </Pressable>
        );
      })}
      {!lignes.length && <Text style={[s.discret, { textAlign: 'center', marginTop: 10 }]}>Aucune intervention en {an}. Elles se notent depuis la fiche d'un nid.</Text>}
      <Text style={[s.discret, { fontSize: police.mini, marginTop: 10 }]}>Produits et n° d'autorisation : Menu → Produits biocides. Entreprise et n° Certibiocide : Paramètres.</Text>
    </ScrollView>
  );
}
