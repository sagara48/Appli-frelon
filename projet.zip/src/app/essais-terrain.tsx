/** Essais sur le terrain : tout ce qui n'a pas encore tourné sur le vrai matériel, appareil par appareil.
 *  Coches automatiques quand l'appli voit passer la preuve, sinon « Marche » / « Problème » + note ; rapport à partager. */
import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, Share, Text, TextInput, View } from 'react-native';
import { Bouton, Carte, EnTete, Titre, s } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { useEtat } from '@/store/store';
import { APPAREILS, ESSAIS, bilanEssais, rapportEssais, type Essai } from '@/calc/essaisTerrain';
import { effacerEssais, noterEssai, useEssaisTerrain } from '@/services/essaisTerrain';

export default function EssaisTerrain() {
  const r = useEssaisTerrain();
  const v = useEtat((x) => ({ toit: x.versionToit, port: x.portatif.version }));
  const [ouvert, setOuvert] = useState<string | null>(null);
  const [note, setNote] = useState('');
  const b = bilanEssais(r);
  const entete = [`Toit ${v.toit?.fw ?? '?'} · portatif ${v.port?.fw ?? '?'} · ${new Date().toLocaleString('fr-FR')}`];

  const ligne = (e: Essai) => {
    const x = r[e.id], ouv = ouvert === e.id;
    return (
      <View key={e.id} style={{ paddingVertical: 10, borderTopWidth: 1, borderTopColor: C.ligne, gap: 6 }}>
        <Pressable onPress={() => { setOuvert(ouv ? null : e.id); setNote(x?.note ?? ''); }} style={[s.ligne, { gap: 10, alignItems: 'flex-start' }]}>
          <View style={{ width: 26, height: 26, borderRadius: 13, alignItems: 'center', justifyContent: 'center', backgroundColor: x ? (x.etat === 'ok' ? C.ok : C.alerte) : C.ligne }}>
            <Text style={{ color: x ? '#fff' : C.discret, fontWeight: '800' }}>{x ? (x.etat === 'ok' ? '✓' : '!') : ''}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: C.encre, fontWeight: '700' }}>{e.titre}</Text>
            {x && <Text style={[s.discret, { fontSize: police.mini }]}>{x.etat === 'ok' ? (x.auto ? 'vu par l\'appli' : 'marche') : 'problème'} · {new Date(x.t).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}{x.note ? ` · ${x.note}` : ''}</Text>}
            {!x && e.auto && <Text style={[s.discret, { fontSize: police.mini }]}>se coche seul quand l'appli le voit</Text>}
          </View>
        </Pressable>
        {ouv && (
          <View style={{ gap: 8, paddingLeft: 36 }}>
            <Text style={s.discret}>{e.comment}</Text>
            <TextInput value={note} onChangeText={setNote} placeholder="Note (ce qui s'est passé, écart mesuré…)" placeholderTextColor="#9AA3AC" multiline
              style={{ borderWidth: 1, borderColor: C.ligne, borderRadius: 10, padding: 10, color: C.encre, minHeight: 44, backgroundColor: C.carte }} />
            <View style={[s.ligne, { gap: 8 }]}>
              <Bouton titre="Marche" plein onPress={() => { noterEssai(e.id, 'ok', note.trim()); setOuvert(null); }} />
              <Bouton titre="Problème" onPress={() => { noterEssai(e.id, 'ko', note.trim()); setOuvert(null); }} />
              {x && <Pressable onPress={() => { noterEssai(e.id, null); setOuvert(null); }} style={{ justifyContent: 'center' }}><Text style={[s.discret, { textDecorationLine: 'underline' }]}>À refaire</Text></Pressable>}
            </View>
          </View>
        )}
      </View>
    );
  };

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre="Essais sur le terrain" />
      <Carte style={{ borderColor: b.ko ? C.alerte : b.reste ? C.accent : C.ok, borderWidth: 2 }}>
        <Text style={{ color: C.encre, fontSize: police.normal + 2, fontWeight: '800' }}>{b.ok} marchent · {b.ko} problème{b.ko > 1 ? 's' : ''} · {b.reste} à faire</Text>
        <Text style={[s.discret, { marginTop: 4 }]}>
          Ce qui n'a encore jamais tourné sur le vrai matériel. Touchez un essai pour voir comment le faire. Ceux marqués « se coche seul »
          se valident dès que l'appli voit passer la preuve (la sortie simulée ne compte pas). Envoyez le rapport : il dit quoi corriger.
        </Text>
        <View style={[s.ligne, { gap: 10, marginTop: 10 }]}>
          <Bouton titre="Partager le rapport" plein onPress={() => { Share.share({ message: rapportEssais(r, entete) }).catch(() => {}); }} />
          <Bouton titre="Tout recommencer" onPress={() => Alert.alert('Essais', 'Effacer tous les résultats ?', [{ text: 'Annuler', style: 'cancel' }, { text: 'Effacer', style: 'destructive', onPress: effacerEssais }])} />
        </View>
      </Carte>
      {APPAREILS.map((a) => {
        const l = ESSAIS.filter((e) => e.appareil === a);
        const fait = l.filter((e) => r[e.id]).length;
        return (
          <Carte key={a}>
            <View style={[s.ligne, { justifyContent: 'space-between' }]}>
              <Titre>{a}</Titre>
              <Text style={s.discret}>{fait} / {l.length}</Text>
            </View>
            {l.map(ligne)}
          </Carte>
        );
      })}
    </ScrollView>
  );
}
