/** Activité des frelons selon la météo (É23) : meilleur créneau, heure par heure, jours suivants (Open-Meteo). */
import { useLocalSearchParams } from 'expo-router';
import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import Svg, { Rect, Text as T } from 'react-native-svg';
import { Bouton, Carte, EnTete, Titre, s } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { meilleurePosition, useEtat } from '@/store/store';
import { pointCardinal } from '@/calc/geo';
import { chargerMeteo, meilleurCreneau, type Meteo } from '@/services/meteo';
import { suivrePosition } from '@/services/position';
import { ecrireValeur, lireValeur } from '@/db';
import { useParametres } from '@/services/parametres';

const ACT = ['Nulle', 'Faible', 'Moyenne', 'Forte'];
const COUL = ['#C9CDC4', '#E9D79A', '#E8B54A', C.accent];
const JOURS = ['Dim.', 'Lun.', 'Mar.', 'Mer.', 'Jeu.', 'Ven.', 'Sam.'];

export default function MeteoEcran() {
  const { rucher } = useLocalSearchParams<{ rucher?: string }>();
  const { width } = useWindowDimensions();
  const e = useEtat((x) => ({ ruchers: x.ruchers, telephone: x.telephone }));
  const P = useParametres();
  const r = e.ruchers.find((x) => x.id === Number(rucher)) ?? e.ruchers[0];
  const [m, setM] = useState<Meteo | null>(() => lireValeur<Meteo>('meteo'));
  const [err, setErr] = useState('');
  const [charge, setCharge] = useState(false);
  useEffect(() => { suivrePosition(); }, []);
  const lieu = r ? { lat: r.lat, lon: r.lon, nom: `autour du rucher ${r.nom}` } : (() => { const p = meilleurePosition(); return p ? { lat: p.lat, lon: p.lon, nom: 'autour de vous' } : null; })();

  const la = lieu?.lat, lo = lieu?.lon;
  const charger = useCallback(() => {
    if (la === undefined || lo === undefined) return;
    setCharge(true); setErr('');
    chargerMeteo(la, lo, { tempMin: P.tempMin, ventMax: P.ventMax }).then((x) => { setM(x); ecrireValeur('meteo', x); }).catch((e2) => setErr(String((e2 as Error).message ?? e2))).finally(() => setCharge(false));
  }, [la, lo, P.tempMin, P.ventMax]);
  const recu = m?.recuMs ?? 0;
  // chargement réseau au premier affichage (une fois par lieu), sauf si la dernière prévision a moins de 30 min
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- requête réseau lancée par l'affichage de l'écran
    if (Date.now() - recu > 30 * 60000) charger();
  }, [charger]); // eslint-disable-line react-hooks/exhaustive-deps

  const heures = m?.heures.filter((h) => h.h >= 8 && h.h <= 19) ?? [];
  const cr = m ? meilleurCreneau(m.heures) : null;
  const plusChaud = heures.length ? Math.max(...heures.map((h) => h.temp)) : null;
  const ventMax = heures.length ? Math.max(...heures.map((h) => h.vent)) : null;
  const pluie = heures.reduce((a, h) => a + h.pluie, 0);
  const maintenant = m?.heures.find((h) => h.h === new Date().getHours());
  const W = width - 64, bw = heures.length ? W / heures.length : 0;

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Activité des frelons" />
      <Text style={s.discret}>Aujourd'hui · {lieu?.nom ?? 'position inconnue'}{m ? ` · mis à jour à ${new Date(m.recuMs).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}` : ''}</Text>
      {charge && <ActivityIndicator color={C.encre} />}
      {!!err && <Text style={{ color: C.alerte }}>{err} (pas de réseau ?)</Text>}
      {!lieu && <Text style={{ color: C.alerte }}>Ajoutez un rucher ou activez la localisation.</Text>}
      {m && (
        <>
          <Carte style={{ backgroundColor: C.encre }}>
            <Text style={{ color: C.accent, fontWeight: '700', letterSpacing: 1.5, fontSize: police.mini }}>MEILLEUR CRÉNEAU</Text>
            <Text style={{ color: '#fff', fontSize: 34, fontWeight: '800' }}>{cr ? `${cr.debut} h – ${cr.fin} h` : 'Aucun'}</Text>
            <Text style={{ color: '#A9B4BF', lineHeight: 20 }}>
              {cr ? `Bonne journée pour poser des tags : ${Math.round(plusChaud ?? 0)} °C au plus chaud, vent ${ventMax !== null && ventMax < P.ventMax * 0.6 ? 'faible' : `jusqu'à ${Math.round(ventMax ?? 0)} km/h`}, ${pluie < 0.5 ? 'pas de pluie' : `${pluie.toFixed(1).replace('.', ',')} mm de pluie`}.`
                : 'Trop froid, trop de vent ou de la pluie : peu de frelons en chasse aujourd\'hui.'}
            </Text>
          </Carte>
          <Carte>
            <Titre>Heure par heure</Titre>
            <Svg width={W} height={130}>
              {heures.map((h, i) => (
                <React.Fragment key={h.h}>
                  <Rect x={i * bw + 2} y={70 - h.activite * 18} width={bw - 4} height={h.activite * 18 + 4} rx={3} fill={COUL[h.activite]} />
                  <T x={i * bw + bw / 2} y={92} fontSize={10} fill={C.discret} textAnchor="middle">{h.h}h</T>
                  <T x={i * bw + bw / 2} y={110} fontSize={11} fontWeight="700" fill={C.encre} textAnchor="middle">{Math.round(h.temp)}°</T>
                  {h.pluie >= 0.5 && <T x={i * bw + bw / 2} y={126} fontSize={9} fill={C.oeil} textAnchor="middle">pluie</T>}
                </React.Fragment>
              ))}
            </Svg>
            <View style={[s.ligne, { gap: 12 }]}>
              {[3, 2, 1].map((a) => <View key={a} style={[s.ligne, { gap: 4 }]}><View style={{ width: 10, height: 10, borderRadius: 2, backgroundColor: COUL[a] }} /><Text style={[s.discret, { fontSize: police.mini }]}>{ACT[a]}</Text></View>)}
            </View>
            <View style={[s.ligne, { justifyContent: 'space-between', marginTop: 10 }]}>
              <Text style={s.discret}>Vent <Text style={{ color: C.encre, fontWeight: '700' }}>{maintenant ? `${Math.round(maintenant.vent)} km/h ${pointCardinal(maintenant.dirVent)}` : '—'}</Text></Text>
              <Text style={s.discret}>Pluie <Text style={{ color: C.encre, fontWeight: '700' }}>{pluie.toFixed(1).replace('.', ',')} mm</Text></Text>
              <Text style={s.discret}>Coucher <Text style={{ color: C.encre, fontWeight: '700' }}>{m.coucher.replace(':', ' h ')}</Text></Text>
            </View>
          </Carte>
          <Carte>
            <Titre>Jours suivants</Titre>
            {m.jours.slice(1).map((j) => (
              <View key={j.date} style={[s.ligne, { justifyContent: 'space-between', paddingVertical: 6, borderTopWidth: 1, borderTopColor: C.ligne }]}>
                <Text style={{ color: C.encre, width: 50, fontWeight: '700' }}>{JOURS[new Date(j.date).getDay()]}</Text>
                <Text style={[s.discret, { flex: 1 }]}>{Math.round(j.tmax)}° · {j.pluie >= 1 ? `pluie ${Math.round(j.pluie)} mm` : `vent ${Math.round(j.ventMax)} km/h`}</Text>
                <Text style={{ color: j.activite >= 3 ? C.ok : j.activite === 2 ? C.accent : C.discret, fontWeight: '700' }}>{j.activite >= 3 ? 'Bon' : j.activite === 2 ? 'Moyen' : 'Inutile'}</Text>
              </View>
            ))}
          </Carte>
        </>
      )}
      <Bouton titre="Actualiser" onPress={charger} desactive={!lieu || charge} />
      <Text style={[s.discret, { fontSize: police.mini }]}>Seuils (Paramètres) : activité au-dessus de {String(P.tempMin).replace('.', ',')} °C, gênée au-delà de {P.ventMax} km/h de vent, nulle sous la pluie. Prévisions Open-Meteo.</Text>
    </ScrollView>
  );
}
