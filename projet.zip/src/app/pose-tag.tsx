/** Poser un tag (É17) : choisir, vérifier qu'il émet, mémoriser l'appât, relâcher (le chrono démarre). Faisable d'une main. */
import { useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Alert, ScrollView, Text, TextInput, View } from 'react-native';
import { Bouton, Carte, EnTete, Titre, s } from '@/ui/composants';
import { C, idTag, police } from '@/ui/theme';
import { ageS, agePortatif, appatActifDe, chronoLacher, chronoManuel, meilleurePosition, store, useEtat } from '@/store/store';
import { niveauPct } from '@/calc/geo';
import { majTag } from '@/services/carnet';
import { suivrePosition } from '@/services/position';
import { cmdPortatif } from '@/proto/portatif';
import { envoyerPortatif } from '@/sources/portatif';

export default function PoseTag() {
  const router = useRouter();
  const e = useEtat((x) => ({ tags: x.tags, portatif: x.portatif, horlogeMs: x.horlogeMs, chrono: x.chrono, telephone: x.telephone, toit: x.toit, fiches: x.fichesTags }));
  const [saisie, setSaisie] = useState('');
  const [tag, setTag] = useState<number | null>(null);
  const [appat, setAppat] = useState<{ lat: number; lon: number; source: string } | null>(null);
  useEffect(() => { suivrePosition(); }, []);

  // le portatif suit le tag choisi : on voit tout de suite s'il émet
  useEffect(() => { if (tag !== null && store.get().portatif.connexion === 'connecte') envoyerPortatif(cmdPortatif.tag(tag)).catch(() => {}); }, [tag]);

  const t = tag !== null ? e.tags[tag] : undefined;
  const st = e.portatif.st && e.portatif.st.tag === tag ? e.portatif.st : null;
  const emet = t && ageS(store.get(), t) < 15 ? { pct: niveauPct(Math.max(...t.r)), pile: t.pile } : st && agePortatif(store.get()) < 15 ? { pct: niveauPct(st.rssi), pile: -1 } : null;
  const etape = tag === null ? 1 : !emet ? 2 : !appat ? 3 : 4;
  const dispo = Object.values(e.fiches).filter((f) => f.etat === 'dispo').map((f) => f.id);

  const memoriser = () => {
    const p = meilleurePosition();
    if (!p) { Alert.alert('Position', 'Pas de position : activez la localisation, ou connectez le toit / le portatif.'); return; }
    setAppat({ lat: p.lat, lon: p.lon, source: p.source === 'voiture' ? 'voiture (toit)' : p.source === 'portatif' ? 'portatif' : `téléphone ± ${Math.round(e.telephone?.precision ?? 0)} m` });
  };
  const envol = () => {
    if (tag === null || !appat) return;
    const voiture = appat.source.startsWith('voiture');
    chronoLacher(tag, appat.lat, appat.lon, voiture ? 'voiture' : 'main');
    if (!voiture) chronoManuel(tag, 'parti', null); // sans le toit, le chrono démarre à l'envol
    majTag(tag, { etat: 'pose', pose_ms: Date.now(), lat: appat.lat, lon: appat.lon, appat: appatActifDe(tag)?.id ?? null });
    store.choisirTag(tag);
    router.replace('/chrono');
  };

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Poser un tag" />
      <Text style={s.discret}>Étape {etape} sur 4 · à faire d'une main</Text>

      <Etape no={1} fait={tag !== null} titre={tag !== null ? `Tag choisi ${idTag(tag)}` : 'Choisir le tag'}>
        <View style={[s.ligne, { gap: 8 }]}>
          <TextInput value={saisie} onChangeText={setSaisie} keyboardType="numeric" placeholder="n° du tag" placeholderTextColor="#9AA3AC"
            style={{ flex: 1, borderWidth: 1, borderColor: C.ligne, borderRadius: 8, padding: 10, fontSize: 20, color: C.encre }} />
          <View style={{ width: 110 }}><Bouton titre="Choisir" plein onPress={() => { const n = parseInt(saisie, 10); if (n >= 0 && n < 256) setTag(n); }} /></View>
        </View>
        {dispo.length > 0 && <Text style={[s.discret, { marginTop: 6 }]}>Disponibles : {dispo.map(idTag).join(', ')}</Text>}
      </Etape>

      <Etape no={2} fait={!!emet} titre={emet ? `Il émet bien ${emet.pct ?? 0} %${emet.pile >= 0 ? ` · pile ${emet.pile} %` : ''}` : 'Vérifier qu\'il émet'}>
        {tag !== null && !emet && <Text style={s.discret}>Pas encore reçu. Approchez le tag du toit ou du portatif (connecté), il émet une fois par seconde.</Text>}
      </Etape>

      <Etape no={3} fait={!!appat} titre={appat ? `Appât mémorisé ici · ${appat.source}` : 'Mémoriser l\'appât ici'}>
        {!appat && <Bouton titre="Mémoriser la position de l'appât" desactive={tag === null} onPress={memoriser} />}
      </Etape>

      <Etape no={4} fait={false} titre="Relâcher le frelon">
        <Text style={s.discret}>Appuyez au moment où il s'envole. Le chrono démarre et le toit commence à suivre le tag{tag !== null ? ` ${idTag(tag)}` : ''}.</Text>
        <View style={{ marginTop: 10 }}>
          <Bouton titre="Il s'envole" plein desactive={tag === null || !appat} onPress={envol} />
        </View>
        {tag !== null && appat && !emet && <Text style={{ color: C.alerte, marginTop: 6 }}>Le tag n'a pas encore été reçu : vérifiez-le avant de relâcher.</Text>}
      </Etape>

      <Carte>
        <Titre>Rappels</Titre>
        <Text style={{ color: C.encre, lineHeight: 21 }}>•  Fil d'antenne vers l'arrière, le long de l'abdomen.</Text>
        <Text style={{ color: C.encre, lineHeight: 21 }}>•  Laisser sécher la colle 1 minute avant de relâcher.</Text>
        <Text style={{ color: C.encre, lineHeight: 21 }}>•  Le tag pèse environ le poids d'une goutte d'eau : choisir une ouvrière bien vigoureuse.</Text>
      </Carte>
    </ScrollView>
  );
}

function Etape({ no, titre, fait, children }: { no: number; titre: string; fait: boolean; children?: React.ReactNode }) {
  return (
    <Carte>
      <View style={[s.ligne, { gap: 12, alignItems: 'flex-start' }]}>
        <View style={{ width: 28, height: 28, borderRadius: 14, backgroundColor: fait ? C.ok : C.encre, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: '#fff', fontWeight: '800' }}>{fait ? '✓' : no}</Text>
        </View>
        <View style={{ flex: 1, gap: 8 }}>
          <Text style={{ color: C.encre, fontWeight: '700', fontSize: police.normal + 1 }}>{titre}</Text>
          {children}
        </View>
      </View>
    </Carte>
  );
}
