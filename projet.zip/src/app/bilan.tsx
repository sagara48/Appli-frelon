/** Bilan de saison (É21) : nids trouvés, détruits, précision, efficacité, tags ; export tableur. */
import { LIBELLE_METHODE, resultatsSaison } from '@/calc/resultats';
import React, { useState } from 'react';
import { Alert, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import Svg, { Rect, Text as T } from 'react-native-svg';
import { Bouton, Carte, EnTete, Puces, Titre, s, useMaintenant } from '@/ui/composants';
import { C, fmtDist, police } from '@/ui/theme';
import { useEtat } from '@/store/store';
import { distM } from '@/calc/geo';
import { resume } from '@/calc/appat';
import { lirePoses, numeroNid } from '@/services/carnet';
import { exporterCsv, exporterGdsaPdf, exporterGdsaXlsx, libelleEtatNid } from '@/services/exports';
import { sessionActuelle } from '@/services/auth';
import { useParametres } from '@/services/parametres';
import { comparerSaisons, statsRucher } from '@/calc/saison';

const SEMAINE = 7 * 86400000;
const lundi = (ms: number) => { const d = new Date(ms); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d.getTime(); };

/** Journal des poses, complété par la pose en cours de chaque tag (poses d'avant le journal). */
const posesConnues = (j: { tag: number; t: number }[], fiches: { id: number; pose_ms: number | null }[]) =>
  [...j, ...fiches.filter((f) => f.pose_ms && !j.some((x) => x.tag === f.id && x.t === f.pose_ms)).map((f) => ({ tag: f.id, t: f.pose_ms! }))];
/** Durée lisible à partir d'heures. */
const duree = (h: number) => (h < 1 ? `${Math.max(1, Math.round(h * 60))} min` : h < 48 ? `${String(Math.round(h * 10) / 10).replace('.', ',')} h` : `${Math.round(h / 24)} j`);

export default function Bilan() {
  const { width } = useWindowDimensions();
  const e = useEtat((x) => ({ nids: x.nids, fiches: x.fichesTags, chrono: x.chrono, ruchers: x.ruchers, pieges: x.pieges }));
  const now = useMaintenant(60000);
  const saisons = comparerSaisons(e.nids, e.ruchers, e.pieges);
  const anneeCourante = new Date(now).getFullYear();
  const [choix, setChoix] = useState<number | null>(null);
  const annee = choix ?? anneeCourante;
  const annees = [...new Set([anneeCourante, ...saisons.map((x) => x.annee)])].sort((a, b) => b - a);
  const P = useParametres();
  const parRucher = e.ruchers.map((r) => statsRucher(r, e.nids, e.pieges, annee, P.rayonMenaceM, P.rayonLargeM)).sort((a, b) => b.n1km - a.n1km || b.n3km - a.n3km);
  const comp = saisons.slice(0, 5);
  const graph = saisons.slice(0, 3).reverse(); // 3 dernières saisons, de la plus ancienne à la plus récente
  const MOIS = [4, 5, 6, 7, 8, 9, 10]; // mai à novembre
  const COUL_AN = ['#C9CDC4', '#E9C46A', C.accent];
  const nids = e.nids.filter((n) => new Date(n.t).getFullYear() === annee);
  const res = resultatsSaison(e.nids, posesConnues(lirePoses(), Object.values(e.fiches)), e.ruchers, annee, P.rayonMenaceM);
  const detruits = nids.filter((n) => n.etat === 'traite' || n.etat === 'mort').length;
  const precision = nids.length ? nids.reduce((a, n) => a + n.err, 0) / nids.length : null;
  const debut = nids.length ? Math.min(...nids.map((n) => n.t)) : null;
  // semaines (4 dernières)
  const s0 = lundi(now) - 3 * SEMAINE;
  const sem = [0, 1, 2, 3].map((k) => ({ t: s0 + k * SEMAINE, n: nids.filter((n) => n.t >= s0 + k * SEMAINE && n.t < s0 + (k + 1) * SEMAINE).length }));
  // efficacité : appât → nid
  const dists: number[] = [];
  for (const n of nids) {
    const a = e.chrono.appats.filter((x) => x.tag === n.tag);
    if (a.length) dists.push(Math.min(...a.map((x) => distM(x.lat, x.lon, n.lat, n.lon))));
  }
  const chronos = e.chrono.appats.map((a) => resume(e.chrono, a)).filter((r) => r.rt.ok);
  const sources = nids.reduce<Record<string, number>>((acc, n) => { const k = (n.sources || 'à la main').replace(/\s*\([^)]*\)/g, ''); acc[k] = (acc[k] ?? 0) + 1; return acc; }, {});
  const methode = Object.entries(sources).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} (${v})`).join(', ');
  const tags = Object.values(e.fiches);
  const nb = (et: string) => tags.filter((t) => t.etat === et).length;

  const W = width - 64, bw = W / 4, max = Math.max(1, ...sem.map((x) => x.n));
  const donneesGdsa = () => ({ nids: e.nids, ruchers: e.ruchers, pieges: e.pieges, annee, auteur: P.nom || sessionActuelle()?.utilisateur.nom || '', structure: P.structure, r1: P.rayonMenaceM, r2: P.rayonLargeM, maintenant: Date.now() });
  const exporter = () => exporterCsv(`bilan_frelons_${annee}.csv`, [
    ['Nid', 'Trouvé le', 'Tag', 'État', 'Latitude', 'Longitude', 'Précision (m)', 'Trouvé par', 'Support', 'Hauteur', 'Traité le', 'Méthode', 'Produit', 'Opérateur'],
    ...nids.slice().sort((a, b) => a.t - b.t).map((n) => [numeroNid(e.nids, n.id), new Date(n.t).toLocaleDateString('fr-FR'), n.tag >= 0 ? n.tag : '', libelleEtatNid(n.etat),
      n.lat.toFixed(6), n.lon.toFixed(6), Math.round(n.err), n.sources, n.support, n.hauteur, n.traite_ms ? new Date(n.traite_ms).toLocaleDateString('fr-FR') : '', n.methode, n.produit, n.operateur]),
  ]).catch((err) => Alert.alert('Export', String(err)));

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre={`Bilan de saison ${annee}`} />
      {annees.length > 1 && <Puces options={annees.map((a) => [String(a), String(a)] as [string, string])} valeur={String(annee)} onChange={(v) => setChoix(Number(v))} />}
      <Text style={s.discret}>{debut ? `Depuis le ${new Date(debut).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}` : 'Aucun nid noté cette saison'}</Text>
      <View style={[s.ligne, { gap: 10 }]}>
        <Gros k="Nids trouvés" v={String(nids.length)} />
        <Gros k="Détruits" v={String(detruits)} />
        <Gros k="Précision moy." v={precision !== null ? `± ${Math.round(precision)} m` : '—'} />
      </View>
      <Carte>
        <Titre>Vos résultats {annee}</Titre>
        <View style={[s.ligne, { gap: 10, marginBottom: 6 }]}>
          <Gros k="Tags posés" v={String(res.poses)} />
          <Gros k="Nids par un tag" v={String(res.nidsParTag)} />
          <Gros k="Réussite" v={res.taux !== null ? `${res.taux} %` : '—'} />
        </View>
        {res.delaiMedianH !== null && <Text style={{ color: C.encre }}>De la pose au nid : {duree(res.delaiMedianH)} en général (médiane), {duree(res.delaiMinH!)} au plus vite.</Text>}
        {res.distRucherMedianeM !== null && <Text style={{ color: C.encre, marginTop: 4 }}>Nids à {fmtDist(res.distRucherMedianeM)} du rucher le plus proche en général · {res.prochesRucher} à moins de {fmtDist(P.rayonMenaceM)}.</Text>}
        {res.traites > 0 && <Text style={{ color: C.encre, marginTop: 4 }}>Traités : {res.traites} · morts au premier traitement : {res.mortsPremierCoup} ({Math.round((res.mortsPremierCoup / res.traites) * 100)} %){res.retraites ? ` · retraités : ${res.retraites}` : ''}.</Text>}
        {res.methodes.length > 0 && (
          <>
            <Text style={[s.discret, { marginTop: 10, marginBottom: 4 }]}>Ce qui a trouvé les nids</Text>
            {res.methodes.map((x) => (
              <View key={x.m} style={{ marginBottom: 6 }}>
                <View style={[s.ligne, { justifyContent: 'space-between' }]}>
                  <Text style={{ color: C.encre, fontWeight: '700' }}>{LIBELLE_METHODE[x.m]}</Text>
                  <Text style={s.discret}>{x.n} nid{x.n > 1 ? 's' : ''}{x.delaiMedianH !== null ? ` · ${duree(x.delaiMedianH)} après la pose` : ''}</Text>
                </View>
                <View style={{ height: 8, borderRadius: 4, backgroundColor: C.ligne, marginTop: 3 }}>
                  <View style={{ height: 8, borderRadius: 4, backgroundColor: C.accent, width: `${Math.round((x.n / Math.max(1, res.nids)) * 100)}%` }} />
                </View>
              </View>
            ))}
          </>
        )}
        {!res.poses && !res.nids && <Text style={s.discret}>Les résultats se remplissent au fil des poses de tags et des nids trouvés.</Text>}
        {res.poses > 0 && res.nidsParTag === 0 && <Text style={[s.discret, { fontSize: police.mini, marginTop: 4 }]}>Un nid compte « par un tag » quand il est enregistré depuis le suivi d'un tag.</Text>}
      </Carte>
      {annee === anneeCourante && <Carte>
        <Titre>Nids trouvés par semaine</Titre>
        <Svg width={W} height={120}>
          {sem.map((x, i) => (
            <React.Fragment key={i}>
              <Rect x={i * bw + bw * 0.2} y={90 - (x.n / max) * 70} width={bw * 0.6} height={(x.n / max) * 70 + 1} rx={4} fill={C.accent} />
              <T x={i * bw + bw / 2} y={86 - (x.n / max) * 70} fontSize={12} fontWeight="700" fill={C.encre} textAnchor="middle">{x.n}</T>
              <T x={i * bw + bw / 2} y={110} fontSize={11} fill={C.discret} textAnchor="middle">{new Date(x.t).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</T>
            </React.Fragment>
          ))}
        </Svg>
      </Carte>}
      {parRucher.length > 0 && (
        <Carte>
          <Titre>Par rucher ({annee})</Titre>
          {parRucher.map((x) => (
            <View key={x.rucher.id} style={{ paddingVertical: 8, borderTopWidth: 1, borderTopColor: C.ligne }}>
              <View style={[s.ligne, { justifyContent: 'space-between' }]}>
                <Text style={{ color: C.encre, fontWeight: '800', flex: 1 }}>{x.rucher.nom}{x.rucher.ruches ? ` · ${x.rucher.ruches} ruches` : ''}</Text>
                <Text style={{ color: x.aTraiter ? C.alerte : x.n3km ? C.ok : C.discret, fontWeight: '700' }}>{x.aTraiter ? `${x.aTraiter} à traiter` : x.n3km ? 'tout traité' : 'aucun nid'}</Text>
              </View>
              <Text style={s.discret}>
                {x.n1km} nid{x.n1km > 1 ? 's' : ''} à moins de {fmtDist(P.rayonMenaceM)}, {x.n3km} à moins de {fmtDist(P.rayonLargeM)} · {x.detruits} détruit{x.detruits > 1 ? 's' : ''}
                {x.plusProche ? ` · le plus proche à ${fmtDist(x.plusProche.d)}` : ''}
                {x.pieges ? ` · ${x.pieges} piège${x.pieges > 1 ? 's' : ''} : ${x.captures} frelon${x.captures > 1 ? 's' : ''}` : ''}
              </Text>
            </View>
          ))}
        </Carte>
      )}
      {comp.length > 1 && (
        <Carte>
          <Titre>Comparaison des saisons</Titre>
          <View style={[s.ligne, { paddingBottom: 4 }]}>
            <Text style={[s.discret, { flex: 1.6, fontSize: police.mini }]} />
            {comp.map((x) => <Text key={x.annee} style={{ flex: 1, textAlign: 'right', color: C.encre, fontWeight: '800' }}>{x.annee}</Text>)}
          </View>
          <LigneComp k="Nids trouvés" v={comp.map((x) => String(x.nids))} />
          <LigneComp k="Détruits" v={comp.map((x) => (x.nids ? `${Math.round((100 * x.detruits) / x.nids)} %` : '—'))} />
          <LigneComp k="Délai avant traitement" v={comp.map((x) => (x.delaiTraitementJ !== null ? `${x.delaiTraitementJ.toFixed(1).replace('.', ',')} j` : '—'))} />
          <LigneComp k="Distance au rucher" v={comp.map((x) => (x.distRucher !== null ? fmtDist(x.distRucher) : '—'))} />
          <LigneComp k="Précision" v={comp.map((x) => (x.precision !== null ? `± ${Math.round(x.precision)} m` : '—'))} />
          <LigneComp k="Fondatrices piégées" v={comp.map((x) => String(x.captures))} />
          <Text style={[s.discret, { marginTop: 12, marginBottom: 4 }]}>Nids trouvés par mois</Text>
          <Svg width={W} height={130}>
            {MOIS.map((mo, i) => {
              const bwm = W / MOIS.length, mx = Math.max(1, ...graph.flatMap((g) => MOIS.map((k) => g.parMois[k])));
              return (
                <React.Fragment key={mo}>
                  {graph.map((g, j) => {
                    const h = (g.parMois[mo] / mx) * 90, w = (bwm * 0.8) / graph.length;
                    return <Rect key={g.annee} x={i * bwm + bwm * 0.1 + j * w} y={100 - h} width={w - 1} height={h + 1} rx={2} fill={COUL_AN[COUL_AN.length - graph.length + j]} />;
                  })}
                  <T x={i * bwm + bwm / 2} y={118} fontSize={10} fill={C.discret} textAnchor="middle">{new Date(2000, mo, 1).toLocaleDateString('fr-FR', { month: 'short' })}</T>
                </React.Fragment>
              );
            })}
          </Svg>
          <View style={[s.ligne, { gap: 12 }]}>
            {graph.map((g, j) => <View key={g.annee} style={[s.ligne, { gap: 4 }]}><View style={{ width: 10, height: 10, borderRadius: 2, backgroundColor: COUL_AN[COUL_AN.length - graph.length + j] }} /><Text style={[s.discret, { fontSize: police.mini }]}>{g.annee}</Text></View>)}
          </View>
        </Carte>
      )}
      <Carte>
        <Titre>Efficacité</Titre>
        <Ligne k="Distance moyenne appât → nid" v={dists.length ? fmtDist(dists.reduce((a, b) => a + b, 0) / dists.length) : '—'} />
        <Ligne k="Distance moyenne au chrono" v={chronos.length ? fmtDist(chronos.reduce((a, r) => a + r.rt.r, 0) / chronos.length) : '—'} />
        <Ligne k="Vitesse des frelons (réglage)" v={`${e.chrono.reglages.vitesse.toFixed(1).replace('.', ',')} m/s`} />
        <Ligne k="Méthode décisive" v={methode || '—'} />
      </Carte>
      <Carte>
        <Titre>Tags</Titre>
        <View style={[s.ligne, { justifyContent: 'space-between' }]}>
          <Petit k="Récupérés" v={nb('recupere')} /><Petit k="Posés" v={nb('pose')} /><Petit k="Disponibles" v={nb('dispo')} /><Petit k="Perdus" v={nb('perdu')} />
        </View>
      </Carte>
      <Carte>
        <Titre>Pour le GDSA</Titre>
        <Text style={[s.discret, { marginBottom: 8 }]}>Bilan {annee} à envoyer au groupement sanitaire apicole : un rapport PDF d'une page et le classeur détaillé (résumé, nids avec coordonnées et interventions, ruchers, pièges et relevés).</Text>
        <View style={[s.ligne, { gap: 10 }]}>
          <Bouton titre="Rapport PDF" plein onPress={() => exporterGdsaPdf(donneesGdsa()).catch((err) => Alert.alert('Export', String(err)))} />
          <Bouton titre="Classeur Excel" onPress={() => exporterGdsaXlsx(donneesGdsa()).catch((err) => Alert.alert('Export', String(err)))} />
        </View>
      </Carte>
      <Bouton titre="Exporter la liste des nids (CSV)" onPress={exporter} desactive={!nids.length} />
    </ScrollView>
  );
}

const Gros = ({ k, v }: { k: string; v: string }) => (
  <View style={[s.carte, { flex: 1, alignItems: 'center' }]}><Text style={{ fontSize: 24, fontWeight: '800', color: C.encre }}>{v}</Text><Text style={[s.discret, { fontSize: police.mini }]}>{k}</Text></View>
);
const Ligne = ({ k, v }: { k: string; v: string }) => (
  <View style={[s.ligne, { justifyContent: 'space-between', paddingVertical: 6, borderTopWidth: 1, borderTopColor: C.ligne, gap: 10 }]}><Text style={[s.discret, { flex: 1 }]}>{k}</Text><Text style={{ color: C.encre, fontWeight: '700', flexShrink: 1, textAlign: 'right' }}>{v}</Text></View>
);
const LigneComp = ({ k, v }: { k: string; v: string[] }) => (
  <View style={[s.ligne, { paddingVertical: 5, borderTopWidth: 1, borderTopColor: C.ligne }]}>
    <Text style={[s.discret, { flex: 1.6 }]}>{k}</Text>
    {v.map((x, i) => <Text key={i} style={{ flex: 1, textAlign: 'right', color: C.encre, fontWeight: '700' }}>{x}</Text>)}
  </View>
);
const Petit = ({ k, v }: { k: string; v: number }) => (
  <View style={{ alignItems: 'center' }}><Text style={{ fontSize: 20, fontWeight: '800', color: C.encre }}>{v}</Text><Text style={[s.discret, { fontSize: police.mini }]}>{k}</Text></View>
);
