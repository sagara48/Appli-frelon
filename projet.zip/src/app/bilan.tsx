/** Bilan de saison (É21) : nids trouvés, détruits, précision, efficacité, tags ; export tableur. */
import React from 'react';
import { Alert, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import Svg, { Rect, Text as T } from 'react-native-svg';
import { Bouton, Carte, EnTete, Titre, s, useMaintenant } from '@/ui/composants';
import { C, fmtDist, police } from '@/ui/theme';
import { useEtat } from '@/store/store';
import { distM } from '@/calc/geo';
import { resume } from '@/calc/appat';
import { numeroNid } from '@/services/carnet';
import { exporterCsv, libelleEtatNid } from '@/services/exports';

const SEMAINE = 7 * 86400000;
const lundi = (ms: number) => { const d = new Date(ms); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d.getTime(); };

export default function Bilan() {
  const { width } = useWindowDimensions();
  const e = useEtat((x) => ({ nids: x.nids, fiches: x.fichesTags, chrono: x.chrono }));
  const now = useMaintenant(60000);
  const annee = new Date(now).getFullYear();
  const nids = e.nids.filter((n) => new Date(n.t).getFullYear() === annee);
  const detruits = nids.filter((n) => n.etat === 'traite' || n.etat === 'mort').length;
  const precision = nids.length ? nids.reduce((a, n) => a + n.err, 0) / nids.length : null;
  const debut = nids.length ? Math.min(...nids.map((n) => n.t)) : null;
  // semaines (4 dernières)
  const s0 = lundi(now) - 3 * SEMAINE;
  const sem = [0, 1, 2, 3].map((k) => ({ t: s0 + k * SEMAINE, n: nids.filter((n) => n.t >= s0 + k * SEMAINE && n.t < s0 + (k + 1) * SEMAINE).length }));
  // efficacité : appât → nid
  const dists: number[] = [];
  for (const n of nids) {
    const a = e.chrono.appats.filter((x) => x.tag === n.tag);
    if (a.length) dists.push(Math.min(...a.map((x) => distM(x.lat, x.lon, n.lat, n.lon))));
  }
  const chronos = e.chrono.appats.map((a) => resume(e.chrono, a)).filter((r) => r.rt.ok);
  const sources = nids.reduce<Record<string, number>>((acc, n) => { const k = (n.sources || 'à la main').replace(/\s*\([^)]*\)/g, ''); acc[k] = (acc[k] ?? 0) + 1; return acc; }, {});
  const methode = Object.entries(sources).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} (${v})`).join(', ');
  const tags = Object.values(e.fiches);
  const nb = (et: string) => tags.filter((t) => t.etat === et).length;

  const W = width - 64, bw = W / 4, max = Math.max(1, ...sem.map((x) => x.n));
  const exporter = () => exporterCsv(`bilan_frelons_${annee}.csv`, [
    ['Nid', 'Trouvé le', 'Tag', 'État', 'Latitude', 'Longitude', 'Précision (m)', 'Trouvé par', 'Support', 'Hauteur', 'Traité le', 'Méthode', 'Produit', 'Opérateur'],
    ...nids.slice().sort((a, b) => a.t - b.t).map((n) => [numeroNid(e.nids, n.id), new Date(n.t).toLocaleDateString('fr-FR'), n.tag >= 0 ? n.tag : '', libelleEtatNid(n.etat),
      n.lat.toFixed(6), n.lon.toFixed(6), Math.round(n.err), n.sources, n.support, n.hauteur, n.traite_ms ? new Date(n.traite_ms).toLocaleDateString('fr-FR') : '', n.methode, n.produit, n.operateur]),
  ]).catch((err) => Alert.alert('Export', String(err)));

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre={`Bilan de saison ${annee}`} />
      <Text style={s.discret}>{debut ? `Depuis le ${new Date(debut).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}` : 'Aucun nid noté cette saison'}</Text>
      <View style={[s.ligne, { gap: 10 }]}>
        <Gros k="Nids trouvés" v={String(nids.length)} />
        <Gros k="Détruits" v={String(detruits)} />
        <Gros k="Précision moy." v={precision !== null ? `± ${Math.round(precision)} m` : '—'} />
      </View>
      <Carte>
        <Titre>Nids trouvés par semaine</Titre>
        <Svg width={W} height={120}>
          {sem.map((x, i) => (
            <React.Fragment key={i}>
              <Rect x={i * bw + bw * 0.2} y={90 - (x.n / max) * 70} width={bw * 0.6} height={(x.n / max) * 70 + 1} rx={4} fill={C.accent} />
              <T x={i * bw + bw / 2} y={86 - (x.n / max) * 70} fontSize={12} fontWeight="700" fill={C.encre} textAnchor="middle">{x.n}</T>
              <T x={i * bw + bw / 2} y={110} fontSize={11} fill={C.discret} textAnchor="middle">{new Date(x.t).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</T>
            </React.Fragment>
          ))}
        </Svg>
      </Carte>
      <Carte>
        <Titre>Efficacité</Titre>
        <Ligne k="Distance moyenne appât → nid" v={dists.length ? fmtDist(dists.reduce((a, b) => a + b, 0) / dists.length) : '—'} />
        <Ligne k="Distance moyenne au chrono" v={chronos.length ? fmtDist(chronos.reduce((a, r) => a + r.rt.r, 0) / chronos.length) : '—'} />
        <Ligne k="Vitesse des frelons (réglage)" v={`${e.chrono.reglages.vitesse.toFixed(1).replace('.', ',')} m/s`} />
        <Ligne k="Méthode décisive" v={methode || '—'} />
      </Carte>
      <Carte>
        <Titre>Tags</Titre>
        <View style={[s.ligne, { justifyContent: 'space-between' }]}>
          <Petit k="Récupérés" v={nb('recupere')} /><Petit k="Posés" v={nb('pose')} /><Petit k="Disponibles" v={nb('dispo')} /><Petit k="Perdus" v={nb('perdu')} />
        </View>
      </Carte>
      <Bouton titre="Exporter le bilan (tableur)" plein onPress={exporter} desactive={!nids.length} />
    </ScrollView>
  );
}

const Gros = ({ k, v }: { k: string; v: string }) => (
  <View style={[s.carte, { flex: 1, alignItems: 'center' }]}><Text style={{ fontSize: 24, fontWeight: '800', color: C.encre }}>{v}</Text><Text style={[s.discret, { fontSize: police.mini }]}>{k}</Text></View>
);
const Ligne = ({ k, v }: { k: string; v: string }) => (
  <View style={[s.ligne, { justifyContent: 'space-between', paddingVertical: 6, borderTopWidth: 1, borderTopColor: C.ligne, gap: 10 }]}><Text style={[s.discret, { flex: 1 }]}>{k}</Text><Text style={{ color: C.encre, fontWeight: '700', flexShrink: 1, textAlign: 'right' }}>{v}</Text></View>
);
const Petit = ({ k, v }: { k: string; v: number }) => (
  <View style={{ alignItems: 'center' }}><Text style={{ fontSize: 20, fontWeight: '800', color: C.encre }}>{v}</Text><Text style={[s.discret, { fontSize: police.mini }]}>{k}</Text></View>
);
