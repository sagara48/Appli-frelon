/** Sauvegarde et restauration du carnet (nids et photos, tags, ruchers, appâts, réglages) dans un seul fichier. */
import * as DocumentPicker from 'expo-document-picker';
import React, { useState } from 'react';
import { ActivityIndicator, Alert, ScrollView, Text } from 'react-native';
import { Bouton, Carte, EnTete, Titre, s, useMaintenant } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { brancherPersistance, useEtat } from '@/store/store';
import { ecrireValeur, lireValeur } from '@/db';
import { restaurer, sauvegarder } from '@/services/sauvegarde';
import { relireParametres } from '@/services/parametres';

export default function Sauvegarde() {
  const e = useEtat((x) => ({ nids: x.nids.length, ruchers: x.ruchers.length, photos: x.nids.reduce((a, n) => a + n.photos.length, 0) }));
  const [derniere, setDerniere] = useState<number | null>(() => lireValeur<number>('derniereSauvegarde'));
  const [occupe, setOccupe] = useState('');
  const maint = useMaintenant(60000);

  const faire = async () => {
    setOccupe('Préparation de la sauvegarde…');
    try {
      const r = await sauvegarder();
      const t = Date.now();
      ecrireValeur('derniereSauvegarde', t); setDerniere(t);
      if (r.manquantes) Alert.alert('Sauvegarde', `${r.manquantes} photo(s) introuvable(s) sur le téléphone n'ont pas pu être ajoutées.`);
    } catch (err) { Alert.alert('Sauvegarde', String((err as Error).message ?? err)); }
    finally { setOccupe(''); }
  };
  const choisir = async () => {
    const r = await DocumentPicker.getDocumentAsync({ type: ['application/zip', '*/*'], copyToCacheDirectory: true });
    if (r.canceled || !r.assets[0]) return;
    const a = r.assets[0];
    Alert.alert('Restaurer', `Remplacer tout le contenu de l'appli (${e.nids} nid(s), ${e.ruchers} rucher(s), réglages) par « ${a.name} » ?\n\nFaites d'abord une sauvegarde si vous voulez pouvoir revenir en arrière.`, [
      { text: 'Annuler', style: 'cancel' },
      { text: 'Remplacer', style: 'destructive', onPress: async () => {
        setOccupe('Restauration…');
        try {
          const x = await restaurer(a.uri);
          brancherPersistance({ lire: lireValeur, ecrire: ecrireValeur }); // réglages, alertes et appâts de la sauvegarde
          relireParametres();
          setDerniere(lireValeur<number>('derniereSauvegarde'));
          Alert.alert('Restauration', `Terminé : ${x.nids} nid(s) et ${x.photos} photo(s) restaurés.`);
        } catch (err) { Alert.alert('Restauration', String((err as Error).message ?? err)); }
        finally { setOccupe(''); }
      } },
    ]);
  };
  const jours = derniere ? Math.floor((maint - derniere) / 86400000) : null;

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Sauvegarde du carnet" />
      <Text style={s.discret}>Un seul fichier .zip avec les nids et leurs photos, les tags, les ruchers, les appâts et les réglages. Gardez-le hors du téléphone : Drive, mail ou ordinateur.</Text>
      <Carte>
        <Titre>Sauvegarder</Titre>
        <Text style={{ color: C.encre }}>{e.nids} nid(s), {e.photos} photo(s), {e.ruchers} rucher(s)</Text>
        <Text style={{ color: jours === null || jours > 7 ? C.alerte : C.discret, marginVertical: 6 }}>
          {derniere ? `Dernière sauvegarde le ${new Date(derniere).toLocaleDateString('fr-FR')}${jours ? ` (il y a ${jours} jour${jours > 1 ? 's' : ''})` : ' (aujourd\'hui)'}` : 'Jamais sauvegardé'}
        </Text>
        <Bouton titre="Sauvegarder et envoyer" plein desactive={!!occupe} onPress={faire} />
      </Carte>
      <Carte>
        <Titre>Restaurer</Titre>
        <Text style={s.discret}>Sur un nouveau téléphone, ou pour revenir à une sauvegarde. Tout le contenu actuel est remplacé.</Text>
        <Bouton titre="Choisir un fichier de sauvegarde" desactive={!!occupe} onPress={choisir} />
      </Carte>
      {!!occupe && <><ActivityIndicator color={C.encre} /><Text style={[s.discret, { textAlign: 'center' }]}>{occupe}</Text></>}
      <Text style={[s.discret, { fontSize: police.mini }]}>Avec le partage entre téléphones, nids et ruchers sont aussi sur le serveur de l'équipe, mais pas les photos ni les réglages : la sauvegarde reste utile.</Text>
    </ScrollView>
  );
}
