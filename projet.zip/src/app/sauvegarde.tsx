/** Sauvegarde et restauration du carnet (nids et photos, tags, ruchers, appâts, réglages) dans un seul fichier. */
import * as DocumentPicker from 'expo-document-picker';
import React, { useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, EnTete, Puces, Titre, s, useMaintenant } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { brancherPersistance, useEtat } from '@/store/store';
import { ecrireValeur, lireValeur } from '@/db';
import { restaurer, sauvegarder } from '@/services/sauvegarde';
import { relireParametres } from '@/services/parametres';
import { useSession } from '@/services/auth';
import { changerReglageAuto, derniereAuto, listeEnLigne, pretEnLigne, reglageAuto, restaurerEnLigne, sauvegarderEnLigne, type Reglage, type SauvegardeEnLigne } from '@/services/sauvegardeAuto';
import { useRouter } from 'expo-router';

export default function Sauvegarde() {
  const e = useEtat((x) => ({ nids: x.nids.length, ruchers: x.ruchers.length, photos: x.nids.reduce((a, n) => a + n.photos.length, 0) }));
  const [derniere, setDerniere] = useState<number | null>(() => lireValeur<number>('derniereSauvegarde'));
  const [occupe, setOccupe] = useState('');
  const maint = useMaintenant(60000);
  const router = useRouter();
  const session = useSession();
  const [auto, setAuto] = useState<Reglage>(reglageAuto);
  const [derAuto, setDerAuto] = useState<number | null>(derniereAuto);
  const [liste, setListe] = useState<SauvegardeEnLigne[] | null>(null);

  const enLigne = async () => {
    setOccupe('Envoi au serveur…');
    try { await sauvegarderEnLigne(); setDerAuto(derniereAuto()); setListe(null); }
    catch (err) { Alert.alert('Sauvegarde', String((err as Error).message ?? err)); } finally { setOccupe(''); }
  };
  const voirListe = async () => {
    setOccupe('Lecture des sauvegardes…');
    try { setListe(await listeEnLigne()); } catch (err) { Alert.alert('Sauvegardes', String((err as Error).message ?? err)); } finally { setOccupe(''); }
  };
  const restaurerDepuis = (x: SauvegardeEnLigne) => Alert.alert('Restaurer', `Remplacer tout le carnet par la sauvegarde du ${new Date(x.cree_le).toLocaleString('fr-FR')} (${x.nids ?? '?'} nid(s)) ?\n\nLes photos de ce téléphone restent ; la connexion et l'équipe aussi.`, [
    { text: 'Annuler', style: 'cancel' },
    { text: 'Remplacer', style: 'destructive', onPress: async () => {
      setOccupe('Restauration…');
      try {
        const n = await restaurerEnLigne(x.id);
        brancherPersistance({ lire: lireValeur, ecrire: ecrireValeur });
        Alert.alert('Restauration', `Terminé : ${n} nid(s) restaurés.`);
      } catch (err) { Alert.alert('Restauration', String((err as Error).message ?? err)); } finally { setOccupe(''); }
    } },
  ]);

  const faire = async () => {
    setOccupe('Préparation de la sauvegarde…');
    try {
      const r = await sauvegarder();
      const t = Date.now();
      ecrireValeur('derniereSauvegarde', t); setDerniere(t);
      if (r.manquantes) Alert.alert('Sauvegarde', `${r.manquantes} photo(s) introuvable(s) sur le téléphone n'ont pas pu être ajoutées.`);
    } catch (err) { Alert.alert('Sauvegarde', String((err as Error).message ?? err)); }
    finally { setOccupe(''); }
  };
  const choisir = async () => {
    const r = await DocumentPicker.getDocumentAsync({ type: ['application/zip', '*/*'], copyToCacheDirectory: true });
    if (r.canceled || !r.assets[0]) return;
    const a = r.assets[0];
    Alert.alert('Restaurer', `Remplacer tout le contenu de l'appli (${e.nids} nid(s), ${e.ruchers} rucher(s), réglages) par « ${a.name} » ?\n\nFaites d'abord une sauvegarde si vous voulez pouvoir revenir en arrière.`, [
      { text: 'Annuler', style: 'cancel' },
      { text: 'Remplacer', style: 'destructive', onPress: async () => {
        setOccupe('Restauration…');
        try {
          const x = await restaurer(a.uri);
          brancherPersistance({ lire: lireValeur, ecrire: ecrireValeur }); // réglages, alertes et appâts de la sauvegarde
          relireParametres();
          setDerniere(lireValeur<number>('derniereSauvegarde'));
          Alert.alert('Restauration', `Terminé : ${x.nids} nid(s) et ${x.photos} photo(s) restaurés.`);
        } catch (err) { Alert.alert('Restauration', String((err as Error).message ?? err)); }
        finally { setOccupe(''); }
      } },
    ]);
  };
  const jours = derniere ? Math.floor((maint - derniere) / 86400000) : null;

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre="Sauvegarde du carnet" />
      <Text style={s.discret}>Un seul fichier .zip avec les nids et leurs photos, les tags, les ruchers, les appâts et les réglages. Gardez-le hors du téléphone : Drive, mail ou ordinateur.</Text>
      <Carte>
        <Titre>Sauvegarde automatique</Titre>
        <Text style={s.discret}>Sur votre compte (serveur de l'équipe), sans y penser : nids et interventions, tags, ruchers, pièges et réglages. Les 8 dernières sont gardées. Les photos restent dans la sauvegarde .zip ci-dessous.</Text>
        <View style={{ marginVertical: 8 }}>
          <Puces options={[[0, 'Désactivée'], [1, 'Chaque jour'], [7, 'Chaque semaine']]} valeur={auto.jours} onChange={(j) => { const r = { jours: j as Reglage['jours'] }; changerReglageAuto(r); setAuto(r); }} />
        </View>
        {session && pretEnLigne() ? (
          <>
            <Text style={{ color: !derAuto || maint - derAuto > 8 * 86400000 ? C.alerte : C.discret, marginBottom: 6 }}>
              {derAuto ? `Dernière le ${new Date(derAuto).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })}` : 'Pas encore de sauvegarde sur le serveur'}
            </Text>
            <View style={[s.ligne, { gap: 10, flexWrap: 'wrap' }]}>
              <Bouton titre="Sauvegarder maintenant" plein desactive={!!occupe} onPress={enLigne} />
              <Bouton titre="Restaurer…" desactive={!!occupe} onPress={voirListe} />
            </View>
            {liste && (liste.length ? liste.map((x) => (
              <Pressable key={x.id} onPress={() => restaurerDepuis(x)} style={{ paddingVertical: 8, borderTopWidth: 1, borderTopColor: C.ligne }}>
                <Text style={{ color: C.encre, fontWeight: '700' }}>{new Date(x.cree_le).toLocaleString('fr-FR', { dateStyle: 'medium', timeStyle: 'short' })}</Text>
                <Text style={s.discret}>{x.nids ?? '?'} nid(s) · {Math.round((x.taille ?? 0) / 1024)} ko · {x.appareil}</Text>
              </Pressable>
            )) : <Text style={[s.discret, { marginTop: 6 }]}>Aucune sauvegarde sur le serveur.</Text>)}
          </>
        ) : (
          <>
            <Text style={[s.discret, { marginBottom: 6 }]}>Il faut être connecté à votre compte.</Text>
            <Bouton titre="Se connecter" onPress={() => router.push('/connexion')} />
          </>
        )}
      </Carte>
      <Carte>
        <Titre>Sauvegarde complète (.zip)</Titre>
        <Text style={{ color: C.encre }}>{e.nids} nid(s), {e.photos} photo(s), {e.ruchers} rucher(s)</Text>
        <Text style={{ color: jours === null || jours > 7 ? C.alerte : C.discret, marginVertical: 6 }}>
          {derniere ? `Dernière sauvegarde le ${new Date(derniere).toLocaleDateString('fr-FR')}${jours ? ` (il y a ${jours} jour${jours > 1 ? 's' : ''})` : ' (aujourd\'hui)'}` : 'Jamais sauvegardé'}
        </Text>
        <Bouton titre="Sauvegarder et envoyer" plein desactive={!!occupe} onPress={faire} />
      </Carte>
      <Carte>
        <Titre>Restaurer</Titre>
        <Text style={s.discret}>Sur un nouveau téléphone, ou pour revenir à une sauvegarde. Tout le contenu actuel est remplacé.</Text>
        <Bouton titre="Choisir un fichier de sauvegarde" desactive={!!occupe} onPress={choisir} />
      </Carte>
      {!!occupe && <><ActivityIndicator color={C.encre} /><Text style={[s.discret, { textAlign: 'center' }]}>{occupe}</Text></>}
      <Text style={[s.discret, { fontSize: police.mini }]}>La sauvegarde .zip contient aussi les photos : faites-en une de temps en temps, gardée hors du téléphone.</Text>
    </ScrollView>
  );
}
