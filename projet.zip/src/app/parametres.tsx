/** Paramètres : toutes les valeurs réglables de l'appli, regroupées par thème, avec leur valeur par défaut. */
import { useRouter, type Href } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, Switch, Text, TextInput, View } from 'react-native';
import { Carte, EnTete, LigneLien, Titre, s } from '@/ui/composants';
import { C, police } from '@/ui/theme';
import { DEFAUTS, DEFINITIONS, depotValide, type Cle } from '@/calc/parametres';
import { changerParametres, remettreDefauts, useParametres } from '@/services/parametres';
import { useModeExpert } from '@/services/expert';

const fr = (v: string | number | boolean) => (typeof v === 'number' ? String(v).replace('.', ',') : typeof v === 'boolean' ? (v ? 'oui' : 'non') : v);
const AILLEURS: [string, string, string][] = [
  ['Sons et alertes', 'quelles alertes, volume, voix', '/alertes'],
  ['Calendrier de saison', 'dates de chaque étape, décalage du secteur', '/calendrier'],
  ['Avant de partir', 'liste à cocher', '/avant-depart'],
  ['Partage entre téléphones', 'serveur et code d\'équipe', '/partage'],
  ['Cartes hors ligne', 'fond de carte, zones', '/cartes-hors-ligne'],
];

export default function Parametres() {
  const router = useRouter();
  const P = useParametres();
  const expert = useModeExpert();
  const sections = DEFINITIONS.filter((x) => (expert || !x.expert) && (P.ficheComplete || !x.complet));
  const [brouillon, setBrouillon] = useState<Partial<Record<Cle, string>>>({});
  const [ouverte, setOuverte] = useState<string | null>(DEFINITIONS[0].titre);

  const valider = (cle: Cle) => {
    const v = brouillon[cle];
    if (v === undefined) return;
    setBrouillon((o) => { const n = { ...o }; delete n[cle]; return n; });
    if (cle === 'depot' && v.trim() && !depotValide(v)) { Alert.alert('Dépôt GitHub', 'Format attendu : propriétaire/nom, par exemple sagara48/Appli-frelon.'); return; }
    if (typeof DEFAUTS[cle] === 'number' && !Number.isFinite(Number(v.replace(',', '.')))) { Alert.alert('Paramètres', 'Valeur numérique attendue.'); return; }
    changerParametres({ [cle]: v } as Partial<typeof P>); // bornée et nettoyée par normaliser
  };
  const modifiees = (Object.keys(DEFAUTS) as Cle[]).filter((k) => P[k] !== DEFAUTS[k]).length;

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre="Paramètres" />
      <Text style={s.discret}>Valeurs gardées dans le téléphone (et dans la sauvegarde du carnet). {modifiees ? `${modifiees} valeur${modifiees > 1 ? 's' : ''} modifiée${modifiees > 1 ? 's' : ''}.` : 'Toutes les valeurs sont celles par défaut.'}</Text>

      {sections.map((sec) => {
        const ouv = ouverte === sec.titre;
        const nMod = sec.params.filter((d) => P[d.cle] !== DEFAUTS[d.cle]).length;
        return (
          <Carte key={sec.titre}>
            <Pressable onPress={() => setOuverte(ouv ? null : sec.titre)} style={[s.ligne, { justifyContent: 'space-between' }]}>
              <Text style={{ color: C.encre, fontWeight: '800', fontSize: police.normal + 1 }}>{sec.titre}</Text>
              <Text style={s.discret}>{nMod ? `${nMod} modifié${nMod > 1 ? 's' : ''} ` : ''}{ouv ? '▲' : '▼'}</Text>
            </Pressable>
            {ouv && (
              <View style={{ marginTop: 4 }}>
                {!!sec.aide && <Text style={[s.discret, { marginBottom: 4 }]}>{sec.aide}</Text>}
                {sec.params.map((d) => {
                  const num = typeof DEFAUTS[d.cle] === 'number', bool = typeof DEFAUTS[d.cle] === 'boolean';
                  const v = brouillon[d.cle] ?? fr(P[d.cle]);
                  const different = P[d.cle] !== DEFAUTS[d.cle];
                  return (
                    <View key={d.cle} style={{ paddingVertical: 9, borderTopWidth: 1, borderTopColor: C.ligne }}>
                      <View style={[s.ligne, { gap: 10 }]}>
                        <Text style={{ flex: 1, color: C.encre }}>{d.titre}</Text>
                        {bool && <Switch value={P[d.cle] as boolean} onValueChange={(x) => changerParametres({ [d.cle]: x } as Partial<typeof P>)} trackColor={{ true: C.accent, false: C.ligne }} />}
                        {num && (
                          <View style={[s.ligne, { gap: 6 }]}>
                            <TextInput value={v} onChangeText={(t) => setBrouillon((o) => ({ ...o, [d.cle]: t }))} onEndEditing={() => valider(d.cle)} onSubmitEditing={() => valider(d.cle)}
                              keyboardType="decimal-pad" selectTextOnFocus style={[champ, { width: 76, textAlign: 'right' }]} />
                            <Text style={[s.discret, { width: 38 }]}>{d.unite}</Text>
                          </View>
                        )}
                      </View>
                      {!num && !bool && (
                        <TextInput value={v} onChangeText={(t) => setBrouillon((o) => ({ ...o, [d.cle]: t }))} onEndEditing={() => valider(d.cle)} onSubmitEditing={() => valider(d.cle)}
                          placeholder={d.placeholder} placeholderTextColor="#9AA3AC" autoCapitalize={d.cle === 'depot' ? 'none' : 'sentences'} style={[champ, { marginTop: 6 }]} />
                      )}
                      {!!d.aide && <Text style={[s.discret, { fontSize: police.mini, marginTop: 3 }]}>{d.aide}</Text>}
                      {different
                        ? <Text onPress={() => remettreDefauts([d.cle])} style={[s.discret, { fontSize: police.mini, marginTop: 3, textDecorationLine: 'underline' }]}>Revenir à la valeur par défaut : {bool ? (DEFAUTS[d.cle] ? 'oui' : 'non') : fr(DEFAUTS[d.cle]) || 'vide'}{num && d.unite ? ` ${d.unite}` : ''}</Text>
                        : num && d.min !== undefined && <Text style={[s.discret, { fontSize: police.mini, marginTop: 3 }]}>de {fr(d.min)} à {fr(d.max ?? '')} {d.unite}</Text>}
                    </View>
                  );
                })}
                {nMod > 0 && (
                  <Pressable onPress={() => remettreDefauts(sec.params.map((d) => d.cle))} style={{ marginTop: 6 }}>
                    <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Remettre cette rubrique par défaut</Text>
                  </Pressable>
                )}
              </View>
            )}
          </Carte>
        );
      })}

      {!expert && <Text style={[s.discret, { fontSize: police.mini, textAlign: 'center' }]}>Seuils d'alerte, distance, Bluetooth… : activez le mode expert dans le Menu.</Text>}
      <Carte>
        <Titre>Réglés dans leur écran</Titre>
        {AILLEURS.map(([t, d, lien]) => <LigneLien key={lien} titre={t} detail={d} onPress={() => router.push(lien as Href)} />)}
        {expert && <Text style={[s.discret, { fontSize: police.mini, marginTop: 6 }]}>Les réglages de mesure du toit (orientation, gains, seuils) sont gardés dans le boîtier : Menu → Mesure du toit, toit connecté.</Text>}
      </Carte>
      {modifiees > 0 && (
        <Pressable onPress={() => Alert.alert('Paramètres', 'Remettre toutes les valeurs par défaut (profil compris) ?', [{ text: 'Annuler', style: 'cancel' }, { text: 'Tout remettre', style: 'destructive', onPress: () => remettreDefauts() }])} style={{ alignSelf: 'center' }}>
          <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Tout remettre par défaut</Text>
        </Pressable>
      )}
    </ScrollView>
  );
}

const champ = { borderWidth: 1, borderColor: C.ligne, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 7, color: C.encre, fontSize: police.normal };
