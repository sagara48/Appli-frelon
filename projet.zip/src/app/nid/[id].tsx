/** Fiche d'un nid (É15) : état, localisation, description, photos, intervention ; partage et fiche PDF. */
import { useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
import { Directory, File, Paths } from 'expo-file-system';
import * as ImagePicker from 'expo-image-picker';
import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Image, Pressable, ScrollView, Share, Text, View } from 'react-native';
import { Bouton, Carte, Champ, EnTete, Puces, Titre, s, useMaintenant } from '@/ui/composants';
import { C, fmtCoord, fmtDist, idTag, police } from '@/ui/theme';
import { meilleurePosition, store, useEtat } from '@/store/store';
import { distM } from '@/calc/geo';
import { majNid, numeroNid, supprimerNid } from '@/services/carnet';
import { fichePdf, libelleEtatNid, partager as partagerFichier } from '@/services/exports';
import type { EtatNid, Nid } from '@/db';
import { useParametres } from '@/services/parametres';
import { envoyerCible } from '@/services/cible';
import { controleTraitement } from '@/calc/activite';
import { choisirVol, nid3DDe, useVols } from '@/services/vols';
import { litchiCsv, missionPhoto, photosAvantApres } from '@/calc/planVol';
import { allerParLaRoute } from '@/services/route';
import { resumeVol } from '@/calc/vol';
import { aControler, interventionsDe, libelleType } from '@/calc/intervention';
import { effetsDestruction } from '@/calc/resultats';

const fr1 = (x: number) => String(Math.round(x * 10) / 10).replace('.', ',');

const TEXTES = ['support', 'hauteur', 'diametre', 'activite', 'note'] as const;
type Texte = (typeof TEXTES)[number];

export default function FicheNid() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const nids = useEtat((e) => e.nids);
  const ruchers = useEtat((e) => e.ruchers);
  const activites = useEtat((e) => e.activites);
  const V = useVols();
  const P = useParametres();
  const n = nids.find((x) => x.id === Number(id));
  const maint = useMaintenant(60000);
  const [t, setT] = useState<Record<Texte, string> | null>(() => (n ? (Object.fromEntries(TEXTES.map((k) => [k, n[k] ?? ''])) as Record<Texte, string>) : null));
  // enregistrement automatique 1 s après la dernière frappe
  useEffect(() => {
    if (!n || !t) return;
    const change = TEXTES.some((k) => (n[k] ?? '') !== t[k]);
    if (!change) return;
    const h = setTimeout(() => majNid(n.id, t), 1000);
    return () => clearTimeout(h);
  }, [t]); // eslint-disable-line react-hooks/exhaustive-deps -- n change après chaque enregistrement : seule la frappe déclenche
  // retour du viseur : la hauteur mesurée remplace celle du champ
  const hauteurFiche = n?.hauteur ?? '';
  useFocusEffect(useCallback(() => { setT((o) => (o && o.hauteur !== hauteurFiche ? { ...o, hauteur: hauteurFiche } : o)); }, [hauteurFiche]));
  if (!n) return <View style={s.ecran}><EnTete titre="Nid" /><Text style={[s.discret, { padding: 16 }]}>Nid introuvable.</Text></View>;
  const num = numeroNid(nids, n.id);
  const inters = interventionsDe(n);
  const aCtrl = aControler(n, maint, P.controleJours);
  const dejaDetruit = inters.some((x) => x.type === 'destruction');
  const effets = effetsDestruction(ruchers, [n], P.rayonMenaceM);
  const tTrait = [...inters].reverse().find((x) => x.type === 'destruction' || x.type === 'retraitement')?.t ?? n.traite_ms;
  const ctrl = n.tag > 0 && tTrait && n.etat !== 'mort' ? controleTraitement(activites[n.tag], tTrait, maint) : null;
  const volsTag = n.tag > 0 ? V.vols.filter((v) => v.points.some((p) => p.tags.some(([id]) => id === n.tag))) : [];
  const ici = meilleurePosition();
  const d = ici ? distM(ici.lat, ici.lon, n.lat, n.lon) : null;
  const champ = (k: Texte) => ({ valeur: t?.[k] ?? '', onChange: (v: string) => setT((o) => (o ? { ...o, [k]: v } : o)) });

  // traité ou vérifié mort : on note l'intervention correspondante (date, produit, opérateur…)
  const changerEtat = (e: EtatNid) => {
    if (e === n.etat) return;
    if (e === 'traite') { router.push({ pathname: '/intervention', params: { nid: String(n.id), type: 'destruction' } }); return; }
    if (e === 'mort' && n.etat === 'traite') { router.push({ pathname: '/intervention', params: { nid: String(n.id), type: 'controle' } }); return; }
    majNid(n.id, { etat: e, ...(e === 'mort' ? { verifie_ms: maint } : {}) });
  };
  const photo = async (camera: boolean) => {
    const perm = camera ? await ImagePicker.requestCameraPermissionsAsync() : await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) { Alert.alert('Photo', 'Autorisation refusée.'); return; }
    const r = camera ? await ImagePicker.launchCameraAsync({ quality: 0.6 }) : await ImagePicker.launchImageLibraryAsync({ quality: 0.6, mediaTypes: ['images'] });
    if (r.canceled || !r.assets[0]) return;
    try {
      const dir = new Directory(Paths.document, 'photos');
      if (!dir.exists) dir.create({ intermediates: true });
      const dest = new File(dir, `nid${n.id}_${Date.now()}.jpg`);
      new File(r.assets[0].uri).copySync(dest);
      majNid(n.id, { photos: [...n.photos, dest.uri] });
    } catch (e) { Alert.alert('Photo', String(e)); }
  };
  const retirerPhoto = (uri: string) => Alert.alert('Photo', 'Retirer cette photo ?', [{ text: 'Annuler', style: 'cancel' }, { text: 'Retirer', style: 'destructive', onPress: () => {
    try { new File(uri).delete(); } catch {}
    majNid(n.id, { photos: n.photos.filter((p) => p !== uri) });
  } }]);
  const partager = () => Share.share({ message: `Nid de frelons asiatiques n° ${num} (${libelleEtatNid(n.etat)})\n${n.lat.toFixed(6)}, ${n.lon.toFixed(6)} (± ${Math.round(n.err)} m)\nhttps://www.geoportail.gouv.fr/carte?c=${n.lon.toFixed(6)},${n.lat.toFixed(6)}&z=18\n${[n.support, n.hauteur].filter(Boolean).join(' · ')}` });

  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu} keyboardShouldPersistTaps="handled">
      <EnTete titre={`Nid n° ${num}`} />
      <Text style={s.discret}>Trouvé le {new Date(n.t).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}{n.tag >= 0 ? ` · tag ${idTag(n.tag)}` : ''}{n.auteur ? ` · par ${n.auteur}` : ''}</Text>
      <Puces options={[['trouve', 'À traiter'], ['traite', 'Traité'], ['mort', 'Vérifié mort']]} valeur={n.etat === 'estime' ? 'trouve' : n.etat} onChange={(v) => changerEtat(v as EtatNid)} />

      <Carte>
        <Titre>Localisation</Titre>
        <Text style={{ color: C.encre, fontSize: police.normal + 1, fontWeight: '700' }}>{fmtCoord(n.lat, n.lon)} · ± {Math.round(n.err)} m</Text>
        {!!n.sources && <Text style={[s.discret, { marginTop: 4 }]}>Trouvé par : {n.sources}</Text>}
        {d !== null && <Text style={[s.discret, { marginTop: 4 }]}>À {d < 1000 ? `${Math.round(d)} m` : `${(d / 1000).toFixed(1).replace('.', ',')} km`} de vous</Text>}
        {ici && d !== null && d < P.sousNidM && (
          <Pressable onPress={() => Alert.alert('Affiner', 'Remplacer la position du nid par votre position actuelle ?', [{ text: 'Annuler', style: 'cancel' }, { text: 'Remplacer', onPress: () => majNid(n.id, { lat: ici.lat, lon: ici.lon, err: 5 }) }])}>
            <Text style={{ color: C.encre, textDecorationLine: 'underline', marginTop: 6 }}>Je suis sous le nid : prendre ma position</Text>
          </Pressable>
        )}
      </Carte>

      <Carte>
        <Champ titre="Support" placeholder="chêne en lisière, haie, toiture…" {...champ('support')} />
        <View style={[s.ligne, { gap: 10 }]}>
          <View style={{ flex: 1 }}><Champ titre="Hauteur" placeholder="12 m" {...champ('hauteur')} /></View>
          <View style={{ flex: 1 }}><Champ titre="Diamètre du nid" placeholder="50 cm" {...champ('diametre')} /></View>
        </View>
        <Pressable onPress={() => router.push({ pathname: '/viseur', params: { nid: String(n.id) } })} style={{ marginBottom: 8 }}>
          <Text style={{ color: C.encre, textDecorationLine: 'underline' }}>Mesurer la hauteur au viseur du téléphone</Text>
        </Pressable>
        <Champ titre="Activité" placeholder="forte, va-et-vient continu…" {...champ('activite')} />
        <Champ titre="Remarques" multiligne {...champ('note')} />
      </Carte>

      <Carte>
        <Titre>Photos</Titre>
        {(() => {
          const pa = photosAvantApres(n.photos, tTrait ?? null);
          const rangee = (l: string[]) => (
            <View style={[s.ligne, { gap: 8, flexWrap: 'wrap' }]}>
              {l.map((p) => <Pressable key={p} onLongPress={() => retirerPhoto(p)}><Image source={{ uri: p }} style={{ width: 96, height: 96, borderRadius: 8 }} /></Pressable>)}
            </View>
          );
          if (!pa.apres.length || !pa.avant.length) return rangee(n.photos);
          return (
            <View style={{ gap: 8 }}>
              <Text style={[s.discret, { fontWeight: '700' }]}>Avant le traitement</Text>{rangee(pa.avant)}
              <Text style={[s.discret, { fontWeight: '700' }]}>Après le traitement</Text>{rangee(pa.apres)}
              {pa.autres.length > 0 && rangee(pa.autres)}
            </View>
          );
        })()}
        <View style={[s.ligne, { gap: 10, marginTop: 8 }]}>
          <Bouton titre="+ Photo" onPress={() => photo(true)} />
          <Bouton titre="Depuis la galerie" onPress={() => photo(false)} />
        </View>
        {n.etat === 'traite' && tTrait && (
          <View style={{ marginTop: 8 }}>
            <Bouton titre="Vol de contrôle par le drone" plein={maint - tTrait >= 2 * 86400000} onPress={() => {
              const h = parseFloat((n.hauteur || '').replace(',', '.')) || 8;
              partagerFichier(`controle_nid_${num}.csv`, litchiCsv(missionPhoto({ lat: n.lat, lon: n.lon }, h)), 'text/csv').catch(() => {});
            }} />
            <Text style={[s.discret, { fontSize: police.mini, marginTop: 4 }]}>
              {maint - tTrait < 2 * 86400000 ? `À partir du ${new Date(tTrait + 2 * 86400000).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' })} (2 jours après le traitement). ` : ''}
              Mêmes prises de vue que la mission photo : les photos jointes ensuite (« Depuis la galerie ») se rangent sous « Après le traitement », face à celles d'avant. Pas d'activité à l'entrée, enveloppe affaissée ou percée : nid mort.
            </Text>
          </View>
        )}
        {n.etat !== 'mort' && n.etat !== 'traite' && (
          <View style={{ marginTop: 8 }}>
            <Bouton titre="Mission photo par le drone" onPress={() => {
              const h = parseFloat((n.hauteur || '').replace(',', '.')) || 8;
              partagerFichier(`photo_nid_${num}.csv`, litchiCsv(missionPhoto({ lat: n.lat, lon: n.lon }, h)), 'text/csv').catch(() => {});
            }} />
            <Text style={[s.discret, { fontSize: police.mini, marginTop: 4 }]}>Mission Litchi : 2 photos verticales au-dessus du nid ({n.hauteur ? `hauteur notée ${n.hauteur}` : 'hauteur supposée 8 m'}), 2 photos de biais depuis le sud. Décollez au pied du nid ; ensuite « Depuis la galerie » pour les joindre.</Text>
          </View>
        )}
        {n.photos.length > 0 && <Text style={[s.discret, { fontSize: police.mini, marginTop: 4 }]}>Appui long sur une photo pour la retirer.</Text>}
      </Carte>

      {effets.length > 0 && (
        <Carte>
          <Titre>Effet sur les ruchers</Titre>
          {effets.map((x) => (
            <Text key={x.rucher} style={{ color: x.variation <= -30 ? C.ok : C.encre, marginTop: 2 }}>
              Rucher {x.nomRucher} (à {fmtDist(x.distM)}) : frelons devant les ruches {fr1(x.avant)} → {fr1(x.apres)} ({x.variation > 0 ? '+' : ''}{x.variation} %)
            </Text>
          ))}
          <Text style={[s.discret, { fontSize: police.mini, marginTop: 4 }]}>Moyenne des relevés de la semaine avant le traitement et de la semaine après (0 aucun, 1 de 1 à 5, 2 de 5 à 20, 3 plus de 20).</Text>
        </Carte>
      )}
      {ctrl && (
        <Carte style={{ borderColor: ctrl.verdict === 'mort' ? C.ok : ctrl.verdict === 'actif' ? C.alerte : C.ligne, borderWidth: ctrl.verdict === 'mort' || ctrl.verdict === 'actif' ? 2 : 1 }}>
          <Titre>Contrôle par le tag {idTag(n.tag)}</Titre>
          <Text style={{ color: ctrl.verdict === 'mort' ? C.ok : ctrl.verdict === 'actif' ? C.alerte : C.encre, fontWeight: '700' }}>{ctrl.texte}</Text>
          <Text style={[s.discret, { fontSize: police.mini, marginTop: 4 }]}>D'après les sorties du frelon tagué et la température de son tag dans le nid. À confirmer à l'œil avant de noter le nid mort.</Text>
          {(ctrl.verdict === 'mort' || ctrl.verdict === 'actif') && n.etat === 'traite' && (
            <View style={{ marginTop: 8 }}><Bouton titre="Noter le contrôle" onPress={() => router.push({ pathname: '/intervention', params: { nid: String(n.id), type: 'controle' } })} /></View>
          )}
        </Carte>
      )}
      {volsTag.length > 0 && (
        <Carte>
          <Titre>Vols du drone pour le tag {idTag(n.tag)}</Titre>
          {volsTag.slice(0, 5).map((v) => {
            const r = resumeVol(v).tags.find((x) => x.id === n.tag), e3 = nid3DDe(v, n.tag);
            return (
              <Pressable key={v.id} onPress={() => { choisirVol(v.id); store.choisirTag(n.tag); router.navigate('/carte'); }} style={[s.ligne, { justifyContent: 'space-between', paddingVertical: 6, borderTopWidth: 1, borderTopColor: C.ligne }]}>
                <Text style={{ color: C.encre }}>{new Date(v.debut).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}{r ? ` · max ${r.max} dBm à ${fmtDist(distM(n.lat, n.lon, r.lat, r.lon))} du nid` : ''}{e3 ? ` · nid à ~${e3.hauteurM} m de haut (${e3.hauteurMin}-${e3.hauteurMax})` : ''}</Text>
                <Text style={{ color: C.encre, textDecorationLine: 'underline' }}>Carte</Text>
              </Pressable>
            );
          })}
        </Carte>
      )}
      <Carte>
        <Titre>Interventions</Titre>
        {inters.length === 0 && <Text style={s.discret}>Aucune intervention pour l'instant.</Text>}
        {inters.map((x) => (
          <Pressable key={x.id} onPress={() => router.push({ pathname: '/intervention', params: { nid: String(n.id), i: x.id } })}
            style={{ paddingVertical: 8, borderTopWidth: 1, borderTopColor: C.ligne }}>
            <Text style={{ color: C.encre, fontWeight: '700' }}>{libelleType(x.type)} · {new Date(x.t).toLocaleDateString('fr-FR')}</Text>
            <Text style={s.discret}>{[x.methode, x.produit && `${x.produit}${x.quantiteG !== null ? ` ${String(x.quantiteG).replace('.', ',')} g` : ''}`,
              x.type === 'controle' && (x.resultat === 'mort' ? 'nid mort' : x.resultat === 'actif' ? 'encore actif' : ''), x.operateur].filter(Boolean).join(' · ') || 'à compléter'}</Text>
          </Pressable>
        ))}
        {aCtrl && <Text style={{ color: C.alerte, fontWeight: '700', marginTop: 6 }}>Contrôle à faire : traité il y a plus de {P.controleJours} jours.</Text>}
        <View style={[s.ligne, { gap: 10, marginTop: 10, flexWrap: 'wrap' }]}>
          <Bouton titre={dejaDetruit ? 'Retraitement' : 'Destruction'} plein={n.etat === 'trouve'}
            onPress={() => router.push({ pathname: '/intervention', params: { nid: String(n.id), type: dejaDetruit ? 'retraitement' : 'destruction' } })} />
          {n.etat === 'traite' && <Bouton titre="Contrôle" plein={aCtrl} onPress={() => router.push({ pathname: '/intervention', params: { nid: String(n.id), type: 'controle' } })} />}
          <Bouton titre="Autre…" onPress={() => router.push({ pathname: '/intervention', params: { nid: String(n.id), type: 'deplacement' } })} />
        </View>
      </Carte>

      <View style={[s.ligne, { gap: 10 }]}>
        <Bouton titre="Portatif" onPress={() => envoyerCible(n.lat, n.lon, `Nid ${num}`)} />
        <Bouton titre="Par la route" onPress={() => { allerParLaRoute(n.lat, n.lon).catch(() => {}); }} />
        {(n.etat === 'estime' || n.etat === 'trouve') && <Bouton titre="Plan de vol" onPress={() => router.push({ pathname: '/plan-vol', params: { lat: String(n.lat), lon: String(n.lon), err: String(Math.round(n.err || 30)), titre: `Nid ${num}` } })} />}
        <Bouton titre="Partager" onPress={partager} />
        <Bouton titre="Fiche PDF" plein onPress={() => fichePdf({ ...n, ...(t ?? {}) } as Nid, num).catch((e) => Alert.alert('PDF', String(e)))} />
      </View>
      <Pressable onPress={() => Alert.alert('Supprimer', `Supprimer le nid n° ${num} du carnet ?`, [{ text: 'Annuler', style: 'cancel' }, { text: 'Supprimer', style: 'destructive', onPress: () => { supprimerNid(n.id); router.back(); } }])}
        style={{ alignSelf: 'center', marginTop: 4 }}>
        <Text style={[s.discret, { textDecorationLine: 'underline' }]}>Supprimer du carnet</Text>
      </Pressable>
    </ScrollView>
  );
}
