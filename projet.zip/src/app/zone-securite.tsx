/** Zone de sécurité (É18) : ouverte automatiquement à moins de 10 m d'un nid connu (moteur d'alertes). */
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import React, { useEffect } from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import Svg, { Circle, G, Path } from 'react-native-svg';
import { C } from '@/ui/theme';
import { meilleurePosition, useEtat } from '@/store/store';
import { capDeg, distM } from '@/calc/geo';
import { majNid, numeroNid } from '@/services/carnet';
import { couperZone } from '@/services/alertes';
import { suivreBoussole } from '@/services/position';

const sens = (rel: number) => {
  const r = ((rel % 360) + 540) % 360 - 180;
  if (Math.abs(r) <= 25) return 'devant'; if (Math.abs(r) >= 155) return 'derrière vous';
  return `${Math.abs(r) < 90 ? 'devant ' : 'derrière '}à ${r > 0 ? 'droite' : 'gauche'}`;
};

export default function ZoneSecurite() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const e = useEtat((x) => ({ nids: x.nids, boussole: x.boussole, telephone: x.telephone, portatif: x.portatif }));
  useEffect(() => { let stop = () => {}; suivreBoussole().then((f) => { stop = f; }); return () => stop(); }, []);
  const n = e.nids.find((x) => x.id === Number(id));
  const pos = meilleurePosition();
  const d = n && pos ? distM(pos.lat, pos.lon, n.lat, n.lon) : null;
  const cap = n && pos ? capDeg(pos.lat, pos.lon, n.lat, n.lon) : null;
  const hdg = e.portatif.connexion === 'connecte' && e.portatif.st ? e.portatif.st.hdg : e.boussole?.cap ?? null;
  const rel = cap !== null && hdg !== null ? cap - hdg : null;

  return (
    <View style={{ flex: 1, backgroundColor: C.alerte, padding: 24, paddingTop: 60 }}>
      <Stack.Screen options={{ headerShown: false }} />
      <Text style={{ color: '#fff', fontWeight: '800', letterSpacing: 2 }}>ZONE DE SÉCURITÉ</Text>
      <Text style={{ color: '#fff', fontSize: 30, fontWeight: '800', marginTop: 6 }}>{n ? `Nid n° ${numeroNid(e.nids, n.id)} tout proche` : 'Nid tout proche'}</Text>
      <View style={{ alignItems: 'center', marginVertical: 26 }}>
        <Svg width={200} height={200}>
          <Circle cx={100} cy={100} r={94} fill="none" stroke="#ffffff66" strokeWidth={3} />
          {rel !== null && (
            <G transform={`rotate(${rel} 100 100)`}>
              <Path d="M100,16 L132,80 L112,80 L112,130 L88,130 L88,80 L68,80 Z" fill="#fff" />
            </G>
          )}
          <Circle cx={100} cy={100} r={8} fill="#fff" />
        </Svg>
        <Text style={{ color: '#fff', fontSize: 34, fontWeight: '800', marginTop: 10 }}>{d !== null ? `${Math.round(d)} m${rel !== null ? ` ${sens(rel)}` : ''}` : '—'}</Text>
      </View>
      <Text style={{ color: '#fff', fontSize: 17, lineHeight: 24 }}>Alerte à 10 m d'un nid connu. Ne vous approchez pas davantage sans équipement de protection.</Text>
      <View style={{ flex: 1 }} />
      {n && pos && (
        <Pressable onPress={() => Alert.alert('Affiner la position', 'Le nid est juste au-dessus de vous ?', [{ text: 'Annuler', style: 'cancel' },
          { text: 'Oui, enregistrer', onPress: () => { majNid(n.id, { lat: pos.lat, lon: pos.lon, err: 5 }); couperZone(15); router.back(); } }])}
          style={{ backgroundColor: '#fff', padding: 16, borderRadius: 14, alignItems: 'center', marginBottom: 12 }}>
          <Text style={{ color: C.alerte, fontWeight: '800', fontSize: 17 }}>Je suis sous le nid : affiner sa position</Text>
        </Pressable>
      )}
      <View style={{ flexDirection: 'row', gap: 12 }}>
        <Pressable onPress={() => { couperZone(15); router.back(); }} style={{ flex: 1, borderWidth: 2, borderColor: '#fff', padding: 16, borderRadius: 14, alignItems: 'center' }}>
          <Text style={{ color: '#fff', fontWeight: '700', fontSize: 16 }}>Couper 15 min</Text>
        </Pressable>
        <Pressable onPress={() => router.back()} style={{ flex: 1, borderWidth: 2, borderColor: '#fff', padding: 16, borderRadius: 14, alignItems: 'center' }}>
          <Text style={{ color: '#fff', fontWeight: '700', fontSize: 16 }}>Retour</Text>
        </Pressable>
      </View>
    </View>
  );
}
