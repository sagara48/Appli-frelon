/** Scanner le QR d'un tag (étiquette collée sur le boîtier) : ouvre le tag, ou le choisit pour la pose. */
import { useLocalSearchParams, useRouter } from 'expo-router';
import { CameraView, useCameraPermissions } from 'expo-camera';
import React, { useRef, useState } from 'react';
import { Platform, Text, View } from 'react-native';
import { Bouton, EnTete, s } from '@/ui/composants';
import { C } from '@/ui/theme';
import { tagDuQr } from '@/calc/qr';
import { vibrer } from '@/services/sons';
import { marquerAuto } from '@/services/essaisTerrain';

export default function Scanner() {
  const router = useRouter();
  const { pour } = useLocalSearchParams<{ pour?: string }>();
  const [perm, demander] = useCameraPermissions();
  const fait = useRef(false);
  const [msg, setMsg] = useState('');
  if (Platform.OS === 'web') return <View style={s.ecran}><EnTete titre="Scanner un tag" /><Text style={[s.discret, { padding: 16 }]}>Le scanner demande l'appli Android.</Text></View>;
  return (
    <View style={s.ecran}>
      <EnTete titre="Scanner un tag" />
      {!perm?.granted ? (
        <View style={{ padding: 16, gap: 10 }}>
          <Text style={{ color: C.encre }}>Le scanner utilise l'appareil photo.</Text>
          <Bouton titre="Autoriser l'appareil photo" plein onPress={() => { demander().catch(() => {}); }} />
        </View>
      ) : (
        <View style={{ flex: 1 }}>
          <CameraView style={{ flex: 1 }} facing="back" barcodeScannerSettings={{ barcodeTypes: ['qr'] }}
            onBarcodeScanned={(r) => {
              if (fait.current) return;
              const id = tagDuQr(r.data);
              if (id === null) { setMsg('Ce QR n\'est pas une étiquette de tag.'); return; }
              fait.current = true;
              vibrer();
              marquerAuto('qr');
              if (pour === 'pose') router.replace({ pathname: '/pose-tag', params: { tag: String(id) } });
              else router.replace({ pathname: '/tag/[id]', params: { id: String(id) } });
            }} />
          <View pointerEvents="none" style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' }}>
            <View style={{ width: 220, height: 220, borderWidth: 3, borderColor: '#F2C230', borderRadius: 18 }} />
          </View>
          <Text style={{ position: 'absolute', bottom: 24, left: 16, right: 16, textAlign: 'center', color: '#fff', backgroundColor: '#000a', padding: 10, borderRadius: 10 }}>
            {msg || 'Visez l\'étiquette du tag, à 10-20 cm'}
          </Text>
        </View>
      )}
    </View>
  );
}
