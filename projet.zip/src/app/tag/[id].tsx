/** Un tag ouvert par son QR (scanner de l'appli, ou appareil photo du téléphone : frelons://tag/12). */
import { useLocalSearchParams, useRouter } from 'expo-router';
import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { Bouton, Carte, EnTete, s } from '@/ui/composants';
import { C, idTag, police } from '@/ui/theme';
import { store, useEtat } from '@/store/store';
import { cmdPortatif } from '@/proto/portatif';
import { envoyerPortatif } from '@/sources/portatif';

const ETAT: Record<string, string> = { dispo: 'disponible', pose: 'posé sur un frelon', perdu: 'perdu', recupere: 'récupéré' };

export default function TagQr() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const n = Number(id);
  const f = useEtat((x) => x.fichesTags[n] ?? null);
  const vu = useEtat((x) => !!x.tags[n]);
  if (!Number.isFinite(n) || n < 0 || n > 255) return <View style={s.ecran}><EnTete titre="Tag" /><Text style={[s.discret, { padding: 16 }]}>Numéro de tag invalide.</Text></View>;
  const suivre = () => {
    store.choisirTag(n);
    if (store.get().portatif.connexion === 'connecte') envoyerPortatif(cmdPortatif.tag(n)).catch(() => {});
    router.replace('/portatif');
  };
  return (
    <ScrollView style={s.ecran} contentContainerStyle={s.contenu}>
      <EnTete titre={`Tag ${idTag(n)}`} />
      <Carte>
        <Text style={{ color: C.encre, fontSize: police.normal + 4, fontWeight: '800' }}>Tag {idTag(n)}</Text>
        <Text style={s.discret}>{f ? `${ETAT[f.etat] ?? f.etat}${f.pile !== null ? ` · pile ${f.pile} %` : ''}` : 'pas encore dans Mes tags'}{vu ? ' · entendu pendant cette sortie' : ''}</Text>
      </Carte>
      <Bouton titre="Poser ce tag sur un frelon" plein={!f || f.etat !== 'pose'} onPress={() => router.replace({ pathname: '/pose-tag', params: { tag: String(n) } })} />
      <Bouton titre="Le suivre au portatif" plein={f?.etat === 'pose'} onPress={suivre} />
      <Bouton titre="Mes tags" onPress={() => router.replace('/tags')} />
    </ScrollView>
  );
}
