import React from 'react';
import { Text } from 'react-native';
import { Bloc, G, P, PageAide, Puce } from '@/ui/Aide';
import { C } from '@/ui/theme';

export default function AideEtalonnage() {
  return (
    <PageAide titre="Comment étalonner" sousTitre="10 minutes, une fois après le montage">
      <Bloc titre="À quoi ça sert">
        <P>Les 4 antennes ne captent jamais exactement pareil, et le boîtier n'est pas forcément posé pile dans l'axe de la voiture. L'étalonnage mesure ces écarts sur un tag dont on connaît la position, puis le toit les corrige tout seul.</P>
        <P>Il calcule trois choses : le décalage de l'avant (jusqu'à ± 30°), la largeur de lobe des antennes (50 à 100°) et une correction de gain pour chaque voie.</P>
      </Bloc>
      <Bloc titre="Quand le refaire">
        <Puce>Au premier montage du toit.</Puce>
        <Puce>Si vous changez de voiture, déplacez le boîtier ou une antenne.</Puce>
        <Puce>Si les directions affichées tombent souvent à côté.</Puce>
      </Bloc>
      <Bloc titre="Avant de commencer">
        <Puce>Un endroit dégagé où l'on peut tourner en rond : parking vide, chemin autour d'un champ. Loin des bâtiments et des grillages.</Puce>
        <Puce>Un tag chargé, posé à environ 1 m du sol (piquet, poteau), sans métal autour.</Puce>
        <Puce>Le GPS du toit affiche au moins 6 satellites.</Puce>
      </Bloc>
      <Bloc titre="Les 4 étapes">
        <P><G>1.</G> Garer la voiture juste à côté du tag et appuyer sur « Position du tag ». Le toit retient sa position GPS : c'est la référence.</P>
        <P><G>2.</G> Choisir le numéro du tag. Vérifier que son signal apparaît bien.</P>
        <P><G>3.</G> Démarrer, puis faire <G>1 à 2 tours complets autour du tag</G>, à 30–60 m, à vitesse régulière au-dessus de la vitesse minimale (4 km/h). Le tag doit passer devant, à droite, derrière et à gauche de la voiture. Viser au moins 120 trames.</P>
        <P><G>4.</G> Terminer. Le toit calcule les corrections, les applique et les garde en mémoire, même éteint.</P>
      </Bloc>
      <Bloc titre="Lire le résultat">
        <P><Text style={{ color: C.ok, fontWeight: '700' }}>0 à 10°</Text>  Très bon, rien à faire.</P>
        <P><Text style={{ color: C.accent, fontWeight: '700' }}>10 à 20°</Text>  Correct. Refaire plus tard sur un lieu plus dégagé.</P>
        <P><Text style={{ color: C.alerte, fontWeight: '700' }}>plus de 20°</Text>  Recommencer : trop de reflets ou un tour incomplet.</P>
        <P>Un décalage de l'avant supérieur à 15° signifie souvent que le boîtier est tourné sur le toit : mieux vaut le remettre droit et refaire l'étalonnage.</P>
      </Bloc>
      <Bloc titre="Si un message apparaît">
        <P><G>« Pas de GPS »</G> : attendre le fix GPS du toit avant l'étape 1.</P>
        <P><G>« Faire calpos d'abord »</G> : l'étape 1 n'a pas été faite (ou le toit a été redémarré depuis).</P>
        <P><G>« Trop peu de trames »</G> : moins de 40 signaux reçus. Rouler plus près du tag, plus lentement, et vérifier que le tag est bien chargé.</P>
      </Bloc>
    </PageAide>
  );
}
