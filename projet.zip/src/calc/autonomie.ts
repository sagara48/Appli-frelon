/** Autonomie des tags : consommation moyenne d'après le rythme des trames (firmware 7) et la charge de chaque sorte de
 *  trame, mesurée au PPK2 (outils/analyse_ppk2.py) ou estimée en attendant. Sans dépendance au téléphone (testé). */
export type Conso = {
  capaciteMah: number; // pile du tag
  veilleUa: number;    // entre les trames
  trameUc: number;     // trame normale (1M, 3 canaux)
  lpUc: number;        // trame longue portée (codée S8)
  cnUc: number;        // trame connectable (écoute des ordres)
};
/** Valeurs estimées (nRF52820 à +8 dBm), à remplacer par les mesures. */
export const CONSO_ESTIMEE: Conso = { capaciteMah: 1, veilleUa: 3, trameUc: 22, lpUc: 115, cnUc: 26 };

const PERIODE_S = 1.03, NUIT_S = 15.03, RECH_S = 0.53;
/** Courant moyen (µA) selon le mode : jour (1 trame/s, longue portée 1 sur 10, connectable 2 sur 10), nuit (1 / 15 s,
 *  sans longue portée), recherche (1 / 0,5 s, longue portée 1 sur 5). */
export function courantMoyen(c: Conso, mode: 'jour' | 'nuit' | 'recherche'): number {
  if (mode === 'nuit') return c.veilleUa + (4 * c.trameUc + c.cnUc) / (5 * NUIT_S);
  if (mode === 'recherche') return c.veilleUa + (2 * c.trameUc + 2 * c.lpUc + c.cnUc * 2 + 4 * c.trameUc) / (10 * RECH_S);
  return c.veilleUa + (7 * c.trameUc + c.lpUc + 2 * c.cnUc) / (10 * PERIODE_S);
}
/** Autonomie en heures, pile pleine, pour une journée type (heures de nuit = tag au nid dans le noir). */
export function autonomieH(c: Conso, heuresNuit = 11): number {
  const i = (courantMoyen(c, 'jour') * (24 - heuresNuit) + courantMoyen(c, 'nuit') * heuresNuit) / 24;
  return (c.capaciteMah * 1000) / i;
}
/** Heures restantes : pile (%) lue il y a `depuisH` heures. */
export const resteH = (c: Conso, pilePct: number, depuisH: number, heuresNuit = 11) => Math.max(0, (autonomieH(c, heuresNuit) * pilePct) / 100 - depuisH);
export const texteDuree = (h: number) => (h < 1 ? `${Math.round(h * 60)} min` : h < 48 ? `${Math.round(h)} h` : `${(h / 24).toFixed(1).replace('.', ',')} j`);
