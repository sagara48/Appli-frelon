/**
 * Méthode du temps d'aller-retour à l'appât : portage de aller.c (écran de la voiture).
 * - « Lâcher ici » ouvre un appât à la position de la voiture (ou du portatif).
 * - Détection automatique par le toit : niveau proche du maximum = à l'appât ; plus de signal fort pendant 20 s = PARTI
 *   (heure du dernier signal fort) ; signal fort à nouveau = REVENU. Distance = v·(T − p)/2 sur le trajet le plus rapide.
 * - Le toit donne aussi le cap de départ (1re minute) et de retour (dernière minute) si la voiture est à moins de 30 m.
 * - « Parti » / « Revenu » à la main, avec en option le cap pointé avec le portatif.
 * Ce module est pur (pas de React) : l'état est un objet modifié en place, l'appelant publie une copie.
 */
import { estRoundtrip, type ELine, type ERing, RT_P_DEF, RT_V_DEF } from './estim';
import { D2R, KY, capDeg, distM, kxOf } from './geo';

export const MAX_APPATS = 8, MAX_TRAJETS = 12;
const CAP_FENETRE_S = 60, PRES_M = 30, HIST = 128;

type Releve = { t: number; deg: number; q: number };
export type Trajet = { dureeS: number; capDep: number | null; capRet: number | null; finMs: number };
export type Appat = {
  id: number; tag: number; lat: number; lon: number; source: 'voiture' | 'main'; creeMs: number;
  trajets: Trajet[]; nDep: number; nRet: number; capDeg: number; // cap moyen (départs + retours)
  // suivi en cours (non sauvegardé)
  etat: 0 | 1 | 2; // 0 rien, 1 à l'appât, 2 parti
  maxr: number; dernierFort: number; depart: number; depFait: boolean; depOk: boolean; depCap: number; hist: Releve[];
};
export type Reglages = { vitesse: number; auNid: number; partiS: number; fortDb: number };
export const reglagesDefaut = (): Reglages => ({ vitesse: RT_V_DEF, auNid: RT_P_DEF, partiS: 20, fortDb: 15 });

export type Chrono = { appats: Appat[]; reglages: Reglages; prochainId: number; message: string };
export const chronoVide = (): Chrono => ({ appats: [], reglages: reglagesDefaut(), prochainId: 1, message: '' });

export const appatActif = (c: Chrono, tag: number) => { for (let i = c.appats.length - 1; i >= 0; i--) if (c.appats[i].tag === tag) return c.appats[i]; return null; };

function ajouterCap(a: Appat, d: number) {
  const n = a.nDep + a.nRet;
  if (!n) { a.capDeg = d; return; }
  const sx = Math.cos(a.capDeg * D2R) * n + Math.cos(d * D2R), sy = Math.sin(a.capDeg * D2R) * n + Math.sin(d * D2R);
  a.capDeg = (Math.atan2(sy, sx) / D2R + 360) % 360;
}

/** Cap moyen des relèvements de ]t0, t1], en écartant ceux à plus de 35° de la moyenne ; au moins 2 relèvements. */
function capRobuste(h: Releve[], t0: number, t1: number): number | null {
  let sx = 0, sy = 0, n = 0;
  for (const r of h) if (r.t > t0 && r.t <= t1) { sx += Math.cos(r.deg * D2R) * r.q; sy += Math.sin(r.deg * D2R) * r.q; n++; }
  if (n < 2) return null;
  for (let pass = 0; pass < 2; pass++) {
    const m = Math.atan2(sy, sx); let ax = 0, ay = 0, k = 0;
    for (const r of h) if (r.t > t0 && r.t <= t1) {
      const a = r.deg * D2R; if (Math.cos(a - m) < 0.819) continue;
      ax += Math.cos(a) * r.q; ay += Math.sin(a) * r.q; k++;
    }
    if (k < 2) break;
    sx = ax; sy = ay;
  }
  return (Math.atan2(sy, sx) / D2R + 360) % 360;
}

/** « Lâcher ici » : ouvre (ou reprend, à moins de 30 m) l'appât de ce tag. */
export function lacher(c: Chrono, tag: number, lat: number, lon: number, source: Appat['source'], maintenant: number): Appat | null {
  if (lat === 0 && lon === 0) return null;
  let a = c.appats.find((x) => x.tag === tag && distM(lat, lon, x.lat, x.lon) < 30) ?? null;
  if (!a) {
    if (c.appats.length === MAX_APPATS) c.appats.shift();
    a = { id: c.prochainId++, tag, lat, lon, source, creeMs: maintenant, trajets: [], nDep: 0, nRet: 0, capDeg: 0,
      etat: 0, maxr: -128, dernierFort: maintenant, depart: 0, depFait: false, depOk: false, depCap: 0, hist: [] };
  } else c.appats.splice(c.appats.indexOf(a), 1);
  c.appats.push(a); // le plus récent de ce tag en dernier : c'est lui que suivent les boutons
  Object.assign(a, { source, etat: 1, maxr: -128, dernierFort: maintenant, depFait: false, depOk: false, hist: [] });
  return a;
}

function ajouterTrajet(c: Chrono, a: Appat, maintenant: number, capMain: number | null = null) {
  const s = Math.round((maintenant - a.depart) / 1000);
  if (s >= 40 && s <= 2400) {
    let capDep: number | null = null, capRet: number | null = null;
    if (!a.depFait) { const d = capRobuste(a.hist, a.depart, a.depart + CAP_FENETRE_S * 1000); a.depOk = d !== null; if (d !== null) a.depCap = d; a.depFait = true; }
    if (a.depOk) { capDep = a.depCap; ajouterCap(a, a.depCap); a.nDep++; }
    const de = Math.max(maintenant - CAP_FENETRE_S * 1000, a.depart + CAP_FENETRE_S * 1000);
    const r = capMain ?? capRobuste(a.hist, de, maintenant);
    if (r !== null) { capRet = r; ajouterCap(a, r); a.nRet++; }
    if (a.trajets.length === MAX_TRAJETS) a.trajets.shift();
    a.trajets.push({ dureeS: s, capDep, capRet, finMs: maintenant });
    const rt = estRoundtrip(a.trajets.map((t) => t.dureeS), c.reglages.vitesse, c.reglages.auNid);
    c.message = `Tag ${a.tag} revenu : ${Math.floor(s / 60)} min ${String(s % 60).padStart(2, '0')} s → nid à ~${Math.round(rt.r)} m (± ${Math.round(rt.sig)})` +
      (rt.tMin < 90 ? ' : NID TOUT PROCHE' : '');
  }
  Object.assign(a, { etat: 1, dernierFort: maintenant, depFait: false, depOk: false, hist: [] });
}

/** Trame d'un tag reçue par le toit (niveau max des voies, direction absolue, qualité). Renvoie vrai si un trajet a été ajouté. */
export function trameToit(c: Chrono, tag: number, best: number, absDeg: number, q: number, toit: { lat: number; lon: number } | null, maintenant: number): boolean {
  const a = appatActif(c, tag);
  if (!a || !a.etat || best <= -128) return false;
  if (absDeg >= 0 && q >= 40 && toit && toit.lat && distM(toit.lat, toit.lon, a.lat, a.lon) < PRES_M) {
    if (a.hist.length === HIST) a.hist.shift();
    a.hist.push({ t: maintenant, deg: absDeg, q });
  }
  if (a.source !== 'voiture') return false; // le chrono automatique ne suit que l'appât « voiture »
  if (a.etat === 1) {
    if (best > a.maxr) a.maxr = best;
    if (best >= a.maxr - c.reglages.fortDb) a.dernierFort = maintenant;
  } else if (a.etat === 2 && best >= a.maxr - c.reglages.fortDb + 3) { ajouterTrajet(c, a, maintenant); return true; }
  return false;
}

/** Appelé régulièrement (1 fois par seconde au moins) : passage à « parti », cap de départ figé après 1 minute. */
export function tic(c: Chrono, maintenant: number): boolean {
  let change = false;
  for (const a of c.appats) {
    if (a.etat === 1 && a.maxr > -128 && maintenant - a.dernierFort > c.reglages.partiS * 1000) {
      a.etat = 2; a.depart = a.dernierFort; a.depFait = a.depOk = false;
      a.hist = a.hist.filter((h) => h.t > a.depart); // relevements pris après le dernier signal fort
      change = true;
    }
    if (a.etat === 2 && !a.depFait && maintenant - a.depart > CAP_FENETRE_S * 1000) {
      const d = capRobuste(a.hist, a.depart, a.depart + CAP_FENETRE_S * 1000); a.depOk = d !== null; if (d !== null) a.depCap = d; a.depFait = true;
      change = true;
    }
    if (a.etat === 2 && maintenant - a.depart > 2400 * 1000) { a.etat = 1; a.hist = []; change = true; } // > 40 min : abandonné
  }
  return change;
}

/** Boutons « Parti » / « Revenu » ; cap optionnel (direction pointée avec le portatif, ou à l'œil). */
export function manuel(c: Chrono, tag: number, quoi: 'parti' | 'revenu', maintenant: number, cap: number | null = null) {
  const a = appatActif(c, tag); if (!a) return;
  if (quoi === 'parti') {
    Object.assign(a, { etat: 2, depart: maintenant, depFait: cap !== null, depOk: cap !== null, depCap: cap ?? 0, hist: [], maxr: 0 }); // maxr 0 : seul « Revenu » termine
  } else if (a.etat === 2) ajouterTrajet(c, a, maintenant, cap);
}

/** Résumé d'un appât : distance (anneau) et cap. */
export function resume(c: Chrono, a: Appat) {
  const rt = estRoundtrip(a.trajets.map((t) => t.dureeS), c.reglages.vitesse, c.reglages.auNid);
  const nCaps = a.nDep + a.nRet;
  return { rt, cap: nCaps ? a.capDeg : null, nCaps, sigCap: nCaps ? Math.max(5, 15 / Math.sqrt(nCaps)) : null };
}

/** Sources de la fusion pour un tag : anneaux et caps de ses appâts (bait_sources). */
export function sourcesFusion(c: Chrono, tag: number): { anneaux: ERing[]; lignes: ELine[] } {
  const anneaux: ERing[] = [], lignes: ELine[] = [];
  for (const a of c.appats) if (a.tag === tag) {
    const r = resume(c, a);
    if (anneaux.length < 8 && r.rt.ok) anneaux.push({ lat: a.lat, lon: a.lon, r: r.rt.r, sig: r.rt.sig, w: 1 });
    if (r.cap !== null) lignes.push({ lat: a.lat, lon: a.lon, deg: r.cap, sigDeg: r.sigCap!, w: 1 });
  }
  return { anneaux, lignes };
}

/** Méthode des sauts : où poser l'appât suivant (bait_next). Cible = nid estimé s'il existe, sinon l'anneau dans l'axe du cap. */
export function appatSuivant(c: Chrono, tag: number, nid: { lat: number; lon: number } | null):
  { ok: true; lat: number; lon: number; dist: number; cap: number; reste: number } | { ok: false; message: string } {
  const a = appatActif(c, tag);
  if (!a) return { ok: false, message: 'Il faut d\'abord un appât' };
  const r = resume(c, a);
  let cible = nid;
  if (!cible && r.rt.ok && r.cap !== null) {
    const k = kxOf(a.lat);
    cible = { lat: a.lat + (r.rt.r * Math.cos(r.cap * D2R)) / KY, lon: a.lon + (r.rt.r * Math.sin(r.cap * D2R)) / k };
  }
  if (!cible) return { ok: false, message: 'Attendre un aller-retour et un cap (départ, retour ou pointé)' };
  const d = distM(a.lat, a.lon, cible.lat, cible.lon);
  if ((r.rt.ok && r.rt.tMin < 90) || d < 100) return { ok: false, message: 'Nid à moins de ~100 m de l\'appât : finir au portatif' };
  const cc = capDeg(a.lat, a.lon, cible.lat, cible.lon) * D2R, cote = c.appats.indexOf(a) % 2 ? -1 : 1;
  const av = 0.55 * d, lat = 0.2 * d * cote, kx = kxOf(a.lat);
  const ny = av * Math.cos(cc) - lat * Math.sin(cc), nx = av * Math.sin(cc) + lat * Math.cos(cc);
  const p = { lat: a.lat + ny / KY, lon: a.lon + nx / kx };
  return { ok: true, ...p, dist: Math.hypot(nx, ny), cap: capDeg(a.lat, a.lon, p.lat, p.lon), reste: distM(p.lat, p.lon, cible.lat, cible.lon) };
}
