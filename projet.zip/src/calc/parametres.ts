/** Paramètres de l'appli : toutes les valeurs réglables, leurs valeurs par défaut, bornes et textes d'aide.
 *  Sans dépendance au téléphone (testé). L'écran Paramètres est construit à partir de DEFINITIONS. */

export const DEFAUTS = {
  // profil
  nom: '', operateur: '', structure: '',
  // alertes
  tagNouveauS: 30, tagPerduS: 120, pileFaiblePct: 20, nidLocaliseM: 30, battFaiblePct: 15, zoneNidM: 10,
  // tags
  rechargeSeuilPct: 50, rechargeJours: 7,
  // conduite
  annonceS: 10,
  // nids
  sousNidM: 30, positionBonneM: 25,
  // ruchers et bilan
  rayonMenaceM: 1000, rayonLargeM: 3000,
  // pièges
  releverJours: 7, appats: 'Bière + vin blanc + sirop; Sirop de cassis; Appât du commerce; Autre',
  // carte
  densiteM: 400,
  // météo
  tempMin: 12, ventMax: 25,
  // sortie
  repriseH: 12, gpsArrierePlanS: 15,
  // partage et mises à jour
  syncMin: 2, depot: 'sagara48/Appli-frelon', verifMajH: 12,
  // distance estimée d'après le signal
  distRefToit: -25, distRefPortatif: -23, distExposant: 2.5, distMargeDb: 6,
  // Bluetooth
  nomToit: 'TOIT-Frelons', nomPortatif: 'RX-Frelons',
};
export type Parametres = typeof DEFAUTS;
export type Cle = keyof Parametres;

type Def = { cle: Cle; titre: string; aide?: string; unite?: string; min?: number; max?: number; entier?: boolean; placeholder?: string };
/** expert : rubrique affichée seulement en mode expert. */
export type Section = { titre: string; aide?: string; expert?: boolean; params: Def[] };

export const DEFINITIONS: Section[] = [
  { titre: 'Profil', aide: 'Repris sur les fiches, le rapport pour le GDSA et le partage.', params: [
    { cle: 'nom', titre: 'Votre nom', placeholder: 'Nicolas' },
    { cle: 'operateur', titre: 'Opérateur et n° Certibiocide', aide: 'Proposé sur la fiche d\'un nid quand on note une intervention.', placeholder: 'N. Dupont, n° …' },
    { cle: 'structure', titre: 'Structure', aide: 'GDSA, commune, association : affiché sur le rapport de saison.', placeholder: 'GDSA 43' },
  ] },
  { expert: true, titre: 'Alertes', params: [
    { cle: 'tagNouveauS', titre: 'Nouveau tag : entendu depuis moins de', unite: 's', min: 5, max: 600, entier: true },
    { cle: 'tagPerduS', titre: 'Tag perdu après', unite: 's', min: 20, max: 3600, entier: true },
    { cle: 'pileFaiblePct', titre: 'Pile d\'un tag faible sous', unite: '%', min: 1, max: 90, entier: true },
    { cle: 'nidLocaliseM', titre: 'Nid localisé quand la précision passe sous', unite: 'm', min: 5, max: 500, entier: true },
    { cle: 'battFaiblePct', titre: 'Batterie du toit ou du portatif faible sous', unite: '%', min: 5, max: 60, entier: true },
    { cle: 'zoneNidM', titre: 'Écran rouge à l\'approche d\'un nid, à moins de', unite: 'm', min: 3, max: 100, entier: true },
  ] },
  { titre: 'Tags', params: [
    { cle: 'rechargeSeuilPct', titre: 'À recharger si la pile est sous', unite: '%', min: 5, max: 95, entier: true },
    { cle: 'rechargeJours', titre: 'À recharger si la dernière recharge a plus de', unite: 'jours', min: 1, max: 90, entier: true },
  ] },
  { expert: true, titre: 'Nids et ruchers', params: [
    { cle: 'sousNidM', titre: '« Je suis sous le nid » proposé à moins de', unite: 'm', min: 5, max: 200, entier: true },
    { cle: 'positionBonneM', titre: '« Nid trouvé ici » : précision GPS suffisante', unite: 'm', min: 3, max: 100, entier: true },
    { cle: 'rayonMenaceM', titre: 'Rayon autour d\'un rucher (nids menaçants, pièges)', unite: 'm', min: 100, max: 10000, entier: true },
    { cle: 'rayonLargeM', titre: 'Rayon large pour les statistiques par rucher', unite: 'm', min: 200, max: 20000, entier: true },
    { cle: 'densiteM', titre: 'Carte de densité : rayon d\'influence d\'un nid', unite: 'm', min: 50, max: 5000, entier: true },
  ] },
  { titre: 'Pièges de printemps', params: [
    { cle: 'releverJours', titre: 'Piège à relever après', unite: 'jours', min: 1, max: 60, entier: true },
    { cle: 'appats', titre: 'Appâts proposés', aide: 'Séparés par des points-virgules.' },
  ] },
  { titre: 'Météo d\'activité', params: [
    { cle: 'tempMin', titre: 'Frelons actifs au-dessus de', unite: '°C', min: 0, max: 30 },
    { cle: 'ventMax', titre: 'Activité gênée au-delà d\'un vent de', unite: 'km/h', min: 5, max: 80, entier: true },
  ] },
  { expert: true, titre: 'Sortie', params: [
    { cle: 'annonceS', titre: 'Mode conduite : annonce vocale toutes les', unite: 's', min: 3, max: 120, entier: true },
    { cle: 'repriseH', titre: 'Reprendre une sortie interrompue depuis moins de', unite: 'h', min: 1, max: 72, entier: true },
    { cle: 'gpsArrierePlanS', titre: 'Écran verrouillé : position du téléphone toutes les', unite: 's', min: 5, max: 300, entier: true },
  ] },
  { expert: true, titre: 'Partage et mises à jour', params: [
    { cle: 'syncMin', titre: 'Synchronisation du partage toutes les', unite: 'min', min: 1, max: 60, entier: true },
    { cle: 'depot', titre: 'Dépôt GitHub de l\'appli', aide: 'Où chercher les nouvelles versions (propriétaire/nom).', placeholder: 'sagara48/Appli-frelon' },
    { cle: 'verifMajH', titre: 'Chercher une nouvelle version au plus toutes les', unite: 'h', min: 1, max: 168, entier: true },
  ] },
  { expert: true, titre: 'Distance estimée', aide: 'Distance approximative du tag d\'après la force du signal. Le plus simple : Menu → Étalonner la distance, avec un tag posé à une distance connue.', params: [
    { cle: 'distRefToit', titre: 'Signal du toit à 1 m', unite: 'dBm', min: -80, max: 20 },
    { cle: 'distRefPortatif', titre: 'Signal du portatif à 1 m', unite: 'dBm', min: -80, max: 20 },
    { cle: 'distExposant', titre: 'Affaiblissement du milieu (2 dégagé, 2,5 bocage, 3,3 bois)', unite: '', min: 1.6, max: 4.5 },
    { cle: 'distMargeDb', titre: 'Incertitude du signal (fourchette affichée)', unite: 'dB', min: 1, max: 15 },
  ] },
  { expert: true, titre: 'Bluetooth', aide: 'À changer seulement si les noms ont été changés dans les firmwares.', params: [
    { cle: 'nomToit', titre: 'Nom du récepteur de toit' },
    { cle: 'nomPortatif', titre: 'Nom du récepteur portatif' },
  ] },
];

const DEF_PAR_CLE = Object.fromEntries(DEFINITIONS.flatMap((s) => s.params.map((d) => [d.cle, d]))) as Record<Cle, Def>;
export const definition = (c: Cle) => DEF_PAR_CLE[c];

/** Valeurs complètes et valides : défauts pour ce qui manque, nombres bornés, textes nettoyés. */
export function normaliser(p: Partial<Record<string, unknown>> | null | undefined): Parametres {
  const r = { ...DEFAUTS } as Record<Cle, string | number>;
  for (const cle of Object.keys(DEFAUTS) as Cle[]) {
    const v = p?.[cle], def = DEFAUTS[cle];
    if (typeof def === 'number') {
      const n = typeof v === 'number' ? v : typeof v === 'string' ? Number(v.replace(',', '.')) : NaN;
      if (!Number.isFinite(n)) continue;
      const d = DEF_PAR_CLE[cle];
      let x = Math.min(d?.max ?? Infinity, Math.max(d?.min ?? -Infinity, n));
      if (d?.entier) x = Math.round(x);
      r[cle] = x;
    } else if (typeof v === 'string') {
      const t = v.trim();
      // un nom Bluetooth ou un dépôt vide n'aurait pas de sens : on garde le défaut
      r[cle] = t || (['nomToit', 'nomPortatif', 'depot', 'appats'].includes(cle) ? def : '');
    }
  }
  return r as Parametres;
}

/** Liste des appâts (texte séparé par des points-virgules). */
export const listeAppats = (p: Parametres) => p.appats.split(';').map((x) => x.trim()).filter(Boolean);
/** Dépôt valide « propriétaire/nom » ? */
export const depotValide = (d: string) => /^[\w.-]+\/[\w.-]+$/.test(d.trim());
