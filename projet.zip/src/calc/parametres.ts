/** Paramètres de l'appli : toutes les valeurs réglables, leurs valeurs par défaut, bornes et textes d'aide.
 *  Sans dépendance au téléphone (testé). L'écran Paramètres est construit à partir de DEFINITIONS. */

export const DEFAUTS = {
  // profil
  nom: '', operateur: '', structure: '',
  // entreprise et interventions
  ficheComplete: false as boolean, entreprise: '', certibiocide: '', telEntreprise: '', adresseEntreprise: '', controleJours: 3,
  consignes: 'Ne pas toucher au nid ni le décrocher. Tenir enfants et animaux à l\'écart quelques jours. Si des frelons volent encore autour du nid après 3 jours, nous rappeler : un nouveau passage est compris.',
  // alertes
  tagNouveauS: 30, tagPerduS: 120, pileFaiblePct: 20, nidLocaliseM: 30, battFaiblePct: 15, zoneNidM: 10,
  // tags
  rechargeSeuilPct: 50, rechargeJours: 7, silenceJours: 2,
  // consommation des tags (outils/analyse_ppk2.py) : valeurs estimées en attendant la mesure
  tagCapaciteMah: 1, tagVeilleUa: 3, tagTrameUc: 22, tagLpUc: 115, tagCnUc: 26,
  // conduite
  annonceS: 10,
  // nids
  sousNidM: 30, positionBonneM: 25,
  // ruchers et bilan
  rayonMenaceM: 1000, rayonLargeM: 3000,
  // pièges
  releverJours: 7, appats: 'Bière + vin blanc + sirop; Sirop de cassis; Appât du commerce; Autre',
  // carte
  densiteM: 400,
  // météo
  tempMin: 12, ventMax: 25, meteoMatin: true as boolean, meteoHeure: 7,
  // sortie
  repriseH: 12, gpsArrierePlanS: 15,
  // partage et mises à jour
  syncMin: 2, depot: 'sagara48/Appli-frelon', verifMajH: 12,
  // distance estimée d'après le signal
  distRefToit: -25, distRefPortatif: -23, distExposant: 2.5, distMargeDb: 6,
  // Bluetooth
  nomToit: 'TOIT-Frelons', nomPortatif: 'RX-Frelons',
  // automatismes
  autoConnexion: true as boolean, autoEssai: true as boolean, autoPied: true as boolean, autoRecherche: true as boolean, autoNidIci: true as boolean, autoFinTag: true as boolean,
  autoRappels: true as boolean, autoAvantDepart: true as boolean, autoMajFirmware: true as boolean, autoPlanVol: true as boolean, autoCompteRendu: true as boolean,
  equipeDirect: true as boolean,
  // commandes vocales
  voixMotCle: false as boolean,
};
export type Parametres = typeof DEFAUTS;
export type Cle = keyof Parametres;

type Def = { cle: Cle; titre: string; aide?: string; unite?: string; min?: number; max?: number; entier?: boolean; placeholder?: string };
/** expert : rubrique affichée seulement en mode expert. */
/** expert : rubrique du mode expert ; complet : seulement avec la fiche d'intervention complète. */
export type Section = { titre: string; aide?: string; expert?: boolean; complet?: boolean; params: Def[] };

export const DEFINITIONS: Section[] = [
  { titre: 'Profil', aide: 'Repris sur les fiches, le rapport pour le GDSA et le partage.', params: [
    { cle: 'nom', titre: 'Votre nom', placeholder: 'Nicolas' },
    { cle: 'operateur', titre: 'Opérateur', aide: 'Proposé sur chaque intervention.', placeholder: 'N. Dupont' },
    { cle: 'certibiocide', titre: 'N° de certificat Certibiocide', placeholder: 'C-…' },
    { cle: 'structure', titre: 'Structure', aide: 'GDSA, commune, association : affiché sur le rapport de saison.', placeholder: 'GDSA 43' },
  ] },
  { titre: 'Interventions sur les nids', params: [
    { cle: 'ficheComplete', titre: 'Fiche complète', aide: 'Ajoute à chaque intervention le client ou riverain, sa signature, la météo, l\'opérateur et le compte rendu PDF à remettre. Sans : produit, quantité, méthode, hauteur, photos et commentaires.' },
    { cle: 'controleJours', titre: 'Contrôle du nid après un traitement', unite: 'jours', min: 1, max: 30, entier: true },
  ] },
  { complet: true, titre: 'Compte rendu remis au client', aide: 'Repris sur le compte rendu d\'intervention et sur le registre des traitements.', params: [
    { cle: 'entreprise', titre: 'Entreprise ou association', placeholder: 'Nom, SIRET' },
    { cle: 'adresseEntreprise', titre: 'Adresse' },
    { cle: 'telEntreprise', titre: 'Téléphone à rappeler', placeholder: '06 …' },
    { cle: 'consignes', titre: 'Consignes remises au client', aide: 'Imprimées en bas du compte rendu (« Suites de l\'intervention »).' },
  ] },
  { expert: true, titre: 'Alertes', params: [
    { cle: 'tagNouveauS', titre: 'Nouveau tag : entendu depuis moins de', unite: 's', min: 5, max: 600, entier: true },
    { cle: 'tagPerduS', titre: 'Tag perdu après', unite: 's', min: 20, max: 3600, entier: true },
    { cle: 'pileFaiblePct', titre: 'Pile d\'un tag faible sous', unite: '%', min: 1, max: 90, entier: true },
    { cle: 'nidLocaliseM', titre: 'Nid localisé quand la précision passe sous', unite: 'm', min: 5, max: 500, entier: true },
    { cle: 'battFaiblePct', titre: 'Batterie du toit ou du portatif faible sous', unite: '%', min: 5, max: 60, entier: true },
    { cle: 'zoneNidM', titre: 'Écran rouge à l\'approche d\'un nid, à moins de', unite: 'm', min: 3, max: 100, entier: true },
  ] },
  { titre: 'Automatismes', aide: 'Ce que l\'appli fait seule. Chacun se coupe ici.', params: [
    { cle: 'autoConnexion', titre: 'Connexion automatique', aide: 'Se connecte au toit et au portatif dès qu\'ils sont allumés à portée.' },
    { cle: 'autoEssai', titre: 'Enregistrer chaque sortie', aide: 'Toutes les mesures, sans mode brut ; les 10 dernières sorties sont gardées (Menu → Enregistrer un essai).' },
    { cle: 'autoPied', titre: 'Passage voiture → pied', aide: 'Arrêté à moins de 200 m du nid estimé : flèche envoyée au portatif, onglet Portatif ouvert.' },
    { cle: 'autoRecherche', titre: 'Mode recherche du tag', aide: 'Demandé au tag quand on approche du nid (portatif ou voiture à l\'arrêt), arrêté quand le nid est noté.' },
    { cle: 'autoNidIci', titre: '« Nid trouvé ici ? »', aide: 'Proposé quand le portatif reçoit le tag très fort et que vous ne bougez plus.' },
    { cle: 'autoFinTag', titre: 'Fin de vie du tag', aide: 'Quand le tag conclut « nid mort » : noter le contrôle et désactiver le tag, en une touche.' },
    { cle: 'autoRappels', titre: 'Rappels par notification', aide: 'Contrôle d\'un nid traité, piège à relever (9 h), tags à recharger (18 h), tag posé sans nouvelles. Un rappel en retard revient chaque jour.' },
    { cle: 'autoAvantDepart', titre: '« Avant de partir » vérifié à la connexion', aide: 'Batteries, versions, étalonnage, tags, carte, météo : un bandeau dit ce qui manque.' },
    { cle: 'autoMajFirmware', titre: 'Mise à jour des appareils proposée', aide: 'À la connexion d\'un appareil en retard, avec le dernier paquet importé (ou téléchargé depuis le dépôt).' },
    { cle: 'autoPlanVol', titre: 'Plan de vol prêt d\'avance', aide: 'Dès que le nid estimé passe sous ± 30 m : mission Litchi préparée (Menu → Vols du drone).' },
    { cle: 'equipeDirect', titre: 'Équipe en direct', aide: 'Pendant une sortie, votre position, le tag suivi et son nid estimé sont partagés toutes les 30 s avec votre équipe (Partage), et vous voyez les leurs sur la carte. Rien hors sortie.' },
    { cle: 'autoCompteRendu', titre: 'Compte rendu de chaque sortie', aide: 'Résumé enregistré à la fin d\'une sortie (Menu → Comptes rendus de sortie).' },
  ] },
  { titre: 'Commandes vocales', aide: 'Micro : bouton en haut des onglets Chrono et Portatif. Dites « aide » pour la liste des phrases.', params: [
    { cle: 'voixMotCle', titre: 'Dire « frelon » avant chaque commande', aide: 'Évite qu\'une conversation à côté déclenche une commande (« frelon, parti »).' },
  ] },
  { titre: 'Tags', params: [
    { cle: 'rechargeSeuilPct', titre: 'À recharger si la pile est sous', unite: '%', min: 5, max: 95, entier: true },
    { cle: 'rechargeJours', titre: 'À recharger si la dernière recharge a plus de', unite: 'jours', min: 1, max: 90, entier: true },
    { cle: 'silenceJours', titre: 'Tag posé « sans nouvelles » après', unite: 'jours', min: 1, max: 30, entier: true },
  ] },
  { expert: true, titre: 'Consommation des tags', aide: 'Mesurée au PPK2 : outils/analyse_ppk2.py donne les cinq valeurs à recopier ici. Elles servent à l\'autonomie affichée dans Mes tags.', params: [
    { cle: 'tagCapaciteMah', titre: 'Capacité de la pile', unite: 'mAh', min: 0.5, max: 500 },
    { cle: 'tagVeilleUa', titre: 'Courant de veille', unite: 'µA', min: 0.1, max: 100 },
    { cle: 'tagTrameUc', titre: 'Charge d\'une trame normale', unite: 'µC', min: 1, max: 500 },
    { cle: 'tagLpUc', titre: 'Charge d\'une trame longue portée', unite: 'µC', min: 1, max: 2000 },
    { cle: 'tagCnUc', titre: 'Charge d\'une trame connectable', unite: 'µC', min: 1, max: 500 },
  ] },
  { expert: true, titre: 'Nids et ruchers', params: [
    { cle: 'sousNidM', titre: '« Je suis sous le nid » proposé à moins de', unite: 'm', min: 5, max: 200, entier: true },
    { cle: 'positionBonneM', titre: '« Nid trouvé ici » : précision GPS suffisante', unite: 'm', min: 3, max: 100, entier: true },
    { cle: 'rayonMenaceM', titre: 'Rayon autour d\'un rucher (nids menaçants, pièges)', unite: 'm', min: 100, max: 10000, entier: true },
    { cle: 'rayonLargeM', titre: 'Rayon large pour les statistiques par rucher', unite: 'm', min: 200, max: 20000, entier: true },
    { cle: 'densiteM', titre: 'Carte de densité : rayon d\'influence d\'un nid', unite: 'm', min: 50, max: 5000, entier: true },
  ] },
  { titre: 'Pièges de printemps', params: [
    { cle: 'releverJours', titre: 'Piège à relever après', unite: 'jours', min: 1, max: 60, entier: true },
    { cle: 'appats', titre: 'Appâts proposés', aide: 'Séparés par des points-virgules.' },
  ] },
  { titre: 'Météo d\'activité', params: [
    { cle: 'tempMin', titre: 'Frelons actifs au-dessus de', unite: '°C', min: 0, max: 30 },
    { cle: 'ventMax', titre: 'Activité gênée au-delà d\'un vent de', unite: 'km/h', min: 5, max: 80, entier: true },
    { cle: 'meteoMatin', titre: 'Prévenir le matin d\'un bon créneau', aide: 'Notification les jours où la prévision annonce au moins 2 h d\'activité (relue à chaque ouverture de l\'appli).' },
    { cle: 'meteoHeure', titre: 'Heure de la notification', unite: 'h', min: 5, max: 12 },
  ] },
  { expert: true, titre: 'Sortie', params: [
    { cle: 'annonceS', titre: 'Mode conduite : annonce vocale toutes les', unite: 's', min: 3, max: 120, entier: true },
    { cle: 'repriseH', titre: 'Reprendre une sortie interrompue depuis moins de', unite: 'h', min: 1, max: 72, entier: true },
    { cle: 'gpsArrierePlanS', titre: 'Écran verrouillé : position du téléphone toutes les', unite: 's', min: 5, max: 300, entier: true },
  ] },
  { expert: true, titre: 'Partage et mises à jour', params: [
    { cle: 'syncMin', titre: 'Synchronisation du partage toutes les', unite: 'min', min: 1, max: 60, entier: true },
    { cle: 'depot', titre: 'Dépôt GitHub de l\'appli', aide: 'Où chercher les nouvelles versions (propriétaire/nom).', placeholder: 'sagara48/Appli-frelon' },
    { cle: 'verifMajH', titre: 'Chercher une nouvelle version au plus toutes les', unite: 'h', min: 1, max: 168, entier: true },
  ] },
  { expert: true, titre: 'Distance estimée', aide: 'Réglés automatiquement : signal du toit et incertitude par l\'étalonnage du toit, signal du portatif par les tags étalonnés à 1 m, affaiblissement par les nids trouvés (la valeur ci-dessous sert en attendant). À changer seulement pour un dépannage.', params: [
    { cle: 'distRefToit', titre: 'Signal du toit à 1 m', unite: 'dBm', min: -80, max: 20 },
    { cle: 'distRefPortatif', titre: 'Signal du portatif à 1 m', unite: 'dBm', min: -80, max: 20 },
    { cle: 'distExposant', titre: 'Affaiblissement du milieu (2 dégagé, 2,5 bocage, 3,3 bois)', unite: '', min: 1.6, max: 4.5 },
    { cle: 'distMargeDb', titre: 'Incertitude du signal (fourchette affichée)', unite: 'dB', min: 1, max: 15 },
  ] },
  { expert: true, titre: 'Bluetooth', aide: 'À changer seulement si les noms ont été changés dans les firmwares.', params: [
    { cle: 'nomToit', titre: 'Nom du récepteur de toit' },
    { cle: 'nomPortatif', titre: 'Nom du récepteur portatif' },
  ] },
];

const DEF_PAR_CLE = Object.fromEntries(DEFINITIONS.flatMap((s) => s.params.map((d) => [d.cle, d]))) as Record<Cle, Def>;
export const definition = (c: Cle) => DEF_PAR_CLE[c];

/** Valeurs complètes et valides : défauts pour ce qui manque, nombres bornés, textes nettoyés. */
export function normaliser(p: Partial<Record<string, unknown>> | null | undefined): Parametres {
  const r = { ...DEFAUTS } as Record<Cle, string | number | boolean>;
  for (const cle of Object.keys(DEFAUTS) as Cle[]) {
    const v = p?.[cle], def = DEFAUTS[cle];
    if (typeof def === 'number') {
      const n = typeof v === 'number' ? v : typeof v === 'string' ? Number(v.replace(',', '.')) : NaN;
      if (!Number.isFinite(n)) continue;
      const d = DEF_PAR_CLE[cle];
      let x = Math.min(d?.max ?? Infinity, Math.max(d?.min ?? -Infinity, n));
      if (d?.entier) x = Math.round(x);
      r[cle] = x;
    } else if (typeof def === 'boolean') {
      if (typeof v === 'boolean') r[cle] = v;
    } else if (typeof v === 'string') {
      const t = v.trim();
      // un nom Bluetooth ou un dépôt vide n'aurait pas de sens : on garde le défaut
      r[cle] = t || (['nomToit', 'nomPortatif', 'depot', 'appats'].includes(cle) ? def : '');
    }
  }
  return r as Parametres;
}

/** Liste des appâts (texte séparé par des points-virgules). */
export const listeAppats = (p: Parametres) => p.appats.split(';').map((x) => x.trim()).filter(Boolean);
/** Dépôt valide « propriétaire/nom » ? */
export const depotValide = (d: string) => /^[\w.-]+\/[\w.-]+$/.test(d.trim());
