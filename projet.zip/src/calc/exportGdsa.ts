/** Export de fin de saison pour le GDSA (groupement de défense sanitaire apicole) :
 *  classeur avec résumé, nids, ruchers, pièges et relevés ; même contenu résumé pour le rapport PDF. Sans dépendance au téléphone. */
import { distM } from './geo';
import { capturesPiege, comparerSaisons, statsRucher } from './saison';
import type { Feuille } from './xlsx';
import type { Nid, Piege, Rucher } from '../db';

const ETAT: Record<string, string> = { estime: 'À traiter', trouve: 'À traiter', traite: 'Traité', mort: 'Vérifié mort' };
const jour = (ms: number | null | undefined) => (ms ? new Date(ms).toLocaleDateString('fr-FR') : '');
const arrondi = (v: number | null, d = 0) => (v === null ? null : Math.round(v * 10 ** d) / 10 ** d);
const an = (ms: number) => new Date(ms).getFullYear();

export type DonneesGdsa = { nids: Nid[]; ruchers: Rucher[]; pieges: Piege[]; annee: number; auteur: string; maintenant: number; structure?: string; r1?: number; r2?: number };
const km = (m: number) => (m >= 1000 ? `${String(+(m / 1000).toFixed(1)).replace('.', ',')} km` : `${m} m`);

export type ResumeGdsa = {
  annee: number; auteur: string; structure: string; r1: number; r2: number; edite: string; nids: number; detruits: number; aTraiter: number; morts: number;
  delaiJ: number | null; distRucher: number | null; precision: number | null;
  pieges: number; fondatrices: number; releves: number;
  parRucher: { nom: string; ruches: number | null; n1km: number; n3km: number; detruits: number; aTraiter: number; plusProcheM: number | null; captures: number }[];
  saisons: { annee: number; nids: number; detruits: number; captures: number }[];
};

export function resumeGdsa(d: DonneesGdsa): ResumeGdsa {
  const nids = d.nids.filter((n) => an(n.t) === d.annee);
  const s = comparerSaisons(d.nids, d.ruchers, d.pieges);
  const cette = s.find((x) => x.annee === d.annee);
  const releves = d.pieges.reduce((a, p) => a + p.releves.filter((r) => an(r.t) === d.annee).length, 0);
  return {
    annee: d.annee, auteur: d.auteur, structure: d.structure ?? '', r1: d.r1 ?? 1000, r2: d.r2 ?? 3000, edite: new Date(d.maintenant).toLocaleDateString('fr-FR'),
    nids: nids.length, detruits: nids.filter((n) => n.etat === 'traite' || n.etat === 'mort').length,
    aTraiter: nids.filter((n) => n.etat === 'trouve' || n.etat === 'estime').length, morts: nids.filter((n) => n.etat === 'mort').length,
    delaiJ: cette?.delaiTraitementJ ?? null, distRucher: cette?.distRucher ?? null, precision: cette?.precision ?? null,
    pieges: d.pieges.filter((p) => p.releves.some((r) => an(r.t) === d.annee) || (p.pose_ms !== null && an(p.pose_ms) === d.annee)).length,
    fondatrices: d.pieges.reduce((a, p) => a + capturesPiege(p, d.annee), 0), releves,
    parRucher: d.ruchers.map((r) => statsRucher(r, d.nids, d.pieges, d.annee, d.r1 ?? 1000, d.r2 ?? 3000)).map((x) => ({
      nom: x.rucher.nom, ruches: x.rucher.ruches, n1km: x.n1km, n3km: x.n3km, detruits: x.detruits, aTraiter: x.aTraiter,
      plusProcheM: x.plusProche ? Math.round(x.plusProche.d) : null, captures: x.captures,
    })),
    saisons: s.map((x) => ({ annee: x.annee, nids: x.nids, detruits: x.detruits, captures: x.captures })),
  };
}

export function feuillesGdsa(d: DonneesGdsa): Feuille[] {
  const r = resumeGdsa(d);
  const tri = [...d.nids].sort((a, b) => a.t - b.t);
  const numero = (id: number) => tri.findIndex((n) => n.id === id) + 1;
  const proche = (lat: number, lon: number) => {
    let b: { nom: string; d: number } | null = null;
    for (const x of d.ruchers) { const dd = distM(lat, lon, x.lat, x.lon); if (!b || dd < b.d) b = { nom: x.nom, d: dd }; }
    return b;
  };
  const nids = tri.filter((n) => an(n.t) === d.annee);
  const pct = (a: number, b: number) => (b ? `${Math.round((100 * a) / b)} %` : '');

  const resume: Feuille = { nom: 'Résumé', lignes: [
    ['Bilan frelon asiatique', `Saison ${r.annee}`],
    ['Établi par', r.auteur || ''],
    ['Structure', r.structure || ''],
    ['Édité le', r.edite],
    [],
    ['Nids trouvés', r.nids],
    ['Nids détruits (traités ou vérifiés morts)', r.detruits, pct(r.detruits, r.nids)],
    ['dont vérifiés morts', r.morts],
    ['Nids restant à traiter', r.aTraiter],
    ['Délai moyen entre découverte et traitement (jours)', arrondi(r.delaiJ, 1)],
    ['Distance moyenne au rucher le plus proche (m)', arrondi(r.distRucher)],
    ['Précision moyenne de localisation (m)', arrondi(r.precision)],
    [],
    ['Pièges de printemps utilisés', r.pieges],
    ['Relevés de pièges', r.releves],
    ['Fondatrices (frelons asiatiques) piégées', r.fondatrices],
    [],
    ['Saison', 'Nids trouvés', 'Nids détruits', 'Fondatrices piégées'],
    ...r.saisons.map((s) => [s.annee, s.nids, s.detruits, s.captures]),
  ] };

  const feuilleNids: Feuille = { nom: 'Nids', lignes: [
    ['N°', 'Trouvé le', 'État', 'Latitude (WGS84)', 'Longitude (WGS84)', 'Précision (m)', 'Support', 'Hauteur', 'Diamètre', 'Activité',
      'Traité le', 'Méthode', 'Produit', 'Quantité', 'Opérateur / n° Certibiocide', 'Vérifié mort le', 'Rucher le plus proche', 'Distance au rucher (m)', 'Trouvé par', 'Noté par', 'Remarques'],
    ...nids.map((n) => {
      const p = proche(n.lat, n.lon);
      return [numero(n.id), jour(n.t), ETAT[n.etat] ?? n.etat, Number(n.lat.toFixed(6)), Number(n.lon.toFixed(6)), Math.round(n.err), n.support, n.hauteur, n.diametre, n.activite,
        jour(n.traite_ms ?? n.inter_ms), n.methode, n.produit, n.quantite, n.operateur, jour(n.verifie_ms), p?.nom ?? '', p ? Math.round(p.d) : null, n.sources, n.auteur, n.note];
    }),
  ] };

  const feuilleRuchers: Feuille = { nom: 'Ruchers', lignes: [
    ['Rucher', 'Ruches', 'Latitude', 'Longitude', `Nids à moins de ${km(r.r1)}`, `Nids à moins de ${km(r.r2)}`, 'Détruits', 'À traiter', 'Nid le plus proche (m)', `Fondatrices piégées à moins de ${km(r.r1)}`],
    ...r.parRucher.map((x, i) => [x.nom, x.ruches, Number(d.ruchers[i].lat.toFixed(6)), Number(d.ruchers[i].lon.toFixed(6)), x.n1km, x.n3km, x.detruits, x.aTraiter, x.plusProcheM, x.captures]),
  ] };

  const pieges = d.pieges.filter((p) => p.releves.some((x) => an(x.t) === d.annee) || (p.pose_ms !== null && an(p.pose_ms) === d.annee));
  const feuillePieges: Feuille = { nom: 'Pièges', lignes: [
    ['Piège', 'Latitude', 'Longitude', 'Appât', 'Posé le', 'Retiré le', 'Relevés', 'Frelons asiatiques', 'Autres insectes', 'Rucher le plus proche', 'Distance (m)'],
    ...pieges.map((p) => {
      const rel = p.releves.filter((x) => an(x.t) === d.annee), pr = proche(p.lat, p.lon);
      return [p.nom, Number(p.lat.toFixed(6)), Number(p.lon.toFixed(6)), p.appat, jour(p.pose_ms), jour(p.retire_ms), rel.length,
        rel.reduce((a, x) => a + x.frelons, 0), rel.reduce((a, x) => a + x.autres, 0), pr?.nom ?? '', pr ? Math.round(pr.d) : null];
    }),
  ] };
  const feuilleReleves: Feuille = { nom: 'Relevés des pièges', lignes: [
    ['Piège', 'Date', 'Frelons asiatiques', 'Autres insectes', 'Remarque'],
    ...pieges.flatMap((p) => p.releves.filter((x) => an(x.t) === d.annee).sort((a, b) => a.t - b.t).map((x) => [p.nom, jour(x.t), x.frelons, x.autres, x.note])),
  ] };
  return [resume, feuilleNids, feuilleRuchers, feuillePieges, feuilleReleves];
}

const esc = (s: string) => s.replace(/[<>&"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' })[c]!);
/** Rapport d'une ou deux pages (HTML pour l'impression en PDF). */
export function rapportHtml(r: ResumeGdsa): string {
  const ligne = (k: string, v: string | number | null) => `<tr><th>${esc(k)}</th><td>${v === null || v === '' ? '—' : esc(String(v))}</td></tr>`;
  const fr = (v: number | null, d = 0) => (v === null ? null : v.toFixed(d).replace('.', ','));
  return `<html><head><meta charset="utf-8"><style>
  body{font-family:sans-serif;color:#14202E;padding:28px;font-size:13px} h1{margin:0 0 4px;font-size:22px} .s{color:#5B6672;margin:0 0 18px}
  h2{font-size:13px;text-transform:uppercase;letter-spacing:1px;color:#5B6672;margin:20px 0 6px}
  table{border-collapse:collapse;width:100%} th,td{padding:5px 8px;border-bottom:1px solid #DDE1D8;text-align:left} th{color:#5B6672;font-weight:normal;width:62%}
  .t th,.t td{width:auto;text-align:right} .t th:first-child,.t td:first-child{text-align:left} .t thead th{color:#14202E;font-weight:bold}
  .k{display:flex;gap:10px;margin:8px 0 4px} .k div{flex:1;border:1px solid #DDE1D8;border-radius:8px;padding:10px;text-align:center} .k b{display:block;font-size:22px}
</style></head><body>
  <h1>Bilan frelon asiatique – saison ${r.annee}</h1>
  <p class="s">${r.auteur ? `Établi par ${esc(r.auteur)} · ` : ''}${r.structure ? `${esc(r.structure)} · ` : ''}édité le ${r.edite}</p>
  <div class="k"><div><b>${r.nids}</b>nids trouvés</div><div><b>${r.detruits}</b>nids détruits</div><div><b>${r.fondatrices}</b>fondatrices piégées</div></div>
  <h2>Nids</h2><table>
    ${ligne('Nids détruits (traités ou vérifiés morts)', `${r.detruits}${r.nids ? ` (${Math.round((100 * r.detruits) / r.nids)} %)` : ''}`)}
    ${ligne('dont vérifiés morts', r.morts)}${ligne('Restant à traiter', r.aTraiter)}
    ${ligne('Délai moyen découverte → traitement', r.delaiJ !== null ? `${fr(r.delaiJ, 1)} jours` : null)}
    ${ligne('Distance moyenne au rucher le plus proche', r.distRucher !== null ? `${Math.round(r.distRucher)} m` : null)}
    ${ligne('Précision moyenne de localisation', r.precision !== null ? `± ${Math.round(r.precision)} m` : null)}
  </table>
  <h2>Pièges de printemps</h2><table>${ligne('Pièges utilisés', r.pieges)}${ligne('Relevés', r.releves)}${ligne('Fondatrices piégées', r.fondatrices)}</table>
  ${r.parRucher.length ? `<h2>Par rucher</h2><table class="t"><thead><tr><th>Rucher</th><th>Ruches</th><th>Nids &lt; ${km(r.r1)}</th><th>Nids &lt; ${km(r.r2)}</th><th>Détruits</th><th>À traiter</th><th>Plus proche</th><th>Fondatrices</th></tr></thead>
    ${r.parRucher.map((x) => `<tr><td>${esc(x.nom)}</td><td>${x.ruches ?? ''}</td><td>${x.n1km}</td><td>${x.n3km}</td><td>${x.detruits}</td><td>${x.aTraiter}</td><td>${x.plusProcheM !== null ? `${x.plusProcheM} m` : '—'}</td><td>${x.captures}</td></tr>`).join('')}</table>` : ''}
  ${r.saisons.length > 1 ? `<h2>Évolution</h2><table class="t"><thead><tr><th>Saison</th><th>Nids trouvés</th><th>Détruits</th><th>Fondatrices piégées</th></tr></thead>
    ${r.saisons.map((s) => `<tr><td>${s.annee}</td><td>${s.nids}</td><td>${s.detruits}</td><td>${s.captures}</td></tr>`).join('')}</table>` : ''}
  <p class="s" style="margin-top:24px">Le détail (coordonnées de chaque nid, interventions, relevés des pièges) est dans le classeur joint.</p>
</body></html>`;
}
