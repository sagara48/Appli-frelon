/**
 * Fusion de toutes les sources d'un tag → une seule estimation du nid (portage de compute() dans fusion.c).
 * Sources prises en compte dans cette version : relèvements du toit, directions à l'œil, tours sur soi-même du portatif, nids du portatif.
 * + anneaux et caps du chrono à l'appât (bait_sources).
 */
import { estFuse, type ELine, type EPoint, type ERing, type FRes } from './estim';
import type { Ligne } from './releves';

/** Direction notée à l'œil, ou relèvement d'un tour sur soi-même du portatif (src 'tour', sig = précision en degrés). t : heure (ms). */
export type DirectionOeil = { lat: number; lon: number; deg: number; t?: number; src?: 'tour'; sig?: number; ctr?: number };

/** Précision d'un tour sur soi-même d'après son contraste (dB entre le meilleur et le pire côté) ; null = trop plat, ignoré. */
export function sigmaTour(ctr: number): number | null {
  if (!(ctr >= 4)) return null;
  return Math.round(Math.max(8, Math.min(20, 28 - 1.8 * ctr)));
}
/** Estimation ponctuelle : tour sur place du portatif (par défaut), nid estimé en marchant, nid du drone (3D). */
export type PointPortatif = { lat: number; lon: number; errM: number; src?: 'balayage' | 'marche' | 'drone' };
export type Sources = { lignes: Ligne[]; oeil: DirectionOeil[]; portatif: PointPortatif[]; anneaux?: ERing[]; capsAppat?: ELine[] };

export type Fusion = FRes & { nVoiture: number; nOeil: number; nTour: number; nPortatif: number; nAnneaux: number; nCapsAppat: number; nMarche: number; nDrone: number };

export function fusionner(s: Sources): Fusion {
  const L: ELine[] = [];
  const nCar = s.lignes.filter((l) => !l.ecartee).length;
  const wCar = nCar > 8 ? 8 / nCar : 1; // relevés voiture corrélés entre eux : poids total plafonné
  for (const l of s.lignes)
    L.push({ lat: l.lat, lon: l.lon, deg: l.absDeg, sigDeg: 10, w: wCar * (0.3 + (0.7 * l.q) / 100) * (l.ecartee ? 0.3 : 1) });
  for (const v of s.oeil) L.push({ lat: v.lat, lon: v.lon, deg: v.deg, sigDeg: v.sig ?? 15, w: 1 }); // à l'œil : ±15° ; tour : selon contraste
  for (const c of s.capsAppat ?? []) L.push(c); // caps de départ / retour moyens des appâts
  // les tours sont versés un par un : le nid que le portatif en tire (mêmes tours croisés) ferait double compte
  const tours = s.oeil.filter((v) => v.src === 'tour').length;
  const pts = tours ? s.portatif.filter((p) => p.src && p.src !== 'balayage') : s.portatif;
  const P: EPoint[] = pts.map((p) => ({ lat: p.lat, lon: p.lon, err: p.errM, w: 1 }));
  const R = s.anneaux ?? [];
  const f = estFuse(L, P, R);
  return { ...f, nVoiture: s.lignes.length, nOeil: s.oeil.length - tours, nTour: tours, nPortatif: pts.filter((p) => !p.src || p.src === 'balayage').length, nAnneaux: R.length,
    nCapsAppat: s.capsAppat?.length ?? 0, nMarche: s.portatif.filter((p) => p.src === 'marche').length, nDrone: s.portatif.filter((p) => p.src === 'drone').length };
}
