/** Distance approximative d'un tag d'après la force du signal (modèle de propagation « log-distance ») :
 *    RSSI = RSSI_1m − 10 · n · log10(d)   →   d = 10^((RSSI_1m − RSSI) / (10 · n))
 *  RSSI_1m : signal reçu à 1 m (propre à chaque récepteur et à son antenne, à étalonner) ;
 *  n : affaiblissement du milieu (2 en terrain dégagé, 2,5 à 3 en bocage, 3 à 3,5 en bois).
 *  Le signal varie de plusieurs dB (feuillage, position du frelon, orientation de l'antenne) :
 *  on donne une fourchette correspondant à ± marge dB. */

export type ModeleDistance = { ref1m: number; n: number; margeDb: number };
export type Distance = { m: number; min: number; max: number };

export function distanceRssi(rssi: number, mod: ModeleDistance): Distance | null {
  if (!Number.isFinite(rssi) || rssi <= -127) return null; // voie muette
  const d = (x: number) => Math.min(20000, Math.max(1, 10 ** ((mod.ref1m - x) / (10 * mod.n))));
  return { m: d(rssi), min: d(rssi + mod.margeDb), max: d(rssi - mod.margeDb) };
}

/** RSSI à 1 m déduit d'une mesure à une distance connue (étalonnage). */
export const refDepuisMesure = (rssi: number, distanceM: number, n: number) => rssi + 10 * n * Math.log10(Math.max(1, distanceM));

/** Arrondi lisible : 5 m sous 50 m, 10 m sous 200 m, 50 m sous 1 km, puis 0,1 km. */
export function arrondiDistance(m: number): string {
  if (m >= 1000) return `${(Math.round(m / 100) / 10).toString().replace('.', ',')} km`;
  const pas = m < 50 ? 5 : m < 200 ? 10 : 50;
  return `${Math.max(pas, Math.round(m / pas) * pas)} m`;
}
/** « ≈ 120 m » et la fourchette « 70 – 210 m ». */
export function texteDistance(d: Distance): { court: string; fourchette: string } {
  return { court: `≈ ${arrondiDistance(d.m)}`, fourchette: `${arrondiDistance(d.min)} – ${arrondiDistance(d.max)}` };
}
