/** Géométrie des tuiles Web Mercator (fond IGN) : sans dépendance, testable hors téléphone. */
import { D2R } from './geo';

export type Couche = 'plan' | 'photo';
export const ZOOM_MIN = 11, ZOOM_MAX = 17, ZOOM_HORS_LIGNE = [12, 13, 14, 15, 16];

/* ---------- géométrie Web Mercator ---------- */
export const lonVersX = (lon: number, z: number) => ((lon + 180) / 360) * 2 ** z;
export const latVersY = (lat: number, z: number) => ((1 - Math.log(Math.tan(lat * D2R) + 1 / Math.cos(lat * D2R)) / Math.PI) / 2) * 2 ** z;
export const xVersLon = (x: number, z: number) => (x / 2 ** z) * 360 - 180;
export const yVersLat = (y: number, z: number) => Math.atan(Math.sinh(Math.PI * (1 - (2 * y) / 2 ** z))) / D2R;
/** Mètres par pixel d'une tuile de 256 px au niveau z. */
export const resolution = (lat: number, z: number) => (156543.03 * Math.cos(lat * D2R)) / 2 ** z;
/** Niveau dont la résolution est la plus proche de mParPx (en restant un peu plus fin). */
export const zoomPour = (lat: number, mParPx: number) =>
  Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, Math.ceil(Math.log2((156543.03 * Math.cos(lat * D2R)) / mParPx))));

/** Tuiles couvrant un rectangle lat/lon à un niveau donné. */
export function tuilesDe(la1: number, lo1: number, la2: number, lo2: number, z: number) {
  const x1 = Math.floor(lonVersX(Math.min(lo1, lo2), z)), x2 = Math.floor(lonVersX(Math.max(lo1, lo2), z));
  const y1 = Math.floor(latVersY(Math.max(la1, la2), z)), y2 = Math.floor(latVersY(Math.min(la1, la2), z));
  const t: { x: number; y: number; z: number }[] = [];
  for (let x = x1; x <= x2; x++) for (let y = y1; y <= y2; y++) t.push({ x, y, z });
  return t;
}

export type Zone = { id: string; nom: string; lat: number; lon: number; largeurKm: number; hauteurKm: number; couches: Couche[]; tuiles: number; octets: number; dateMs: number };

export function rectangleZone(z: Pick<Zone, 'lat' | 'lon' | 'largeurKm' | 'hauteurKm'>) {
  const dla = (z.hauteurKm * 500) / 110540, dlo = (z.largeurKm * 500) / (111320 * Math.cos(z.lat * D2R));
  return { la1: z.lat - dla, lo1: z.lon - dlo, la2: z.lat + dla, lo2: z.lon + dlo };
}
export function compterTuiles(z: Pick<Zone, 'lat' | 'lon' | 'largeurKm' | 'hauteurKm' | 'couches'>) {
  const r = rectangleZone(z);
  return ZOOM_HORS_LIGNE.reduce((n, zz) => n + tuilesDe(r.la1, r.lo1, r.la2, r.lo2, zz).length, 0) * z.couches.length;
}
/** Taille estimée (octets) : ~18 ko par tuile de plan, ~28 ko par tuile photo. */
export const tailleEstimee = (z: Pick<Zone, 'lat' | 'lon' | 'largeurKm' | 'hauteurKm' | 'couches'>) =>
  compterTuiles({ ...z, couches: ['plan'] }) * (z.couches.includes('plan') ? 18000 : 0) + compterTuiles({ ...z, couches: ['photo'] }) * (z.couches.includes('photo') ? 28000 : 0);

