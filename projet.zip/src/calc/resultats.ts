/** Résultats de saison, tags sans nouvelles, et effet de la destruction d'un nid sur la pression devant les ruches proches.
 *  Sans dépendance au téléphone (testé). */
import { distM } from './geo';
import { interventionsDe } from './intervention';
import { lirePressions, type ReleveP } from './pression';

const JOUR = 86400000;
const mediane = (v: number[]) => { if (!v.length) return null; const s = [...v].sort((a, b) => a - b), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };

/* ---------- tag perdu ---------- */
export type Vu = { t: number; lat: number; lon: number; par: string; err: number | null };
type TagVu = { vu_ms?: number | null; vu_lat?: number | null; vu_lon?: number | null };
/** Faut-il mémoriser ce nouveau contact ? (au plus toutes les 2 min, ou dès que la position bouge de plus de 30 m) */
export function doitNoter(f: TagVu, v: Vu): boolean {
  if (!f.vu_ms || f.vu_lat == null || f.vu_lon == null) return true;
  return v.t - f.vu_ms >= 120000 || distM(f.vu_lat, f.vu_lon, v.lat, v.lon) > 30;
}
/** Tags posés dont on n'a plus de nouvelles depuis `jours` (ni entendus, ni posés récemment). */
export function sansNouvelles<T extends TagVu & { etat: string; pose_ms: number | null }>(fiches: T[], maintenant: number, jours: number): T[] {
  return fiches.filter((f) => f.etat === 'pose' && maintenant - Math.max(f.vu_ms ?? 0, f.pose_ms ?? 0) >= jours * JOUR);
}

/* ---------- pression et nids ---------- */
type NidMin = { id: number; lat: number; lon: number; etat: string; traite_ms: number | null; interventions?: string | null; t: number;
  inter_ms: number | null; methode: string; produit: string; quantite: string; operateur: string; hauteur: string; diametre: string; verifie_ms: number | null };
type RucherMin = { id: number; nom: string; lat: number; lon: number; pressions: string };
export type Effet = { rucher: number; nomRucher: string; nid: number; t: number; distM: number; avant: number; apres: number; nAvant: number; nApres: number; variation: number };

const moyenne = (l: ReleveP[], debut: number, fin: number) => {
  const x = l.filter((r) => r.t >= debut && r.t < fin);
  return { m: x.length ? x.reduce((a, r) => a + r.n, 0) / x.length : null, n: x.length };
};
/** Pour chaque nid traité à moins de `rayonM` d'un rucher : pression moyenne des 7 jours avant le traitement
 *  et des 7 jours suivants (à partir du lendemain). Variation en % (négatif = baisse). Il faut au moins un relevé de chaque côté. */
export function effetsDestruction(ruchers: RucherMin[], nids: NidMin[], rayonM: number): Effet[] {
  const r: Effet[] = [];
  for (const ru of ruchers) {
    const l = lirePressions(ru.pressions);
    if (!l.length) continue;
    for (const n of nids) {
      const traits = interventionsDe(n).filter((i) => i.type === 'destruction' || i.type === 'retraitement').map((i) => i.t);
      const t = traits[0] ?? n.traite_ms;
      if (!t) continue;
      const d = distM(ru.lat, ru.lon, n.lat, n.lon);
      if (d > rayonM) continue;
      const av = moyenne(l, t - 7 * JOUR, t), ap = moyenne(l, t + JOUR, t + 8 * JOUR);
      if (av.m === null || ap.m === null) continue;
      r.push({ rucher: ru.id, nomRucher: ru.nom, nid: n.id, t, distM: d, avant: av.m, apres: ap.m, nAvant: av.n, nApres: ap.n,
        variation: av.m > 0 ? Math.round(((ap.m - av.m) / av.m) * 100) : ap.m > 0 ? 100 : 0 });
    }
  }
  return r.sort((a, b) => b.t - a.t);
}

/* ---------- résultats de saison ---------- */
export type Pose = { tag: number; t: number };
export type Methode = 'voiture' | 'portatif' | 'chrono' | 'oeil' | 'drone' | 'main';
export const LIBELLE_METHODE: Record<Methode, string> = { voiture: 'Voiture (toit)', portatif: 'Portatif', chrono: 'Chrono à l\'appât', oeil: 'À l\'œil', drone: 'Drone', main: 'À la main' };
/** Méthode principale d'un nid, d'après le texte de ses sources (la première citée). */
export function methodeDe(sources: string): Methode {
  const s = (sources || '').toLowerCase();
  const pos: [Methode, number][] = ([['voiture', s.indexOf('voiture')], ['portatif', s.indexOf('portatif')], ['chrono', s.indexOf('chrono')],
    ['oeil', s.search(/œil|oeil/)], ['drone', s.search(/drone|nacelle/)]] as [Methode, number][]).filter(([, i]) => i >= 0);
  return pos.length ? pos.sort((a, b) => a[1] - b[1])[0][0] : 'main';
}

export type Resultats = {
  poses: number; tagsDistincts: number; nids: number; nidsParTag: number; taux: number | null;
  delaiMedianH: number | null; delaiMinH: number | null;
  distRucherMedianeM: number | null; prochesRucher: number;
  methodes: { m: Methode; n: number; delaiMedianH: number | null }[];
  traites: number; mortsPremierCoup: number; retraites: number;
};
export function resultatsSaison(nids: (NidMin & { tag: number; sources: string })[], poses: Pose[], ruchers: { lat: number; lon: number }[], an: number, rayonM: number): Resultats {
  const dansAn = (t: number) => new Date(t).getFullYear() === an;
  const p = poses.filter((x) => dansAn(x.t));
  const ns = nids.filter((n) => dansAn(n.t));
  const parTag = ns.filter((n) => n.tag > 0);
  // délai entre la dernière pose du tag (avant la découverte) et la découverte du nid
  const delai = (n: { tag: number; t: number }) => {
    const d = poses.filter((x) => x.tag === n.tag && x.t <= n.t && n.t - x.t < 30 * JOUR).sort((a, b) => b.t - a.t)[0];
    return d ? (n.t - d.t) / 3600000 : null;
  };
  const delais = parTag.map(delai).filter((x): x is number => x !== null);
  const dists = ns.map((n) => (ruchers.length ? Math.min(...ruchers.map((r) => distM(r.lat, r.lon, n.lat, n.lon))) : null)).filter((x): x is number => x !== null);
  const parMethode = new Map<Methode, { n: number; d: number[] }>();
  for (const n of ns) {
    const m = methodeDe(n.sources), o = parMethode.get(m) ?? { n: 0, d: [] };
    o.n++;
    const d = n.tag > 0 ? delai(n) : null;
    if (d !== null) o.d.push(d);
    parMethode.set(m, o);
  }
  let traites = 0, morts1 = 0, retraites = 0;
  for (const n of ns) {
    const l = interventionsDe(n), nb = l.filter((i) => i.type === 'destruction' || i.type === 'retraitement').length;
    if (!nb && !n.traite_ms) continue;
    traites++;
    if (nb > 1) retraites++;
    else if (n.etat === 'mort') morts1++;
  }
  const arr = (x: number | null) => (x === null ? null : Math.round(x * 10) / 10);
  return {
    poses: p.length, tagsDistincts: new Set(p.map((x) => x.tag)).size, nids: ns.length, nidsParTag: parTag.length,
    taux: p.length ? Math.round((parTag.length / p.length) * 100) : null,
    delaiMedianH: arr(mediane(delais)), delaiMinH: delais.length ? arr(Math.min(...delais)) : null,
    distRucherMedianeM: dists.length ? Math.round(mediane(dists)!) : null, prochesRucher: dists.filter((d) => d <= rayonM).length,
    methodes: [...parMethode.entries()].map(([m, o]) => ({ m, n: o.n, delaiMedianH: arr(mediane(o.d)) })).sort((a, b) => b.n - a.n),
    traites, mortsPremierCoup: morts1, retraites,
  };
}
