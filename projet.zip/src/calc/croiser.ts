/** « Où rouler pour croiser » : quand les relèvements d'un tag partent tous du même côté du nid estimé, ils sont presque
 *  parallèles et l'estimation reste allongée. Le meilleur relèvement suivant se prend dans le plus grand trou de leurs
 *  directions vues depuis le nid, à la distance habituelle des relevés. Même calcul que l'écran voiture (croiser.c).
 *  Avec les routes d'OpenStreetMap, on choisit le point de route le plus proche de ce point idéal dans un secteur de ± 40°. */
import { capDeg, D2R, distM, kxOf, KY } from './geo';
import { CARROSSABLES, surSegment, type Voie } from './route';

export type Croisement = {
  besoin: boolean; // false : les relèvements entourent déjà assez le nid (plus grand trou < 140°)
  trouDeg: number; // largeur du plus grand trou entre les directions vues depuis le nid
  dirDeg: number; // direction (depuis le nid) où aller relever
  distM: number; // distance au nid du point idéal
  lat: number; lon: number; // point idéal
};

export const TROU_MIN = 140;

export function pointA(lat: number, lon: number, capD: number, d: number) {
  return { lat: lat + (d * Math.cos(capD * D2R)) / KY, lon: lon + (d * Math.sin(capD * D2R)) / kxOf(lat) };
}
const ecartAngle = (a: number, b: number) => Math.abs((((a - b) % 360) + 540) % 360 - 180);

export function ouCroiser(nid: { lat: number; lon: number }, obs: { lat: number; lon: number }[]): Croisement | null {
  const pts = obs.filter((o) => distM(nid.lat, nid.lon, o.lat, o.lon) > 20);
  if (!pts.length) return null;
  const ph = pts.map((o) => capDeg(nid.lat, nid.lon, o.lat, o.lon)).sort((a, b) => a - b);
  let trou = 360 - ph[ph.length - 1] + ph[0], centre = (ph[ph.length - 1] + trou / 2) % 360;
  for (let i = 1; i < ph.length; i++) { const g = ph[i] - ph[i - 1]; if (g > trou) { trou = g; centre = ph[i - 1] + g / 2; } }
  const ds = pts.map((o) => distM(nid.lat, nid.lon, o.lat, o.lon)).sort((a, b) => a - b);
  const d = Math.max(150, Math.min(800, ds[Math.floor(ds.length / 2)]));
  const p = pointA(nid.lat, nid.lon, centre, d);
  return { besoin: trou >= TROU_MIN, trouDeg: Math.round(trou), dirDeg: Math.round(centre) % 360, distM: Math.round(d), ...p };
}

export type PointCroise = { lat: number; lon: number; distNidM: number; ecartDeg: number; type: string; nom?: string };
/** Point de route carrossable le plus proche du point idéal, vu du nid à ± 40° de la bonne direction, entre 100 et 1 200 m. */
export function routePourCroiser(nid: { lat: number; lon: number }, c: Croisement, voies: Voie[]): PointCroise | null {
  let best: (PointCroise & { s: number }) | null = null;
  for (const v of voies) {
    if (!CARROSSABLES.includes(v.type)) continue;
    for (let i = 1; i < v.points.length; i++) {
      const a = v.points[i - 1], b = v.points[i];
      const n = Math.max(1, Math.ceil(distM(a.lat, a.lon, b.lat, b.lon) / 25));
      const cands = [surSegment(c, a, b)];
      for (let k = 0; k <= n; k++) cands.push({ lat: a.lat + ((b.lat - a.lat) * k) / n, lon: a.lon + ((b.lon - a.lon) * k) / n });
      for (const q of cands) {
        const dn = distM(nid.lat, nid.lon, q.lat, q.lon), e = ecartAngle(capDeg(nid.lat, nid.lon, q.lat, q.lon), c.dirDeg);
        if (dn < 100 || dn > 1200 || e > 40) continue;
        const s = distM(q.lat, q.lon, c.lat, c.lon) + e * 4; // un peu de préférence pour l'axe
        if (!best || s < best.s) best = { lat: q.lat, lon: q.lon, distNidM: Math.round(dn), ecartDeg: Math.round(e), type: v.type, nom: v.nom, s };
      }
    }
  }
  if (!best) return null;
  const { s: _s, ...r } = best;
  return r;
}
