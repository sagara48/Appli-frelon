/** Plan de vol automatique autour d'un nid estimé : spirale (de l'extérieur vers le nid) ou quadrillage,
 *  exporté en mission Litchi (CSV) pour un vol par points de passage, et en trace KML.
 *  Sans dépendance au téléphone (testé). */

/** spirale / quadrillage : relevés en survol ; tour : 3 stations où le drone pivote sur place (relèvement depuis le ciel). */
export type Motif = 'spirale' | 'quadrillage' | 'tour';
export type ReglagesPlan = { motif: Motif; rayonM: number; hauteurM: number; espacementM: number; vitesse: number };
export const PLAN_DEFAUT: ReglagesPlan = { motif: 'spirale', rayonM: 150, hauteurM: 40, espacementM: 50, vitesse: 6 };
/** Litchi accepte au plus 99 points de passage. */
export const MAX_POINTS = 99;
export const HAUTEUR_MAX = 120; // réglementation : 120 m au-dessus du sol

export type Point = { lat: number; lon: number };
/** Point de mission : cap imposé, hauteur propre, inclinaison de la nacelle de prise de vue, actions Litchi
 *  ([type, paramètre] : 0 = attendre (ms), 1 = photo, 4 = tourner le drone (°), 5 = incliner la caméra (°)). */
export type PointMission = Point & { cap?: number; h?: number; gimbal?: number; actions?: [number, number][] };
export type Plan = { points: PointMission[]; longueurM: number; dureeMin: number; tronque: boolean; reglages: ReglagesPlan; centre: Point };

const M_LAT = 111320;
const versGeo = (c: Point, x: number, y: number): Point => ({ lat: c.lat + y / M_LAT, lon: c.lon + x / (M_LAT * Math.cos((c.lat * Math.PI) / 180)) });
const versXY = (c: Point, p: Point) => ({ x: (p.lon - c.lon) * M_LAT * Math.cos((c.lat * Math.PI) / 180), y: (p.lat - c.lat) * M_LAT });

/** Rayon conseillé : au moins 3 fois l'incertitude du nid estimé, entre 80 et 400 m. */
export const rayonConseille = (errM: number) => Math.round(Math.min(400, Math.max(80, 3 * errM)) / 10) * 10;

function spirale(r: ReglagesPlan): { x: number; y: number }[] {
  // spirale d'Archimède r = e.θ/2π, parcourue de l'extérieur vers le centre, un point tous les ~e/1,5 m
  const e = r.espacementM, thMax = (2 * Math.PI * r.rayonM) / e, pas = e / 1.5;
  const pts: { x: number; y: number }[] = [];
  let th = thMax;
  while (th > 0) {
    const rr = (e * th) / (2 * Math.PI);
    pts.push({ x: rr * Math.sin(th), y: rr * Math.cos(th) });
    th -= pas / Math.max(rr, pas); // pas constant le long de la courbe
  }
  pts.push({ x: 0, y: 0 });
  return pts;
}
function quadrillage(r: ReglagesPlan): { x: number; y: number }[] {
  // allers-retours est-ouest espacés de e, limités au cercle de rayon R
  const pts: { x: number; y: number }[] = [];
  let k = 0;
  for (let y = -r.rayonM + r.espacementM / 2; y <= r.rayonM; y += r.espacementM, k++) {
    const dx = Math.sqrt(Math.max(0, r.rayonM * r.rayonM - y * y));
    if (dx < 5) continue;
    const a = { x: -dx, y }, b = { x: dx, y };
    pts.push(...(k % 2 ? [b, a] : [a, b]));
  }
  return pts;
}

/* ---------- tour sur place : 3 stations, 6 caps chacune ---------- */
export const TOUR_CAPS = [0, 60, 120, 180, 240, 300];
export const TOUR_ATTENTE_MS = 3000;
/** Stations à 120° autour du nid estimé, à la distance `rayonM` ; à chaque station, un point par cap (même position),
 *  3 s d'attente : le drone pivote par pas de 60°. L'analyse découpe l'arrêt en 6 parts égales (calc/tourSurPlace). */
function tour(r: ReglagesPlan): { x: number; y: number; cap?: number; actions?: [number, number][] }[] {
  const pts: { x: number; y: number; cap?: number; actions?: [number, number][] }[] = [];
  for (const az of [0, 120, 240]) {
    const a = (az * Math.PI) / 180, x = r.rayonM * Math.sin(a), y = r.rayonM * Math.cos(a);
    for (const cap of TOUR_CAPS) pts.push({ x, y, cap, actions: [[0, TOUR_ATTENTE_MS]] });
  }
  return pts;
}

/** Mission photo d'un nid trouvé : verticale haute, verticale basse, puis vue oblique depuis le sud (caméra vers le nid). */
export function missionPhoto(nid: Point, hauteurNidM: number, vitesse = 5): Plan {
  const hn = Math.max(0, hauteurNidM);
  const h1 = Math.min(HAUTEUR_MAX, Math.max(30, hn + 20)), h2 = Math.min(h1 - 5, Math.max(15, hn + 12)), h3 = Math.max(10, hn + 8);
  const pts: PointMission[] = [
    { ...nid, h: h1, cap: 0, gimbal: -90, actions: [[5, -90], [0, 2000], [1, 0]] },
    { ...nid, h: h2, cap: 0, gimbal: -90, actions: [[0, 2000], [1, 0]] },
    { ...versGeo(nid, 0, -25), h: h3, cap: 0, gimbal: -20, actions: [[5, -20], [0, 2000], [1, 0], [0, 1000], [1, 0]] },
  ];
  const L = (h1 - h2) + Math.hypot(25, h3 - h2);
  return { points: pts, longueurM: Math.round(L), dureeMin: Math.round(((L / vitesse + 12) / 60) * 10) / 10, tronque: false, reglages: { motif: 'spirale', rayonM: 25, hauteurM: h1, espacementM: 25, vitesse }, centre: nid };
}

/** Heure d'ajout d'une photo de nid (nom « nid12_1763100000000.jpg ») ; null si inconnue. */
export function heurePhoto(uri: string): number | null {
  const m = uri.match(/_(\d{12,14})\.jpe?g$/i);
  return m ? Number(m[1]) : null;
}
/** Photos d'un nid rangées avant / après le traitement, pour les comparer côte à côte. */
export function photosAvantApres(photos: string[], traiteMs: number | null): { avant: string[]; apres: string[]; autres: string[] } {
  const r = { avant: [] as string[], apres: [] as string[], autres: [] as string[] };
  for (const p of photos) {
    const t = heurePhoto(p);
    if (!traiteMs || t === null) r.autres.push(p); else (t < traiteMs ? r.avant : r.apres).push(p);
  }
  return r;
}

export function genererPlan(centre: Point, reglages: ReglagesPlan): Plan {
  if (reglages.motif === 'tour') {
    const r = { ...reglages, rayonM: Math.min(200, Math.max(30, reglages.rayonM)), hauteurM: Math.min(HAUTEUR_MAX, Math.max(15, reglages.hauteurM)), vitesse: Math.min(15, Math.max(1, reglages.vitesse)) };
    const xy = tour(r);
    let L = r.rayonM; // depuis le centre (décollage près du nid estimé)
    for (let i = 1; i < xy.length; i++) L += Math.hypot(xy[i].x - xy[i - 1].x, xy[i].y - xy[i - 1].y);
    const attente = xy.length * (TOUR_ATTENTE_MS / 1000 + 1.5);
    return { points: xy.map((p) => ({ ...versGeo(centre, p.x, p.y), cap: p.cap, actions: p.actions })), longueurM: Math.round(L), dureeMin: Math.round(((L / r.vitesse + attente) / 60) * 10) / 10, tronque: false, reglages: r, centre };
  }
  const r = { ...reglages, rayonM: Math.max(20, reglages.rayonM), espacementM: Math.max(10, reglages.espacementM), hauteurM: Math.min(HAUTEUR_MAX, Math.max(10, reglages.hauteurM)), vitesse: Math.min(15, Math.max(1, reglages.vitesse)) };
  let xy = r.motif === 'spirale' ? spirale(r) : quadrillage(r);
  const tronque = xy.length > MAX_POINTS;
  if (tronque) { const k = Math.ceil(xy.length / MAX_POINTS); xy = xy.filter((_, i) => i % k === 0 || i === xy.length - 1).slice(-MAX_POINTS); }
  let L = 0;
  for (let i = 1; i < xy.length; i++) L += Math.hypot(xy[i].x - xy[i - 1].x, xy[i].y - xy[i - 1].y);
  return { points: xy.map((p) => versGeo(centre, p.x, p.y)), longueurM: Math.round(L), dureeMin: Math.round((L / r.vitesse / 60) * 10) / 10, tronque, reglages: r, centre };
}

/** Points en mètres autour du centre (pour l'aperçu). */
export const pointsXY = (p: Plan) => p.points.map((q) => versXY(p.centre, q));

/** Mission Litchi : hauteur au-dessus du décollage, vitesse par point, cap libre, nacelle sans action photo. */
export function litchiCsv(p: Plan): string {
  const actTete = Array.from({ length: 15 }, (_, i) => `actiontype${i + 1},actionparam${i + 1}`).join(',');
  const tete = `latitude,longitude,altitude(m),heading(deg),curvesize(m),rotationdir,gimbalmode,gimbalpitchangle,${actTete},altitudemode,speed(m/s),poi_latitude,poi_longitude,poi_altitude(m),poi_altitudemode,photo_timeinterval,photo_distinterval`;
  const l = p.points.map((q, i) => {
    const s = p.points[i + 1] ?? p.points[i - 1] ?? q;
    const route = Math.round(((Math.atan2((s.lon - q.lon) * Math.cos((q.lat * Math.PI) / 180), s.lat - q.lat) * 180) / Math.PI + 360) % 360);
    const cap = q.cap ?? (i === p.points.length - 1 ? 0 : route);
    const act = Array.from({ length: 15 }, (_, k) => (q.actions?.[k] ? `${q.actions[k][0]},${q.actions[k][1]}` : '-1,0')).join(',');
    return [q.lat.toFixed(7), q.lon.toFixed(7), q.h ?? p.reglages.hauteurM, cap, q.cap !== undefined ? 0 : 0.2, 0, q.gimbal !== undefined ? 2 : 0, q.gimbal ?? 0, act, 0, p.reglages.vitesse, 0, 0, 0, 0, -1, -1].join(',');
  });
  return [tete, ...l].join('\n') + '\n';
}
/** Trace KML (Google Earth, cartes) : chemin et nid estimé. */
export function planKml(p: Plan, titre: string): string {
  const coords = p.points.map((q) => `${q.lon.toFixed(7)},${q.lat.toFixed(7)},${p.reglages.hauteurM}`).join(' ');
  const esc = (s: string) => s.replace(/[<>&]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' })[c]!);
  return `<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>${esc(titre)}</name>
<Placemark><name>Nid estimé</name><Point><coordinates>${p.centre.lon.toFixed(7)},${p.centre.lat.toFixed(7)},0</coordinates></Point></Placemark>
<Placemark><name>Plan de vol (${p.reglages.motif}, ${p.reglages.hauteurM} m)</name><LineString><altitudeMode>relativeToGround</altitudeMode><coordinates>${coords}</coordinates></LineString></Placemark>
</Document></kml>\n`;
}
