/** Plan de vol automatique autour d'un nid estimé : spirale (de l'extérieur vers le nid) ou quadrillage,
 *  exporté en mission Litchi (CSV) pour un vol par points de passage, et en trace KML.
 *  Sans dépendance au téléphone (testé). */

export type Motif = 'spirale' | 'quadrillage';
export type ReglagesPlan = { motif: Motif; rayonM: number; hauteurM: number; espacementM: number; vitesse: number };
export const PLAN_DEFAUT: ReglagesPlan = { motif: 'spirale', rayonM: 150, hauteurM: 40, espacementM: 50, vitesse: 6 };
/** Litchi accepte au plus 99 points de passage. */
export const MAX_POINTS = 99;
export const HAUTEUR_MAX = 120; // réglementation : 120 m au-dessus du sol

export type Point = { lat: number; lon: number };
export type Plan = { points: Point[]; longueurM: number; dureeMin: number; tronque: boolean; reglages: ReglagesPlan; centre: Point };

const M_LAT = 111320;
const versGeo = (c: Point, x: number, y: number): Point => ({ lat: c.lat + y / M_LAT, lon: c.lon + x / (M_LAT * Math.cos((c.lat * Math.PI) / 180)) });
const versXY = (c: Point, p: Point) => ({ x: (p.lon - c.lon) * M_LAT * Math.cos((c.lat * Math.PI) / 180), y: (p.lat - c.lat) * M_LAT });

/** Rayon conseillé : au moins 3 fois l'incertitude du nid estimé, entre 80 et 400 m. */
export const rayonConseille = (errM: number) => Math.round(Math.min(400, Math.max(80, 3 * errM)) / 10) * 10;

function spirale(r: ReglagesPlan): { x: number; y: number }[] {
  // spirale d'Archimède r = e.θ/2π, parcourue de l'extérieur vers le centre, un point tous les ~e/1,5 m
  const e = r.espacementM, thMax = (2 * Math.PI * r.rayonM) / e, pas = e / 1.5;
  const pts: { x: number; y: number }[] = [];
  let th = thMax;
  while (th > 0) {
    const rr = (e * th) / (2 * Math.PI);
    pts.push({ x: rr * Math.sin(th), y: rr * Math.cos(th) });
    th -= pas / Math.max(rr, pas); // pas constant le long de la courbe
  }
  pts.push({ x: 0, y: 0 });
  return pts;
}
function quadrillage(r: ReglagesPlan): { x: number; y: number }[] {
  // allers-retours est-ouest espacés de e, limités au cercle de rayon R
  const pts: { x: number; y: number }[] = [];
  let k = 0;
  for (let y = -r.rayonM + r.espacementM / 2; y <= r.rayonM; y += r.espacementM, k++) {
    const dx = Math.sqrt(Math.max(0, r.rayonM * r.rayonM - y * y));
    if (dx < 5) continue;
    const a = { x: -dx, y }, b = { x: dx, y };
    pts.push(...(k % 2 ? [b, a] : [a, b]));
  }
  return pts;
}

export function genererPlan(centre: Point, reglages: ReglagesPlan): Plan {
  const r = { ...reglages, rayonM: Math.max(20, reglages.rayonM), espacementM: Math.max(10, reglages.espacementM), hauteurM: Math.min(HAUTEUR_MAX, Math.max(10, reglages.hauteurM)), vitesse: Math.min(15, Math.max(1, reglages.vitesse)) };
  let xy = r.motif === 'spirale' ? spirale(r) : quadrillage(r);
  const tronque = xy.length > MAX_POINTS;
  if (tronque) { const k = Math.ceil(xy.length / MAX_POINTS); xy = xy.filter((_, i) => i % k === 0 || i === xy.length - 1).slice(-MAX_POINTS); }
  let L = 0;
  for (let i = 1; i < xy.length; i++) L += Math.hypot(xy[i].x - xy[i - 1].x, xy[i].y - xy[i - 1].y);
  return { points: xy.map((p) => versGeo(centre, p.x, p.y)), longueurM: Math.round(L), dureeMin: Math.round((L / r.vitesse / 60) * 10) / 10, tronque, reglages: r, centre };
}

/** Points en mètres autour du centre (pour l'aperçu). */
export const pointsXY = (p: Plan) => p.points.map((q) => versXY(p.centre, q));

/** Mission Litchi : hauteur au-dessus du décollage, vitesse par point, cap libre, nacelle sans action photo. */
export function litchiCsv(p: Plan): string {
  const tete = 'latitude,longitude,altitude(m),heading(deg),curvesize(m),rotationdir,gimbalmode,gimbalpitchangle,altitudemode,speed(m/s),poi_latitude,poi_longitude,poi_altitude(m),poi_altitudemode,photo_timeinterval,photo_distinterval';
  const l = p.points.map((q, i) => {
    const s = p.points[i + 1] ?? p.points[i - 1] ?? q;
    const cap = Math.round(((Math.atan2((s.lon - q.lon) * Math.cos((q.lat * Math.PI) / 180), s.lat - q.lat) * 180) / Math.PI + 360) % 360);
    return [q.lat.toFixed(7), q.lon.toFixed(7), p.reglages.hauteurM, i === p.points.length - 1 ? 0 : cap, 0.2, 0, 0, 0, 0, p.reglages.vitesse, 0, 0, 0, 0, -1, -1].join(',');
  });
  return [tete, ...l].join('\n') + '\n';
}
/** Trace KML (Google Earth, cartes) : chemin et nid estimé. */
export function planKml(p: Plan, titre: string): string {
  const coords = p.points.map((q) => `${q.lon.toFixed(7)},${q.lat.toFixed(7)},${p.reglages.hauteurM}`).join(' ');
  const esc = (s: string) => s.replace(/[<>&]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' })[c]!);
  return `<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>${esc(titre)}</name>
<Placemark><name>Nid estimé</name><Point><coordinates>${p.centre.lon.toFixed(7)},${p.centre.lat.toFixed(7)},0</coordinates></Point></Placemark>
<Placemark><name>Plan de vol (${p.reglages.motif}, ${p.reglages.hauteurM} m)</name><LineString><altitudeMode>relativeToGround</altitudeMode><coordinates>${coords}</coordinates></LineString></Placemark>
</Document></kml>\n`;
}
