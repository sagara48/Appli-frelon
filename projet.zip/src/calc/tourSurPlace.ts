/** Tour sur place en vol (mission « tour » du plan de vol) : à chaque station, le drone reste au même endroit et
 *  pivote par pas de 60° (0, 60 … 300°, 3 s chacun). Avec une antenne qui regarde de côté (nacelle inclinée vers
 *  l'avant), le niveau du tag passe par un maximum quand le nez du drone pointe vers le nid : on en tire un cap.
 *  Le drone ne transmet pas son cap : l'arrêt est découpé en 6 parts égales, dans l'ordre des caps de la mission.
 *  Deux stations ou plus donnent le nid par intersection des caps. Sans dépendance au téléphone (testé). */
import { distM } from './geo';
import type { PointVol } from './vol';
import { TOUR_CAPS } from './planVol';

export type Arret = { lat: number; lon: number; debut: number; fin: number };
export type CapStation = Arret & { cap: number; contrasteDb: number; niveaux: (number | null)[] };
export type ResultatTour = { stations: CapStation[]; nid: { lat: number; lon: number; errM: number } | null };

/** Arrêts du drone : au moins `dureeMin` ms à moins de 5 m du même point. */
export function arrets(points: PointVol[], dureeMin = (TOUR_CAPS.length - 1) * 3000): Arret[] {
  const r: Arret[] = [];
  let i = 0;
  while (i < points.length) {
    let j = i + 1, la = points[i].lat, lo = points[i].lon;
    while (j < points.length && distM(la, lo, points[j].lat, points[j].lon) < 5) {
      const n = j - i + 1; la += (points[j].lat - la) / n; lo += (points[j].lon - lo) / n; j++;
    }
    if (points[j - 1].t - points[i].t >= dureeMin) r.push({ lat: la, lon: lo, debut: points[i].t, fin: points[j - 1].t });
    i = j;
  }
  return r;
}

const med = (v: number[]) => { const s = [...v].sort((a, b) => a - b), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };

/** Cap du tag depuis un arrêt : niveau médian de chaque sixième de l'arrêt, moyenne des caps pondérée par la puissance.
 *  `decalage` = direction de l'antenne par rapport au nez du drone (0 = vers l'avant). */
export function capArret(points: PointVol[], tag: number, a: Arret, decalage = 0): CapStation | null {
  const N = TOUR_CAPS.length, T = (a.fin - a.debut) / N;
  const niveaux = TOUR_CAPS.map((_, k) => {
    const v = points.filter((p) => p.t >= a.debut + (k + 0.2) * T && p.t <= a.debut + (k + 0.8) * T).flatMap((p) => p.tags.filter(([id]) => id === tag).map(([, r]) => r));
    return v.length ? med(v) : null;
  });
  const ok = niveaux.filter((x): x is number => x !== null);
  if (ok.length < N - 1) return null;
  const mx = Math.max(...ok), mn = Math.min(...ok);
  let sx = 0, sy = 0;
  niveaux.forEach((r, k) => { if (r === null) return; const w = Math.pow(10, (r - mx) / 10), c = ((TOUR_CAPS[k] + decalage) * Math.PI) / 180; sx += w * Math.sin(c); sy += w * Math.cos(c); });
  return { ...a, cap: Math.round(((Math.atan2(sx, sy) * 180) / Math.PI + 360) % 360), contrasteDb: Math.round(mx - mn), niveaux };
}

/** Intersection au sens des moindres carrés des demi-droites (stations, caps) ; null si moins de 2 caps assez
 *  différents (30°) ou une intersection derrière une station. */
export function intersection(st: { lat: number; lon: number; cap: number }[]): { lat: number; lon: number; errM: number } | null {
  if (st.length < 2) return null;
  const ref = st[0], kx = 111320 * Math.cos((ref.lat * Math.PI) / 180), ky = 111320;
  const L = st.map((s) => ({ x: (s.lon - ref.lon) * kx, y: (s.lat - ref.lat) * ky, dx: Math.sin((s.cap * Math.PI) / 180), dy: Math.cos((s.cap * Math.PI) / 180) }));
  let ecart = 0;
  for (let i = 0; i < L.length; i++) for (let j = i + 1; j < L.length; j++) ecart = Math.max(ecart, Math.abs(Math.asin(Math.max(-1, Math.min(1, L[i].dx * L[j].dy - L[i].dy * L[j].dx)))));
  if (ecart < (30 * Math.PI) / 180) return null;
  let a = 0, b = 0, c = 0, bx = 0, by = 0;
  for (const l of L) { const nx = -l.dy, ny = l.dx, d = nx * l.x + ny * l.y; a += nx * nx; b += nx * ny; c += ny * ny; bx += nx * d; by += ny * d; }
  const det = a * c - b * b;
  if (Math.abs(det) < 1e-9) return null;
  const x = (c * bx - b * by) / det, y = (a * by - b * bx) / det;
  if (L.some((l) => (x - l.x) * l.dx + (y - l.y) * l.dy < 0)) return null; // le nid doit être devant chaque station
  const res = L.map((l) => Math.abs(-l.dy * (x - l.x) + l.dx * (y - l.y)));
  const errM = Math.round(10 + 2 * Math.sqrt(res.reduce((s, r) => s + r * r, 0) / res.length));
  return { lat: ref.lat + y / ky, lon: ref.lon + x / kx, errM };
}

export function analyserTour(points: PointVol[], tag: number, decalage = 0): ResultatTour {
  const stations = arrets(points).map((a) => capArret(points, tag, a, decalage)).filter((x): x is CapStation => !!x);
  const bons = stations.filter((s) => s.contrasteDb >= 4);
  return { stations, nid: intersection(bons) };
}
