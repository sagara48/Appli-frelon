/** Fiche de banc d'essai : première mise sous tension de chaque carte, dans l'ordre du guide de montage
 *  (chacune sert à tester la suivante). Données seules : l'écran Banc d'essai les affiche et coche ce que l'appli peut vérifier. */

/** Vérifications faites par l'appli elle-même (voir l'écran). */
export type Auto =
  | 'portatifConnecte' | 'portatifGps' | 'portatifTag' | 'portatifJournal'
  | 'toitConnecte' | 'toitVoies' | 'toitGps' | 'toitJournal' | 'toitVersion' | 'portatifVersion';

export type Mesure = { unite: string; min?: number; max?: number };
export type Etape = { id: string; titre: string; detail?: string; mesure?: Mesure; auto?: Auto; attention?: boolean };
export type Carte = { id: string; nom: string; intro: string; etapes: Etape[] };

const V3 = { unite: 'V', min: 3.2, max: 3.4 };
const ACCU = { unite: 'V', min: 3.0, max: 4.2 };

/** Contrôles communs avant la première mise sous tension. */
const avant = (p: string, ou: string): Etape[] => [
  { id: `${p}-visu`, titre: 'Contrôle visuel à la loupe', detail: 'Pas de pont d\'étain entre broches, pas de composant décalé ou manquant, connecteurs droits.' },
  { id: `${p}-cc`, titre: 'Pas de court-circuit entre 3V3 et GND', detail: `Carte hors tension, multimètre en continuité sur ${ou} : il ne doit pas biper.`, attention: true },
];

export const CARTES: Carte[] = [
  {
    id: 'chargeur', nom: 'Chargeur et gabarit',
    intro: 'En premier : il charge les tags et sert de banc pour les flasher.',
    etapes: [
      ...avant('ch', 'la barrette J3 (3V3 et GND)'),
      { id: 'ch-oled', titre: 'Enficher l\'écran OLED sur J2', detail: 'Dans le bon sens : GND, VCC, SCL, SDA.' },
      { id: 'ch-3v3', titre: 'Alimenter par l\'USB-C et mesurer le 3V3', detail: 'Sur J3, entre 3V3 et GND.', mesure: V3 },
      { id: 'ch-flash', titre: 'Flasher chargeur_v3.hex', detail: 'WCH-LinkE sur J3 dans l\'ordre 3V3, SWIO, GND ; WCH-LinkUtility, puce CH32V003, Program.' },
      { id: 'ch-ecran', titre: 'L\'écran affiche « CHARGEUR TAG V4 » puis les 6 places' },
      { id: 'ch-led', titre: 'Les 6 LED sont correctes à vide' },
      { id: 'ch-gabarit', titre: 'Gabarit de programmation : nappe 10 broches 1,27 mm sur J2', detail: 'Repère de la broche 1 du même côté sur la sonde et sur le gabarit.' },
    ],
  },
  {
    id: 'tags', nom: 'Tags',
    intro: 'Répéter pour chaque tag. Noter le numéro au feutre dès le flashage.',
    etapes: [
      { id: 'tg-visu', titre: 'Détacher les tags du panneau et les contrôler à la loupe' },
      { id: 'tg-ant', titre: 'Antenne de 29 mm soudée', detail: 'Si PCBWay ne l\'a pas posée. Gratter le vernis du fil émaillé avant de souder.' },
      { id: 'tg-flash', titre: 'Flasher tag_NNN.hex sur le gabarit', detail: 'Un fichier différent par tag (numéro inscrit dans la puce). Accepter « Recover » si la puce est protégée.' },
      { id: 'tg-charge', titre: 'Charge sur le chargeur', detail: 'La place passe en charge puis indique la fin de charge.' },
      { id: 'tg-banc', titre: 'Le portatif en mode BANC affiche le numéro et « ÉMISSION OK »', detail: 'À faire quand le portatif est prêt.', auto: 'portatifTag' },
      { id: 'tg-nb', titre: 'Nombre de tags validés', mesure: { unite: 'tags', min: 1 } },
    ],
  },
  {
    id: 'portatif', nom: 'Récepteur portatif',
    intro: 'Accu 18650, écran 2", module radio E73.',
    etapes: [
      ...avant('pt', 'la barrette J3'),
      { id: 'pt-accu', titre: 'Tension de l\'accu 18650 avant de le mettre', detail: 'Et sens du + dans le support.', mesure: ACCU, attention: true },
      { id: 'pt-ecran', titre: 'Enficher l\'écran 2" et brancher le câble U.FL du E73 vers J7', detail: 'Toujours brancher l\'antenne avant d\'émettre.' },
      { id: 'pt-3v3', titre: 'Mettre sous tension et mesurer le 3V3', detail: 'Sur J3, entre 3V3 et GND.', mesure: V3 },
      { id: 'pt-flash', titre: 'Flasher portatif_premier_flashage_merged.hex', detail: 'J-Link sur J3 (GND, 3V3, SWDIO, SWCLK), Programmer, Erase & write. La LED clignote au redémarrage.' },
      { id: 'pt-affiche', titre: 'L\'écran s\'allume et affiche le niveau' },
      { id: 'pt-ble', titre: 'L\'appli se connecte à RX-Frelons', detail: 'Onglet Portatif → Connecter.', auto: 'portatifConnecte' },
      { id: 'pt-version', titre: 'Firmware compatible avec l\'appli', detail: 'Menu → Appareils : version affichée en vert ou orange.', auto: 'portatifVersion' },
      { id: 'pt-journal', titre: 'Aucune ligne non comprise dans le journal', detail: 'Menu → Journal de mise au point, filtre Portatif.', auto: 'portatifJournal' },
      { id: 'pt-gps', titre: 'Position GPS obtenue', detail: 'Dehors, ciel dégagé, quelques minutes la première fois.', auto: 'portatifGps' },
      { id: 'pt-maj', titre: 'Mise à jour par Bluetooth essayée une fois', detail: 'Menu → Mises à jour, avec le paquet du portatif.' },
    ],
  },
  {
    id: 'ecran', nom: 'Écran de la voiture et son dos',
    intro: 'Écran Waveshare 7", dos avec 2 accus et radio 868 MHz.',
    etapes: [
      { id: 'ec-flash', titre: 'Flasher l\'écran Waveshare', detail: 'ESP Tool dans Chrome, Erase Flash, ecran_frelons_complet.bin à l\'adresse 0x0, puis RESET.' },
      { id: 'ec-tactile', titre: 'L\'écran démarre et le tactile répond' },
      { id: 'ec-sd', titre: 'Carte micro-SD testée (H2testw) et formatée en FAT32' },
      ...avant('ds', 'les pastilles SWD du dos'),
      { id: 'ds-accu1', titre: 'Tension du 1er accu 18650', mesure: ACCU, attention: true },
      { id: 'ds-accu2', titre: 'Tension du 2e accu 18650', detail: 'Même modèle et même charge que le 1er : moins de 0,1 V d\'écart.', mesure: ACCU, attention: true },
      { id: 'ds-ant', titre: 'Antennes 868 MHz et 2,4 GHz branchées avant la mise sous tension', detail: 'Un module radio qui émet sans antenne peut être abîmé.', attention: true },
      { id: 'ds-flash', titre: 'Flasher sol_premier_flashage_merged.hex sur le dos', detail: 'J-Link sur les pastilles SWD sous la carte.' },
      { id: 'ds-usb', titre: 'Câble USB-C de J2 vers l\'écran : l\'écran montre la pile du dos' },
    ],
  },
  {
    id: 'toit', nom: 'Récepteur de toit',
    intro: 'Carte chef, 4 cartes voie, 4 panneaux et l\'antenne omni.',
    etapes: [
      { id: 'tt-cav', titre: 'Cavaliers d\'adresse des voies sur J5', detail: 'Avant : aucun. Droite : ID0. Arrière : ID1. Gauche : ID0 et ID1.' },
      ...avant('tt', 'J2 du chef et J4 de chaque voie'),
      { id: 'tt-accu', titre: 'Tension de l\'accu 18650 du chef', mesure: ACCU, attention: true },
      { id: 'tt-ant', titre: 'Les 4 panneaux et l\'antenne omni branchés avant la mise sous tension', attention: true },
      { id: 'tt-3v3', titre: 'Mettre sous tension et mesurer le 3V3 du chef', detail: 'Sur J2.', mesure: V3 },
      { id: 'tt-flash', titre: 'Flasher le chef (J2) et les 4 voies (J4)', detail: 'chef_premier_flashage_merged.hex, et voie_premier_flashage_merged.hex pour les 4.' },
      { id: 'tt-jst', titre: 'Câbles JST 6 broches chef → voies, broche 1 à broche 1' },
      { id: 'tt-ble', titre: 'L\'appli se connecte à TOIT-Frelons', detail: 'Menu → Récepteur de toit → Connecter.', auto: 'toitConnecte' },
      { id: 'tt-voies', titre: 'Les 4 voies répondent', auto: 'toitVoies' },
      { id: 'tt-version', titre: 'Firmwares du chef et des voies compatibles avec l\'appli', detail: 'Menu → Appareils : version affichée en vert ou orange.', auto: 'toitVersion' },
      { id: 'tt-journal', titre: 'Aucune ligne non comprise dans le journal', detail: 'Filtre Toit.', auto: 'toitJournal' },
      { id: 'tt-gps', titre: 'GPS : au moins 6 satellites', detail: 'Dehors, ciel dégagé.', auto: 'toitGps' },
      { id: 'tt-joint', titre: 'Caisson fermé : joint en place, presse-étoupe serré' },
      { id: 'tt-etal', titre: 'Étalonnage fait', detail: 'Menu → Étalonnage du toit.' },
    ],
  },
  {
    id: 'nacelle', nom: 'Nacelle du drone',
    intro: 'LiPo 500 mAh, GPS, radio 868 MHz.',
    etapes: [
      ...avant('nc', 'les pastilles SWD'),
      { id: 'nc-lipo', titre: 'Polarité et tension de la LiPo avant de la souder', detail: 'Rouge sur +. La petite carte de protection doit être présente.', mesure: ACCU, attention: true },
      { id: 'nc-ant', titre: 'Antennes GPS et 868 MHz, câble IPEX du E73 vers J1, branchés avant la mise sous tension', attention: true },
      { id: 'nc-flash', titre: 'Flasher nacelle_premier_flashage_merged.hex', detail: 'J-Link sur les pastilles SWD sous la carte.' },
      { id: 'nc-poids', titre: 'Peser la nacelle complète', detail: 'Pour vérifier la charge du Phantom.', mesure: { unite: 'g' } },
      { id: 'nc-sol', titre: 'Au sol, tag posé à côté : le tag apparaît sur l\'écran de la voiture' },
      { id: 'nc-vol', titre: 'Premier vol à vue, à vide puis avec la nacelle', detail: 'Vérifier la tenue en vol stationnaire et l\'autonomie restante.' },
    ],
  },
];

/** État d'une étape : cochée (à la main ou par l'appli) et valeur mesurée. */
export type Coche = { ok: boolean; t: number; val?: string; auto?: boolean };
export type EtatBanc = Record<string, Coche>;

/** Lecture d'une valeur tapée (virgule acceptée). */
export const lireNombre = (txt: string): number | null => {
  const v = Number(txt.replace(',', '.').trim());
  return txt.trim() && Number.isFinite(v) ? v : null;
};

/** La valeur est-elle dans la plage attendue ? null si rien à juger. */
export function mesureOk(m: Mesure | undefined, txt: string | undefined): boolean | null {
  if (!m || !txt) return null;
  const v = lireNombre(txt);
  if (v === null) return false;
  if (m.min !== undefined && v < m.min) return false;
  if (m.max !== undefined && v > m.max) return false;
  return m.min !== undefined || m.max !== undefined ? true : null;
}

/** Avancement d'une carte : étapes faites / total. */
export const avancement = (c: Carte, e: EtatBanc) => ({ fait: c.etapes.filter((x) => e[x.id]?.ok).length, total: c.etapes.length });

/** Texte de la fiche, pour l'export. */
export function texteBanc(e: EtatBanc, notes: Record<string, string>) {
  const lignes: string[] = ['Banc d\'essai – système frelons', ''];
  for (const c of CARTES) {
    const a = avancement(c, e);
    lignes.push(`== ${c.nom} (${a.fait}/${a.total})`);
    for (const x of c.etapes) {
      const k = e[x.id];
      const mes = x.mesure && k?.val ? ` : ${k.val} ${x.mesure.unite}${mesureOk(x.mesure, k.val) === false ? ' (HORS PLAGE)' : ''}` : '';
      lignes.push(`[${k?.ok ? 'x' : ' '}] ${x.titre}${mes}${k?.ok ? `  (${new Date(k.t).toLocaleDateString('fr-FR')}${k.auto ? ', vérifié par l\'appli' : ''})` : ''}`);
    }
    if (notes[c.id]?.trim()) lignes.push(`Notes : ${notes[c.id].trim()}`);
    lignes.push('');
  }
  return lignes.join('\n');
}
