/** Pression des frelons devant les ruches : un relevé par jour et par rucher (frelons en vol stationnaire devant les ruches),
 *  en 4 niveaux faciles à estimer d'un coup d'œil. Sans dépendance au téléphone (testé). */

/** 0 : aucun · 1 : 1 à 5 · 2 : 5 à 20 · 3 : plus de 20 */
export type Niveau = 0 | 1 | 2 | 3;
export const NIVEAUX: [Niveau, string][] = [[0, 'Aucun'], [1, '1 à 5'], [2, '5 à 20'], [3, 'Plus de 20']];
export const libelleNiveau = (n: Niveau) => NIVEAUX[n]?.[1] ?? '';
export type ReleveP = { t: number; n: Niveau };

const JOUR = 86400000;
const memeJour = (a: number, b: number) => new Date(a).toDateString() === new Date(b).toDateString();

export function lirePressions(json: string | null | undefined): ReleveP[] {
  try {
    const l = JSON.parse(json || '[]') as ReleveP[];
    return Array.isArray(l) ? l.filter((x) => typeof x?.t === 'number' && [0, 1, 2, 3].includes(x.n)).sort((a, b) => a.t - b.t) : [];
  } catch { return []; }
}
/** Ajoute un relevé ; un relevé du même jour est remplacé (on corrige d'un appui). */
export function ajouterReleve(l: ReleveP[], t: number, n: Niveau): ReleveP[] {
  return [...l.filter((x) => !memeJour(x.t, t)), { t, n }].sort((a, b) => a.t - b.t);
}
/** Relevé du jour, s'il existe. */
export const releveDuJour = (l: ReleveP[], maintenant: number) => l.find((x) => memeJour(x.t, maintenant)) ?? null;

/** Moyenne des relevés sur une période [debut, fin[ ; null sans relevé. */
function moyenne(l: ReleveP[], debut: number, fin: number): number | null {
  const x = l.filter((r) => r.t >= debut && r.t < fin);
  return x.length ? x.reduce((a, r) => a + r.n, 0) / x.length : null;
}
/** Tendance : 7 derniers jours comparés aux 7 précédents. */
export function tendance(l: ReleveP[], maintenant: number): 'hausse' | 'baisse' | 'stable' | null {
  const a = moyenne(l, maintenant - 7 * JOUR, maintenant + 1), b = moyenne(l, maintenant - 14 * JOUR, maintenant - 7 * JOUR);
  if (a === null || b === null) return null;
  return a - b >= 0.5 ? 'hausse' : b - a >= 0.5 ? 'baisse' : 'stable';
}
/** Niveau actuel : moyenne des 7 derniers jours, arrondie. */
export function niveauActuel(l: ReleveP[], maintenant: number): Niveau | null {
  const a = moyenne(l, maintenant - 7 * JOUR, maintenant + 1);
  return a === null ? null : (Math.round(a) as Niveau);
}
/** Relevés de la saison (année civile) de la date donnée, pour le graphique. */
export const saison = (l: ReleveP[], an: number) => l.filter((x) => new Date(x.t).getFullYear() === an);
