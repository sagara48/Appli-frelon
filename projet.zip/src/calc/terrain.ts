/** Apprendre avec les nids trouvés : 1) le terrain (affaiblissement du signal avec la distance) d'après les points de la
 *  carte du signal à pied ; 2) l'erreur d'orientation des antennes du toit d'après les relèvements pris en roulant.
 *  Sans dépendance au téléphone (testé). */
import { capDeg, distM } from './geo';
import type { Pas } from './traceAPied';
import type { Ligne } from './releves';

const med = (v: number[]) => { const s = [...v].sort((a, b) => a - b), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };
const wrap = (a: number) => ((a + 540) % 360) - 180;

export type Terrain = { n: number; p1m: number; points: number; r2: number };
/** Niveau = P1m − 10·n·log10(d) ajusté sur les points de la carte à pied (distance au nid trouvé). Il faut au moins 15 points
 *  entre 5 et 400 m, avec des distances assez variées (la plus grande au moins 3 fois la plus petite). n borné à 1,6-4,5. */
export function exposantTerrain(pas: Pas[], nid: { lat: number; lon: number }): Terrain | null {
  const p = pas.map((x) => ({ L: Math.log10(distM(x.lat, x.lon, nid.lat, nid.lon)), r: x.rssi })).filter((x) => x.L >= Math.log10(5) && x.L <= Math.log10(400));
  if (p.length < 15) return null;
  const Ls = p.map((x) => x.L);
  if (Math.max(...Ls) - Math.min(...Ls) < Math.log10(3)) return null;
  const N = p.length, sl = p.reduce((a, x) => a + x.L, 0), sr = p.reduce((a, x) => a + x.r, 0);
  const sll = p.reduce((a, x) => a + x.L * x.L, 0), slr = p.reduce((a, x) => a + x.L * x.r, 0);
  const a = (N * slr - sl * sr) / (N * sll - sl * sl), b = (sr - a * sl) / N;
  const n = Math.max(1.6, Math.min(4.5, -a / 10));
  const moy = sr / N, sst = p.reduce((s, x) => s + (x.r - moy) ** 2, 0), sse = p.reduce((s, x) => s + (x.r - (b + a * x.L)) ** 2, 0);
  return { n: Math.round(n * 100) / 100, p1m: Math.round(b), points: N, r2: sst > 0 ? Math.round((1 - sse / sst) * 100) / 100 : 0 };
}
/** Exposant à utiliser : médiane des derniers nids (au plus 5), seulement les ajustements assez nets (r² ≥ 0,3). */
export function exposantRetenu(l: Terrain[]): number | null {
  const ok = l.filter((t) => t.r2 >= 0.3).slice(-5).map((t) => t.n);
  return ok.length ? Math.round(med(ok) * 10) / 10 : null;
}

export type Recalage = { ecart: number; n: number; dispersion: number };
/** Écart des relèvements du toit (pris entre 40 m et 1 km du nid, qualité ≥ 50) par rapport à la vraie direction du nid :
 *  médiane (positif = les relèvements tournent trop vers la droite). Il faut au moins 8 relèvements. */
export function ecartToit(lignes: Ligne[], nid: { lat: number; lon: number }): Recalage | null {
  const e = lignes.filter((l) => !l.ecartee && l.q >= 50 && l.absDeg >= 0).filter((l) => { const d = distM(l.lat, l.lon, nid.lat, nid.lon); return d >= 40 && d <= 1000; })
    .map((l) => wrap(l.absDeg - capDeg(l.lat, l.lon, nid.lat, nid.lon)));
  if (e.length < 8) return null;
  const m = med(e);
  return { ecart: Math.round(m * 10) / 10, n: e.length, dispersion: Math.round(med(e.map((x) => Math.abs(x - m))) * 10) / 10 };
}
/** Correction proposée : médiane pondérée des nids (au moins 2 nids ou 30 relèvements), si l'écart dépasse 3°.
 *  Renvoie l'angle à envoyer au toit (commande rot = −écart). */
export function correctionToit(l: Recalage[]): { rot: number; nids: number; releves: number; ecart: number } | null {
  const total = l.reduce((a, r) => a + r.n, 0);
  if (!l.length || (l.length < 2 && total < 30)) return null;
  const tous = l.flatMap((r) => new Array(Math.min(r.n, 40)).fill(r.ecart) as number[]);
  const e = med(tous);
  if (Math.abs(e) < 3) return null;
  return { rot: Math.round(-e), nids: l.length, releves: total, ecart: Math.round(e * 10) / 10 };
}

/* ---------- réglages appris sur les sorties (nids trouvés) ---------- */
export type VolAppat = { distM: number; durees: number[] };
/** Vitesse de vol des frelons (m/s) d'après les allers-retours à l'appât des tags dont le nid a été trouvé :
 *  distance réelle appât → nid = v · (T − p) / 2 sur le trajet le plus rapide (même modèle que le chrono). Il faut
 *  au moins 2 trajets par appât ; médiane sur les appâts, bornée à 1,5 - 7 m/s. */
export function vitesseApprise(vols: VolAppat[], auNidS: number): number | null {
  const v = vols.filter((x) => x.durees.length >= 2 && x.distM >= 50).map((x) => {
    const t = Math.min(...x.durees) - auNidS;
    return t > 10 ? (2 * x.distM) / t : NaN;
  }).filter((x) => Number.isFinite(x) && x > 0.5 && x < 15);
  if (!v.length) return null;
  return Math.round(Math.min(7, Math.max(1.5, med(v))) * 10) / 10;
}
export type Precision = { reelM: number; afficheM: number };
/** Écart réel des estimations au nid trouvé, rapporté à l'incertitude affichée : > 1 = estimations trop optimistes.
 *  Il faut au moins 3 nids ; médiane bornée à 0,7 - 3. */
export function facteurIncertitude(p: Precision[]): number | null {
  const r = p.filter((x) => x.afficheM > 0 && Number.isFinite(x.reelM)).map((x) => x.reelM / x.afficheM);
  if (r.length < 3) return null;
  return Math.round(Math.min(3, Math.max(0.7, med(r))) * 10) / 10;
}
