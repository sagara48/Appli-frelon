/** Recette des cartes à la réception : vérifications automatiques à partir de ce que les appareils envoient.
 *  Sans dépendance au téléphone (testé). */
import { decoderEtat } from './activite';

export type Verif = { nom: string; ok: boolean | null; detail: string }; // null = pas encore testé

/** Moyenne en puissance (dB) de chaque voie sur plusieurs trames, −128 = jamais entendue. */
export function moyennesVoies(trames: number[][], nv = 4): number[] {
  return Array.from({ length: nv }, (_, k) => {
    const v = trames.map((r) => r[k]).filter((x) => x !== undefined && x > -128);
    if (!v.length) return -128;
    return Math.round(10 * Math.log10(v.reduce((a, x) => a + 10 ** (x / 10), 0) / v.length) * 10) / 10;
  });
}
/** Tag posé dans la direction d'une voie (0 avant, 1 droite, 2 arrière, 3 gauche) : cette voie doit être la plus forte,
 *  d'au moins 3 dB. Sinon : câbles ou antennes inversés, voie muette, ou reflet. */
export function verdictDirection(attendue: number, m: number[], noms: string[]): Verif {
  const tri = m.map((v, k) => ({ v, k })).sort((a, b) => b.v - a.v);
  const nom = `Tag ${noms[attendue].toLowerCase()}`;
  if (tri[0].v <= -128) return { nom, ok: false, detail: 'aucune voie ne reçoit le tag' };
  const muettes = m.map((v, k) => (v <= -128 ? noms[k] : '')).filter(Boolean);
  if (tri[0].k !== attendue) return { nom, ok: false, detail: `la voie ${noms[tri[0].k]} reçoit plus fort (${tri[0].v} dBm) que la voie ${noms[attendue]} (${m[attendue]} dBm) : câble ou panneau inversé ?` };
  const ecart = Math.round((tri[0].v - tri[1].v) * 10) / 10;
  if (ecart < 3) return { nom, ok: false, detail: `voie ${noms[attendue]} la plus forte mais de ${ecart} dB seulement (reflet ? panneau mal orienté ?)` };
  return { nom, ok: true, detail: `voie ${noms[attendue]} ${m[attendue]} dBm, ${ecart} dB devant la suivante${muettes.length ? ` (muettes : ${muettes.join(', ')})` : ''}` };
}

export type InfosTag = { id: number; entendu: boolean; pile: number | null; etat: number | null; noirVu: boolean; lumiereVu: boolean; p1m: number | null };
/** Contrôles d'un tag : radio (entendu), pile, température, capteur de lumière (le cacher puis le découvrir), antenne
 *  (niveau à 1 m comparé aux autres tags étalonnés : 6 dB de moins = antenne ou soudure à revoir). */
export function verifsTag(t: InfosTag, medianeP1m: number | null): Verif[] {
  const d = decoderEtat(t.etat);
  return [
    { nom: 'Radio', ok: t.entendu, detail: t.entendu ? 'entendu (quartz et radio bons)' : 'pas entendu : pile vide, quartz, ou soudure de la puce' },
    { nom: 'Pile', ok: t.pile === null ? null : t.pile >= 20, detail: t.pile === null ? 'pile inconnue (passer près du toit)' : `${t.pile} %${t.pile < 20 ? ' : à recharger avant de juger' : ''}` },
    { nom: 'Température', ok: d?.tempC == null ? null : d.tempC >= -5 && d.tempC <= 45, detail: d?.tempC == null ? 'pas encore reçue' : `${d.tempC} °C` },
    { nom: 'Capteur de lumière', ok: t.noirVu && t.lumiereVu ? true : null, detail: t.noirVu && t.lumiereVu ? 'noir et lumière vus' : `cacher le tag dans la main puis le découvrir (${t.noirVu ? 'noir vu' : 'noir pas encore vu'}, ${t.lumiereVu ? 'lumière vue' : 'lumière pas encore vue'})` },
    { nom: 'Antenne', ok: t.p1m === null || medianeP1m === null ? null : t.p1m >= medianeP1m - 6,
      detail: t.p1m === null ? 'à étalonner (Mes tags → Étalonner, tag à 1 m)' : medianeP1m === null ? `${t.p1m} dBm à 1 m` : `${t.p1m} dBm à 1 m (médiane des tags ${medianeP1m})${t.p1m < medianeP1m - 6 ? ' : antenne ou soudure à revoir' : ''}` },
  ];
}
export const mediane = (v: number[]) => { if (!v.length) return null; const s = [...v].sort((a, b) => a - b), m = s.length >> 1; return s.length % 2 ? s[m] : Math.round((s[m - 1] + s[m]) / 2); };

/** Rapport texte de la recette (à garder ou à m'envoyer). */
export function rapportRecette(sections: { titre: string; verifs: Verif[] }[], date: number): string {
  const l = [`Recette des cartes — ${new Date(date).toLocaleString('fr-FR')}`, ''];
  for (const s of sections) {
    l.push(s.titre);
    for (const v of s.verifs) l.push(`  [${v.ok === null ? ' ' : v.ok ? 'OK' : 'NON'}] ${v.nom} : ${v.detail}`);
    l.push('');
  }
  return l.join('\n');
}
