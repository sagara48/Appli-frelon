/** Vols du drone : le dos de l'écran (« SOL-Frelons ») relaie les trames LoRa de la nacelle au téléphone.
 *  Ligne D = trame normale, d = trame rattrapée après une coupure (plus ancienne).
 *  D,seq,lat,lon,alt_m,fix(bit0)|balise(bit1),sats,batt,rssi_lora,snr,n,id:rssi:cnt;...
 *  Sans dépendance au téléphone (testé). */

export type TrameD = { rattrapee: boolean; seq: number; lat: number; lon: number; alt: number; fix: boolean; balise: boolean; sats: number; batt: number; tags: [number, number][] };
export function lireLigneD(l: string): TrameD | null {
  const f = l.trim().split(',');
  if ((f[0] !== 'D' && f[0] !== 'd') || f.length < 11) return null;
  const fx = Number(f[5]) || 0, n = Number(f[10]) || 0;
  const tags: [number, number][] = [];
  for (const x of (f[11] ?? '').split(';').slice(0, n)) {
    const [id, r] = x.split(':').map(Number);
    if (Number.isFinite(id) && Number.isFinite(r)) tags.push([id, r]);
  }
  return { rattrapee: f[0] === 'd', seq: Number(f[1]) || 0, lat: Number(f[2]), lon: Number(f[3]), alt: Number(f[4]), fix: (fx & 1) !== 0, balise: (fx & 2) !== 0,
    sats: Number(f[6]) || 0, batt: Number(f[7]) || 0, tags };
}

/** Un point de vol : heure, position, hauteur au-dessus du décollage, niveaux des tags entendus. */
export type PointVol = { t: number; lat: number; lon: number; h: number; tags: [number, number][] };
export type Vol = { id: string; debut: number; fin: number; sol: number; points: PointVol[]; rattrapees: number };
export const MAX_POINTS_VOL = 4000;
/** Silence au-delà duquel une nouvelle trame commence un autre vol. */
export const FIN_VOL_MS = 120000;

export const volVide = (t: number, alt: number): Vol => ({ id: `${t.toString(36)}`, debut: t, fin: t, sol: alt, points: [], rattrapees: 0 });

/** Ajoute une trame (avec GPS, hors balise d'appât) ; `t` = heure de la mesure. Renvoie un nouveau vol. */
export function ajouterTrame(v: Vol, tr: TrameD, t: number): Vol {
  if (!tr.fix || tr.balise || !Number.isFinite(tr.lat) || (tr.lat === 0 && tr.lon === 0)) return v;
  const sol = Math.min(v.sol, tr.alt);
  const p: PointVol = { t, lat: tr.lat, lon: tr.lon, h: Math.round((tr.alt - sol) * 10) / 10, tags: tr.tags };
  let points: PointVol[];
  if (tr.rattrapee) { // à sa place dans le temps
    const i = v.points.findIndex((x) => x.t > t);
    points = i < 0 ? [...v.points, p] : [...v.points.slice(0, i), p, ...v.points.slice(i)];
  } else points = [...v.points, p];
  if (points.length > MAX_POINTS_VOL) points = points.filter((_, i) => i % 2 === 0 || points[i].tags.length > 0); // on éclaircit les points sans tag
  return { ...v, sol, fin: Math.max(v.fin, t), points, rattrapees: v.rattrapees + (tr.rattrapee ? 1 : 0) };
}

/** Heure d'une trame d'après son numéro (une trame toutes les 500 ms), connaissant le dernier numéro reçu et son heure. */
export function heureDeSeq(seq: number, derSeq: number, derT: number): number {
  const d = (derSeq - seq) & 0xffff;
  return d < 0x8000 ? derT - d * 500 : derT;
}

export type ResumeTag = { id: number; max: number; lat: number; lon: number; h: number; n: number };
export type ResumeVol = { dureeMin: number; hMax: number; tags: ResumeTag[] };
export function resumeVol(v: Vol): ResumeVol {
  const m = new Map<number, ResumeTag>();
  let hMax = 0;
  for (const p of v.points) {
    hMax = Math.max(hMax, p.h);
    for (const [id, r] of p.tags) {
      const o = m.get(id);
      if (!o) m.set(id, { id, max: r, lat: p.lat, lon: p.lon, h: p.h, n: 1 });
      else { o.n++; if (r > o.max) Object.assign(o, { max: r, lat: p.lat, lon: p.lon, h: p.h }); }
    }
  }
  return { dureeMin: Math.round((v.fin - v.debut) / 60000), hMax: Math.round(hMax), tags: [...m.values()].sort((a, b) => b.max - a.max) };
}

/** Niveaux d'un tag au fil du vol (pour la carte). */
export const mesuresTag = (v: Vol, tag: number) => v.points.flatMap((p) => p.tags.filter(([id]) => id === tag).map(([, r]) => ({ lat: p.lat, lon: p.lon, h: p.h, rssi: r })));

const iso = (t: number) => new Date(t).toISOString();
/** Trace GPX (hauteur au-dessus du décollage, niveau du tag le plus fort de chaque point dans <desc>). */
export function volGpx(v: Vol): string {
  const pts = v.points.map((p) => {
    const best = p.tags.reduce<[number, number] | null>((b, x) => (!b || x[1] > b[1] ? x : b), null);
    return `   <trkpt lat="${p.lat.toFixed(7)}" lon="${p.lon.toFixed(7)}"><ele>${p.h.toFixed(1)}</ele><time>${iso(p.t)}</time>${best ? `<desc>tag ${best[0]} ${best[1]} dBm</desc>` : ''}</trkpt>`;
  }).join('\n');
  return `<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="Appli Frelons" xmlns="http://www.topografix.com/GPX/1/1">\n <trk><name>Vol drone ${new Date(v.debut).toLocaleString('fr-FR')}</name><trkseg>\n${pts}\n </trkseg></trk>\n</gpx>\n`;
}
/** Une ligne par mesure de tag : heure, position, hauteur, tag, niveau. */
export function volCsv(v: Vol): string {
  const l = ['heure;latitude;longitude;hauteur_m;tag;niveau_dBm'];
  for (const p of v.points) {
    if (!p.tags.length) l.push(`${iso(p.t)};${p.lat.toFixed(7)};${p.lon.toFixed(7)};${p.h};;`);
    for (const [id, r] of p.tags) l.push(`${iso(p.t)};${p.lat.toFixed(7)};${p.lon.toFixed(7)};${p.h};${id};${r}`);
  }
  return l.join('\n') + '\n';
}

/* ---------- nid en 3D : ajustement du modèle de signal sur tout le vol ---------- */
export type Nid3D = { lat: number; lon: number; hauteurM: number; hauteurMin: number; hauteurMax: number; errM: number; n: number; exposant: number };
/** Niveau = P0 − 10·n·log10(d3D), d3D = distance du drone au nid (avec la hauteur). Pour chaque position (x, y, hauteur)
 *  candidate, P0 et n se calculent par moindres carrés ; on garde la position qui explique le mieux les niveaux.
 *  Incertitude : zone où l'écart reste dans ce que le bruit explique (Δχ² < 6, environ 95 %). Il faut au moins 20 mesures,
 *  des hauteurs de vol variées aident à trouver la hauteur du nid. */
export function nid3D(v: Vol, tag: number): Nid3D | null {
  const tout = mesuresTag(v, tag);
  if (tout.length < 20) return null;
  const pas = Math.ceil(tout.length / 300), m = tout.filter((_, i) => i % pas === 0); // 300 mesures suffisent (temps de calcul)
  const c = m.reduce((b, p) => (p.rssi > b.rssi ? p : b), m[0]);
  const kx = 111320 * Math.cos((c.lat * Math.PI) / 180), ky = 111320;
  const pts = m.map((p) => ({ x: (p.lon - c.lon) * kx, y: (p.lat - c.lat) * ky, h: p.h, r: p.rssi }));
  const N = pts.length;
  const ajuste = (x: number, y: number, z: number) => {
    let sl = 0, sr = 0, sll = 0, slr = 0;
    const L = pts.map((p) => Math.log10(Math.max(1, Math.hypot(p.x - x, p.y - y, p.h - z))));
    for (let i = 0; i < N; i++) { sl += L[i]; sr += pts[i].r; sll += L[i] * L[i]; slr += L[i] * pts[i].r; }
    const det = N * sll - sl * sl;
    // pente = −10 n : en l'air au-dessus des arbres, propagation proche de l'espace libre ; n tenu près de 2,2
    // (sinon la hauteur du nid et l'exposant se compensent et la hauteur devient floue)
    let a = det > 1e-9 ? (N * slr - sl * sr) / det : -22;
    a = Math.max(-26, Math.min(-19, a));
    const b = (sr - a * sl) / N;
    let sse = 0; for (let i = 0; i < N; i++) { const e = pts[i].r - (b + a * L[i]); sse += e * e; }
    return { sse, n: -a / 10 };
  };
  type Cand = { x: number; y: number; z: number; sse: number; n: number };
  let best: Cand = { x: 0, y: 0, z: 0, sse: Infinity, n: 2.5 };
  const grille: Cand[] = [];
  for (let x = -200; x <= 200; x += 10) for (let y = -200; y <= 200; y += 10) for (let z = 0; z <= 40; z += 5) {
    const r = ajuste(x, y, z); const k = { x, y, z, ...r };
    grille.push(k); if (r.sse < best.sse) best = k;
  }
  // affinage autour du meilleur point
  for (let x = best.x - 10; x <= best.x + 10; x += 2) for (let y = best.y - 10; y <= best.y + 10; y += 2) for (let z = Math.max(0, best.z - 5); z <= Math.min(45, best.z + 5); z += 1) {
    const r = ajuste(x, y, z); if (r.sse < best.sse) best = { x, y, z, ...r };
  }
  const s2 = best.sse / Math.max(1, N - 4);
  const zone = grille.filter((g) => (g.sse - best.sse) / s2 < 6);
  const errM = Math.max(5, ...zone.map((g) => Math.hypot(g.x - best.x, g.y - best.y)));
  const zs = zone.map((g) => g.z);
  return {
    lat: c.lat + best.y / ky, lon: c.lon + best.x / kx, hauteurM: best.z,
    hauteurMin: zs.length ? Math.min(...zs, best.z) : best.z, hauteurMax: zs.length ? Math.max(...zs, best.z) : best.z,
    errM: Math.round(errM), n: N, exposant: Math.round(best.n * 10) / 10,
  };
}
