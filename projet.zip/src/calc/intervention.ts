/** Interventions sur un nid (destruction, retraitement, contrôle…) et registre des traitements biocides.
 *  Sur le modèle du compte rendu d'intervention des FREDON : type d'intervention, hauteur (classe < 10 m, 10-25 m, > 25 m),
 *  produit et quantité, opérateur et n° Certibiocide, client présent ou absent et sa signature, suites de l'intervention.
 *  Sans dépendance au téléphone (testé). Les interventions sont rangées dans la fiche du nid (colonne JSON partagée). */

export type TypeInter = 'destruction' | 'retraitement' | 'controle' | 'deplacement' | 'autre_espece';
export const TYPES_INTER: [TypeInter, string][] = [
  ['destruction', 'Destruction'], ['retraitement', 'Retraitement'], ['controle', 'Contrôle'],
  ['deplacement', 'Déplacement sans intervention'], ['autre_espece', 'Autre espèce'],
];
export const libelleType = (t: TypeInter) => TYPES_INTER.find((x) => x[0] === t)?.[1] ?? t;
/** Les types qui emploient (ou peuvent employer) un produit biocide : ils vont au registre. */
export const TRAITEMENTS: TypeInter[] = ['destruction', 'retraitement', 'autre_espece'];

export const METHODES = ['Perche télescopique', 'Drone', 'Lance', 'Retrait mécanique', 'Congélation / étouffement', 'Autre'];

export type Produit = { nom: string; substance: string; amm: string };
export const PRODUITS_DEFAUT: Produit[] = [{ nom: 'Permas-D', substance: 'perméthrine 0,75 %', amm: '' }];

export type Client = { nom: string; adresse: string; commune: string; tel: string };
export type Intervention = {
  id: string; t: number; type: TypeInter;
  methode: string; produit: string; substance: string; amm: string; lot: string; quantiteG: number | null;
  hauteurM: number | null; diametreCm: number | null; nidRetire: boolean;
  /** contrôle : le nid est-il mort ? */
  resultat: '' | 'mort' | 'actif';
  operateur: string; certibiocide: string;
  client: Client; present: boolean; signature: string;
  meteo: string; note: string; photosAvant: string[]; photosApres: string[];
};

export const nouvelId = () => `${Date.now().toString(36)}${Math.floor(Math.random() * 1e6).toString(36)}`;
export function interventionVide(t: number, type: TypeInter = 'destruction', defauts: Partial<Intervention> = {}): Intervention {
  return {
    id: nouvelId(), t, type, methode: '', produit: '', substance: '', amm: '', lot: '', quantiteG: null,
    hauteurM: null, diametreCm: null, nidRetire: false, resultat: '', operateur: '', certibiocide: '',
    client: { nom: '', adresse: '', commune: '', tel: '' }, present: true, signature: '', meteo: '', note: '', photosAvant: [], photosApres: [],
    ...defauts,
  };
}

/** Champs de l'ancienne fiche (une seule intervention, en texte) : repris comme première intervention. */
export type NidAncien = { interventions?: string | null; inter_ms: number | null; methode: string; produit: string; quantite: string; operateur: string;
  hauteur: string; diametre: string; traite_ms: number | null; verifie_ms: number | null; etat: string; t: number };
const nombre = (s: string): number | null => { const m = /(\d+(?:[.,]\d+)?)/.exec(s ?? ''); return m ? Number(m[1].replace(',', '.')) : null; };

/** Interventions d'un nid, les plus anciennes d'abord (y compris l'ancienne intervention unique). */
export function interventionsDe(n: NidAncien): Intervention[] {
  let l: Intervention[] = [];
  try { l = JSON.parse(n.interventions || '[]') as Intervention[]; } catch { l = []; }
  if (!Array.isArray(l)) l = [];
  l = l.map((i) => ({ ...interventionVide(i.t ?? n.t), ...i, client: { nom: '', adresse: '', commune: '', tel: '', ...((i.client ?? {}) as Partial<Client>) } }));
  if (!l.length && (n.inter_ms || n.methode || n.produit || n.quantite)) {
    const t = n.inter_ms ?? n.traite_ms ?? n.t;
    l.push(interventionVide(t, 'destruction', {
      id: `ancien-${t}`, methode: n.methode, produit: n.produit, quantiteG: nombre(n.quantite), operateur: n.operateur,
      hauteurM: nombre(n.hauteur), diametreCm: nombre(n.diametre),
    }));
    if (n.verifie_ms) l.push(interventionVide(n.verifie_ms, 'controle', { id: `ancien-c-${n.verifie_ms}`, resultat: 'mort', operateur: n.operateur }));
  }
  return l.sort((a, b) => a.t - b.t);
}

/** Classe de hauteur du compte rendu FREDON. */
export const classeHauteur = (h: number | null) => (h === null ? '' : h < 10 ? 'moins de 10 m' : h <= 25 ? 'de 10 à 25 m' : 'plus de 25 m');

/** État du nid et champs de l'ancienne fiche, déduits des interventions (pour la carte, le bilan, le GDSA). */
export function etatDepuis(l: Intervention[], etatActuel: string) {
  let etat = etatActuel === 'estime' ? 'trouve' : etatActuel;
  let traite_ms: number | null = null, verifie_ms: number | null = null;
  for (const i of l) {
    if (i.type === 'destruction' || i.type === 'retraitement') { etat = 'traite'; traite_ms = i.t; verifie_ms = null; }
    if (i.type === 'controle' && i.resultat === 'mort') { etat = 'mort'; verifie_ms = i.t; }
    if (i.type === 'controle' && i.resultat === 'actif') { etat = 'trouve'; verifie_ms = null; }
  }
  const der = [...l].reverse().find((i) => TRAITEMENTS.includes(i.type));
  return {
    etat, traite_ms, verifie_ms,
    inter_ms: der?.t ?? null, methode: der?.methode ?? '', produit: der?.produit ?? '',
    quantite: der?.quantiteG != null ? `${der.quantiteG} g` : '', operateur: der ? [der.operateur, der.certibiocide && `n° ${der.certibiocide}`].filter(Boolean).join(', ') : '',
  };
}

/** Nid à contrôler : traité depuis au moins `jours` jours, sans contrôle depuis. */
export function aControler(n: { etat: string; traite_ms: number | null }, maintenant: number, jours = 3): boolean {
  return n.etat === 'traite' && !!n.traite_ms && maintenant - n.traite_ms >= jours * 86400000;
}
/** Date du contrôle conseillé après un traitement. */
export const dateControle = (t: number, jours = 3) => t + jours * 86400000;

/* ---------- registre ---------- */
export type LigneRegistre = { nid: number; inter: Intervention; lat: number; lon: number };
/** Lignes du registre de l'année (traitements et déplacements), de la plus ancienne à la plus récente. */
export function lignesRegistre(nids: { id: number; lat: number; lon: number; l: Intervention[] }[], numero: (id: number) => number, an: number, operateur = ''): LigneRegistre[] {
  return nids.flatMap((n) => n.l.filter((i) => new Date(i.t).getFullYear() === an && i.type !== 'controle')
    .filter((i) => !operateur || i.operateur === operateur)
    .map((inter) => ({ nid: numero(n.id), inter, lat: n.lat, lon: n.lon })))
    .sort((a, b) => a.inter.t - b.inter.t);
}
/** Totaux par produit : nombre de traitements et quantité en grammes. */
export function totauxProduits(l: LigneRegistre[]): { produit: string; n: number; g: number }[] {
  const m = new Map<string, { produit: string; n: number; g: number }>();
  for (const { inter: i } of l) {
    if (!TRAITEMENTS.includes(i.type)) continue;
    const k = i.produit || 'sans produit';
    const o = m.get(k) ?? { produit: k, n: 0, g: 0 };
    o.n++; o.g += i.quantiteG ?? 0;
    m.set(k, o);
  }
  return [...m.values()].sort((a, b) => b.g - a.g);
}

const jj = (t: number) => new Date(t).toLocaleDateString('fr-FR');
const hh = (t: number) => new Date(t).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
export const ENTETE_REGISTRE = ['Date', 'Heure', 'Nid n°', 'Commune', 'Adresse', 'Latitude', 'Longitude', 'Intervention', 'Méthode', 'Hauteur (m)',
  'Produit', 'Substance active', 'N° AMM', 'Lot', 'Quantité (g)', 'Nid retiré', 'Opérateur', 'N° Certibiocide', 'Client', 'Observations'];
export function ligneTableau(r: LigneRegistre): (string | number)[] {
  const i = r.inter;
  return [jj(i.t), hh(i.t), r.nid, i.client.commune, i.client.adresse, Number(r.lat.toFixed(6)), Number(r.lon.toFixed(6)), libelleType(i.type), i.methode,
    i.hauteurM ?? '', i.produit, i.substance, i.amm, i.lot, i.quantiteG ?? '', i.nidRetire ? 'oui' : 'non', i.operateur, i.certibiocide, i.client.nom, i.note];
}
