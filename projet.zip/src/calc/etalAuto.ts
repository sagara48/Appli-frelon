/** Réglages calculés automatiquement à partir des étalonnages (au lieu d'être saisis dans Paramètres).
 *  - Signal du toit à 1 m et incertitude : déduits des tours d'étalonnage du toit (tag à position connue, la voiture
 *    passe à des distances variées) : niveau = P1m − 10·n·log10(d), ajusté par moindres carrés.
 *  - Signal du portatif à 1 m : médiane des étalonnages des tags à 1 m.
 *  Sans dépendance au téléphone (testé). */

export type PointDist = { d: number; rssi: number };
export type AjustementDist = { ref1m: number; n: number; margeDb: number; nPts: number; nLibre: boolean };

const med = (v: number[]) => { const s = [...v].sort((a, b) => a - b), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };

/** Ajuste le modèle de distance sur des mesures (tours d'étalonnage du toit). null si trop peu de mesures ou des
 *  distances trop semblables. n libre s'il reste plausible (1,6 à 3,5), sinon fixé à 2 (lieu dégagé de l'étalonnage). */
export function ajusterDistance(pts: PointDist[]): AjustementDist | null {
  const p = pts.filter((x) => Number.isFinite(x.d) && Number.isFinite(x.rssi) && x.rssi > -127 && x.d >= 3 && x.d <= 500);
  if (p.length < 30) return null;
  const L = p.map((x) => Math.log10(x.d));
  const lmin = Math.min(...L), lmax = Math.max(...L);
  if (lmax - lmin < 0.3) return null; // distances trop proches (au moins un rapport 2 entre la plus courte et la plus longue)
  const N = p.length;
  let sl = 0, sr = 0, sll = 0, slr = 0;
  for (let i = 0; i < N; i++) { sl += L[i]; sr += p[i].rssi; sll += L[i] * L[i]; slr += L[i] * p[i].rssi; }
  const det = N * sll - sl * sl;
  let b = det > 1e-9 ? (N * slr - sl * sr) / det : -20;
  let nLibre = true;
  if (-b / 10 < 1.6 || -b / 10 > 3.5) { b = -20; nLibre = false; }
  // ordonnée à l'origine robuste : médiane des écarts (les reflets donnent des creux, pas des pics)
  const ref1m = med(p.map((x, i) => x.rssi - b * L[i]));
  const res = p.map((x, i) => x.rssi - (ref1m + b * L[i]));
  const ecart = Math.sqrt(res.reduce((s, r) => s + r * r, 0) / Math.max(1, N - 2));
  return { ref1m: Math.round(ref1m), n: Math.round((-b / 10) * 10) / 10, margeDb: Math.min(12, Math.max(3, Math.round(ecart))), nPts: N, nLibre };
}

/** Signal du portatif à 1 m : médiane des tags étalonnés (null sans étalonnage). */
export function refPortatif(p1m: number[]): number | null {
  const v = p1m.filter((x) => Number.isFinite(x) && x < 0 && x > -90);
  return v.length ? Math.round(med(v)) : null;
}

/** Distance en mètres entre deux points GPS (équirectangulaire, suffisant à quelques centaines de mètres). */
export function distM(a: { lat: number; lon: number }, b: { lat: number; lon: number }) {
  const k = 111320, x = (b.lon - a.lon) * k * Math.cos(((a.lat + b.lat) / 2) * Math.PI / 180), y = (b.lat - a.lat) * k;
  return Math.hypot(x, y);
}

/* ---------- état des étalonnages (écran Étalonnage) ---------- */
export type EtatEtape = 'fait' | 'afaire' | 'arefaire' | 'auto';
export type Etape = { cle: string; titre: string; etat: EtatEtape; detail: string };
export type Entrees = {
  boussole: boolean | null; // null = portatif jamais vu
  rf: { att: number; lna: number } | null | undefined; // undefined = inconnu
  tagsEtalonnes: number; tagsConnus: number;
  toit: { errDeg: number; date: number } | null;
  distToit: { ref1m: number; margeDb: number; date: number } | null;
  exposant: number | null; nidsTerrain: number;
  vitesse?: number | null; facteur?: number | null; // appris sur les sorties (nids trouvés)
  maintenant: number;
};
const MOIS = 30 * 86400000;
/** Étapes dans l'ordre de la procédure, avec leur état. */
export function etapes(x: Entrees): Etape[] {
  const l: Etape[] = [];
  l.push({ cle: 'boussole', titre: 'Boussole du portatif', etat: x.boussole ? 'fait' : 'afaire',
    detail: x.boussole ? 'Calibrée' : x.boussole === null ? 'Portatif pas encore connecté' : 'Pas calibrée : la flèche du portatif peut se tromper' });
  l.push({ cle: 'rf', titre: 'Entrée radio du portatif', etat: x.rf ? 'fait' : 'afaire',
    detail: x.rf ? (x.rf.att === 0 ? `Préampli +${x.rf.lna} dB, pas d'atténuateur` : `Préampli +${x.rf.lna} dB, atténuateur ${x.rf.att} dB`) : 'Pas mesurée : valeurs d\'usine' });
  l.push({ cle: 'tags', titre: 'Tags à 1 m', etat: x.tagsConnus && x.tagsEtalonnes >= x.tagsConnus ? 'fait' : 'afaire',
    detail: x.tagsConnus ? `${x.tagsEtalonnes} / ${x.tagsConnus} tags étalonnés` : 'Aucun tag connu pour l\'instant' });
  const vieux = x.toit && x.maintenant - x.toit.date > 12 * MOIS;
  l.push({ cle: 'toit', titre: 'Toit de la voiture', etat: !x.toit ? 'afaire' : x.toit.errDeg > 20 || vieux ? 'arefaire' : 'fait',
    detail: !x.toit ? 'Jamais fait : directions approximatives' : `Erreur ${Math.round(x.toit.errDeg)}°${x.toit.errDeg > 20 ? ' : à refaire sur un lieu plus dégagé' : vieux ? ' : plus d\'un an, à refaire' : ''}${x.distToit ? ` · distance : ${x.distToit.ref1m} dBm à 1 m, ± ${x.distToit.margeDb} dB` : ''}` });
  l.push({ cle: 'terrain', titre: 'Terrain (appris seul)', etat: 'auto',
    detail: [x.exposant !== null ? `Exposant ${x.exposant.toFixed(1).replace('.', ',')} appris sur ${x.nidsTerrain} nid${x.nidsTerrain > 1 ? 's' : ''} trouvé${x.nidsTerrain > 1 ? 's' : ''}` : 'S\'affine à chaque nid trouvé avec le portatif (2,5 en attendant)',
      x.vitesse ? `vol des frelons ${x.vitesse.toFixed(1).replace('.', ',')} m/s` : '',
      x.facteur ? `estimations ${x.facteur > 1.15 ? `${x.facteur.toFixed(1).replace('.', ',')} fois moins précises qu'affiché : marges élargies` : 'aussi précises qu\'affiché'}` : ''].filter(Boolean).join(' · ') });
  return l;
}
export const resteAFaire = (l: Etape[]) => l.filter((e) => e.etat === 'afaire' || e.etat === 'arefaire').length;
