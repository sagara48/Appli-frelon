/** Santé des antennes du toit : à chaque sortie, chaque voie (avant, droite, arrière, gauche, omni) est comparée aux
 *  autres trame par trame ; sur une sortie, les directions des tags varient assez pour que l'écart moyen d'une voie soit
 *  stable d'une sortie à l'autre. Une voie qui baisse durablement (câble écrasé, connecteur oxydé, antenne fêlée) ou qui
 *  « décroche » souvent (connecteur desserré) se voit avant que les relèvements ne se faussent. Calcul pur (testé). */
export const VOIES = ['avant', 'droite', 'arrière', 'gauche', 'omni'] as const;
const AUCUN = -120; // en dessous : voie muette (le toit écrit −127)

/** Bilan d'une sortie : écart médian de chaque voie (dB) à la médiane des voies, et part des trames où elle est muette
 *  alors que les autres entendent bien. */
export type BilanSortie = { t: number; n: number; ecart: (number | null)[]; muet: number[] };

export class Accumulateur {
  private e: number[][] = VOIES.map(() => []);
  private m = VOIES.map(() => 0);
  private n = 0;
  ajouter(r: number[]) {
    const ok = r.slice(0, 5).filter((x) => x > AUCUN);
    if (ok.length < 3 || Math.max(...ok) < -92) return; // trame trop faible : peu parlante
    const med = mediane(ok)!;
    this.n++;
    r.slice(0, 5).forEach((x, k) => {
      if (x > AUCUN) { if (this.e[k].length < 20000) this.e[k].push(x - med); } else if (med > -85) this.m[k]++;
    });
  }
  get trames() { return this.n; }
  bilan(t: number): BilanSortie | null {
    if (this.n < 150) return null;
    return { t, n: this.n, ecart: this.e.map((l) => (l.length >= 50 ? Math.round(mediane(l)! * 10) / 10 : null)), muet: this.m.map((x) => Math.round((100 * x) / this.n)) };
  }
}

function mediane(v: number[]): number | null {
  if (!v.length) return null;
  const s = [...v].sort((a, b) => a - b), i = s.length >> 1;
  return s.length % 2 ? s[i] : (s[i - 1] + s[i]) / 2;
}

export type EtatVoie = { voie: string; etat: 'ok' | 'faible' | 'coupe' | 'apprentissage'; ref: number | null; recent: number | null; texte: string };

/** Diagnostic d'après l'historique (sorties de la plus ancienne à la plus récente) : référence = sorties d'avant les 3 dernières. */
export function diagnosticAntennes(h: BilanSortie[]): EtatVoie[] {
  return VOIES.map((voie, k) => {
    const pts = h.filter((b) => b.ecart[k] !== null);
    if (pts.length < 5) return { voie, etat: 'apprentissage', ref: null, recent: null, texte: `${pts.length} sortie${pts.length > 1 ? 's' : ''} sur 5 pour apprendre son niveau habituel` };
    const rec = pts.slice(-3), anc = pts.slice(0, -3).slice(-12);
    const ref = mediane(anc.map((b) => b.ecart[k]!))!, recent = mediane(rec.map((b) => b.ecart[k]!))!;
    const muetRef = mediane(h.slice(0, -3).slice(-12).map((b) => b.muet[k])) ?? 0, muetRec = rec.map((b) => b.muet[k]);
    if (muetRec.every((x) => x >= 15) && muetRec.some((x) => x >= muetRef + 10))
      return { voie, etat: 'coupe', ref, recent, texte: `muette dans ${Math.round(mediane(muetRec)!)} % des trames depuis 3 sorties (d'habitude ${Math.round(muetRef)} %) : connecteur desserré ou câble coupé par moments` };
    const baisse = rec.map((b) => ref - b.ecart[k]!);
    if (baisse.every((x) => x >= 4))
      return { voie, etat: 'faible', ref, recent, texte: `${Math.round(mediane(baisse)!)} dB plus faible que d'habitude depuis 3 sorties : câble, connecteur ou antenne à vérifier` };
    return { voie, etat: 'ok', ref, recent, texte: `stable (${recent >= 0 ? '+' : ''}${recent.toFixed(1).replace('.', ',')} dB par rapport aux autres voies)` };
  });
}
