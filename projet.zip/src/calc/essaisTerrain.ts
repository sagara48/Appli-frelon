/** Essais sur le terrain : tout ce qui n'a jamais tourné sur le vrai matériel, appareil par appareil, avec la façon de
 *  l'essayer. Une partie se coche seule (l'appli voit passer la bonne ligne), le reste à la main (« Marche » ou
 *  « Problème » avec une note). Le rapport se partage pour réglage. Calcul pur (testé). */

export type Appareil = 'Toit' | 'Écran voiture' | 'Portatif' | 'Tags' | 'Appli' | 'Drone';
/** auto : nom de l'événement qui coche l'essai tout seul (services/essaisTerrain.ts). */
export type Essai = { id: string; appareil: Appareil; titre: string; comment: string; auto?: string };
export type Resultat = { etat: 'ok' | 'ko'; t: number; note?: string; auto?: boolean };

export const ESSAIS: Essai[] = [
  { id: 'toit-co', appareil: 'Toit', titre: 'Connexion et version 1.4.0', comment: 'Toit sous tension, appli ouverte : il se connecte seul et annonce 1.4.0 (Menu → Appareils).', auto: 'toit14' },
  { id: 'toit-gyro', appareil: 'Toit', titre: 'Cap à l\'arrêt (gyroscope)', comment: 'Gyroscope branché. Rouler 1 min puis s\'arrêter et tourner lentement sur un parking : « Cap : gyroscope » dans l\'état du toit, la flèche suit.', auto: 'gyro' },
  { id: 'toit-bn', appareil: 'Toit', titre: 'Boîte noire', comment: 'Rouler 5 min téléphone éteint ou appli fermée, puis reconnecter : les relevés manqués reviennent (journal « Boîte noire »).', auto: 'bn' },
  { id: 'toit-ordre', appareil: 'Toit', titre: 'Ordre à un tag par le toit', comment: 'Portatif éteint, tag allumé à 20 m de la voiture : Mes tags → « Répond ? ». Réponse en moins d\'une minute.', auto: 'ordreToit' },
  { id: 'ecran-carte', appareil: 'Écran voiture', titre: 'Carte hors ligne par Wi-Fi', comment: 'Partage de connexion du téléphone allumé. Écran : Réglages → page 2 → Carte hors ligne → Télécharger ici. Les tuiles arrivent, la carte se remplit.' },
  { id: 'ecran-zoom', appareil: 'Écran voiture', titre: 'Carte hors zone', comment: 'Rouler hors de la zone téléchargée : fond agrandi (flou) au lieu d\'un fond vide.' },
  { id: 'ecran-croiser', appareil: 'Écran voiture', titre: '« Croiser ici »', comment: 'Relèvements d\'un seul côté du nid : cercle bleu « croiser ici » sur la carte et ligne « POUR CROISER ». Aller relever là : l\'estimation se resserre.' },
  { id: 'port-co', appareil: 'Portatif', titre: 'Connexion et version 1.4.0', comment: 'Portatif allumé près du téléphone : connexion seule, version 1.4.0.', auto: 'port14' },
  { id: 'port-tour', appareil: 'Portatif', titre: 'Tour sur soi-même', comment: 'Tag posé à 50-100 m. GONIOMÉTRIE → OK, tourner 20-30 s : direction et contraste affichés, ajoutée à l\'estimation (onglet Portatif).', auto: 'tour' },
  { id: 'port-tour-juste', appareil: 'Portatif', titre: 'Direction du tour juste', comment: 'Même essai, tag à un endroit connu : écart entre la direction donnée et la vraie (noter l\'écart en degrés).' },
  { id: 'port-carte', appareil: 'Portatif', titre: 'Mini-carte', comment: 'Marcher 5 min en suivant un tag, puis MODE jusqu\'à CARTE : trace colorée, position, cap, échelle.' },
  { id: 'port-voit', appareil: 'Portatif', titre: 'Voiture notée par le portatif', comment: 'Portatif à côté de la voiture, toit allumé, 1 min : l\'appli reçoit la position de la voiture (Carte → « Voiture garée »).', auto: 'voit' },
  { id: 'port-retour', appareil: 'Portatif', titre: 'Retour à la voiture', comment: 'S\'éloigner de 200 m, menu → « Retour a la voiture » : la flèche ramène à la voiture.' },
  { id: 'port-ordre', appareil: 'Portatif', titre: 'Ordre à un tag par le portatif', comment: 'Menu → « Tag suivi : repond-il ? » : réponse en moins d\'une minute.', auto: 'ordrePort' },
  { id: 'tag-etat', appareil: 'Tags', titre: 'Au nid / en chasse et température', comment: 'Tag dans une boîte fermée puis à la lumière : l\'état bascule dans Mes tags, la température est plausible.', auto: 'etatTag' },
  { id: 'tag-chg', appareil: 'Tags', titre: 'Recharge notée par le chargeur', comment: 'Poser un tag sur le chargeur près du portatif : « rechargé » dans Mes tags.', auto: 'chg' },
  { id: 'tag-qr', appareil: 'Tags', titre: 'Étiquette QR', comment: 'Mes tags → Étiquettes QR → imprimer, coller dans la case du tag de la boîte de rangement. Poser un tag → Scanner : le bon numéro est choisi. Essayer aussi avec l\'appareil photo ordinaire du téléphone.', auto: 'qr' },
  { id: 'tag-tombe', appareil: 'Tags', titre: 'Tag tombé', comment: 'Laisser un tag immobile à la lumière 3 h de jour : message « tombé », ses relèvements suivants mis de côté.', auto: 'tombe' },
  { id: 'app-voix', appareil: 'Appli', titre: 'Commandes vocales', comment: 'Chrono → Commandes vocales. Dire « Signal », « Où est le nid ? », « Tag 12 », dehors avec du vent.', auto: 'voix' },
  { id: 'app-voix-faux', appareil: 'Appli', titre: 'Pas de fausse commande', comment: 'Micro allumé 10 min pendant une conversation : aucune commande déclenchée par erreur (sinon : Paramètres → dire « frelon » avant).' },
  { id: 'app-widget', appareil: 'Appli', titre: 'Widget « Sortie »', comment: 'Ajouter le widget Frelons – Sortie. Pendant une sortie : il se met à jour, Parti / Revenu marchent sans ouvrir l\'appli.' },
  { id: 'app-notif', appareil: 'Appli', titre: 'Notifications', comment: 'Rappels du matin, météo, contrôle de nid : arrivent à l\'heure, l\'appui ouvre le bon écran.' },
  { id: 'app-equipe', appareil: 'Appli', titre: 'Équipe en direct', comment: 'Deux téléphones de la même équipe en sortie : chacun voit l\'autre sur la carte (point bleu nommé), mis à jour toutes les 30 s.', auto: 'equipe' },
  { id: 'app-arriere', appareil: 'Appli', titre: 'Écran verrouillé', comment: 'Sortie de 30 min téléphone en poche, écran éteint : alertes et chrono continuent, rien de perdu au déverrouillage.' },
  { id: 'app-viseur', appareil: 'Appli', titre: 'Hauteur au viseur', comment: 'Fiche d\'un nid (ou d\'un objet de hauteur connue : lampadaire, toit) → Mesurer la hauteur au viseur, deux visées à 20 m l\'une de l\'autre. Noter l\'écart avec la vraie hauteur.' },
  { id: 'app-antennes', appareil: 'Toit', titre: 'Santé des antennes', comment: 'Après 5 sorties : Menu → Santé des antennes, toutes les voies « stable ». Pour vérifier l\'alerte : dévisser à moitié un connecteur pendant 3 sorties courtes.' },
  { id: 'drone-vol', appareil: 'Drone', titre: 'Vol enregistré', comment: 'Un vol avec la nacelle : il apparaît dans Vols du drone avec ses mesures.', auto: 'vol' },
  { id: 'drone-controle', appareil: 'Drone', titre: 'Vol de contrôle', comment: 'Fiche d\'un nid traité → « Vol de contrôle par le drone » dans Litchi : mêmes prises de vue qu\'avant, photos rangées « Après le traitement ».' },
];

export const APPAREILS: Appareil[] = ['Toit', 'Écran voiture', 'Portatif', 'Tags', 'Appli', 'Drone'];

export function bilanEssais(r: Record<string, Resultat>): { ok: number; ko: number; reste: number; total: number } {
  let ok = 0, ko = 0;
  for (const e of ESSAIS) { const x = r[e.id]; if (x?.etat === 'ok') ok++; else if (x?.etat === 'ko') ko++; }
  return { ok, ko, reste: ESSAIS.length - ok - ko, total: ESSAIS.length };
}

/** Rapport texte à partager (les problèmes d'abord, avec leur note). */
export function rapportEssais(r: Record<string, Resultat>, entete: string[] = []): string {
  const b = bilanEssais(r);
  const d = (t: number) => new Date(t).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  const l = [`ESSAIS SUR LE TERRAIN — ${b.ok} marchent, ${b.ko} problèmes, ${b.reste} à faire (sur ${b.total})`, ...entete, ''];
  const pb = ESSAIS.filter((e) => r[e.id]?.etat === 'ko');
  if (pb.length) {
    l.push('PROBLÈMES');
    for (const e of pb) l.push(`- [${e.appareil}] ${e.titre} (${d(r[e.id].t)}) : ${r[e.id].note || 'sans note'}`);
    l.push('');
  }
  for (const a of APPAREILS) {
    l.push(a.toUpperCase());
    for (const e of ESSAIS.filter((x) => x.appareil === a)) {
      const x = r[e.id];
      l.push(`  ${x ? (x.etat === 'ok' ? 'OK ' : 'KO ') : '-- '} ${e.titre}${x ? ` (${d(x.t)}${x.auto ? ', vu par l\'appli' : ''})` : ''}${x?.note && x.etat === 'ok' ? ` : ${x.note}` : ''}`);
    }
  }
  return l.join('\n');
}
