/** Calculs de saison (sans dépendance au téléphone, testés) : pièges, statistiques par rucher, comparaison des saisons,
 *  densité des nids sur la carte, tags à recharger. */
import { distM } from './geo';
import type { FicheTag, Nid, Piege, Rucher } from '../db';

const JOUR = 86400000;
const annee = (ms: number) => new Date(ms).getFullYear();
const moy = (l: number[]) => (l.length ? l.reduce((a, b) => a + b, 0) / l.length : null);
const detruit = (n: Nid) => n.etat === 'traite' || n.etat === 'mort';

/* ---------- pièges ---------- */
export const piegeActif = (p: Piege) => !p.retire_ms;
/** Frelons capturés par un piège une année donnée (toutes années si an absent). */
export const capturesPiege = (p: Piege, an?: number) => p.releves.filter((r) => an === undefined || annee(r.t) === an).reduce((a, r) => a + r.frelons, 0);
export const dernierReleve = (p: Piege) => (p.releves.length ? Math.max(...p.releves.map((r) => r.t)) : null);
/** Un piège actif est « à relever » quand son dernier relevé (ou sa pose) date de plus de `jours`. */
export function aRelever(p: Piege, maintenant: number, jours = 7): boolean {
  if (!piegeActif(p)) return false;
  const ref = dernierReleve(p) ?? p.pose_ms;
  return ref === null || maintenant - ref > jours * JOUR;
}
/** Captures par semaine (lundi de la semaine → total), pour une année. */
export function capturesParSemaine(pieges: Piege[], an: number): { lundi: number; n: number }[] {
  const m = new Map<number, number>();
  for (const p of pieges) for (const r of p.releves) {
    if (annee(r.t) !== an) continue;
    const d = new Date(r.t); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
    m.set(d.getTime(), (m.get(d.getTime()) ?? 0) + r.frelons);
  }
  return [...m.entries()].sort((a, b) => a[0] - b[0]).map(([lundi, n]) => ({ lundi, n }));
}

/* ---------- par rucher ---------- */
export type StatsRucher = {
  rucher: Rucher; n1km: number; n3km: number; detruits: number; aTraiter: number;
  plusProche: { nid: Nid; d: number } | null; pieges: number; captures: number;
};
/** Nids de l'année autour d'un rucher (rayon proche r1, rayon large r2), détruits ou non, plus proche ; pièges à moins de r1 et leurs captures. */
export function statsRucher(r: Rucher, nids: Nid[], pieges: Piege[], an: number, r1 = 1000, r2 = 3000): StatsRucher {
  const autour = nids.filter((n) => annee(n.t) === an).map((nid) => ({ nid, d: distM(r.lat, r.lon, nid.lat, nid.lon) })).filter((x) => x.d <= Math.max(r1, r2)).sort((a, b) => a.d - b.d);
  const proches = autour.filter((x) => x.d <= r1);
  const pg = pieges.filter((p) => distM(r.lat, r.lon, p.lat, p.lon) <= r1);
  return {
    rucher: r, n1km: proches.length, n3km: autour.length, detruits: autour.filter((x) => detruit(x.nid)).length,
    aTraiter: autour.filter((x) => !detruit(x.nid)).length, plusProche: autour[0] ?? null,
    pieges: pg.length, captures: pg.reduce((a, p) => a + capturesPiege(p, an), 0),
  };
}

/* ---------- comparaison des saisons ---------- */
export type Saison = {
  annee: number; nids: number; detruits: number; precision: number | null; delaiTraitementJ: number | null;
  distRucher: number | null; captures: number; parMois: number[];
};
/** Une ligne par année où il y a des nids ou des captures, de la plus récente à la plus ancienne. */
export function comparerSaisons(nids: Nid[], ruchers: Rucher[], pieges: Piege[]): Saison[] {
  const ans = new Set<number>([...nids.map((n) => annee(n.t)), ...pieges.flatMap((p) => p.releves.map((r) => annee(r.t)))]);
  return [...ans].sort((a, b) => b - a).map((an) => {
    const l = nids.filter((n) => annee(n.t) === an);
    const parMois = Array.from({ length: 12 }, (_, m) => l.filter((n) => new Date(n.t).getMonth() === m).length);
    const delais = l.filter((n) => n.traite_ms && n.traite_ms >= n.t).map((n) => (n.traite_ms! - n.t) / JOUR);
    const dr = ruchers.length ? l.map((n) => Math.min(...ruchers.map((r) => distM(r.lat, r.lon, n.lat, n.lon)))) : [];
    return {
      annee: an, nids: l.length, detruits: l.filter(detruit).length, precision: moy(l.map((n) => n.err)),
      delaiTraitementJ: moy(delais), distRucher: moy(dr), captures: pieges.reduce((a, p) => a + capturesPiege(p, an), 0), parMois,
    };
  });
}

/* ---------- densité des nids (carte) ---------- */
export type Cellule = { x: number; y: number; v: number }; // v entre 0 et 1
/** Grille de densité (noyau gaussien) sur l'écran : `pos` donne la position écran d'un nid, `mParPx` l'échelle.
 *  Rayon d'influence `sigmaM` (400 m par défaut). Les cellules presque vides ne sont pas renvoyées. */
export function grilleDensite(points: { lat: number; lon: number }[], pos: (p: { lat: number; lon: number }) => { x: number; y: number },
  W: number, H: number, mParPx: number, pasPx = 20, sigmaM = 400): Cellule[] {
  if (!points.length) return [];
  const sp = sigmaM / mParPx; // sigma en pixels
  const pts = points.map(pos).filter((p) => p.x > -4 * sp && p.x < W + 4 * sp && p.y > -4 * sp && p.y < H + 4 * sp);
  if (!pts.length) return [];
  const cel: Cellule[] = [];
  let max = 0;
  for (let y = pasPx / 2; y < H; y += pasPx) for (let x = pasPx / 2; x < W; x += pasPx) {
    let v = 0;
    for (const p of pts) { const d2 = (p.x - x) ** 2 + (p.y - y) ** 2; if (d2 < 16 * sp * sp) v += Math.exp(-d2 / (2 * sp * sp)); }
    if (v > 0) { cel.push({ x, y, v }); if (v > max) max = v; }
  }
  // normalisé sur un maximum d'au moins 1 nid : un nid isolé ne colore pas la carte comme un foyer de dix
  const ref = Math.max(max, 1);
  return cel.map((c) => ({ ...c, v: c.v / ref })).filter((c) => c.v > 0.08);
}

/* ---------- tags à recharger ---------- */
export type RaisonRecharge = 'pile' | 'pose' | 'ancien' | 'jamais';
/** Pourquoi un tag disponible ou posé est à recharger (null = rien à signaler).
 *  pile : dernière pile entendue sous le seuil ; pose : posé depuis la dernière recharge ; ancien : recharge trop vieille (décharge). */
export function raisonRecharge(f: FicheTag, maintenant: number, seuilPct = 50, joursMax = 7): RaisonRecharge | null {
  if (f.etat === 'perdu') return null;
  if (f.pile !== null && f.pile < seuilPct && (f.recharge_ms === null || (f.pile_ms ?? 0) > f.recharge_ms)) return 'pile';
  if (f.recharge_ms === null) return f.pose_ms ? 'pose' : 'jamais';
  if (f.pose_ms && f.pose_ms > f.recharge_ms && f.etat !== 'pose') return 'pose';
  if (maintenant - f.recharge_ms > joursMax * JOUR) return 'ancien';
  return null;
}
export const LIBELLE_RECHARGE: Record<RaisonRecharge, string> = {
  pile: 'pile faible', pose: 'a servi depuis sa dernière recharge', ancien: 'rechargé il y a plus d\'une semaine', jamais: 'recharge jamais notée',
};
