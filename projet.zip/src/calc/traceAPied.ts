/** Carte du signal à pied : le portatif envoie chaque seconde sa position GPS et le niveau du tag suivi.
 *  On garde un point tous les 3 m (ou toutes les 15 s sur place, en gardant le plus fort), par tag.
 *  Sans dépendance au téléphone (testé). */
import { distM } from './geo';

export type Pas = { lat: number; lon: number; rssi: number; t: number };
export const MAX_PAS = 1500;

/** Ajoute une mesure ; renvoie la même liste si rien n'a changé. */
export function ajouterPas(l: Pas[] | undefined, p: Pas): Pas[] {
  const liste = l ?? [];
  const der = liste[liste.length - 1];
  if (!Number.isFinite(p.lat) || !Number.isFinite(p.rssi) || (p.lat === 0 && p.lon === 0)) return liste;
  if (der && distM(der.lat, der.lon, p.lat, p.lon) < 3) {
    if (p.t - der.t < 15000) return p.rssi > der.rssi ? [...liste.slice(0, -1), { ...der, rssi: p.rssi }] : liste;
  }
  const n = [...liste, p];
  return n.length > MAX_PAS ? n.slice(n.length - MAX_PAS) : n;
}

/** Point le plus fort (moyenne des 3 meilleurs pour lisser un pic isolé). */
export function pointFort(l: Pas[] | undefined): Pas | null {
  if (!l || !l.length) return null;
  const tri = [...l].sort((a, b) => b.rssi - a.rssi).slice(0, 3);
  const k = tri.length;
  return { lat: tri.reduce((s, p) => s + p.lat, 0) / k, lon: tri.reduce((s, p) => s + p.lon, 0) / k, rssi: tri[0].rssi, t: tri[0].t };
}

/** Couleur d'un niveau : bleu froid (−100 dBm) → jaune → rouge chaud (−50 dBm et plus). */
export function couleurSignal(rssi: number): string {
  const x = Math.max(0, Math.min(1, (rssi + 100) / 50));
  const h = Math.round(220 - 220 * x); // 220 = bleu, 0 = rouge
  return `hsl(${h}, 85%, 48%)`;
}
