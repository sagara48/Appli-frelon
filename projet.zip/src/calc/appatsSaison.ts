/** « Où poser les appâts l'an prochain » : les fondatrices installent souvent leur nid à moins d'un ou deux km de celui
 *  d'où elles sont sorties, et les ouvrières chassent devant les ruchers. Score d'un endroit = nids des saisons
 *  passées autour (la dernière compte double) + ruchers proches, d'autant plus qu'ils ont subi de la pression.
 *  On garde les meilleurs endroits distants d'au moins 800 m. Ce n'est qu'une aide : la carte de densité et
 *  l'expérience du terrain restent juges. Sans dépendance au téléphone (testé). */
import { distM, KY, kxOf } from './geo';
import { lirePressions } from './pression';

export type NidS = { lat: number; lon: number; t: number; etat: string };
export type RucherS = { nom: string; lat: number; lon: number; pressions: string };
export type Emplacement = { lat: number; lon: number; score: number; nids1km: number; rucher: { nom: string; distM: number } | null; raison: string };

const SIG_NID = 900, SIG_RUCHER = 500, PAS = 100, SEPARATION = 800;

export function emplacementsAppats(nids: NidS[], ruchers: RucherS[], maintenant: number, n = 6): Emplacement[] {
  const an = new Date(maintenant).getFullYear();
  // saison passée : nids de l'année en cours (on prépare la suivante) et des années d'avant
  const N = nids.filter((x) => x.lat && x.lon).map((x) => {
    const age = an - new Date(x.t).getFullYear();
    return { ...x, w: age <= 0 ? 2 : age === 1 ? 1 : 0.5 };
  });
  const R = ruchers.filter((r) => r.lat && r.lon).map((r) => {
    const p = lirePressions(r.pressions).filter((x) => an - new Date(x.t).getFullYear() <= 1);
    const max = p.reduce((m, x) => Math.max(m, x.n), 0);
    return { ...r, w: 0.6 + 0.4 * max };
  });
  if (!N.length) return [];
  const pts = [...N, ...R];
  const la0 = pts.reduce((a, p) => a + p.lat, 0) / pts.length, kx = kxOf(la0);
  let x1 = 1e9, x2 = -1e9, y1 = 1e9, y2 = -1e9;
  for (const p of pts) { const x = (p.lon - pts[0].lon) * kx, y = (p.lat - la0) * KY; x1 = Math.min(x1, x); x2 = Math.max(x2, x); y1 = Math.min(y1, y); y2 = Math.max(y2, y); }
  x1 -= 1500; x2 += 1500; y1 -= 1500; y2 += 1500;
  const nx = Math.min(200, Math.ceil((x2 - x1) / PAS)), ny = Math.min(200, Math.ceil((y2 - y1) / PAS));
  const sx = (x2 - x1) / nx, sy = (y2 - y1) / ny;
  const Np = N.map((p) => ({ x: (p.lon - pts[0].lon) * kx, y: (p.lat - la0) * KY, w: p.w }));
  const Rp = R.map((p) => ({ x: (p.lon - pts[0].lon) * kx, y: (p.lat - la0) * KY, w: p.w }));
  const g = new Float64Array((nx + 1) * (ny + 1));
  for (let j = 0; j <= ny; j++) for (let i = 0; i <= nx; i++) {
    const x = x1 + i * sx, y = y1 + j * sy;
    let v = 0;
    for (const p of Np) { const d2 = (p.x - x) ** 2 + (p.y - y) ** 2; if (d2 < 16 * SIG_NID * SIG_NID) v += p.w * Math.exp(-d2 / (2 * SIG_NID * SIG_NID)); }
    for (const p of Rp) { const d2 = (p.x - x) ** 2 + (p.y - y) ** 2; if (d2 < 16 * SIG_RUCHER * SIG_RUCHER) v += p.w * Math.exp(-d2 / (2 * SIG_RUCHER * SIG_RUCHER)); }
    g[j * (nx + 1) + i] = v;
  }
  const ordre = Array.from(g.keys()).sort((a, b) => g[b] - g[a]);
  const max = g[ordre[0]] || 1, choisis: Emplacement[] = [];
  for (const k of ordre) {
    if (choisis.length >= n || g[k] < 0.2 * max) break;
    const i = k % (nx + 1), j = Math.floor(k / (nx + 1));
    const lat = la0 + (y1 + j * sy) / KY, lon = pts[0].lon + (x1 + i * sx) / kx;
    if (choisis.some((c) => distM(c.lat, c.lon, lat, lon) < SEPARATION)) continue;
    const nids1km = N.filter((p) => distM(p.lat, p.lon, lat, lon) < 1000).length;
    const proche = R.map((r) => ({ nom: r.nom, distM: Math.round(distM(r.lat, r.lon, lat, lon)) })).sort((a, b) => a.distM - b.distM)[0] ?? null;
    const rucher = proche && proche.distM < 1500 ? proche : null;
    const raison = [nids1km ? `${nids1km} nid${nids1km > 1 ? 's' : ''} à moins d'1 km` : null, rucher ? `rucher « ${rucher.nom} » à ${rucher.distM} m` : null].filter(Boolean).join(', ');
    choisis.push({ lat, lon, score: Math.round((100 * g[k]) / max), nids1km, rucher, raison });
  }
  return choisis;
}
