/** Format du fichier de sauvegarde (zip : sauvegarde.json + photos/). Sans dépendance au téléphone, pour les tests. */
import { strFromU8, strToU8, unzipSync, zipSync, type Zippable } from 'fflate';
import type { Sauvegarde } from '../db';

const nomFichier = (uri: string) => uri.split('/').pop() ?? uri;

/** Contenu du zip (testable sans téléphone : les photos sont lues par la fonction donnée). */
export function construireZip(s: Sauvegarde, lirePhoto: (uri: string) => Uint8Array | null): { zip: Uint8Array; photos: number; manquantes: number } {
  const fichiers: Zippable = {};
  let photos = 0, manquantes = 0;
  const nids = s.nids.map((n) => {
    let liste: string[] = [];
    try { liste = JSON.parse(String(n.photos ?? '[]')) as string[]; } catch {}
    const noms: string[] = [];
    for (const uri of liste) {
      const o = lirePhoto(uri);
      if (!o) { manquantes++; continue; }
      const nom = nomFichier(uri);
      fichiers[`photos/${nom}`] = [o, { level: 0 }]; // déjà compressées (JPEG)
      noms.push(nom); photos++;
    }
    return { ...n, photos: JSON.stringify(noms) };
  });
  fichiers['sauvegarde.json'] = strToU8(JSON.stringify({ ...s, nids }));
  return { zip: zipSync(fichiers, { level: 6 }), photos, manquantes };
}

/** Lecture d'un zip de sauvegarde : contenu et photos (nom → octets). Lève une erreur lisible si ce n'en est pas une. */
export function lireZip(octets: Uint8Array): { s: Sauvegarde; photos: Record<string, Uint8Array> } {
  let f: Record<string, Uint8Array>;
  try { f = unzipSync(octets); } catch { throw new Error('Ce fichier n\'est pas un zip.'); }
  const j = f['sauvegarde.json'];
  if (!j) throw new Error('Ce zip n\'est pas une sauvegarde de l\'Appli Frelons (sauvegarde.json absent).');
  const s = JSON.parse(strFromU8(j)) as Sauvegarde;
  if (s.version !== 1 || !Array.isArray(s.nids) || !Array.isArray(s.reglages)) throw new Error('Sauvegarde illisible ou d\'une version inconnue.');
  const photos: Record<string, Uint8Array> = {};
  for (const [k, v] of Object.entries(f)) if (k.startsWith('photos/') && k.length > 7) photos[k.slice(7)] = v;
  return { s, photos };
}
