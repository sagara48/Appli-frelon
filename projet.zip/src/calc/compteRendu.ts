/** Compte rendu d'une sortie (enregistré automatiquement à la fin) : durée, trajets, tags entendus, nids estimés et
 *  trouvés, allers-retours à l'appât. Sans dépendance au téléphone (testé). */
export type CompteRendu = {
  debut: number; fin: number; kmVoiture: number; kmPied: number; tags: number[];
  estimations: { tag: number; errM: number }[]; nidsTrouves: { id: number; numero: number; tag: number }[]; allersRetours: number; arretes: number;
};
const hm = (ms: number) => { const m = Math.round(ms / 60000); return m < 60 ? `${m} min` : `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, '0')}`; };
const km = (x: number) => (x < 1 ? `${Math.round(x * 1000)} m` : `${x.toFixed(1).replace('.', ',')} km`);
const t3 = (n: number) => String(n).padStart(3, '0');

export function resumeCourt(c: CompteRendu): string {
  const p = [hm(c.fin - c.debut), `${c.tags.length} tag${c.tags.length > 1 ? 's' : ''}`];
  if (c.nidsTrouves.length) p.push(`${c.nidsTrouves.length} nid${c.nidsTrouves.length > 1 ? 's' : ''} trouvé${c.nidsTrouves.length > 1 ? 's' : ''}`);
  else if (c.estimations.length) p.push(`${c.estimations.length} nid${c.estimations.length > 1 ? 's' : ''} estimé${c.estimations.length > 1 ? 's' : ''}`);
  return p.join(' · ');
}

export function texteCompteRendu(c: CompteRendu, auteur = ''): string {
  const d = new Date(c.debut);
  const l = [
    `Sortie frelons du ${d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })}, ${d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })} – ${new Date(c.fin).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })} (${hm(c.fin - c.debut)})${auteur ? `, ${auteur}` : ''}`,
    `Trajet : ${km(c.kmVoiture)} en voiture${c.kmPied > 0.05 ? `, ${km(c.kmPied)} à pied` : ''}`,
    `Tags entendus : ${c.tags.length ? c.tags.map(t3).join(', ') : 'aucun'}`,
  ];
  if (c.estimations.length) l.push(`Nids estimés : ${c.estimations.map((e) => `tag ${t3(e.tag)} à ± ${Math.round(e.errM)} m`).join(' ; ')}`);
  if (c.nidsTrouves.length) l.push(`Nids trouvés : ${c.nidsTrouves.map((n) => `n° ${n.numero}${n.tag > 0 ? ` (tag ${t3(n.tag)})` : ''}`).join(', ')}`);
  if (c.allersRetours) l.push(`Allers-retours chronométrés à l'appât : ${c.allersRetours}`);
  if (c.arretes) l.push(`Nids traités : ${c.arretes}`);
  return l.join('\n');
}
