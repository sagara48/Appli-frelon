/** Calendrier de saison : les étapes de l'année contre le frelon asiatique, avec leurs périodes (jour et mois de début et de fin).
 *  Dates indicatives pour la moyenne montagne (Haute-Loire, Lozère) : la saison y démarre un peu plus tard qu'en plaine.
 *  Le décalage réglable (en jours) avance ou retarde toutes les périodes d'un coup. */

export type Etape = {
  id: string; titre: string; detail: string;
  debut: [number, number]; fin: [number, number]; // [jour, mois 1-12]
  lien?: string; lienTitre?: string; // écran de l'appli correspondant
};

export const ETAPES: Etape[] = [
  { id: 'hiver', titre: 'Entretien du matériel', debut: [1, 12], fin: [15, 2], lien: '/banc-essai', lienTitre: 'Banc d\'essai',
    detail: 'Mises à jour des appareils, essai de chaque carte, recharge des accus, cartes hors ligne des secteurs à suivre.' },
  { id: 'pieges', titre: 'Piégeage des fondatrices', debut: [1, 3], fin: [15, 5], lien: '/pieges', lienTitre: 'Pièges de printemps',
    detail: 'Pièges à appât sucré près des ruchers et des nids de l\'an passé (carte de densité). Relever chaque semaine.' },
  { id: 'preparer', titre: 'Préparer la saison des tags', debut: [15, 3], fin: [30, 4], lien: '/tags', lienTitre: 'Mes tags',
    detail: 'Tags rechargés, toit étalonné, portatif et écran essayés, équipiers réglés pour le partage.' },
  { id: 'primaires', titre: 'Nids primaires', debut: [15, 4], fin: [30, 6], lien: '/nids', lienTitre: 'Carnet des nids',
    detail: 'Petits nids dans les abris, cabanons, haies basses, autour des ruchers : les chercher et les noter dans le carnet.' },
  { id: 'retirer', titre: 'Retirer les pièges', debut: [15, 5], fin: [15, 6], lien: '/pieges', lienTitre: 'Pièges de printemps',
    detail: 'Fin du piégeage de printemps : au-delà, les pièges prennent surtout d\'autres insectes.' },
  { id: 'tags', titre: 'Pose des tags et localisation', debut: [1, 7], fin: [31, 10], lien: '/pose-tag', lienTitre: 'Poser un tag',
    detail: 'Frelons en chasse devant les ruchers : poser les tags, suivre en voiture puis au portatif, noter chaque nid trouvé.' },
  { id: 'destruction', titre: 'Destruction des nids', debut: [1, 8], fin: [31, 10], lien: '/nids', lienTitre: 'Carnet des nids',
    detail: 'Avant la sortie des futures fondatrices (fin d\'automne). Noter la date, le produit et l\'opérateur sur la fiche.' },
  { id: 'verifier', titre: 'Vérifier les nids traités', debut: [15, 9], fin: [30, 11], lien: '/nids', lienTitre: 'Carnet des nids',
    detail: 'Quelques jours après le traitement, contrôler l\'absence d\'activité et passer le nid en « Vérifié mort ». Récupérer les tags.' },
  { id: 'bilan', titre: 'Bilan de saison et GDSA', debut: [1, 11], fin: [15, 12], lien: '/bilan', lienTitre: 'Bilan de saison',
    detail: 'Rapport PDF et classeur pour le GDSA, sauvegarde du carnet.' },
];

const JOUR = 86400000;
/** Période d'une étape pour l'année `an` (une étape à cheval sur deux années commence l'année `an`). */
export function periode(e: Etape, an: number, decalageJ = 0): { debut: number; fin: number } {
  const d = new Date(an, e.debut[1] - 1, e.debut[0]).getTime() + decalageJ * JOUR;
  const anFin = e.fin[1] < e.debut[1] || (e.fin[1] === e.debut[1] && e.fin[0] < e.debut[0]) ? an + 1 : an;
  const f = new Date(anFin, e.fin[1] - 1, e.fin[0], 23, 59).getTime() + decalageJ * JOUR;
  return { debut: d, fin: f };
}

export type Dates = Record<string, { debut: [number, number]; fin: [number, number] }>;
/** Étapes avec les dates choisies par l'utilisateur à la place des dates par défaut. */
export const etapesReglees = (dates: Dates = {}): Etape[] => ETAPES.map((e) => (dates[e.id] ? { ...e, debut: dates[e.id].debut, fin: dates[e.id].fin } : e));
/** « 15/03 » → [15, 3] ; null si la date n'existe pas (29/02 accepté). */
export function lireJourMois(txt: string): [number, number] | null {
  const m = /^\s*(\d{1,2})\s*[/.\-]\s*(\d{1,2})\s*$/.exec(txt);
  if (!m) return null;
  const j = Number(m[1]), mo = Number(m[2]);
  if (mo < 1 || mo > 12 || j < 1 || j > new Date(2024, mo, 0).getDate()) return null;
  return [j, mo];
}
export const jourMois = (d: [number, number]) => `${String(d[0]).padStart(2, '0')}/${String(d[1]).padStart(2, '0')}`;

export type EtatEtape = 'en-cours' | 'a-venir' | 'passee';
export type EtapeDatee = Etape & { debutMs: number; finMs: number; etat: EtatEtape; saison: number };
/** Étapes autour de la date : celle de l'année en cours, ou celle commencée l'an passé si elle court encore (hiver). */
export function etapesDatees(maintenant: number, decalageJ = 0, dates: Dates = {}): EtapeDatee[] {
  const an = new Date(maintenant).getFullYear();
  return etapesReglees(dates).map((e) => {
    let saison = an;
    let p = periode(e, an, decalageJ);
    const avant = periode(e, an - 1, decalageJ);
    if (avant.fin >= maintenant) { saison = an - 1; p = avant; } // étape d'hiver commencée l'an passé
    const etat: EtatEtape = maintenant < p.debut ? 'a-venir' : maintenant > p.fin ? 'passee' : 'en-cours';
    return { ...e, debutMs: p.debut, finMs: p.fin, etat, saison };
  }).sort((a, b) => a.debutMs - b.debutMs);
}

/** Clé d'une étape pour une saison (case cochée « fait », rappel déjà donné). */
export const cleEtape = (e: { id: string; saison: number }) => `${e.id}-${e.saison}`;

/** Étapes commencées depuis moins de `jours` jours, ni faites ni déjà rappelées : à rappeler au démarrage. */
export function aRappeler(maintenant: number, faites: Record<string, boolean>, rappelees: Record<string, boolean>, decalageJ = 0, jours = 14, dates: Dates = {}): EtapeDatee[] {
  return etapesDatees(maintenant, decalageJ, dates).filter((e) => e.etat === 'en-cours' && maintenant - e.debutMs < jours * JOUR && !faites[cleEtape(e)] && !rappelees[cleEtape(e)]);
}
