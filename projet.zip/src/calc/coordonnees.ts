/** Lecture de coordonnées saisies ou collées, dans les formats qu'on rencontre : degrés décimaux (point ou virgule),
 *  degrés-minutes (GPS de randonnée, géocaching), degrés-minutes-secondes, liens Google Maps / OpenStreetMap / geo:,
 *  et Lambert 93 (Géoportail, plateformes de signalement, cadastre). Calcul pur (testé). */

export type Lu = { lat: number; lon: number; format: string };

const D2R = Math.PI / 180;
const dansFrance = (lat: number, lon: number) => lat > 41 && lat < 51.5 && lon > -5.5 && lon < 10;
const valide = (lat: number, lon: number) => Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180 && !(lat === 0 && lon === 0);

/** Lambert 93 (EPSG:2154) → WGS84 (écart < 1 m : RGF93 et WGS84 coïncident à mieux que le mètre). */
export function lambert93VersWgs84(x: number, y: number): { lat: number; lon: number } {
  const a = 6378137, f = 1 / 298.257222101, e = Math.sqrt(2 * f - f * f);
  const phi1 = 44 * D2R, phi2 = 49 * D2R, phi0 = 46.5 * D2R, lon0 = 3 * D2R, x0 = 700000, y0 = 6600000;
  const m = (p: number) => Math.cos(p) / Math.sqrt(1 - e * e * Math.sin(p) ** 2);
  const t = (p: number) => Math.tan(Math.PI / 4 - p / 2) / ((1 - e * Math.sin(p)) / (1 + e * Math.sin(p))) ** (e / 2);
  const n = (Math.log(m(phi1)) - Math.log(m(phi2))) / (Math.log(t(phi1)) - Math.log(t(phi2)));
  const F = m(phi1) / (n * t(phi1) ** n), r0 = a * F * t(phi0) ** n;
  const dx = x - x0, dy = r0 - (y - y0);
  const r = Math.sign(n) * Math.hypot(dx, dy), th = Math.atan2(dx, dy);
  const tt = (r / (a * F)) ** (1 / n);
  let phi = Math.PI / 2 - 2 * Math.atan(tt);
  for (let i = 0; i < 10; i++) phi = Math.PI / 2 - 2 * Math.atan(tt * ((1 - e * Math.sin(phi)) / (1 + e * Math.sin(phi))) ** (e / 2));
  return { lat: phi / D2R, lon: (th / n + lon0) / D2R };
}

/** Une coordonnée en degrés à partir de « 45°02'28.3"N », « N 45 02.472 », « 45.0412 », « -3,8851 »… */
function angle(s: string): number | null {
  const h = s.match(/[NSEOW]/i)?.[0]?.toUpperCase();
  const sgn = h === 'S' || h === 'O' || h === 'W' || /^\s*-/.test(s) ? -1 : 1;
  const nums = (s.replace(/(\d),(\d)/g, '$1.$2').match(/\d+(?:\.\d+)?/g) ?? []).map(Number);
  if (!nums.length || nums.length > 3) return null;
  const [d, m = 0, sec = 0] = nums;
  if (m >= 60 || sec >= 60) return null;
  return sgn * (d + m / 60 + sec / 3600);
}

export function lireCoordonnees(texte: string): Lu | null {
  const t = texte.trim();
  if (!t) return null;
  // liens : Google Maps (@lat,lon / q=lat,lon / !3dlat!4dlon), OpenStreetMap (mlat/mlon ou #map=z/lat/lon), geo:
  const lien = t.match(/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/) ?? t.match(/[@=](-?\d+\.\d+),\s*(-?\d+\.\d+)/) ?? t.match(/geo:(-?\d+\.\d+),(-?\d+\.\d+)/i)
    ?? t.match(/map=\d+\/(-?\d+\.\d+)\/(-?\d+\.\d+)/);
  if (lien) { const lat = Number(lien[1]), lon = Number(lien[2]); if (valide(lat, lon)) return { lat, lon, format: 'lien' }; }
  const osm = t.match(/mlat=(-?\d+\.\d+).*mlon=(-?\d+\.\d+)/);
  if (osm) { const lat = Number(osm[1]), lon = Number(osm[2]); if (valide(lat, lon)) return { lat, lon, format: 'lien' }; }
  // Lambert 93 : deux grands nombres (X 100 000 – 1 300 000, Y 6 000 000 – 7 200 000)
  const grands = (t.replace(/(\d)[\s ](?=\d{3}\b)/g, '$1').match(/\d{6,7}(?:[.,]\d+)?/g) ?? []).map((v) => Number(v.replace(',', '.')));
  if (grands.length === 2) {
    const [a, b] = grands, x = a < b ? a : b, y = a < b ? b : a;
    if (x > 100000 && x < 1300000 && y > 6000000 && y < 7200000) { const p = lambert93VersWgs84(x, y); return { ...p, format: 'Lambert 93' }; }
  }
  // avec hémisphères : « N 45°02.472' E 3°53.106' », « 45°02'28"N 3°53'06"E »
  const hemi = t.match(/^\s*([NS]?)\s*([^NSEOW]+?)\s*([NS]?)[\s,;]+([EOW]?)\s*([^NSEOW]+?)\s*([EOW]?)\s*$/i);
  if (hemi && (hemi[1] || hemi[3]) && (hemi[4] || hemi[6])) {
    const lat = angle(`${hemi[1] || hemi[3]} ${hemi[2]}`), lon = angle(`${hemi[4] || hemi[6]} ${hemi[5]}`);
    if (lat !== null && lon !== null && valide(lat, lon)) return { lat, lon, format: /['°]\s*\d+(?:[.,]\d+)?\s*["″]/.test(t) ? 'degrés minutes secondes' : /\d+[.,]\d+\s*['′]/.test(t) || /°\s*\d/.test(t) ? 'degrés minutes' : 'degrés décimaux' };
  }
  // degrés décimaux : « 45.0412, 3.8851 », « 45,0412 3,8851 », « 45,0412; 3,8851 »
  const dec = t.match(/^\s*(-?\d{1,2}(?:[.,]\d+)?)\s*[°]?\s*(?:[,;]\s*|\s+)(-?\d{1,3}(?:[.,]\d+)?)\s*°?\s*$/);
  if (dec) {
    const lat = Number(dec[1].replace(',', '.')), lon = Number(dec[2].replace(',', '.'));
    if (valide(lat, lon)) return dansFrance(lat, lon) || !dansFrance(lon, lat) ? { lat, lon, format: 'degrés décimaux' } : { lat: lon, lon: lat, format: 'degrés décimaux (inversés)' };
  }
  // degrés minutes sans hémisphère : « 45°02.472' 3°53.106' »
  const dm = t.match(/^\s*(-?\d{1,2}\s*°\s*\d{1,2}(?:[.,]\d+)?\s*['′]?(?:\s*\d{1,2}(?:[.,]\d+)?\s*["″])?)\s*[,;]?\s+(-?\d{1,3}\s*°\s*\d{1,2}(?:[.,]\d+)?\s*['′]?(?:\s*\d{1,2}(?:[.,]\d+)?\s*["″])?)\s*$/);
  if (dm) { const lat = angle(dm[1]), lon = angle(dm[2]); if (lat !== null && lon !== null && valide(lat, lon)) return { lat, lon, format: 'degrés minutes' }; }
  return null;
}

/** Date « JJ/MM/AAAA » (ou JJ/MM/AA, JJ.MM.AAAA, JJ-MM-AAAA) → ms à midi local ; null si invalide ou dans le futur. */
export function lireDate(texte: string, maintenant: number): number | null {
  const m = texte.trim().match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2}|\d{4})$/);
  if (!m) return null;
  const j = Number(m[1]), mo = Number(m[2]), a = m[3].length === 2 ? 2000 + Number(m[3]) : Number(m[3]);
  const d = new Date(a, mo - 1, j, 12, 0, 0);
  if (d.getMonth() !== mo - 1 || d.getDate() !== j || a < 2004 || d.getTime() > maintenant + 86400000) return null;
  return d.getTime();
}
