/** Versions attendues par cette appli, et comparaison avec ce que les appareils annoncent.
 *  - Le protocole (format des lignes Bluetooth) doit être le même des deux côtés : sinon l'appli ne comprend pas tout.
 *  - Le firmware peut être plus ancien que celui livré avec l'appli : tout marche, une mise à jour est simplement proposée.
 *  À tenir à jour à chaque changement de firmware ou de format (voir aussi PROTO_TOIT et PROTO_PORTATIF dans les firmwares). */

export const PROTO_TOIT = 1;
export const PROTO_PORTATIF = 1;
/** Firmwares livrés avec cette version de l'appli (paquets de mise à jour du même envoi). */
export const FIRMWARE_PREVU = { toit: '1.3.0', portatif: '1.3.0', voie: 2 } as const;

/** Versions annoncées par un appareil ; `absente` : connecté depuis un moment sans réponse à « ver » (firmware d'avant la 1.1.0). */
export type VersionAppareil = { fw: string; proto: number; voies?: number[]; recuMs: number; absente?: boolean;
  rst?: number; upS?: number; rstVoies?: number[] }; // 1.2.0 : cause du dernier redémarrage, secondes depuis
export type Verdict =
  | { etat: 'ok'; texte: string }
  | { etat: 'maj'; texte: string } // compatible, firmware plus ancien que celui livré
  | { etat: 'firmware'; texte: string } // protocole ancien : mettre à jour le firmware
  | { etat: 'appli'; texte: string } // protocole plus récent : mettre à jour l'appli
  | { etat: 'inconnu'; texte: string }; // le firmware ne donne pas sa version (antérieur à la 1.1.0)

/** « 1.10.2+3 » → [1, 10, 2] ; comparaison numérique version par version. */
export function comparerVersions(a: string, b: string): number {
  const p = (v: string) => v.split('+')[0].split('.').map((x) => parseInt(x, 10) || 0);
  const x = p(a), y = p(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] ?? 0) - (y[i] ?? 0); if (d) return Math.sign(d); }
  return 0;
}

/** null tant que l'appareil n'a pas répondu (connexion en cours). */
export function verdict(appareil: 'toit' | 'portatif', v: VersionAppareil | null): Verdict | null {
  const nom = appareil === 'toit' ? 'du toit' : 'du portatif';
  if (!v) return null;
  if (v.absente) return { etat: 'inconnu', texte: `Le firmware ${nom} ne donne pas sa version : il date d'avant la 1.1.0. Mettez-le à jour (Menu → Mises à jour).` };
  const attendu = appareil === 'toit' ? PROTO_TOIT : PROTO_PORTATIF;
  if (!Number.isFinite(v.proto) || v.proto < attendu)
    return { etat: 'firmware', texte: `Firmware ${nom} ${v.fw} trop ancien pour cette appli (protocole ${v.proto}, attendu ${attendu}) : mettez-le à jour.` };
  if (v.proto > attendu)
    return { etat: 'appli', texte: `Firmware ${nom} ${v.fw} plus récent que l'appli (protocole ${v.proto}, l'appli comprend le ${attendu}) : mettez l'appli à jour.` };
  const prevu = FIRMWARE_PREVU[appareil];
  if (comparerVersions(v.fw, prevu) < 0) return { etat: 'maj', texte: `Firmware ${nom} ${v.fw} compatible ; la version ${prevu} est disponible.` };
  // voies du toit : version de chacune
  if (appareil === 'toit' && v.voies) {
    const vieilles = v.voies.map((x, i) => (x > 0 && x < FIRMWARE_PREVU.voie ? i : -1)).filter((i) => i >= 0);
    if (vieilles.length) return { etat: 'maj', texte: `Firmware ${nom} ${v.fw} à jour ; ${vieilles.length} voie(s) à mettre à jour.` };
  }
  return { etat: 'ok', texte: `Firmware ${nom} ${v.fw}, compatible.` };
}
