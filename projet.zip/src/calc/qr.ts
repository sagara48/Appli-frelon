/** QR code des tags : contenu « frelons://tag/12 » (un appareil photo ordinaire ouvre aussi l'appli sur ce tag).
 *  Matrice par qrcode-generator (niveau de correction M : supporte une étiquette un peu salie ou rayée). */
import qrcode from 'qrcode-generator';

export const lienTag = (id: number) => `frelons://tag/${id}`;
/** Numéro du tag lu dans un QR (« frelons://tag/12 », ou un simple « 12 » / « TAG 012 ») ; null sinon. */
export function tagDuQr(texte: string): number | null {
  const t = texte.trim();
  const m = t.match(/^frelons:\/\/+tag\/(\d{1,3})\b/i) ?? t.match(/^(?:tag\s*)?(\d{1,3})$/i);
  if (!m) return null;
  const n = Number(m[1]);
  return n >= 0 && n <= 255 ? n : null;
}

/** Modules du QR (true = noir), carré n × n. */
export function matriceQr(texte: string): boolean[][] {
  const q = qrcode(0, 'M');
  q.addData(texte);
  q.make();
  const n = q.getModuleCount();
  return Array.from({ length: n }, (_, r) => Array.from({ length: n }, (_, c) => q.isDark(r, c)));
}

/** Chemin SVG des modules noirs (unité = 1 module, marge comprise : décalage de `marge`). */
export function cheminQr(m: boolean[][], marge = 2): string {
  const d: string[] = [];
  m.forEach((ligne, r) => {
    let c = 0;
    while (c < ligne.length) {
      if (!ligne[c]) { c++; continue; }
      let f = c; while (f < ligne.length && ligne[f]) f++;
      d.push(`M${c + marge} ${r + marge}h${f - c}v1h${c - f}z`);
      c = f;
    }
  });
  return d.join('');
}

/** Liste de numéros « 1-12, 20, 31 » → [1..12, 20, 31] (au plus 120, sans doublon). */
export function listeNumeros(texte: string): number[] {
  const r = new Set<number>();
  for (const p of texte.split(/[,; ]+/).filter(Boolean)) {
    const m = p.match(/^(\d{1,3})(?:-(\d{1,3}))?$/);
    if (!m) continue;
    const a = Number(m[1]), b = m[2] !== undefined ? Number(m[2]) : a;
    for (let i = Math.min(a, b); i <= Math.max(a, b) && r.size < 120; i++) if (i <= 255) r.add(i);
  }
  return [...r].sort((x, y) => x - y);
}

/** Planche d'étiquettes A4 à imprimer (expo-print), taille du QR en mm.
 *  boite : étiquettes carrées de 13 mm pour le fond des cases de la boîte de rangement (QR de 12 mm, trait de coupe),
 *  numéro imprimé au-dessus, hors du carré (il sert à coller chaque étiquette dans la bonne case, puis part à la coupe). */
export function planchePdf(ids: number[], tailleMm: number, idTag: (n: number) => string, boite = false): string {
  const svg = (id: number, mm: number) => {
    const m = matriceQr(lienTag(id)), n = m.length + 4;
    return `<svg viewBox="0 0 ${n} ${n}" width="${mm}mm" height="${mm}mm" shape-rendering="crispEdges"><rect width="${n}" height="${n}" fill="#fff"/><path d="${cheminQr(m)}" fill="#000"/></svg>`;
  };
  const cases = boite
    ? ids.map((id) => `<div class="b"><div class="bn">${id}</div><div class="bq">${svg(id, 12)}</div></div>`).join('')
    : ids.map((id) => `<div class="e">${svg(id, tailleMm)}<div class="n">TAG ${idTag(id)}</div></div>`).join('');
  const police = Math.max(6, Math.round(tailleMm * 0.28));
  const titre = boite
    ? 'Étiquettes du fond des cases de la boîte de rangement — couper sur le trait (13 mm), coller chaque carré au fond de la case du même numéro.'
    : 'Étiquettes QR des tags — à découper et coller dans la case de chaque tag de la boîte de rangement (adhésif transparent par-dessus).';
  return `<!doctype html><html><head><meta charset="utf-8"><style>
@page { size: A4; margin: 10mm; }
body { margin: 0; font-family: Arial, sans-serif; }
.g { display: flex; flex-wrap: wrap; gap: ${boite ? '3mm 6mm' : '4mm'}; }
.e { width: ${tailleMm + 4}mm; padding: 1.5mm; border: 0.2mm dashed #999; text-align: center; page-break-inside: avoid; }
.n { font-size: ${police}pt; font-weight: bold; margin-top: 0.8mm; letter-spacing: 0.2pt; }
.b { width: 13mm; text-align: center; page-break-inside: avoid; }
.bn { font-size: 7pt; color: #555; height: 3.5mm; }
.bq { width: 13mm; height: 13mm; box-sizing: border-box; border: 0.15mm solid #888; display: flex; align-items: center; justify-content: center; }
h1 { font-size: 10pt; font-weight: normal; color: #555; margin: 0 0 4mm; }
</style></head><body><h1>${titre}</h1><div class="g"${boite ? ' style="width: 94mm"' : ''}>${cases}</div></body></html>`;
}
