/** Rappels par notification : calculés à partir du carnet, reprogrammés à chaque changement. Un rappel en retard
 *  revient chaque jour à la même heure jusqu'à ce que la chose soit faite. Sans dépendance au téléphone (testé). */
import type { FicheTag, Nid, Piege } from '../db';
import { dateControle } from './intervention';
import { dernierReleve, raisonRecharge } from './saison';

export type Rappel = { date: number; titre: string; texte: string; url: string };
export type ReglagesRappels = { controleJours: number; releverJours: number; rechargeSeuilPct: number; rechargeJours: number; silenceJours: number; heureMatin: number; heureSoir: number };
const JOUR = 86400000;

/** « heure » (h locale) du jour de t ; si c'est déjà passé, le premier jour suivant où ce n'est pas passé. */
export function prochaine(t: number, heure: number, maintenant: number): number {
  const d = new Date(t); d.setHours(Math.floor(heure), Math.round((heure % 1) * 60), 0, 0);
  while (d.getTime() < maintenant) d.setDate(d.getDate() + 1); // setDate : juste même au changement d'heure
  return d.getTime();
}

export function rappels(nids: Nid[], pieges: Piege[], fiches: FicheTag[], R: ReglagesRappels, maintenant: number, numero: (id: number) => number = (id) => id): Rappel[] {
  const l: Rappel[] = [];
  for (const n of nids) {
    if (n.etat !== 'traite' || !n.traite_ms) continue;
    l.push({ date: prochaine(dateControle(n.traite_ms, R.controleJours), R.heureMatin, maintenant), titre: 'Contrôle de nid à faire',
      texte: `Nid n° ${numero(n.id)} traité le ${new Date(n.traite_ms).toLocaleDateString('fr-FR')} : vérifier qu'il est mort.`, url: `/nid/${n.id}` });
  }
  for (const p of pieges) {
    if (p.retire_ms) continue;
    const depuis = dernierReleve(p) ?? p.pose_ms;
    if (!depuis) continue;
    l.push({ date: prochaine(depuis + R.releverJours * JOUR, R.heureMatin, maintenant), titre: 'Piège à relever', texte: `${p.nom || `Piège ${p.id}`} : dernier relevé il y a ${Math.max(R.releverJours, Math.round((maintenant - depuis) / JOUR))} jours.`, url: '/pieges' });
  }
  const recharger = fiches.filter((f) => f.etat !== 'pose' && f.etat !== 'perdu' && raisonRecharge(f, maintenant, R.rechargeSeuilPct, R.rechargeJours) !== null);
  if (recharger.length) {
    l.push({ date: prochaine(maintenant, R.heureSoir, maintenant), titre: 'Tags à recharger', texte: `${recharger.length} tag${recharger.length > 1 ? 's' : ''} à poser sur le chargeur : ${recharger.slice(0, 8).map((f) => f.id).join(', ')}${recharger.length > 8 ? '…' : ''}.`, url: '/tags' });
  }
  for (const f of fiches) {
    if (f.etat !== 'pose') continue;
    const vu = Math.max(f.vu_ms ?? 0, f.pose_ms ?? 0);
    if (!vu) continue;
    l.push({ date: prochaine(vu + R.silenceJours * JOUR, R.heureMatin, maintenant), titre: 'Tag sans nouvelles', texte: `Tag ${f.id} posé et plus entendu depuis ${R.silenceJours} jour${R.silenceJours > 1 ? 's' : ''} : itinéraire par ses derniers contacts dans Mes tags.`, url: '/tags?filtre=silence' });
  }
  return l.sort((a, b) => a.date - b.date).slice(0, 40);
}
