/** Approche par la route : point de route carrossable le plus proche du nid (données OpenStreetMap), pour s'y faire
 *  guider en voiture puis finir à pied. Les petites routes et chemins comptent, mais une route revêtue est préférée
 *  quand elle n'est guère plus loin (30 m). Sans dépendance au téléphone (testé). */
import { capDeg, distM } from './geo';

export type Voie = { type: string; nom?: string; points: { lat: number; lon: number }[] };
export type Approche = { lat: number; lon: number; distM: number; capVersNid: number; type: string; nom?: string };
export const REVETUES = ['motorway_link', 'trunk', 'primary', 'secondary', 'tertiary', 'unclassified', 'residential', 'living_street', 'service'];
export const CARROSSABLES = [...REVETUES, 'track'];

/** Point le plus proche d'un segment (approximation plane locale). */
export function surSegment(p: { lat: number; lon: number }, a: { lat: number; lon: number }, b: { lat: number; lon: number }) {
  const k = Math.cos((p.lat * Math.PI) / 180);
  const ax = a.lon * k, ay = a.lat, bx = b.lon * k, by = b.lat, px = p.lon * k, py = p.lat;
  const dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
  const t = l2 > 0 ? Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / l2)) : 0;
  return { lat: ay + t * dy, lon: (ax + t * dx) / k };
}

export function approche(nid: { lat: number; lon: number }, voies: Voie[]): Approche | null {
  let meilleur: Approche | null = null, revetue: Approche | null = null;
  for (const v of voies) {
    if (!CARROSSABLES.includes(v.type)) continue;
    for (let i = 1; i < v.points.length; i++) {
      const q = surSegment(nid, v.points[i - 1], v.points[i]);
      const d = distM(nid.lat, nid.lon, q.lat, q.lon);
      const a: Approche = { ...q, distM: Math.round(d), capVersNid: Math.round(capDeg(q.lat, q.lon, nid.lat, nid.lon)), type: v.type, nom: v.nom };
      if (!meilleur || d < meilleur.distM) meilleur = a;
      if (REVETUES.includes(v.type) && (!revetue || d < revetue.distM)) revetue = a;
    }
  }
  return revetue && meilleur && revetue.distM <= meilleur.distM + 30 ? revetue : meilleur;
}

/** Lien Google Maps : itinéraire en voiture jusqu'au point d'approche. */
export const lienApproche = (a: { lat: number; lon: number }) => `https://www.google.com/maps/dir/?api=1&destination=${a.lat.toFixed(6)},${a.lon.toFixed(6)}&travelmode=driving`;
export const texteApproche = (a: Approche) => `${a.nom ? `${a.nom}, ` : ''}${a.type === 'track' ? 'chemin' : 'route'} à ${a.distM} m du nid ; ensuite à pied, cap ${a.capVersNid}°`;
