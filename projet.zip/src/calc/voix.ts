/** Commandes vocales : phrase reconnue → commande. Pur (testé dans scripts/test_services.ts).
 *  Les phrases sont courtes et tolérantes (accents, articles, « frelon » devant facultatif ou exigé). */
export type CommandeVoix =
  | { cmd: 'parti' } | { cmd: 'revenu' } | { cmd: 'lacher' } | { cmd: 'nid' }
  | { cmd: 'recherche' } | { cmd: 'finRecherche' } | { cmd: 'tour' } | { cmd: 'point' }
  | { cmd: 'ouNid' } | { cmd: 'signal' } | { cmd: 'tag'; tag: number } | { cmd: 'carte' }
  | { cmd: 'aide' } | { cmd: 'stop' } | { cmd: 'voiture' };

const NOMBRES: Record<string, number> = {
  zero: 0, un: 1, une: 1, deux: 2, trois: 3, quatre: 4, cinq: 5, six: 6, sept: 7, huit: 8, neuf: 9, dix: 10, onze: 11, douze: 12,
  treize: 13, quatorze: 14, quinze: 15, seize: 16, 'dix sept': 17, 'dix huit': 18, 'dix neuf': 19, vingt: 20,
};

/** Minuscules, sans accents ni ponctuation, espaces simples. */
export function normaliser(t: string): string {
  return t.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
}

/** Liste des phrases, pour l'aide à l'écran et « aide » à voix haute. */
export const PHRASES: [string, string][] = [
  ['« Parti » / « Revenu »', 'chrono à l\'appât du tag choisi'],
  ['« Lâcher ici »', 'ouvre un appât à votre position'],
  ['« Nid trouvé »', 'note le nid à votre position'],
  ['« Mode recherche » / « Fin de recherche »', 'ordre au tag suivi'],
  ['« Fais un tour » / « Ajoute le point »', 'tour sur soi-même du portatif'],
  ['« Où est le nid ? »', 'distance et direction annoncées'],
  ['« Signal »', 'niveau et distance du tag suivi'],
  ['« Tag 12 »', 'change de tag'],
  ['« Carte »', 'mini-carte sur le portatif'],
  ['« Retour à la voiture »', 'flèche du portatif vers la voiture'],
  ['« Arrête d\'écouter »', 'coupe le micro'],
];

/**
 * Reconnaît une commande. motCle : la phrase doit commencer par « frelon » (évite qu'une conversation déclenche
 * une commande). Renvoie null si rien ne correspond.
 */
export function analyserPhrase(texte: string, motCle = false): CommandeVoix | null {
  let t = normaliser(texte);
  const appel = /^(frelons?|frelon s)\b\s*/;
  if (appel.test(t)) t = t.replace(appel, '');
  else if (motCle) return null;
  if (!t) return null;
  t = ` ${t} `;
  if (/ (arrete|stop|coupe|fin) (d |de |l )*(ecoute|ecouter|micro) | tais toi /.test(t)) return { cmd: 'stop' };
  if (/ (aide|que (puis je|peux tu|dois je) dire|commandes) /.test(t)) return { cmd: 'aide' };
  if (/ (fin|arrete|stop|termine)( de| la| le)* (recherche|mode recherche) /.test(t)) return { cmd: 'finRecherche' };
  if (/ mode recherche | (lance|active|demarre)( la| le)* recherche /.test(t)) return { cmd: 'recherche' };
  const mt = t.match(/ (tag|balise) (numero )?([a-z0-9]+(?: (?:sept|huit|neuf))?) /);
  if (mt) {
    const n = /^\d+$/.test(mt[3]) ? Number(mt[3]) : NOMBRES[mt[3]];
    if (n !== undefined && n >= 0 && n <= 255) return { cmd: 'tag', tag: n };
  }
  if (/ (retour|retourner|rentrer)( a| à)?( la)? voiture | ou est (la )?voiture /.test(t)) return { cmd: 'voiture' };
  if (/ (ou est|ou se trouve|c est ou|distance)( le| du)* nid | ou est il /.test(t)) return { cmd: 'ouNid' };
  if (/ (nid trouve|trouve le nid|j ai trouve|nid ici|le nid est la) /.test(t)) return { cmd: 'nid' };
  if (/ (lache|lacher|lachez|lache ici|appat ici|pose l appat) /.test(t)) return { cmd: 'lacher' };
  if (/ (ajoute|enregistre|note)( le| un)* (point|releve) /.test(t)) return { cmd: 'point' };
  if (/ (fais|faire|lance|nouveau|commence)( un| le)* tour | tour sur (moi|place) /.test(t)) return { cmd: 'tour' };
  if (/ (il |elle )?(est )?(revenu|revenue|revient) | retour /.test(t)) return { cmd: 'revenu' };
  if (/ (il |elle )?(est )?(parti|partie|part) | depart | s en va /.test(t)) return { cmd: 'parti' };
  if (/ (signal|niveau|combien) /.test(t)) return { cmd: 'signal' };
  if (/ (mini )?carte /.test(t)) return { cmd: 'carte' };
  return null;
}

/** Phrase à annoncer pour la direction du nid. */
export function phraseNid(d: number, cap: number, err: number, cardinal: string): string {
  const dist = d < 1000 ? `${Math.round(d / (d < 100 ? 5 : 10)) * (d < 100 ? 5 : 10)} mètres` : `${(d / 1000).toFixed(1).replace('.', ',')} kilomètres`;
  return `Nid à ${dist}, cap ${Math.round(cap)}, ${cardinalParle(cardinal)}, à plus ou moins ${Math.round(err)} mètres`;
}
export function cardinalParle(c: string): string {
  return ({ N: 'nord', NE: 'nord-est', E: 'est', SE: 'sud-est', S: 'sud', SO: 'sud-ouest', O: 'ouest', NO: 'nord-ouest' } as Record<string, string>)[c] ?? c;
}
