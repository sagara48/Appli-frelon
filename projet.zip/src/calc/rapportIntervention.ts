/** Mise en page HTML du compte rendu d'intervention (modèle FREDON) et du registre des traitements : converties en PDF par l'appli.
 *  Sans dépendance au téléphone (aperçu possible dans un navigateur). */
import { classeHauteur, dateControle, libelleType, totauxProduits, TRAITEMENTS, TYPES_INTER, type Intervention, type LigneRegistre } from './intervention';

export type Entreprise = { entreprise: string; structure: string; adresseEntreprise: string; telEntreprise: string; certibiocide: string; consignes: string; controleJours: number };
type NidLieu = { lat: number; lon: number; support: string };
const echapper = (s: string) => (s ?? '').replace(/[<>&"']/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' })[c]!);
const SIGNATURE_VB_PDF = '0 0 300 120';
const coche = (oui: boolean) => (oui ? '&#9746;' : '&#9744;');
const STYLE_DOC = `body{font-family:sans-serif;color:#14202E;padding:22px;font-size:12.5px} h1{font-size:20px;margin:0 0 2px} .s{color:#5B6672;margin:0 0 14px}
  table{border-collapse:collapse;width:100%;margin-bottom:12px} th{text-align:left;width:34%;color:#5B6672;font-weight:normal;padding:5px 8px;border-bottom:1px solid #DDE1D8;vertical-align:top}
  td{padding:5px 8px;border-bottom:1px solid #DDE1D8;vertical-align:top} h2{font-size:12px;text-transform:uppercase;letter-spacing:1px;color:#5B6672;margin:14px 0 4px}
  .ent{display:flex;justify-content:space-between;border-bottom:2px solid #14202E;padding-bottom:8px;margin-bottom:14px} .ent div{line-height:1.45}
  img.ph{width:31%;margin:1%;border-radius:4px} .cases span{display:inline-block;margin-right:14px} .sig{display:flex;gap:16px} .sig>div{flex:1;border:1px solid #DDE1D8;border-radius:6px;padding:8px;min-height:110px}
  .suites{background:#F2F4EF;border-radius:6px;padding:10px 12px;margin-top:12px;line-height:1.5}`;

/** Compte rendu d'intervention à remettre au client (modèle FREDON) : PDF partagé. */

export function compteRenduHtml(n: NidLieu, numero: number, i: Intervention, p: Entreprise): string {
  const l = (k: string, v: string) => (v ? `<tr><th>${echapper(k)}</th><td>${echapper(v)}</td></tr>` : '');
  const ph = (t: string, a: string[]) => (a.length ? `<h2>${t}</h2>${a.map((u) => `<img class="ph" src="${u}" />`).join('')}` : '');
  const sig = i.signature ? `<svg viewBox="${SIGNATURE_VB_PDF}" width="100%" height="90"><path d="${echapper(i.signature)}" stroke="#14202E" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>` : '';
  const traitement = TRAITEMENTS.includes(i.type);
  const html = `<html><head><meta charset="utf-8"><style>${STYLE_DOC}</style></head><body>
    <div class="ent"><div><b>${echapper(p.entreprise || p.structure || 'Intervention frelons asiatiques')}</b><br>${echapper(p.adresseEntreprise)}${p.telEntreprise ? `<br>Tél. ${echapper(p.telEntreprise)}` : ''}</div>
      <div style="text-align:right">${p.certibiocide || i.certibiocide ? `Certibiocide n° ${echapper(i.certibiocide || p.certibiocide)}` : ''}</div></div>
    <h1>Compte rendu d'intervention</h1>
    <p class="s">Nid de frelons asiatiques n° ${numero} · ${new Date(i.t).toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' })}</p>
    <h2>Lieu</h2><table>
      ${l('Client ou riverain', i.client.nom)}${l('Adresse', [i.client.adresse, i.client.commune].filter(Boolean).join(', '))}${l('Téléphone', i.client.tel)}
      ${l('Coordonnées GPS', `${n.lat.toFixed(6)} N · ${n.lon.toFixed(6)} E`)}${l('Support du nid', n.support)}
    </table>
    <h2>Intervention</h2>
    <p class="cases">${TYPES_INTER.map(([k, t]) => `<span>${coche(i.type === k)} ${echapper(t)}</span>`).join('')}</p>
    <table>
      ${l('Hauteur du nid', i.hauteurM !== null ? `${String(i.hauteurM).replace('.', ',')} m (${classeHauteur(i.hauteurM)})` : '')}${l('Diamètre du nid', i.diametreCm !== null ? `${i.diametreCm} cm` : '')}
      ${l('Méthode', i.methode)}
      ${traitement ? l('Produit', i.produit ? [i.produit, i.substance, i.amm && `AMM ${i.amm}`, i.lot && `lot ${i.lot}`].filter(Boolean).join(' · ') : 'aucun (méthode mécanique)') : ''}
      ${traitement && i.quantiteG !== null ? l('Quantité appliquée', `${String(i.quantiteG).replace('.', ',')} g`) : ''}
      ${traitement ? l('Nid décroché et emporté', i.nidRetire ? 'oui' : 'non') : ''}
      ${i.type === 'controle' ? l('Résultat du contrôle', i.resultat === 'mort' ? 'nid mort, plus d\'activité' : i.resultat === 'actif' ? 'encore actif : nouveau traitement prévu' : '') : ''}
      ${l('Météo', i.meteo)}${l('Commentaires', i.note)}
    </table>
    ${ph('Avant', i.photosAvant)}${ph('Après', i.photosApres)}
    <h2>Signatures</h2>
    <div class="sig"><div><b>Opérateur</b><br>${echapper(i.operateur)}${i.certibiocide ? `<br>Certibiocide n° ${echapper(i.certibiocide)}` : ''}</div>
      <div><b>Client ou riverain</b><br>${i.present ? `${coche(true)} certifie que l'intervention a été réalisée${sig}` : `${coche(true)} absent lors de l'intervention`}</div></div>
    ${traitement ? `<div class="suites"><b>Suites de l'intervention</b><br>${echapper(p.consignes)}<br>Contrôle prévu vers le ${new Date(dateControle(i.t, p.controleJours)).toLocaleDateString('fr-FR')}.${p.telEntreprise ? ` Nous contacter : ${echapper(p.telEntreprise)}.` : ''}</div>` : ''}
  </body></html>`;
  return html;
}

export function registreHtml(lignes: LigneRegistre[], an: number, p: Entreprise): string {
  const tot = totauxProduits(lignes);
  const rows = lignes.map(({ nid, inter: i }) => `<tr><td>${new Date(i.t).toLocaleDateString('fr-FR')}</td><td>${nid}</td><td>${echapper(i.client.commune)}</td><td>${echapper(libelleType(i.type))}</td>
    <td>${echapper(i.methode)}</td><td>${echapper([i.produit, i.amm && `AMM ${i.amm}`, i.lot && `lot ${i.lot}`].filter(Boolean).join(' · '))}</td><td style="text-align:right">${i.quantiteG ?? ''}</td>
    <td>${i.nidRetire ? 'oui' : ''}</td><td>${echapper([i.operateur, i.certibiocide].filter(Boolean).join(' · '))}</td></tr>`).join('');
  const html = `<html><head><meta charset="utf-8"><style>@page{size:A4 landscape;margin:12mm} ${STYLE_DOC} td,th{font-size:10.5px;width:auto} thead th{color:#14202E;font-weight:bold;border-bottom:2px solid #14202E}</style></head><body>
    <div class="ent"><div><b>${echapper(p.entreprise || p.structure || '')}</b><br>${echapper(p.adresseEntreprise)}</div><div style="text-align:right">${p.certibiocide ? `Certibiocide n° ${echapper(p.certibiocide)}` : ''}</div></div>
    <h1>Registre des traitements biocides ${an}</h1><p class="s">Destructions de nids de frelons asiatiques · ${lignes.length} intervention${lignes.length > 1 ? 's' : ''} · édité le ${new Date().toLocaleDateString('fr-FR')}</p>
    <table><thead><tr><th>Date</th><th>Nid</th><th>Commune</th><th>Intervention</th><th>Méthode</th><th>Produit</th><th>Qté (g)</th><th>Retiré</th><th>Opérateur</th></tr></thead><tbody>${rows}</tbody></table>
    <h2>Totaux par produit</h2><table>${tot.map((t) => `<tr><th>${echapper(t.produit)}</th><td>${t.n} traitement${t.n > 1 ? 's' : ''} · ${String(Math.round(t.g * 10) / 10).replace('.', ',')} g</td></tr>`).join('')}</table>
  </body></html>`;
  return html;
}
