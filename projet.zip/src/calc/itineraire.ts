/** Itinéraire pour retrouver des tags sans nouvelles : leurs derniers contacts dans l'ordre du plus proche voisin
 *  depuis la position de départ, en lien Google Maps (10 étapes au plus). Sans dépendance au téléphone (testé). */
import { distM } from './geo';

export type Etape = { lat: number; lon: number; nom: string };
export function ordreVisite(depart: { lat: number; lon: number } | null, etapes: Etape[]): Etape[] {
  const reste = [...etapes], r: Etape[] = [];
  let ici: { lat: number; lon: number } = depart ?? reste[0];
  while (reste.length) {
    let k = 0;
    reste.forEach((x, i) => { if (distM(ici.lat, ici.lon, x.lat, x.lon) < distM(ici.lat, ici.lon, reste[k].lat, reste[k].lon)) k = i; });
    const x = reste.splice(k, 1)[0]; r.push(x); ici = x;
  }
  return r;
}
/** Lien Google Maps (itinéraire en voiture) ; null sans étape. */
export function lienItineraire(depart: { lat: number; lon: number } | null, etapes: Etape[]): string | null {
  const l = ordreVisite(depart, etapes).slice(0, 10);
  if (!l.length) return null;
  const f = (p: { lat: number; lon: number }) => `${p.lat.toFixed(6)},${p.lon.toFixed(6)}`;
  const dest = l[l.length - 1], via = l.slice(0, -1);
  return `https://www.google.com/maps/dir/?api=1${depart ? `&origin=${f(depart)}` : ''}&destination=${f(dest)}${via.length ? `&waypoints=${via.map(f).join('%7C')}` : ''}&travelmode=driving`;
}
