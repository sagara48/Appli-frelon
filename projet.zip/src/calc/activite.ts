/** « Au nid » ou « en chasse » : le tag (firmware 4, carte V4.1) envoie un octet d'état dans chaque trame.
 *  bit 7 = dans le noir (dans le nid), bits 0-6 = température + 40 °C (0 = inconnue). 0 = tag sans cet octet.
 *  On en déduit les sorties de chasse : passage nid → dehors (départ) puis dehors → nid (retour).
 *  Sans dépendance au téléphone (testé). */

export type EtatTag = { nid: boolean; tempC: number | null };
/** Octet d'état → au nid / température ; null pour un tag ancien (octet absent ou nul). */
export function decoderEtat(b: number | null | undefined): EtatTag | null {
  if (!b || !Number.isFinite(b) || b < 0 || b > 255) return null;
  const t = b & 0x7f;
  return { nid: (b & 0x80) !== 0, tempC: t ? t - 40 : null };
}

export type Sortie = { debut: number; fin: number | null };
/** Relevé espacé (5 min, ou à chaque changement) : sert au contrôle d'un traitement par le tag. */
export type ReleveT = { t: number; c: number | null; nid: boolean };
export type Activite = { nid: boolean; depuisMs: number; vuMs: number; tempC: number | null; sorties: Sortie[]; releves?: ReleveT[] };
const MAX_RELEVES = 600; // ~2 jours à 5 min
function ajouterReleveT(l: ReleveT[] | undefined, e: EtatTag, t: number): ReleveT[] | undefined {
  const der = l?.[l.length - 1];
  if (der && der.nid === e.nid && t - der.t < 5 * 60000) return l;
  return [...(l ?? []), { t, c: e.tempC, nid: e.nid }].slice(-MAX_RELEVES);
}
const MAX_SORTIES = 50;
/** Au-delà de ce silence, on ne sait plus ce qu'il s'est passé : la sortie en cours n'est pas comptée. */
const TROU_MS = 20 * 60000;

/** Ajoute une trame (état décodé, heure) ; renvoie la même activité si rien n'a changé d'utile. */
export function noterEtat(a: Activite | null | undefined, e: EtatTag, t: number): Activite {
  if (!a) return { nid: e.nid, depuisMs: t, vuMs: t, tempC: e.tempC, sorties: [], releves: [{ t, c: e.tempC, nid: e.nid }] };
  if (t < a.vuMs) return a; // trame plus ancienne (deux sources)
  const trou = t - a.vuMs > TROU_MS;
  if (e.nid === a.nid) {
    if (e.tempC === a.tempC && t - a.vuMs < 10000) return a; // pas de nouveau à moins de 10 s près
    return { ...a, vuMs: t, tempC: e.tempC ?? a.tempC, releves: ajouterReleveT(a.releves, e, t) };
  }
  let sorties = a.sorties;
  if (!e.nid) sorties = [...sorties, { debut: trou ? t : a.vuMs + Math.round((t - a.vuMs) / 2), fin: null }].slice(-MAX_SORTIES); // départ
  else {
    const der = sorties[sorties.length - 1];
    if (der && der.fin === null) sorties = [...sorties.slice(0, -1), trou ? { ...der, fin: -1 } : { ...der, fin: t }]; // retour (-1 = durée inconnue)
  }
  return { nid: e.nid, depuisMs: t, vuMs: t, tempC: e.tempC ?? a.tempC, sorties, releves: ajouterReleveT(a.releves, e, t) };
}

export type BilanActivite = { sortiesJour: number; dureeMedianeMin: number | null; derniereMin: number | null; enCours: boolean };
/** Sorties du jour (depuis minuit), durée médiane des sorties terminées, durée de la dernière. */
export function bilanActivite(a: Activite | null | undefined, maintenant: number): BilanActivite | null {
  if (!a) return null;
  const minuit = new Date(maintenant); minuit.setHours(0, 0, 0, 0);
  const jour = a.sorties.filter((s) => s.debut >= minuit.getTime());
  const finies = a.sorties.filter((s) => s.fin !== null && s.fin > 0).map((s) => ((s.fin as number) - s.debut) / 60000);
  const tri = [...finies].sort((x, y) => x - y), m = tri.length >> 1;
  const med = !tri.length ? null : tri.length % 2 ? tri[m] : (tri[m - 1] + tri[m]) / 2;
  const der = [...a.sorties].reverse().find((s) => s.fin !== null && s.fin > 0);
  return {
    sortiesJour: jour.length,
    dureeMedianeMin: med === null ? null : Math.round(med),
    derniereMin: der ? Math.round(((der.fin as number) - der.debut) / 60000) : null,
    enCours: !a.nid,
  };
}

/** Texte court : « Au nid depuis 12 min » / « En chasse depuis 3 min ». `null` si l'information est trop vieille (> 10 min sans trame). */
export function texteActivite(a: Activite | null | undefined, maintenant: number): string | null {
  if (!a || maintenant - a.vuMs > 10 * 60000) return null;
  const min = Math.max(0, Math.round((maintenant - a.depuisMs) / 60000));
  const d = min < 1 ? "à l'instant" : min < 90 ? `depuis ${min} min` : `depuis ${Math.floor(min / 60)} h ${String(min % 60).padStart(2, '0')}`;
  return `${a.nid ? 'Au nid' : 'En chasse'} ${d}${a.tempC !== null ? ` · ${a.tempC} °C` : ''}`;
}

/* ---------- remontée des erreurs ---------- */
/** Cause de redémarrage (registre RESETREAS, vu par hwinfo de Zephyr) → texte. */
export function causeRedemarrage(r: number): string {
  if (r & 0x10) return 'chien de garde (blocage logiciel)';
  if (r & 0x100) return 'blocage du processeur';
  if (r & 0x4) return 'tension trop basse';
  if (r & 0x2) return 'redémarrage logiciel';
  if (r & 0x1) return 'bouton reset';
  if (r & 0x80) return 'réveil';
  if (r & 0x8) return 'mise sous tension';
  return r ? 'autre' : 'inconnue';
}
/** Une cause qui mérite d'être signalée (pas une mise sous tension ou une mise à jour normale). */
export const causeAnormale = (r: number) => (r & (0x10 | 0x100 | 0x4)) !== 0;

/* ---------- tag immobile ---------- */
/** Minutes de jour (8 h - 20 h, heure du téléphone) entre deux instants. */
export function minutesDeJour(debut: number, fin: number): number {
  let m = 0;
  for (let t = debut; t < fin; t += 60000) { const h = new Date(t).getHours(); if (h >= 8 && h < 20) m++; }
  return m;
}
/** Tag toujours entendu mais sans le moindre passage nid ↔ dehors depuis au moins `heures` heures de jour :
 *  tombé du frelon, ou frelon mort (au nid ou à terre). Renvoie la durée en minutes, ou null. */
export function immobileDepuis(a: Activite | null | undefined, maintenant: number, heures = 3): number | null {
  if (!a || maintenant - a.vuMs > 15 * 60000) return null;           // il faut l'entendre encore
  const debut = Math.max(a.depuisMs, maintenant - 48 * 3600000);
  return minutesDeJour(debut, maintenant) >= heures * 60 ? Math.round((maintenant - a.depuisMs) / 60000) : null;
}

/* ---------- contrôle d'un traitement par le tag ---------- */
export type VerdictControle = 'inconnu' | 'attente' | 'actif' | 'mort' | 'doute';
export type Controle = { verdict: VerdictControle; texte: string; cAvant: number | null; cApres: number | null; sortiesApres: number; heures: number };
const med = (v: number[]) => { if (!v.length) return null; const s = [...v].sort((a, b) => a - b), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };
/** Un frelon tagué vivant sort du nid ; au nid, le tag est au chaud (25-30 °C dans un nid actif).
 *  Après le traitement (`tT`) : plus de sortie, et un tag dans le noir qui refroidit (≤ 18 °C, ou 6 °C de moins qu'avant)
 *  → nid probablement mort. Il faut au moins 6 h de recul et le tag encore entendu. */
export function controleTraitement(a: Activite | null | undefined, tT: number, maintenant: number): Controle {
  const heures = Math.max(0, Math.round((maintenant - tT) / 3600000));
  const vide = { cAvant: null, cApres: null, sortiesApres: 0, heures };
  if (!a || a.vuMs < tT + 2 * 3600000) return { ...vide, verdict: 'inconnu', texte: 'Tag pas entendu depuis le traitement : passez près du nid avec le portatif ou la voiture.' };
  const r = a.releves ?? [];
  const cAvant = med(r.filter((x) => x.nid && x.c !== null && x.t < tT && x.t >= tT - 48 * 3600000).map((x) => x.c as number));
  const apres = r.filter((x) => x.nid && x.c !== null && x.t >= tT + 2 * 3600000);
  const recents = apres.filter((x) => x.t >= a.vuMs - 2 * 3600000);
  const cApres = med(recents.map((x) => x.c as number));
  const sortiesApres = a.sorties.filter((s) => s.debut > tT + 3600000).length;
  const base = { cAvant, cApres: cApres === null ? null : Math.round(cApres), sortiesApres, heures };
  if (sortiesApres > 0) return { ...base, verdict: 'actif', texte: `Le frelon tagué est ressorti ${sortiesApres} fois depuis le traitement : nid probablement encore actif.` };
  if (a.vuMs - tT < 6 * 3600000) return { ...base, verdict: 'attente', texte: `Pas de sortie depuis ${heures} h ; attendre au moins 6 h pour conclure.` };
  if (!a.nid) return { ...base, verdict: 'doute', texte: 'Le tag ne bouge plus mais il est à la lumière : frelon mort hors du nid, ou tag tombé ?' };
  const froid = cApres !== null && (cApres <= 18 || (cAvant !== null && cApres <= cAvant - 6));
  if (froid) return { ...base, verdict: 'mort', texte: `Aucune sortie depuis ${heures} h et le tag a refroidi dans le nid (${Math.round(cApres!)} °C${cAvant !== null ? `, ${Math.round(cAvant)} °C avant` : ''}) : nid probablement mort.` };
  return { ...base, verdict: 'attente', texte: `Aucune sortie depuis ${heures} h, mais le nid reste tiède${cApres !== null ? ` (${Math.round(cApres)} °C)` : ''} : à revoir.` };
}
