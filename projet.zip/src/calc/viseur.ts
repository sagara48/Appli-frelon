/** Hauteur du nid par visée au téléphone : l'appareil photo visé sur le nid donne l'angle de hausse (accéléromètre)
 *  et la direction (boussole + accéléromètre), le GPS la position.
 *  - Deux visées d'endroits assez écartés (≥ 15° vues du nid) : leurs directions se croisent sur le pied du nid → distance
 *    de chaque visée → hauteur = distance × tan(hausse) + hauteur des yeux. La moyenne des deux est retenue.
 *  - Sinon, la position du nid connue (fiche) donne la distance ; ou mieux, une distance mesurée au pied de l'arbre (pas).
 *  Terrain supposé à peu près plat entre vous et l'arbre. Calcul pur (testé). */
import { capDeg, D2R, distM, KY, kxOf } from './geo';

export type V3 = { x: number; y: number; z: number };
export type Visee = { lat: number; lon: number; cap: number; hausse: number; precision?: number; t: number; photo?: string };
export const OEIL_M = 1.5;
/** Déclinaison magnétique (Massif central, 2026 : ~ +2° est). */
export const DECLINAISON = 2;

const norme = (v: V3) => Math.hypot(v.x, v.y, v.z) || 1;
const croix = (a: V3, b: V3): V3 => ({ x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x });

/** Orientation de l'axe de l'appareil photo arrière (−Z de l'appareil) : hausse au-dessus de l'horizon et cap vrai.
 *  g : accélération gravité comprise (vers le haut quand l'appareil est immobile, convention Android/W3C),
 *  m : champ magnétique, mêmes axes. */
export function orientationCamera(g: V3, m: V3): { hausse: number; cap: number } {
  const n = norme(g), u = { x: g.x / n, y: g.y / n, z: g.z / n };
  const hausse = Math.asin(Math.max(-1, Math.min(1, -u.z))) / D2R;
  const est = croix(m, u), ne = norme(est), E = { x: est.x / ne, y: est.y / ne, z: est.z / ne };
  const N = croix(u, E);
  const cap = (Math.atan2(-E.z, -N.z) / D2R + DECLINAISON + 360) % 360;
  return { hausse, cap };
}

/** Intersection des directions de deux visées (mètres locaux) ; null si elles sont trop parallèles (< 15°) ou se croisent derrière. */
export function croiserVisees(a: Visee, b: Visee): { lat: number; lon: number } | null {
  const kx = kxOf(a.lat);
  const bx = (b.lon - a.lon) * kx, by = (b.lat - a.lat) * KY;
  const da = { x: Math.sin(a.cap * D2R), y: Math.cos(a.cap * D2R) }, db = { x: Math.sin(b.cap * D2R), y: Math.cos(b.cap * D2R) };
  const det = da.x * -db.y - da.y * -db.x;
  const ecart = Math.abs((((a.cap - b.cap) % 360) + 540) % 360 - 180);
  if (ecart < 15 || ecart > 165 || Math.abs(det) < 1e-6) return null;
  const s = (bx * -db.y - by * -db.x) / det, t = (da.x * by - da.y * bx) / det;
  if (s <= 0 || t <= 0) return null;
  return { lat: a.lat + (s * da.y) / KY, lon: a.lon + (s * da.x) / kx };
}

export type Hauteur = { hauteurM: number; minM: number; maxM: number; methode: string; pied: { lat: number; lon: number } | null; detail: string[] };

function hauteurUne(d: number, hausse: number, errD: number, oeil: number) {
  const h = d * Math.tan(hausse * D2R) + oeil;
  const lo = Math.max(0, (d - errD) * Math.tan((hausse - 2) * D2R) + oeil), hi = (d + errD) * Math.tan((hausse + 2) * D2R) + oeil;
  return { h, lo, hi };
}

/** Hauteur à partir des visées (la plus récente en dernier). distMesuree : distance au pied de l'arbre pour la dernière visée. */
export function hauteurNid(visees: Visee[], nid: { lat: number; lon: number; err: number } | null, distMesuree: number | null = null, oeil = OEIL_M): Hauteur | null {
  const ok = visees.filter((v) => v.hausse > 3 && v.hausse < 85);
  if (!ok.length) return null;
  const det = (v: Visee, d: number) => `${Math.round(d)} m, hausse ${Math.round(v.hausse)}°`;
  if (distMesuree && distMesuree > 0) {
    const v = ok[ok.length - 1], r = hauteurUne(distMesuree, v.hausse, 0.5, oeil);
    return { hauteurM: r.h, minM: r.lo, maxM: r.hi, methode: 'distance mesurée au pied', pied: null, detail: [det(v, distMesuree)] };
  }
  for (let i = ok.length - 1; i > 0; i--) for (let j = i - 1; j >= 0; j--) {
    const p = croiserVisees(ok[j], ok[i]);
    if (!p) continue;
    const rs = [ok[j], ok[i]].map((v) => { const d = distM(v.lat, v.lon, p.lat, p.lon); return { v, d, ...hauteurUne(d, v.hausse, Math.max(3, d * 0.12) + (v.precision ?? 5) * 0.5, oeil) }; });
    return { hauteurM: (rs[0].h + rs[1].h) / 2, minM: Math.min(rs[0].lo, rs[1].lo), maxM: Math.max(rs[0].hi, rs[1].hi), methode: 'deux visées croisées', pied: p, detail: rs.map((r) => det(r.v, r.d)) };
  }
  if (nid) {
    const rs = ok.map((v) => { const d = distM(v.lat, v.lon, nid.lat, nid.lon); return { v, d, ...hauteurUne(d, v.hausse, Math.max(3, nid.err) + (v.precision ?? 5) * 0.5, oeil) }; }).filter((r) => r.d > 3);
    if (!rs.length) return null;
    const m = rs.reduce((a, r) => a + r.h, 0) / rs.length;
    return { hauteurM: m, minM: Math.min(...rs.map((r) => r.lo)), maxM: Math.max(...rs.map((r) => r.hi)), methode: 'position du nid (fiche)', pied: null, detail: rs.map((r) => det(r.v, r.d)) };
  }
  return null;
}

/** Écart entre la direction visée et celle du nid de la fiche (contrôle : la visée vise-t-elle le bon arbre ?). */
export const ecartAvecNid = (v: Visee, nid: { lat: number; lon: number }) => Math.abs((((v.cap - capDeg(v.lat, v.lon, nid.lat, nid.lon)) % 360) + 540) % 360 - 180);
