/** CBOR minimal (RFC 8949) pour le protocole SMP de mcumgr : entiers, octets, texte, tableaux, tables, booléens, null. */
export type Cbor = number | string | boolean | null | Uint8Array | Cbor[] | { [k: string]: Cbor };

function tete(maj: number, n: number, out: number[]) {
  if (n < 24) out.push((maj << 5) | n);
  else if (n < 0x100) out.push((maj << 5) | 24, n);
  else if (n < 0x10000) out.push((maj << 5) | 25, n >> 8, n & 0xff);
  else out.push((maj << 5) | 26, (n >>> 24) & 0xff, (n >>> 16) & 0xff, (n >>> 8) & 0xff, n & 0xff);
}
function utf8(s: string): number[] {
  const o: number[] = [];
  for (const ch of s) {
    const c = ch.codePointAt(0)!;
    if (c < 0x80) o.push(c);
    else if (c < 0x800) o.push(0xc0 | (c >> 6), 0x80 | (c & 63));
    else if (c < 0x10000) o.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
    else o.push(0xf0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
  }
  return o;
}
function deUtf8(b: Uint8Array): string {
  let s = '', i = 0;
  while (i < b.length) {
    const c = b[i++];
    if (c < 0x80) s += String.fromCharCode(c);
    else if (c < 0xe0) s += String.fromCharCode(((c & 31) << 6) | (b[i++] & 63));
    else if (c < 0xf0) { s += String.fromCharCode(((c & 15) << 12) | ((b[i] & 63) << 6) | (b[i + 1] & 63)); i += 2; }
    else { s += String.fromCodePoint(((c & 7) << 18) | ((b[i] & 63) << 12) | ((b[i + 1] & 63) << 6) | (b[i + 2] & 63)); i += 3; }
  }
  return s;
}

function enc(v: Cbor, out: number[]) {
  if (v === null) out.push(0xf6);
  else if (v === true) out.push(0xf5);
  else if (v === false) out.push(0xf4);
  else if (typeof v === 'number') { if (!Number.isInteger(v)) throw new Error('CBOR : réel non géré'); if (v >= 0) tete(0, v, out); else tete(1, -1 - v, out); }
  else if (typeof v === 'string') { const b = utf8(v); tete(3, b.length, out); for (const x of b) out.push(x); }
  else if (v instanceof Uint8Array) { tete(2, v.length, out); for (let i = 0; i < v.length; i++) out.push(v[i]); }
  else if (Array.isArray(v)) { tete(4, v.length, out); v.forEach((x) => enc(x, out)); }
  else { const k = Object.keys(v); tete(5, k.length, out); for (const kk of k) { enc(kk, out); enc(v[kk], out); } }
}
export function encoder(v: Cbor): Uint8Array { const out: number[] = []; enc(v, out); return Uint8Array.from(out); }

export function decoder(b: Uint8Array): Cbor {
  let i = 0;
  const lireN = (ai: number): number => {
    if (ai < 24) return ai;
    if (ai === 24) return b[i++];
    if (ai === 25) { const n = (b[i] << 8) | b[i + 1]; i += 2; return n; }
    if (ai === 26) { const n = ((b[i] << 24) >>> 0) + (b[i + 1] << 16) + (b[i + 2] << 8) + b[i + 3]; i += 4; return n; }
    if (ai === 27) { let n = 0; for (let k = 0; k < 8; k++) n = n * 256 + b[i++]; return n; }
    if (ai === 31) return -1; // longueur indéfinie
    throw new Error('CBOR invalide');
  };
  const un = (): Cbor => {
    const o = b[i++], maj = o >> 5, ai = o & 31;
    if (maj === 7) {
      if (ai === 20) return false; if (ai === 21) return true; if (ai === 22 || ai === 23) return null;
      if (ai === 26) { const v = new DataView(b.buffer, b.byteOffset + i, 4).getFloat32(0); i += 4; return v; }
      if (ai === 27) { const v = new DataView(b.buffer, b.byteOffset + i, 8).getFloat64(0); i += 8; return v; }
      throw new Error('CBOR : type simple inconnu');
    }
    const n = lireN(ai);
    switch (maj) {
      case 0: return n;
      case 1: return -1 - n;
      case 2: { const v = b.slice(i, i + n); i += n; return v; }
      case 3: { const v = deUtf8(b.slice(i, i + n)); i += n; return v; }
      case 4: { const a: Cbor[] = []; if (n < 0) { while (b[i] !== 0xff) a.push(un()); i++; } else for (let k = 0; k < n; k++) a.push(un()); return a; }
      case 5: { const m: { [k: string]: Cbor } = {}; const lire = () => { const k = un(); m[String(k)] = un(); };
        if (n < 0) { while (b[i] !== 0xff) lire(); i++; } else for (let k = 0; k < n; k++) lire(); return m; }
      default: throw new Error('CBOR : type non géré');
    }
  };
  return un();
}
