/** Paquet de mise à jour (dfu_application.zip produit par la compilation nRF Connect) : manifest.json + image signée. */
import { unzipSync, strFromU8 } from 'fflate';

export type Appareil = 'toit' | 'voie' | 'portatif' | 'nacelle' | 'sol';
export type Paquet = { appareil: Appareil; nomFichier: string; version: string; image: Uint8Array; date: number };

const NOMS: Record<string, Appareil> = { chef: 'toit', voie: 'voie', rx_v2: 'portatif', nacelle: 'nacelle', sol: 'sol' };
export const LIBELLES: Record<Appareil, string> = {
  toit: 'Récepteur de toit', voie: '4 voies du toit', portatif: 'Portatif', nacelle: 'Nacelle drone', sol: 'Station au sol du drone',
};
/** Nom Bluetooth à chercher pour chaque appareil (préfixe). Les voies et la nacelle ont un nom spécial en mode mise à jour. */
export const NOM_BLE: Record<Appareil, string[]> = {
  toit: ['TOIT-Frelons'], portatif: ['RX-Frelons'], voie: ['VOIE-AV-MAJ', 'VOIE-DR-MAJ', 'VOIE-AR-MAJ', 'VOIE-GA-MAJ'],
  nacelle: ['NACELLE-MAJ'], sol: ['SOL-MAJ'],
};

export function lirePaquet(zip: Uint8Array, nomFichier: string): Paquet {
  const f = unzipSync(zip);
  if (!f['manifest.json']) throw new Error('Ce fichier n\'est pas un paquet de mise à jour (manifest.json absent).');
  const m = JSON.parse(strFromU8(f['manifest.json']));
  const app = NOMS[m.name];
  if (!app) throw new Error(`Paquet inconnu : « ${m.name} »`);
  const fi = m.files?.[0];
  const image = fi && f[fi.file];
  if (!image) throw new Error('Image absente du paquet.');
  if (fi.size && fi.size !== image.length) throw new Error('Paquet abîmé (taille différente).');
  return { appareil: app, nomFichier, version: String(fi.version_MCUBOOT ?? '?').replace(/\+0$/, ''), image, date: (m.time ?? 0) * 1000 };
}
