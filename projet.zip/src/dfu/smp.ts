/**
 * Mise à jour des appareils par Bluetooth : protocole SMP de mcumgr (service 8D53DC1D…), comme l'appli nRF Connect Device Manager.
 * 1) envoi de l'image (groupe image, commande upload) par morceaux ; 2) image marquée « à essayer » ; 3) redémarrage.
 * MCUboot installe l'image au redémarrage ; le firmware la valide lui-même (maj_confirm). Si elle ne démarre pas, l'ancienne revient.
 */
import type { Device, Subscription } from 'react-native-ble-plx';
import { decoder, encoder, type Cbor } from './cbor';

export const SMP_SERVICE = '8d53dc1d-1db7-4cd3-868b-8a527460aa84';
const SMP_CHAR = 'da2e7828-fbce-4e01-ae9e-261174997c48';
const GRP_OS = 0, GRP_IMAGE = 1;

const b64 = (u: Uint8Array) => { let s = ''; for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]); return btoa(s); };
const deb64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const hex = (u: Uint8Array) => Array.from(u, (x) => x.toString(16).padStart(2, '0')).join('');

export type Image = { slot: number; version: string; hash: Uint8Array; active: boolean; confirmed: boolean; pending: boolean };

export class Smp {
  private seq = 0;
  private attente: { seq: number; ok: (r: Record<string, Cbor>) => void; ko: (e: Error) => void } | null = null;
  private tampon = new Uint8Array(0);
  private sub: Subscription | null = null;
  constructor(private device: Device, private mtu: number) {}

  async ouvrir() {
    await this.device.discoverAllServicesAndCharacteristics();
    this.sub = this.device.monitorCharacteristicForService(SMP_SERVICE, SMP_CHAR, (err, c) => {
      if (err) { this.attente?.ko(new Error(err.message)); this.attente = null; return; }
      if (c?.value) this.recevoir(deb64(c.value));
    });
  }
  fermer() { this.sub?.remove(); this.sub = null; }

  private recevoir(d: Uint8Array) {
    const t = new Uint8Array(this.tampon.length + d.length); t.set(this.tampon); t.set(d, this.tampon.length); this.tampon = t;
    if (this.tampon.length < 8) return;
    const len = (this.tampon[2] << 8) | this.tampon[3];
    if (this.tampon.length < 8 + len) return; // réponse en plusieurs notifications
    const seq = this.tampon[6];
    const corps = this.tampon.slice(8, 8 + len);
    this.tampon = this.tampon.slice(8 + len);
    if (!this.attente || this.attente.seq !== seq) return;
    const a = this.attente; this.attente = null;
    try {
      const r = decoder(corps) as Record<string, Cbor>;
      const err = r.err as Record<string, Cbor> | undefined;
      const rc = (r.rc as number | undefined) ?? (err?.rc as number | undefined) ?? 0;
      if (rc) a.ko(new Error(`refusé par l'appareil (code ${rc})`)); else a.ok(r);
    } catch (e) { a.ko(e as Error); }
  }

  private requete(op: number, groupe: number, id: number, corps: Cbor, delaiMs = 6000): Promise<Record<string, Cbor>> {
    const data = encoder(corps);
    const seq = (this.seq = (this.seq + 1) & 0xff);
    const paquet = new Uint8Array(8 + data.length);
    paquet.set([op, 0, data.length >> 8, data.length & 0xff, groupe >> 8, groupe & 0xff, seq, id]);
    paquet.set(data, 8);
    return new Promise((ok, ko) => {
      const minut = setTimeout(() => { if (this.attente?.seq === seq) { this.attente = null; ko(new Error('pas de réponse de l\'appareil')); } }, delaiMs);
      this.attente = { seq, ok: (r) => { clearTimeout(minut); ok(r); }, ko: (e) => { clearTimeout(minut); ko(e); } };
      this.device.writeCharacteristicWithoutResponseForService(SMP_SERVICE, SMP_CHAR, b64(paquet)).catch((e) => { clearTimeout(minut); this.attente = null; ko(e); });
    });
  }

  async images(): Promise<Image[]> {
    const r = await this.requete(0, GRP_IMAGE, 0, {});
    return ((r.images as Record<string, Cbor>[]) ?? []).map((i) => ({
      slot: Number(i.slot ?? 0), version: String(i.version ?? '?'), hash: (i.hash as Uint8Array) ?? new Uint8Array(),
      active: !!i.active, confirmed: !!i.confirmed, pending: !!i.pending,
    }));
  }

  /** Envoie l'image ; avancement(octets envoyés, total). */
  async envoyer(img: Uint8Array, avancement: (fait: number, total: number) => void, annule: () => boolean) {
    const morceau = Math.max(64, this.mtu - 3 - 8 - 28); // en-tête SMP + clés CBOR {off, data, len}
    let off = 0, essais = 0;
    while (off < img.length) {
      if (annule()) throw new Error('annulé');
      const data = img.slice(off, off + morceau);
      const corps: Record<string, Cbor> = off === 0 ? { image: 0, len: img.length, off: 0, data } : { off, data };
      try {
        const r = await this.requete(2, GRP_IMAGE, 1, corps);
        off = typeof r.off === 'number' ? r.off : off + data.length;
        essais = 0;
      } catch (e) {
        if (++essais > 4) throw e; // l'appareil reprend là où il en était : on renvoie le même morceau
      }
      avancement(Math.min(off, img.length), img.length);
    }
  }

  /** Marque la nouvelle image « à essayer » au prochain démarrage, puis redémarre l'appareil. */
  async installer(): Promise<void> {
    const imgs = await this.images();
    const nouvelle = imgs.find((i) => i.slot === 1);
    if (!nouvelle) throw new Error('image envoyée introuvable');
    await this.requete(2, GRP_IMAGE, 0, { hash: nouvelle.hash, confirm: false });
    await this.requete(2, GRP_OS, 5, {}).catch(() => {}); // l'appareil redémarre souvent avant de répondre
  }
}
export const hashTexte = (h: Uint8Array) => hex(h).slice(0, 12);
