/**
 * Portatif simulé : une personne à pied, à 170 m du nid du tag 7, avec l'antenne directive du portatif.
 * Il répond aux mêmes commandes que le vrai (tag, son, lna, sweep, fix, clr) et envoie les mêmes lignes JSON.
 * Entre deux tours, la personne marche vers la direction trouvée au dernier tour : c'est l'utilisateur qui la guide.
 */
import { D2R, KY, distM, kxOf } from '../calc/geo';

const NID_VRAI = { lat: 45.0483716, lon: 3.8839642 }; // tag 7 de la sortie simulée
const SWEEP_MAX = 180, FIX_MAX = 8;

export class PortatifSimule {
  private lat: number; private lon: number;
  private cap = 0; private dirMarche: number;
  private estN = 0; private estDebut = Date.now();
  private tag = 7; private son = true; private poche = false; private lna: 'auto' | 'on' | 'off' | 'att' = 'auto';
  private rssiF = -99; private trend = 0;
  private sweep: number[] | null = null; private couverture = 0; private sweepOk = false; private sweepBrg = 0; private prochaineTrame = 0;
  private fixes: { lat: number; lon: number; brg: number }[] = [];
  private nid: { lat: number; lon: number; err: number } | null = null;
  private t = 0; private dernEnvoi = 0; private trouveSignale = false;
  private minuterie: ReturnType<typeof setInterval> | null = null;

  constructor(private envoyer: (ligne: string) => void, private acceleration = () => 1) {
    // départ : 170 m à l'ouest-sud-ouest du nid (le nid est au cap 70°) ; la personne part dans une direction fausse de 35°
    const kx = kxOf(NID_VRAI.lat);
    this.lat = NID_VRAI.lat + (170 * Math.cos(250 * D2R)) / KY;
    this.lon = NID_VRAI.lon + (170 * Math.sin(250 * D2R)) / kx;
    this.dirMarche = 70 + 35;
    this.cap = this.dirMarche;
  }

  /** Pour les essais : impose la direction de marche. */
  marcherVers(cap: number) { this.dirMarche = cap; }

  demarrer() { this.arreter(); this.minuterie = setInterval(() => this.pas(0.1 * this.acceleration()), 100); }
  arreter() { if (this.minuterie) clearInterval(this.minuterie); this.minuterie = null; }

  commande(c: string) {
    const [cmd, arg] = c.trim().split(/\s+/);
    if (cmd === 'tag' && arg) this.tag = Number(arg);
    else if (cmd === 'son') this.son = arg === '1';
    else if (cmd === 'poche') this.poche = arg === '1';
    else if (cmd === 'etal' && arg) setTimeout(() => this.envoyer(JSON.stringify({ type: 'etal', id: Number(arg), p1m: -52, n: 20 })), 3000);
    else if (cmd === 'est') { this.estN = 0; this.estDebut = Date.now(); }
    else if (cmd === 'lna' && arg) this.lna = arg as typeof this.lna;
    else if (cmd === 'sweep') { this.sweep = new Array(SWEEP_MAX).fill(-128); this.couverture = 0; this.sweepOk = false; }
    else if (cmd === 'fix' && this.sweepOk) {
      if (this.fixes.length < FIX_MAX) this.fixes.push({ lat: this.lat, lon: this.lon, brg: this.sweepBrg });
      this.estimerNid();
    } else if (cmd === 'clr') { this.fixes = []; this.nid = null; this.sweepOk = false; this.sweep = null; }
  }

  /** Niveau reçu (dBm) selon la distance et l'angle entre l'antenne et le nid. */
  private niveau(): number {
    if (this.tag !== 7) return -128;
    const d = Math.max(distM(this.lat, this.lon, NID_VRAI.lat, NID_VRAI.lon), 1);
    const kx = kxOf(this.lat);
    const vers = Math.atan2((NID_VRAI.lon - this.lon) * kx, (NID_VRAI.lat - this.lat) * KY) / D2R;
    const ecart = (this.cap - vers) * D2R;
    const antenne = -14 * (1 - Math.cos(ecart)) / 2; // −14 dB vers l'arrière
    return -36 - 22 * Math.log10(d) + antenne + (Math.random() - 0.5) * 5;
  }

  private pas(dt: number) {
    this.t += dt;
    const dNid = distM(this.lat, this.lon, NID_VRAI.lat, NID_VRAI.lon);
    if (this.sweep && !this.sweepOk) {
      this.cap = (this.cap + 18 * dt) % 360; // un tour en 20 s
      this.couverture |= 2 ** Math.floor(this.cap / 10); // secteurs de 10° balayés par la boussole
      if (this.t >= this.prochaineTrame) { // le tag n'émet qu'une trame par seconde
        this.prochaineTrame = this.t + 1 + Math.random() * 0.06;
        const r = this.niveau();
        const sec = Math.floor(this.cap / 2) % SWEEP_MAX;
        if (r > -128 && r > this.sweep[sec]) this.sweep[sec] = Math.round(r);
      }
      this.resultatTour();
    } else if (dNid > 8) {
      // marche à 1,2 m/s dans la direction choisie, avec un peu de zigzag
      const v = 1.2 * dt, a = (this.dirMarche + Math.sin(this.t / 7) * 10) * D2R;
      this.lat += (v * Math.cos(a)) / KY;
      this.lon += (v * Math.sin(a)) / kxOf(this.lat);
      this.cap = (this.dirMarche + (Math.random() - 0.5) * 8 + 360) % 360;
    } else if (!this.trouveSignale) {
      this.trouveSignale = true; // arrivé : on reste sur place
    }
    const r = this.niveau();
    if (r > -128) {
      const ancien = this.rssiF;
      this.rssiF = this.rssiF + (r - this.rssiF) * Math.min(1, dt * 1.5);
      this.trend = this.trend * 0.9 + ((this.rssiF - ancien) / Math.max(dt, 0.01)) * 0.1;
    }
    if (this.t - this.dernEnvoi >= 1) { this.dernEnvoi = this.t; this.envoyerEtat(); }
  }

  private progression() { let n = 0; for (let i = 0; i < 36; i++) if (Math.floor(this.couverture / 2 ** i) % 2) n++; return Math.floor((n * 100) / 36); }

  /** Même calcul que nav_sweep_result() : tour complet (34 secteurs de 10° sur 36) et 8 trames au moins,
   *  puis moyenne pondérée cos² sur ±45°, évaluée tous les 2°. */
  private resultatTour() {
    const s = this.sweep!;
    const remplis = s.filter((x) => x !== -128).length;
    if (this.progression() < 94 || remplis < 8) return;
    // ajustement d'une sinusoïde niveau = A + B·cos(cap − φ) sur toutes les trames : φ = direction du maximum
    let m = 0; const pts: [number, number][] = [];
    for (let i = 0; i < SWEEP_MAX; i++) if (s[i] !== -128) { pts.push([(i * 2 + 1) * D2R, s[i]]); m += s[i]; }
    m /= pts.length;
    let sc = 0, ss = 0;
    for (const [a, r] of pts) { sc += (r - m) * Math.cos(a); ss += (r - m) * Math.sin(a); }
    const bi = Math.floor((((Math.atan2(ss, sc) / D2R) + 360) % 360) / 2);
    this.sweepBrg = bi * 2 + 1;
    this.sweepOk = true;
    this.dirMarche = this.sweepBrg; // la personne repart vers le maximum trouvé
  }

  /** Même calcul que nav_estimate_nest() : moindres carrés pondérés (incertitude latérale = distance × tan 10°, 10 m mini),
   *  nid rejeté s'il est derrière un relevé, précision = 2 × grand axe de l'ellipse d'incertitude. */
  private estimerNid() {
    const F = this.fixes;
    if (F.length < 2) return;
    const la0 = F[0].lat, lo0 = F[0].lon, kx = kxOf(la0);
    let x = 0, y = 0, a11 = 0, a12 = 0, a22 = 0, det = 0;
    for (let pass = 0; pass < 2; pass++) {
      let b1 = 0, b2 = 0; a11 = a12 = a22 = 0;
      for (const f of F) {
        const px = (f.lon - lo0) * kx, py = (f.lat - la0) * KY, th = f.brg * D2R;
        const nx = -Math.cos(th), ny = Math.sin(th);
        const sig = pass ? Math.max(Math.hypot(x - px, y - py) * 0.176, 10) : 10, w = 1 / (sig * sig);
        a11 += w * nx * nx; a12 += w * nx * ny; a22 += w * ny * ny;
        const c = nx * px + ny * py; b1 += w * nx * c; b2 += w * ny * c;
      }
      det = a11 * a22 - a12 * a12;
      if (det <= 0 || det < 1e-12 * (a11 + a22) ** 2) return;
      x = (a22 * b1 - a12 * b2) / det; y = (a11 * b2 - a12 * b1) / det;
    }
    for (const f of F) {
      const px = (f.lon - lo0) * kx, py = (f.lat - la0) * KY, th = f.brg * D2R;
      if ((x - px) * Math.sin(th) + (y - py) * Math.cos(th) < -30) return;
    }
    const tr = (a11 + a22) / det, dt = 1 / det;
    const lmax = tr / 2 + Math.sqrt(Math.max(tr * tr / 4 - dt, 0));
    this.nid = { lat: la0 + y / KY, lon: lo0 + x / kx, err: Math.min(2 * Math.sqrt(lmax), 9999) };
  }

  private envoyerEtat() {
    const entendu = this.tag === 7;
    const rf = this.lna === 'on' ? 0 : this.lna === 'off' ? 1 : this.lna === 'att' ? 2 : this.rssiF < -75 ? 0 : 1;
    this.envoyer(JSON.stringify({
      type: 'sw', act: this.sweep && !this.sweepOk ? 1 : 0, pct: this.sweep ? this.progression() : 0, ok: this.sweepOk ? 1 : 0,
      brg: this.sweepOk ? this.sweepBrg : -1, nfix: this.fixes.length,
    }));
    this.envoyer(JSON.stringify({
      type: 'st', tag: this.tag, rssi: entendu ? +this.rssiF.toFixed(1) : 0, raw: entendu ? Math.round(this.rssiF) : 0,
      trend: entendu ? +this.trend.toFixed(2) : 0, age: entendu ? 0.4 : 999, hdg: Math.round(this.cap), fix: 1,
      lat: +this.lat.toFixed(6), lon: +this.lon.toFixed(6), sats: 9, bat: 82, lna: rf,
      poche: this.poche ? 1 : 0,
      etat: (Date.now() / 60000) % 10 < 7 ? 0x80 | 61 : 63, // tag 4 : au nid 7 min (21 °C), en chasse 3 min (23 °C)
    }));
    if (this.tag !== 12) this.envoyer(JSON.stringify({ type: 'tag', id: 12, rssi: -97, age: 40, lat: 45.0521, lon: 3.8795 }));
    if (this.tag !== 7) this.envoyer(JSON.stringify({ type: 'tag', id: 7, rssi: Math.round(this.rssiF), age: 0, lat: this.lat, lon: this.lon }));
    // nid estimé en marchant : l'incertitude diminue avec le temps (simulation)
    if (this.tag === 7 && ++this.estN % 5 === 0) {
      const s = (Date.now() - this.estDebut) / 1000, err = Math.max(18, 160 - s * 4), marche = Math.min(400, s * 1.2);
      this.envoyer(JSON.stringify({ type: 'est', tag: 7, lat: +(NID_VRAI.lat + err / 4 / 111320).toFixed(6), lon: +(NID_VRAI.lon - err / 5 / 78000).toFixed(6), err: Math.round(err), ok: err < 60 && marche >= 30 ? 1 : 0, n: Math.round(s), marche: Math.round(marche), p1m: -52 }));
    }
    if (this.nid) this.envoyer(JSON.stringify({ type: 'nest', lat: +this.nid.lat.toFixed(6), lon: +this.nid.lon.toFixed(6), err: Math.round(this.nid.err) }));
  }
}
